// Isolated-world client for the main-world Ruffle bridge installed by
// `public/dirplayer-ruffle-bridge-host.js`. Provides a Promise-based
// API that mirrors the subset of the Ruffle player surface used by
// `flashPlayerManager.ts`.
//
// Why this exists: Chrome MV3 isolated worlds expose a null
// `customElements`, so Ruffle (which calls `customElements.define`
// during element registration) cannot run in the same world as
// dirplayer's content script. We register Ruffle in the main world
// instead and ferry method/property calls across via DOM CustomEvents.
//
// Why CustomEvents instead of postMessage: the Wayback Machine's
// `wombat.js` overwrites `window.postMessage` in the main world to
// sanitize origins and rewrite URLs, which silently drops our bridge
// traffic. DOM events propagate through the shared document and are
// not intercepted by wombat.

const REQ_EVENT = 'dirplayer-ruffle-bridge-request';
const RES_EVENT = 'dirplayer-ruffle-bridge-response';
const EVT_EVENT = 'dirplayer-ruffle-bridge-event';

let nextRequest = 1;
const pendingRequests = new Map<
  number,
  { resolve: (v: unknown) => void; reject: (e: Error) => void }
>();

type BridgeEventHandler = (eventName: string, detail: unknown) => void;
const eventHandlers = new Map<string, Set<BridgeEventHandler>>();

window.addEventListener(RES_EVENT, (ev) => {
  const m: any = (ev as CustomEvent).detail;
  if (!m) return;
  const pending = pendingRequests.get(m.requestId);
  if (!pending) return;
  pendingRequests.delete(m.requestId);
  if (m.error) pending.reject(new Error(m.error));
  else pending.resolve(m.result);
});

window.addEventListener(EVT_EVENT, (ev) => {
  const m: any = (ev as CustomEvent).detail;
  if (!m) return;
  const handlers = eventHandlers.get(m.playerId);
  if (handlers) {
    handlers.forEach((h) => {
      try { h(m.eventName, m.detail); } catch (e) { /* ignore */ }
    });
  }
});

function bridgeCall<T = unknown>(payload: Record<string, unknown>): Promise<T> {
  const requestId = nextRequest++;
  return new Promise<T>((resolve, reject) => {
    pendingRequests.set(requestId, {
      resolve: (v) => resolve(v as T),
      reject,
    });
    window.dispatchEvent(new CustomEvent(REQ_EVENT, {
      detail: { requestId, ...payload },
    }));
  });
}

/** True when the main-world bridge host is reachable AND has Ruffle ready. */
export async function isBridgeReady(): Promise<boolean> {
  try {
    return await bridgeCall<boolean>({ method: 'isReady' });
  } catch {
    return false;
  }
}

/**
 * Wait for the main-world bridge to report Ruffle as loaded. Polls a
 * handful of times because the bridge host script may still be parsing
 * when the first request fires.
 */
export async function waitForBridge(timeoutMs = 5000): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await isBridgeReady()) return true;
    await new Promise((r) => setTimeout(r, 50));
  }
  return false;
}

export async function bridgeCreatePlayer(): Promise<string> {
  const { playerId } = await bridgeCall<{ playerId: string }>({
    method: 'createPlayer',
  });
  return playerId;
}

export function bridgeCallMethod(
  playerId: string,
  methodName: string,
  args: unknown[] = [],
): Promise<unknown> {
  return bridgeCall({ method: 'callMethod', playerId, methodName, args });
}

export function bridgeGetProp(
  playerId: string,
  propName: string,
): Promise<unknown> {
  return bridgeCall({ method: 'getProp', playerId, propName });
}

export function bridgeSetProp(
  playerId: string,
  propName: string,
  value: unknown,
): Promise<void> {
  return bridgeCall({ method: 'setProp', playerId, propName, value });
}

export function bridgeDestroyPlayer(playerId: string): Promise<void> {
  return bridgeCall({ method: 'destroyPlayer', playerId });
}

/**
 * Ask the main-world host to register its own Flash→Director callback handlers
 * (getURL "event:"/"lingo:" and fscommand) on the player and forward each
 * invocation back as a bridge event (subscribe via bridgeOnEvent). Needed
 * because the callback functions themselves can't cross the world boundary.
 */
export function bridgeRegisterCallbackForwarders(playerId: string): Promise<void> {
  return bridgeCall({ method: 'registerCallbackForwarders', playerId });
}

// ---------------------------------------------------------------------------
// Synchronous bridge — for the handful of Ruffle calls Lingo consumes INLINE
// (GetVariable / SetVariable / CallFunction). The Promise transport above can't
// satisfy a synchronous Lingo read, but `dispatchEvent` runs listeners
// synchronously, so the main-world host answers the request DURING dispatch and
// writes the result onto a shared, `dirplayer_`-namespaced hidden DOM node. Plain
// DOM text crosses the isolated↔main boundary, is untouched by wombat (which only
// wraps navigation / postMessage), and is invisible to stock Ruffle (its own
// surface is un-prefixed). We read the node back the instant `dispatchEvent`
// returns. No new event name, no postMessage, no un-namespaced global.
const SYNC_NODE_ID = '__dirplayer_ruffle_sync_channel';
let syncNode: HTMLElement | null = null;
let nextSyncId = 1;

function ensureSyncNode(): HTMLElement {
  if (syncNode && syncNode.isConnected) return syncNode;
  let el = document.getElementById(SYNC_NODE_ID);
  if (!el) {
    el = document.createElement('div');
    el.id = SYNC_NODE_ID;
    el.style.display = 'none';
    (document.documentElement || document.body).appendChild(el);
  }
  syncNode = el as HTMLElement;
  return syncNode;
}

/**
 * Synchronous bridge call. Dispatches the (already-namespaced) request event —
 * whose listener the main-world host runs synchronously — and reads the result
 * the host wrote to the shared node before `dispatchEvent` returned. Returns
 * `undefined` if the host didn't answer (bridge not ready, method not sync),
 * which callers treat like a null Flash read. Throws if the host reported an
 * error for the call.
 */
function bridgeCallSync(payload: Record<string, unknown>): unknown {
  const node = ensureSyncNode();
  const syncId = nextSyncId++;
  node.textContent = '';
  window.dispatchEvent(new CustomEvent(REQ_EVENT, {
    detail: { sync: true, syncId, ...payload },
  }));
  const raw = node.textContent;
  if (!raw) return undefined;
  let msg: { syncId?: number; result?: unknown; error?: string | null };
  try {
    msg = JSON.parse(raw);
  } catch {
    return undefined;
  }
  if (!msg || msg.syncId !== syncId) return undefined;
  if (msg.error) throw new Error(msg.error);
  return msg.result;
}

export function bridgeGetVariableSync(
  playerId: string,
  path: string,
): string | null {
  const r = bridgeCallSync({ method: 'getVariableSync', playerId, args: [path] });
  if (r == null) return null;
  // Only PRIMITIVES are real data here. A Flash variable holding an object
  // (`getVariable(sprite, "_level0", 0)` — the standard idiom for grabbing a
  // SWF's root timeline) cannot cross the world boundary: the host serialises
  // sync results with JSON.stringify into a DOM node, so a MovieClip arrives as
  // `{}`. Coercing that with String() produced "[object Object]", which the Rust
  // getVariable handler then returned as the variable's VALUE — so the object
  // form silently became a string and the next call on it died with
  // "No handler gotoAndStop for string datum" (Agent Free Ride's OffGame
  // loading bar). Extension-only: the dev UI calls Ruffle's GetVariable
  // directly, gets a non-string back, and falls through to the object handle.
  //
  // Returning null lets that fallback run here too. It matches the documented
  // contract — "If the value of the Flash variable is an object reference, you
  // must set the returnValueOrReference parameter to FALSE ... If it is
  // returned as a string, the string will not be a valid object reference."
  // (Director 11.5 Scripting Dictionary, getVariable().)
  if (typeof r === 'object') return null;
  return String(r);
}

export function bridgeSetVariableSync(
  playerId: string,
  path: string,
  value: string,
): boolean {
  const r = bridgeCallSync({
    method: 'setVariableSync',
    playerId,
    args: [path, value],
  });
  return !!r;
}

/**
 * Synchronous generic method call on the main-world player (e.g.
 * `dirplayer_hitTest`, which must return its classification immediately).
 */
export function bridgeCallMethodSync(
  playerId: string,
  method: string,
  args: unknown[],
): unknown {
  return bridgeCallSync({ method: 'callMethodSync', playerId, args: [method, args] });
}

export function bridgeCallFunctionSync(
  playerId: string,
  path: string,
  args: unknown[],
): unknown {
  // Return the RAW value (boolean / number / string / object / null), NOT a
  // stringified form. dirplayer's ruffle_call_function extern receives this as a
  // JsValue and branches on its type — AS `true` must stay a boolean so it maps
  // to Lingo Int(1) (DGS `includeIsLoaded() = 1`); `String(true)` = "true" would
  // become Datum::String and break the comparison. The bridge's JSON round-trip
  // already preserves JSON types.
  return bridgeCallSync({
    method: 'callFunctionSync',
    playerId,
    args: [path, args],
  });
}

/**
 * Find the DOM element corresponding to a bridge-managed player. The
 * main-world host stamps `data-dirplayer-bridge-id` on each player so
 * the isolated world can locate it via querySelector.
 */
export function bridgeFindElement(playerId: string): HTMLElement | null {
  return document.querySelector(
    `[data-dirplayer-bridge-id="${playerId}"]`,
  );
}

/**
 * Subscribe to events forwarded from the main-world player. Pass the
 * playerId returned from `bridgeCreatePlayer`. Returns an unsubscribe
 * function.
 */
export function bridgeOnEvent(
  playerId: string,
  handler: BridgeEventHandler,
): () => void {
  let set = eventHandlers.get(playerId);
  if (!set) {
    set = new Set();
    eventHandlers.set(playerId, set);
  }
  set.add(handler);
  return () => {
    const s = eventHandlers.get(playerId);
    if (s) {
      s.delete(handler);
      if (s.size === 0) eventHandlers.delete(playerId);
    }
  };
}

/**
 * True when this isolated world cannot use Ruffle directly because it
 * has no working CustomElementRegistry. Detected by inspecting
 * `window.customElements` — Chrome MV3 content-script isolated worlds
 * leave it null even on plain pages, while page-level main-world
 * polyfills always have it.
 *
 * Standalone (page-loaded polyfill) skips the bridge entirely; the
 * extension's content script always uses it.
 */
export function isBridgeRequired(): boolean {
  return (window as { customElements?: unknown }).customElements == null;
}
