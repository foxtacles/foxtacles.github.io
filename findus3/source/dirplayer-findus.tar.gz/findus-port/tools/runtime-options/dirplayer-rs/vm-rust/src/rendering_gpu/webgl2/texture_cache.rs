//! Texture caching for WebGL2 renderer
//!
//! Caches bitmap textures on the GPU to avoid re-uploading
//! unchanged bitmaps every frame.

use std::collections::HashMap;
use web_sys::{WebGl2RenderingContext, WebGlTexture};

use crate::player::cast_lib::CastMemberRef;
use crate::player::sprite::ColorRef;
use crate::player::symbols::builtin::BuiltInSymbol;

/// Cache key that includes member reference, ink mode, and colorize parameters
/// Different ink modes may need different textures because the matte mask computation
/// differs. For example, 32-bit bitmaps with ink 8 (Matte) need flood-fill matte computation,
/// but with other inks they use the bitmap's embedded alpha.
///
/// Colorize (foreColor/backColor) is now included because Director's colorize feature
/// remaps palette indices to interpolate between fore and back colors.
///
/// For ink 8 (Matte), the sprite's bgColor affects the matte computation for indexed bitmaps.
/// Canvas2D uses the sprite's bgColor as the background color for flood-fill matte computation,
/// so different sprites using the same bitmap with different bgColors need different textures.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct TextureCacheKey {
    pub member_ref: CastMemberRef,
    /// Backing bitmap (BitmapRef.id, the slot in bitmap_manager). For most
    /// members `member_ref` already pins one bitmap, but a single Flash
    /// cast member can have N independent per-sprite bitmaps when several
    /// sprites share it (storyscramble's 3 story tiles each get their own
    /// `flash_frame_buffers[sprite]` even though they all reference cast
    /// 2:1). Without this field the cache collapses them and renders the
    /// first uploaded version for every sprite.
    pub image_ref: u32,
    /// Ink mode - affects whether matte computation is applied (especially for 32-bit bitmaps)
    pub ink: i32,
    /// Colorize parameters (only used when has_fore_color or has_back_color is true)
    /// Format: (has_fore, has_back, fg_r, fg_g, fg_b, bg_r, bg_g, bg_b)
    /// Using Option to avoid cache misses when colorize isn't used
    pub colorize: Option<(bool, bool, u8, u8, u8, u8, u8, u8)>,
    /// Sprite's bgColor for ink 8 indexed bitmaps (affects matte computation)
    /// Only included when ink==8 and bitmap is indexed (depth <= 8)
    /// Using Option to avoid cache misses when not applicable
    pub sprite_bg_color: Option<(u8, u8, u8)>,
}

/// Cached texture information
pub struct CachedTexture {
    /// WebGL texture handle
    pub texture: WebGlTexture,
    /// Texture width
    pub width: u32,
    /// Texture height
    pub height: u32,
    /// Version counter for invalidation
    pub version: u32,
    /// Last frame this texture was used
    pub last_used_frame: u64,
    /// GL context, kept so `Drop` can free the GPU texture. Dropping a
    /// `WebGlTexture` handle does NOT call `gl.deleteTexture`, so without this
    /// every evicted / replaced / invalidated cache entry would leak its GPU
    /// texture (memory climbs on animation- or text-heavy movies).
    gl: WebGl2RenderingContext,
}

impl Drop for CachedTexture {
    fn drop(&mut self) {
        self.gl.delete_texture(Some(&self.texture));
    }
}

/// LRU texture cache for bitmap textures
pub struct TextureCache {
    /// Cached textures by member reference + bgColor
    textures: HashMap<TextureCacheKey, CachedTexture>,
    /// Maximum number of textures to cache
    max_size: usize,
    /// Current frame counter for LRU tracking
    current_frame: u64,
}

impl TextureCache {
    /// Create a new texture cache with default max size
    pub fn new() -> Self {
        Self::with_max_size(256)
    }

    /// Create a new texture cache with specified max size
    pub fn with_max_size(max_size: usize) -> Self {
        Self {
            textures: HashMap::new(),
            max_size,
            current_frame: 0,
        }
    }

    /// Get a cached texture for a cache key (member + bgColor)
    pub fn get(&mut self, key: &TextureCacheKey) -> Option<&CachedTexture> {
        if let Some(cached) = self.textures.get_mut(key) {
            cached.last_used_frame = self.current_frame;
            Some(cached)
        } else {
            None
        }
    }

    /// Insert or update a texture in the cache. `gl` is stored so the entry can
    /// free its GPU texture on eviction/replacement via `Drop`.
    pub fn insert(
        &mut self,
        gl: &WebGl2RenderingContext,
        key: TextureCacheKey,
        texture: WebGlTexture,
        width: u32,
        height: u32,
        version: u32,
    ) {
        // Evict old entries if cache is full
        if self.textures.len() >= self.max_size {
            self.evict_lru();
        }

        // A same-key insert replaces (and drops → deletes) the previous entry.
        self.textures.insert(
            key,
            CachedTexture {
                texture,
                width,
                height,
                version,
                last_used_frame: self.current_frame,
                gl: gl.clone(),
            },
        );
    }

    /// Check if a texture needs updating (version changed)
    pub fn needs_update(&self, key: &TextureCacheKey, version: u32) -> bool {
        match self.textures.get(key) {
            Some(cached) => cached.version != version,
            None => true,
        }
    }

    /// Remove a texture from the cache
    pub fn remove(&mut self, key: &TextureCacheKey) -> Option<CachedTexture> {
        self.textures.remove(key)
    }

    /// Drop every entry whose key references the given cast member. Used when a
    /// member is erased or replaced so a subsequent allocation at the same slot
    /// number doesn't hit a stale texture.
    pub fn invalidate_for_member(&mut self, member_ref: &CastMemberRef) {
        self.textures.retain(|k, _| k.member_ref != *member_ref);
    }

    /// Clear all cached textures
    pub fn clear(&mut self) {
        self.textures.clear();
    }

    /// Advance to next frame (for LRU tracking)
    pub fn next_frame(&mut self) {
        self.current_frame += 1;
    }

    /// Get number of cached textures
    pub fn len(&self) -> usize {
        self.textures.len()
    }

    /// Check if cache is empty
    pub fn is_empty(&self) -> bool {
        self.textures.is_empty()
    }

    /// Check if a key exists in the cache (without updating last_used_frame)
    pub fn has(&self, key: &TextureCacheKey) -> bool {
        self.textures.contains_key(key)
    }

    /// Evict least recently used texture
    fn evict_lru(&mut self) {
        let oldest_key = self
            .textures
            .iter()
            .min_by_key(|(_, cached)| cached.last_used_frame)
            .map(|(key, _)| key.clone());

        if let Some(key) = oldest_key {
            self.textures.remove(&key);
        }
    }
}

impl Default for TextureCache {
    fn default() -> Self {
        Self::new()
    }
}

/// Cache key for rendered text textures
/// Unlike bitmap textures which are cached by member_ref, text textures need to be
/// keyed by all the parameters that affect the rendered appearance.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct RenderedTextCacheKey {
    /// The member reference (for Field/Text/Font member)
    pub member_ref: CastMemberRef,
    /// The actual text content (hash or truncated string for memory efficiency)
    pub text_hash: u64,
    /// Hash of styled spans (if any) - 0 if no styled spans
    pub styled_spans_hash: u64,
    /// Hash of alignment and word_wrap settings
    pub settings_hash: u64,
    /// Ink mode
    pub ink: i32,
    /// Blend value
    pub blend: i32,
    /// Foreground color
    pub fg_color: ColorRef,
    /// Background color
    pub bg_color: ColorRef,
    /// Whether the field has keyboard focus (affects cursor rendering)
    pub has_focus: bool,
    /// Caret/selection state. Hashed into the cache key so the texture
    /// invalidates as the user moves the caret or extends the selection.
    /// `caret_blink_on` toggles every 500ms while focused — at most two
    /// cached entries per field rotate.
    pub sel_start: i32,
    pub sel_end: i32,
    pub caret_blink_on: bool,
    /// Texture width (needed because sprite rect can change independently of text)
    pub width: u32,
    /// Texture height
    pub height: u32,
    /// True when a skew or rotation transform is active on the sprite. The
    /// rasterizer pads the bitmap to the authored height instead of
    /// shrinking to text content (or fill-scaling line spacing), so the
    /// texture maps 1:1 onto the authored sprite_rect that gets sheared
    /// into a parallelogram. Distinct cache entry from the flat-display
    /// path so the same member can have both a tight texture (for ordinary
    /// scenes) and a padded texture (when a sprite happens to be tilted).
    ///
    /// NOTE: also set for box_type_locked (#fixed/#scroll/#limit) and
    /// multi_par_adjust_locked (#adjust + breaks) to suppress the
    /// measure-shrink path. Use `transform_active` (below) when the
    /// distinction matters — e.g. upload_height's no-trim only applies
    /// to true rotation/skew transforms.
    pub keep_authored_height: bool,
    /// True only for actual skew/rotation transforms. Subset of
    /// `keep_authored_height`.
    pub transform_active: bool,
}

impl RenderedTextCacheKey {
    /// Create a new cache key with a hash of the text content
    pub fn new(
        member_ref: CastMemberRef,
        text: &str,
        ink: i32,
        blend: i32,
        fg_color: ColorRef,
        bg_color: ColorRef,
        width: u32,
        height: u32,
    ) -> Self {
        Self::new_with_styled_spans(
            member_ref,
            text,
            None,
            ink,
            blend,
            fg_color,
            bg_color,
            false,
            0,
            0,
            false,
            width,
            height,
            BuiltInSymbol::Left,
            false,
            "",
            0,
            None,
            0,
            0,
        )
    }

    /// Create a new cache key with focus state (for Field members with cursor)
    pub fn new_with_focus(
        member_ref: CastMemberRef,
        text: &str,
        ink: i32,
        blend: i32,
        fg_color: ColorRef,
        bg_color: ColorRef,
        has_focus: bool,
        sel_start: i32,
        sel_end: i32,
        caret_blink_on: bool,
        width: u32,
        height: u32,
        alignment: BuiltInSymbol,
        word_wrap: bool,
        font_name: &str,
        font_size: u16,
        font_style: Option<u8>,
        line_spacing: u16,
        top_spacing: i16,
    ) -> Self {
        Self::new_with_styled_spans(
            member_ref,
            text,
            None,
            ink,
            blend,
            fg_color,
            bg_color,
            has_focus,
            sel_start,
            sel_end,
            caret_blink_on,
            width,
            height,
            alignment,
            word_wrap,
            font_name,
            font_size,
            font_style,
            line_spacing,
            top_spacing,
        )
    }

    /// Create a new cache key with styled spans (for HTML-styled text)
    pub fn new_with_styled_spans(
        member_ref: CastMemberRef,
        text: &str,
        styled_spans: Option<&[crate::player::handlers::datum_handlers::cast_member::font::StyledSpan]>,
        ink: i32,
        blend: i32,
        fg_color: ColorRef,
        bg_color: ColorRef,
        has_focus: bool,
        sel_start: i32,
        sel_end: i32,
        caret_blink_on: bool,
        width: u32,
        height: u32,
        alignment: BuiltInSymbol,
        word_wrap: bool,
        font_name: &str,
        font_size: u16,
        font_style: Option<u8>,
        line_spacing: u16,
        top_spacing: i16,
    ) -> Self {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let mut hasher = DefaultHasher::new();
        text.hash(&mut hasher);
        let text_hash = hasher.finish();

        // Hash styled spans if present
        let styled_spans_hash = if let Some(spans) = styled_spans {
            let mut span_hasher = DefaultHasher::new();
            for span in spans {
                span.text.hash(&mut span_hasher);
                // Hash style properties
                span.style.font_face.hash(&mut span_hasher);
                span.style.font_size.hash(&mut span_hasher);
                span.style.color.hash(&mut span_hasher);
                span.style.bg_color.hash(&mut span_hasher);
                span.style.bold.hash(&mut span_hasher);
                span.style.italic.hash(&mut span_hasher);
                span.style.underline.hash(&mut span_hasher);
            }
            span_hasher.finish()
        } else {
            0
        };

        // Hash alignment, word_wrap, and font settings
        let mut settings_hasher = DefaultHasher::new();
        font_name.hash(&mut settings_hasher);
        alignment.hash(&mut settings_hasher);
        word_wrap.hash(&mut settings_hasher);
        font_name.hash(&mut settings_hasher);
        font_size.hash(&mut settings_hasher);
        font_style.hash(&mut settings_hasher);
        line_spacing.hash(&mut settings_hasher);
        top_spacing.hash(&mut settings_hasher);
        let settings_hash = settings_hasher.finish();

        Self {
            member_ref,
            text_hash,
            styled_spans_hash,
            settings_hash,
            ink,
            blend,
            fg_color,
            bg_color,
            has_focus,
            sel_start,
            sel_end,
            caret_blink_on,
            width,
            height,
            // Caller flips this after construction when the sprite has a
            // skew/rotation transform so the cache distinguishes the
            // authored-height-padded texture from the tight one.
            keep_authored_height: false,
            transform_active: false,
        }
    }
}

/// Cached rendered text texture information
pub struct CachedRenderedText {
    /// WebGL texture handle
    pub texture: WebGlTexture,
    /// Texture width
    pub width: u32,
    /// Texture height
    pub height: u32,
    /// Last frame this texture was used
    pub last_used_frame: u64,
    /// GL context, kept so `Drop` frees the GPU texture (see `CachedTexture`).
    gl: WebGl2RenderingContext,
}

impl Drop for CachedRenderedText {
    fn drop(&mut self) {
        self.gl.delete_texture(Some(&self.texture));
    }
}

/// LRU texture cache for rendered text textures
pub struct RenderedTextCache {
    /// Cached textures by text cache key
    textures: HashMap<RenderedTextCacheKey, CachedRenderedText>,
    /// Maximum number of textures to cache
    max_size: usize,
    /// Current frame counter for LRU tracking
    current_frame: u64,
}

impl RenderedTextCache {
    /// Create a new rendered text cache with default max size
    pub fn new() -> Self {
        Self::with_max_size(128)
    }

    /// Create a new rendered text cache with specified max size
    pub fn with_max_size(max_size: usize) -> Self {
        Self {
            textures: HashMap::new(),
            max_size,
            current_frame: 0,
        }
    }

    /// Get a cached texture
    pub fn get(&mut self, key: &RenderedTextCacheKey) -> Option<&CachedRenderedText> {
        if let Some(cached) = self.textures.get_mut(key) {
            cached.last_used_frame = self.current_frame;
            Some(cached)
        } else {
            None
        }
    }

    /// Insert a texture into the cache. `gl` is stored so the entry frees its
    /// GPU texture on eviction/replacement via `Drop`.
    pub fn insert(
        &mut self,
        gl: &WebGl2RenderingContext,
        key: RenderedTextCacheKey,
        texture: WebGlTexture,
        width: u32,
        height: u32,
    ) {
        // Evict old entries if cache is full
        if self.textures.len() >= self.max_size {
            self.evict_lru();
        }

        self.textures.insert(
            key,
            CachedRenderedText {
                texture,
                width,
                height,
                last_used_frame: self.current_frame,
                gl: gl.clone(),
            },
        );
    }

    /// Advance to next frame (for LRU tracking)
    pub fn next_frame(&mut self) {
        self.current_frame += 1;
    }

    /// Drop every entry whose key references the given cast member.
    pub fn invalidate_for_member(&mut self, member_ref: &CastMemberRef) {
        self.textures.retain(|k, _| k.member_ref != *member_ref);
    }

    /// Clear all cached textures
    pub fn clear(&mut self) {
        self.textures.clear();
    }

    /// Evict least recently used texture
    fn evict_lru(&mut self) {
        let oldest_key = self
            .textures
            .iter()
            .min_by_key(|(_, cached)| cached.last_used_frame)
            .map(|(key, _)| key.clone());

        if let Some(key) = oldest_key {
            self.textures.remove(&key);
        }
    }
}

impl Default for RenderedTextCache {
    fn default() -> Self {
        Self::new()
    }
}
