use wasm_bindgen::prelude::*;
use wasm_bindgen_futures::JsFuture;

use crate::player::{
    commands::PlayerVMCommand,
    reserve_player_mut, reserve_player_ref,
    PLAYER_OPT,
};
use crate::player::testing_shared::{TestHarness, SnapshotOutput, SpriteQuery};

/// Browser test harness that lets the real player runtime drive the frame loop.
/// Instead of calling `run_single_frame` directly, we let `init_player()`'s
/// loops run normally and interact via polling and input events.
pub struct BrowserTestPlayer {}

impl BrowserTestPlayer {
    pub async fn new() -> Self {
        // `preserve_external_params: false` — this is the per-TEST boundary, and
        // one movie's external params are never right for the next movie.
        Self::reset_player_with(false).await;
        BrowserTestPlayer {}
    }

    /// Fully tear down the current dirplayer and allocate a fresh one via
    /// `DirPlayer::new()`. Called both by `BrowserTestPlayer::new()` (per-test
    /// setup) and by `load_movie()` (per-movie setup) so every movie load
    /// starts from a clean state — no leaked scopes, globals, timeouts, or
    /// cached sprite textures from a previously loaded movie.
    /// Call the JS bridge's `resolveAndLoadMovieXtras()` (exposed on `window`
    /// by the runner template) and await it. No-op when the hook is absent.
    async fn resolve_movie_xtras() {
        let Some(window) = web_sys::window() else { return };
        let Ok(hook) = js_sys::Reflect::get(&window, &JsValue::from_str("dirplayer_resolveAndLoadMovieXtras")) else { return };
        let Ok(func) = hook.dyn_into::<js_sys::Function>() else { return };
        let Ok(ret) = func.call0(&window) else { return };
        if let Ok(promise) = ret.dyn_into::<js_sys::Promise>() {
            let _ = JsFuture::from(promise).await;
        }
    }

    async fn reset_player() {
        Self::reset_player_with(true).await
    }

    /// `preserve_external_params` — carry the current player's external params
    /// onto the fresh one. TRUE for the per-movie reset inside `load_movie`:
    /// tests call `cfg.apply_external_params()` BEFORE `load_movie`, so
    /// discarding them there would leave the new player without the
    /// credentials/args the test configured. FALSE at the per-test boundary
    /// (`BrowserTestPlayer::new`), so a movie's params cannot reach the next
    /// test — see the note there.
    async fn reset_player_with(preserve_external_params: bool) {
        let preserved_external_params = if preserve_external_params {
            unsafe { PLAYER_OPT.as_ref().map(|p| p.external_params.clone()).unwrap_or_default() }
        } else {
            Default::default()
        };
        // The projector's `--do` / `--doBefore` / `--go` payloads travel with
        // the external params, and for the same reason: a test calls
        // `cfg.apply_startup_do()` BEFORE `load_movie`, and this reset happens
        // INSIDE it. Dropping them here left `startup_do` unset by the time the
        // movie-init sequence looked for it, so the seeded member kept the
        // placeholder the .dcr shipped with and the wrapper redirected nowhere.
        let preserved_startup = if preserve_external_params {
            unsafe {
                PLAYER_OPT
                    .as_ref()
                    .map(|p| (p.startup_do.clone(), p.startup_do_before.clone(), p.startup_go))
                    .unwrap_or_default()
            }
        } else {
            Default::default()
        };

        // Stop the current movie and clear all timeouts before resetting.
        // Stop every playing sound too: the old player is about to be dropped,
        // but dropping an `Rc<AudioBufferSourceNode>` does NOT halt the node —
        // the AudioContext keeps it running until it ends, so a looping sound
        // from the previous movie would keep playing over the next test.
        unsafe {
            if let Some(player) = PLAYER_OPT.as_mut() {
                player.stop();
                player.sound_manager.stop_all();
                player.timeout_manager.clear();
                // Drop the outgoing movie's cast bitmaps up front (they're
                // anchored, so nothing else frees them until the whole player is
                // dropped below). Doing it here, before the ~120-frame drain and
                // before the new player is allocated, releases a bitmap-heavy
                // movie's pixels (Infestation ~10 MB+ decoded) early so it doesn't
                // overlap the incoming movie's load — cutting the reset peak.
                player.bitmap_manager.clear_movie_bitmaps();
            }
        }
        crate::js_api::JsApi::dispatch_clear_timeouts();
        // Tear down every Ruffle/Flash instance from the previous movie so its
        // per-frame capture RAF loop, Ruffle player, and SWF audio don't leak
        // across the movie switch (the per-sprite unload path only fires for
        // sprites the frame actually changed).
        crate::js_api::JsApi::dispatch_flash_reset_all();
        // JS-Lingo runtimes live in a thread_local, so dropping the old player
        // below does NOT free them — clear them explicitly.
        crate::player::js_lingo_loader::clear_all_runtimes();

        // Bump the generation so any in-flight loops from the previous movie
        // detect staleness on their next await and exit. Then drain: wait
        // until no Lingo handler is still mid-execution on the OLD player.
        // Without this, a handler that's at an async yield point (e.g. waiting
        // on a frame tick) would resume AFTER we swap PLAYER_OPT and mutate
        // the new player's scope stack, wrapping scope_count to an underflowed
        // u32 and panicking on the next scope access.
        unsafe {
            crate::player::PLAYER_GENERATION += 1;
        }
        for _ in 0..120 {
            let depth = unsafe { PLAYER_OPT.as_ref().map(|p| p.handler_stack_depth).unwrap_or(0) };
            if depth == 0 {
                break;
            }
            Self::next_frame().await;
        }
        // Give loops one more tick to process the generation-change and exit.
        for _ in 0..4 {
            Self::next_frame().await;
        }

        // Drop the persistent renderer entirely so every movie starts with a
        // fresh WebGL2 context: no stale GL state (blend mode, color mask,
        // bound textures), no accumulated trails FBO contents, no leftover
        // shader/scene3d caches. `player_create_canvas` will rebuild it on
        // the next `ensure_renderer()` call. The draw loop stays alive and
        // picks up whatever renderer is currently in RENDERER_LOCK per rAF.
        crate::rendering::with_renderer_mut(|renderer_lock| {
            if let Some(renderer) = renderer_lock.take() {
                // Remove the old canvas from the DOM so the new renderer's
                // canvas replaces it (rather than being appended alongside).
                match &renderer {
                    crate::rendering_gpu::DynamicRenderer::WebGL2(r) => {
                        let canvas = r.canvas();
                        if let Some(parent) = canvas.parent_node() {
                            let _ = parent.remove_child(canvas);
                        }
                    }
                    _ => {}
                }
                drop(renderer);
            }
        });

        unsafe {
            if let Some(old) = PLAYER_OPT.take() {
                // Actually free the previous player. `DirPlayer` has no `Drop`
                // impl, and the drain loop above already waited for every
                // in-flight handler to unwind, so there is no outstanding
                // borrow — dropping just reclaims its heap (cast bitmaps,
                // datums, score). The old code `mem::forget`-ed it, which
                // leaked the entire player (tens of MB of cast bitmaps) on
                // every movie load — the browser test run climbed past a GB.
                drop(old);
            }

            // Create fresh channels to disconnect any old command/event loops
            // from init_player(). This prevents them from holding the semaphore
            // or interfering with our inline init_movie().
            let (tx, rx) = async_std::channel::unbounded();
            let (event_tx, event_rx) = async_std::channel::unbounded();
            crate::player::PLAYER_TX = Some(tx.clone());
            crate::player::PLAYER_EVENT_TX = Some(event_tx);
            PLAYER_OPT = Some(crate::player::DirPlayer::new(tx));
            crate::player::xtra::multiuser::MULTIUSER_XTRA_MANAGER_OPT =
                Some(crate::player::xtra::multiuser::MultiuserXtraManager::new());
            crate::player::xtra::xmlparser::XMLPARSER_XTRA_MANAGER_OPT =
                Some(crate::player::xtra::xmlparser::XmlParserXtraManager::new());
            crate::player::xtra::curl::CURL_XTRA_MANAGER_OPT =
                Some(crate::player::xtra::curl::CurlXtraManager::new());
            // Spawn fresh command and event loops for the new channels
            crate::player::spawn_player_local(async move {
                crate::player::commands::run_command_loop(rx).await;
            });
            crate::player::spawn_player_local(async move {
                crate::player::events::run_event_loop(event_rx).await;
            });
        }

        // Init logger (normally done by init_player which we skip in test mode)
        let _ = console_log::init_with_level(log::Level::Warn);

        // Restore external_params on the freshly created player so any
        // `cfg.apply_external_params()` call the test made before `load_movie`
        // is preserved across the reset.
        if !preserved_external_params.is_empty() {
            unsafe {
                if let Some(player) = PLAYER_OPT.as_mut() {
                    player.external_params = preserved_external_params;
                }
            }
        }
        let (startup_do, startup_do_before, startup_go) = preserved_startup;
        if startup_do.is_some() || startup_do_before.is_some() || startup_go.is_some() {
            unsafe {
                if let Some(player) = PLAYER_OPT.as_mut() {
                    player.startup_do = startup_do;
                    player.startup_do_before = startup_do_before;
                    player.startup_go = startup_go;
                }
            }
        }

        // Load the system font (required for text rendering)
        crate::player::font::player_load_system_font("/assets/charmap-system.png").await;
    }

    /// Wait for the next animation frame.
    async fn next_frame() {
        let promise = js_sys::Promise::new(&mut |resolve, _| {
            web_sys::window().unwrap()
                .request_animation_frame(&resolve)
                .unwrap();
        });
        let _ = JsFuture::from(promise).await;
    }

    /// Sleep for the given number of milliseconds.
    async fn sleep_ms(ms: u32) {
        let promise = js_sys::Promise::new(&mut |resolve, _| {
            web_sys::window().unwrap()
                .set_timeout_with_callback_and_timeout_and_arguments_0(&resolve, ms as i32)
                .unwrap();
        });
        let _ = JsFuture::from(promise).await;
    }

    /// Ensure a renderer exists, creating one if needed.
    fn ensure_renderer() {
        use crate::rendering::RENDERER_LOCK;
        RENDERER_LOCK.with(|lock| {
            if lock.borrow().is_some() { return; }
            crate::rendering::player_create_canvas().unwrap();
        });
    }

    /// Fetch and register an external Xtra plugin .wasm. Call this from a
    /// test BEFORE `load_movie` so plugin-using Lingo (`new(xtra "...")`,
    /// `the xtraList`, instance handlers) finds the xtra registered.
    /// Returns the registered xtra name.
    pub async fn load_external_xtra(&self, url: &str) -> Result<String, String> {
        crate::player::xtra::external::load_for_test(url).await
    }
}

impl TestHarness for BrowserTestPlayer {
    fn asset_path(&self, relative: &str) -> String {
        format!("/assets/{}", relative)
    }

    async fn init_movie(&mut self) {
        crate::player::testing_shared::log_test_action("Init movie");
        reserve_player_mut(|player| {
            player.is_playing = false;
        });
        unsafe {
            let player = crate::player::player_mut();
            player.play();
        }
    }

    async fn load_movie(&mut self, url: &str) {
        crate::player::testing_shared::log_test_action(&format!("Load: {}", url));
        let full_url = if url.starts_with("http://") || url.starts_with("https://") {
            url.to_string()
        } else {
            let origin = web_sys::window().unwrap().location().origin().unwrap();
            format!("{}{}", origin, url)
        };

        // Allocate a brand-new DirPlayer via DirPlayer::new() so every movie
        // load starts from a clean slate — no scopes, globals, timeouts,
        // datum allocations, or cached sprite textures from a prior movie.
        Self::reset_player().await;

        unsafe {
            let player = crate::player::player_mut();
            let _ = player.load_movie_from_file(&full_url).await;
        }

        // Resolve the movie's XTRl declarations against the registry and load
        // the matching wasm plugins (Groove, BobbaXtra, …). The dev host does
        // this in `LoadMovie`; without it a movie that needs an external Xtra
        // dies on its first plugin call ("No built-in handler: ...").
        Self::resolve_movie_xtras().await;

        // Initialize the renderer now that the stage size is known
        Self::ensure_renderer();
    }

    async fn step_frame(&mut self) -> bool {
        // Yield to the browser — the real frame loop, command loop,
        // and event loop all run during this yield.
        Self::next_frame().await;
        // Fail fast: surface any Lingo script errors before the next wait/step.
        if let Some(err) = Self::take_script_error() {
            crate::player::testing_shared::log_test_action(&format!("Script error: {}", err));
            panic!("Script error: {}", err);
        }
        reserve_player_ref(|player| player.is_playing)
    }


    // Override input methods to dispatch through the command channel
    // so they're processed by the command loop at the right time,
    // avoiding concurrent access with the frame loop.

    async fn click(&mut self, x: i32, y: i32) {
        crate::player::testing_shared::log_test_action(&format!("Click ({}, {})", x, y));
        use crate::player::commands::player_dispatch;
        reserve_player_mut(|player| {
            player.mouse_loc = (x, y);
            player.movie.mouse_down = true;
        });
        player_dispatch(PlayerVMCommand::MouseDown((x, y)));
        self.step_frame().await;
        reserve_player_mut(|player| {
            player.mouse_loc = (x, y);
            player.movie.mouse_down = false;
        });
        player_dispatch(PlayerVMCommand::MouseUp((x, y)));
    }

    async fn key_down(&mut self, key: &str, code: u16) {
        use crate::player::commands::player_dispatch;
        reserve_player_mut(|player| {
            player.keyboard_manager.key_down(key.to_string(), code);
        });
        player_dispatch(PlayerVMCommand::KeyDown(key.to_string(), code));
    }

    async fn key_up(&mut self, key: &str, code: u16) {
        use crate::player::commands::player_dispatch;
        reserve_player_mut(|player| {
            player.keyboard_manager.key_up(key, code);
        });
        player_dispatch(PlayerVMCommand::KeyUp(key.to_string(), code));
    }

    fn snapshot_stage(&self) -> SnapshotOutput {
        use crate::rendering::{RENDERER_LOCK, with_renderer_mut};
        use crate::rendering_gpu::Renderer;

        Self::ensure_renderer();

        with_renderer_mut(|renderer_lock| {
            if let Some(renderer) = renderer_lock {
                reserve_player_mut(|player| renderer.draw_frame(player));
            }
        });

        Self::canvas_to_snapshot()
    }

    async fn snapshot_sprite_isolated(&self, query: impl Into<SpriteQuery>) -> Result<SnapshotOutput, String> {
        use crate::rendering::with_renderer_mut;
        use crate::rendering_gpu::Renderer;

        Self::ensure_renderer();

        let query = query.into();
        let sprite_num = self.find_sprite(&query)
            .ok_or_else(|| format!("No sprite with {} found", query))?;
        let (l, t, r, b) = self.sprite_rect(sprite_num).await?;

        with_renderer_mut(|renderer_lock| {
            if let Some(renderer) = renderer_lock {
                reserve_player_mut(|player| {
                    renderer.draw_sprite_isolated(player, sprite_num as i16);
                });
            }
        });

        let full = Self::canvas_to_snapshot();
        // Restore the full frame so subsequent renders aren't broken
        with_renderer_mut(|renderer_lock| {
            if let Some(renderer) = renderer_lock {
                reserve_player_mut(|player| renderer.draw_frame(player));
            }
        });

        Ok(full.crop(l, t, r, b))
    }
}

impl BrowserTestPlayer {
    /// Remove and return the first pending Lingo script error, if any.
    fn take_script_error() -> Option<String> {
        let window = web_sys::window()?;
        let val = js_sys::Reflect::get(&window, &wasm_bindgen::JsValue::from_str("__scriptErrors")).ok()?;
        let arr: js_sys::Array = wasm_bindgen::JsCast::dyn_into(val).ok()?;
        if arr.length() == 0 { return None; }
        arr.shift().as_string()
    }

    /// Capture the current canvas contents as a base64 PNG snapshot.
    fn canvas_to_snapshot() -> SnapshotOutput {
        use crate::rendering::RENDERER_LOCK;
        use crate::rendering_gpu::Renderer;

        let data_url = RENDERER_LOCK.with(|lock| {
            let renderer = lock.borrow();
            let renderer = renderer.as_ref().expect("Renderer should be initialized");
            let canvas = renderer.canvas();
            canvas.to_data_url_with_type("image/png").expect("toDataURL failed")
        });

        let base64 = data_url.strip_prefix("data:image/png;base64,")
            .unwrap_or(&data_url)
            .to_string();
        SnapshotOutput::Base64Png(base64)
    }
}
