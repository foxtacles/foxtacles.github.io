use log::{debug, warn, error};
use crate::{
    director::lingo::datum::{Datum, DatumType},
    player::{
        DatumRef, MovieFrameTarget, Score, ScriptError, ScriptErrorCode, ScriptInstanceRef, cast_lib::{CastMemberRef, INVALID_CAST_MEMBER_REF, NULL_CAST_MEMBER_REF}, datum_formatting::format_datum, events::{
            dispatch_event_to_all_behaviors, dispatch_system_event_to_timeouts, player_dispatch_event_beginsprite, player_invoke_static_event, player_invoke_targeted_event, player_wait_available
        }, get_score_sprite_mut, handlers::datum_handlers::{player_call_datum_handler, script_instance::ScriptInstanceUtils}, player_call_script_handler, reserve_player_mut, reserve_player_mut_async, reserve_player_ref, score::{sprite_rollover_test, get_sprite_at}, symbols::{builtin::BuiltInSymbol, symbol::Symbol}
    },
    utils::log_i,
};

pub struct MovieHandlers {}

impl MovieHandlers {
    pub fn puppet_tempo(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            player.movie.puppet_tempo = player.get_datum(&args[0]).int_value()? as u32;
            Ok(DatumRef::Void)
        })
    }

    pub fn script(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let identifier = player.get_datum(&args[0]);
            let formatted_id = format_datum(&args[0], &player);

            let member_ref = match identifier {
                Datum::String(script_name) => Ok(player
                    .movie
                    .cast_manager
                    .find_member_ref_by_name(&script_name)),
                Datum::Int(script_num) => Ok(player
                    .movie
                    .cast_manager
                    .find_member_ref_by_number(*script_num as u32)),
                Datum::CastMember(cast_member_ref) => Ok(Some(cast_member_ref.clone())),
                _ => Err(ScriptError::new(format!(
                    "Invalid identifier for script: {}",
                    formatted_id
                ))), // TODO
            }?;
            let script = member_ref
                .to_owned()
                .and_then(|r| player.movie.cast_manager.get_script_by_ref(&r));

            match script {
                Some(_) => Ok(player.alloc_datum(Datum::ScriptRef(member_ref.unwrap()))),
                None => Err(ScriptError::new(format!(
                    "Script not found {}",
                    formatted_id
                ))),
            }
        })
    }

    pub fn member(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            if args.len() > 2 {
                return Err(ScriptError::new(
                    "Too many arguments for member".to_string(),
                ));
            }
            let member_name_or_num_ref = args.get(0).unwrap();
            let member_name_or_num = player.get_datum(member_name_or_num_ref);
            if let Datum::CastMember(_) = &member_name_or_num {
                return Ok(member_name_or_num_ref.clone());
            }
            let cast_name_or_num = args.get(1).map(|x| player.get_datum(x));
            let member = player.movie.cast_manager.find_member_ref_by_identifiers(
                member_name_or_num,
                cast_name_or_num,
                &player.allocator,
            )?;
            if let Some(member) = member {
                Ok(player.alloc_datum(Datum::CastMember(member.to_owned())))
            } else if let Some(cast_datum) = cast_name_or_num {
                // Director returns a valid ref for member(N, castLib) even if the
                // member slot is empty (used by getDynamicSlot pattern).
                // Only for positive member numbers — negative/zero are invalid refs.
                let cast_num = match cast_datum {
                    Datum::String(s) => player.movie.cast_manager.get_cast_by_name(s)
                        .map(|c| c.number as i32),
                    Datum::Int(n) => Some(*n),
                    Datum::CastLib(n) => Some(*n as i32),
                    _ => None,
                };
                if let (Some(cast_num), Ok(member_num)) = (cast_num, member_name_or_num.int_value()) {
                    if member_num > 0 {
                        Ok(player.alloc_datum(Datum::CastMember(CastMemberRef {
                            cast_lib: cast_num,
                            cast_member: member_num,
                        })))
                    } else if member_num == 0 && cast_num == 0 {
                        // `member(0, 0)` — BOTH args zero — is Director's NULL
                        // member reference; every other non-positive form keeps
                        // the invalid sentinel it had before, so the
                        // getDynamicSlot pattern above is untouched.
                        //
                        // It is the value an EMPTY sprite channel reports for
                        // its member, so it must equal NULL_CAST_MEMBER_REF.
                        // Returning the invalid sentinel made every empty
                        // channel look occupied to the standard score scan.
                        //
                        // Merlin's Revenge 3 snapshots a screen with
                        //   repeat with i = 1 to the lastChannel
                        //     if sprite(i).member <> member(0, 0) then
                        //       ... thelist.append(nMark)
                        // With lastChannel at 1005 that produced ~1005 marks
                        // instead of a few dozen, and drawing the screen then
                        // requested 1010 sprites from a 999-sprite pool,
                        // exhausting it on the first screen. Everything
                        // downstream got VOID for its sprite.
                        Ok(player.alloc_datum(Datum::CastMember(NULL_CAST_MEMBER_REF)))
                    } else {
                        Ok(player.alloc_datum(Datum::CastMember(INVALID_CAST_MEMBER_REF)))
                    }
                } else {
                    Ok(player.alloc_datum(Datum::CastMember(INVALID_CAST_MEMBER_REF)))
                }
            } else {
                // `member(N)` with no cast lib and no existing member: Director
                // returns a valid BY-NUMBER reference to member N of the default
                // cast even when that slot is empty — `member(19)` IS member 19,
                // allocated or not (11.5 Scripting Dictionary: a numbered
                // reference addresses a slot; it does not require the slot to be
                // filled). Without this the ref was INVALID (-1,-1), so
                // `new(#bitmap, member(19))` couldn't target slot 19 (it fell
                // back to the first free slot) and `member(19).image = ...`
                // errored. Tetris reserves empty slots 10-14 / 19-21 and fills
                // them at runtime with exactly that pattern. A failed name
                // lookup or a non-positive number stays invalid.
                let numeric = match &member_name_or_num {
                    Datum::Int(n) => Some(*n),
                    Datum::Float(f) => Some(*f as i32),
                    _ => None,
                };
                match numeric {
                    Some(n) if n > 0 => {
                        // High 16 bits may encode the cast lib (slot-number
                        // form); a bare member number has cast_lib 0 → default
                        // to the first cast (mirrors member_ref_from_slot_number).
                        let cast_lib = (n >> 16) as i32;
                        let cast_member = (n & 0xFFFF) as i32;
                        let cast_lib = if cast_lib == 0 { 1 } else { cast_lib };
                        Ok(player.alloc_datum(Datum::CastMember(CastMemberRef {
                            cast_lib,
                            cast_member,
                        })))
                    }
                    _ => Ok(player.alloc_datum(Datum::CastMember(INVALID_CAST_MEMBER_REF))),
                }
            }
        })
    }

    pub async fn go(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        if args.is_empty() {
            // "go" with no args is gotoLoop: go to nearest marker at or before current frame,
            // or frame 1 if no markers exist
            reserve_player_mut(|player| {
                let current = player.movie.current_frame as i32;
                let label_frame = player.movie.score.frame_labels.iter()
                    .rev()
                    .find(|fl| fl.frame_num <= current)
                    .map(|fl| fl.frame_num as u32);
                player.next_frame = Some(label_frame.unwrap_or(1));
            });
            return Ok(DatumRef::Void);
        }
        // If a second argument is provided, it's a movie path: go frame X of movie "path"
        let go_to_movie = if args.len() >= 2 {
            Some(reserve_player_mut(|player| {
                let movie_path = player.get_datum(&args[1]).string_value()?;
                let search_paths = match player.get_datum(&player.search_paths) {
                    Datum::List(_, items, _) => items.iter()
                        .map(|item| player.get_datum(item).string_value())
                        .collect::<Result<Vec<_>, _>>()?,
                    _ => Vec::new(),
                };
                let movie_paths = crate::player::net_manager::movie_path_candidates(
                    &movie_path, &player.movie.file_name,
                    player.net_manager.base_path.as_ref(), &search_paths,
                );

                // Resolve the first arg into a MovieFrameTarget
                let datum = player.get_datum(&args[0]);
                let datum_type = datum.type_enum();
                let target = match datum_type {
                    DatumType::Int => MovieFrameTarget::Frame(datum.int_value()? as u32),
                    DatumType::String => MovieFrameTarget::Label(datum.string_value()?),
                    DatumType::Symbol => MovieFrameTarget::Label(datum.string_value()?),
                    _ => MovieFrameTarget::Default,
                };

                let task_id = player.net_manager.preload_net_thing(movie_paths[0].clone());
                Ok::<_, ScriptError>((task_id, target, movie_path, movie_paths))
            })?)
        } else {
            None
        };

        // Director 11.5 Scripting Dictionary, `go()`: calling go() with the
        // movieName parameter "loads frame 1 of the movie", and "if go() is
        // called from within a handler, the handler in which it is placed
        // continues executing" — the REST of the calling handler must see the
        // NEW movie's cast libraries (Miniclip's wrapper_silentbaystudios
        // depends on this: it does `go(1, "gameloader.dcr")` and then, in the
        // same exitFrame, resolves parent scripts that live in gameloader's
        // second cast). So: wait for the fetch HERE and mount eagerly.
        //
        // The wait is a poll loop rather than `net_manager.await_task()`.
        // Yielding via a timer keeps this independent of the ManualFuture
        // completer path and gives the spawned fetch task event-loop time.
        if let Some((mut task_id, target, movie_path, movie_paths)) = go_to_movie {
            let mut alternatives = movie_paths.into_iter().skip(1);
            debug!("[go] go(_, \"{}\") -> net task {}", movie_path, task_id);
            // Tell maybe_hold_dcr_for_preloader to stand down for this fetch.
            reserve_player_mut(|player| { player.goto_wait_active = true; });
            let mut waited_ms: u64 = 0;
            const POLL_MS: u64 = 25;
            const TIMEOUT_MS: u64 = 60_000;
            let done = loop {
                let (done, failed, state) = reserve_player_ref(|player| {
                    let state = player.net_manager.try_get_task_state(task_id);
                    (
                        state.as_ref().map_or(false, |s| s.result.is_some()),
                        state.as_ref().and_then(|s| s.result.as_ref()).is_some_and(|r| r.is_err()),
                        state.map(|s| (s.bytes_loaded, s.bytes_total)),
                    )
                });
                if failed {
                    if let Some(path) = alternatives.next() {
                        task_id = reserve_player_mut(|player| player.net_manager.preload_net_thing(path));
                        waited_ms = 0;
                        continue;
                    }
                    reserve_player_mut(|player| { player.goto_wait_active = false; });
                    return Err(ScriptError::new(format!("Movie not found in current directory or searchPaths: {movie_path}")));
                }
                if done {
                    break true;
                }
                if waited_ms >= TIMEOUT_MS {
                    break false;
                }
                if waited_ms > 0 && waited_ms % 5_000 == 0 {
                    crate::console_warn!(
                        "[go] still waiting for task {} ({} ms, state={:?})",
                        task_id, waited_ms, state
                    );
                }
                let _ = async_std::future::timeout(
                    std::time::Duration::from_millis(POLL_MS),
                    std::future::pending::<()>(),
                )
                .await;
                waited_ms += POLL_MS;
            };
            reserve_player_mut(|player| { player.goto_wait_active = false; });

            if !done {
                // Fetch never finished — fall back to the deferred frame-loop
                // transition so the movie errs loudly instead of freezing.
                crate::console_error!(
                    "[go] movie fetch for \"{}\" (task {}) did not finish within {}s; \
                     deferring the transition to the frame loop",
                    movie_path, task_id, TIMEOUT_MS / 1000
                );
                reserve_player_mut(|player| {
                    player.pending_goto_net_movie = Some((task_id, target));
                });
                return Ok(DatumRef::Void);
            }

            let mounted = crate::player::mount_net_movie(task_id, target, true).await;
            // Success is per-transition noise; a FAILED mount means the calling
            // handler is about to run against the OLD movie's casts, which is
            // exactly the bug this path exists to prevent — surface that one.
            if mounted {
                debug!("[go] eager mount of \"{}\" succeeded after {} ms", movie_path, waited_ms);
            } else {
                crate::console_error!(
                    "[go] eager mount of \"{}\" FAILED after {} ms — the calling handler will continue against the previous movie's casts",
                    movie_path, waited_ms
                );
            }
            return Ok(DatumRef::Void);
        }

        let mut frame_advanced = false;
        let mut enter_frame = 0;

        let destination_frame: u32 = reserve_player_mut(|player| {
            enter_frame = player.movie.current_frame;

            let datum: &Datum = player.get_datum(&args[0]);
            let datum_type = datum.type_enum();
            use crate::player::format_datum;

            debug!("go() called: current_frame={} datum={}", player.movie.current_frame, format_datum(&args[0], player));

            let dest = match datum_type {
                DatumType::Int => Some(datum.int_value()? as u32),

                // A frame label / marker keyword can arrive as either a string
                // (`do("go next")`, `go "label"`) or a symbol (decompiled
                // `go(#next)`), so handle both the same way.
                DatumType::String | DatumType::Symbol => {
                    let s = datum.string_value()?;
                    let key = s.to_ascii_lowercase();
                    // Director marker-navigation keywords: `next` == marker(1),
                    // `previous` == marker(-1), `loop` == marker(0) — i.e. the
                    // next/previous/current MARKER, not the next/previous frame
                    // (Director 11.5 Scripting Dictionary: `next` keyword ≡
                    // `the marker(+1)`). mixmaster's buttons do `do("go next")`.
                    if key == "next" || key == "previous" || key == "loop" {
                        let mut frames: Vec<u32> = player
                            .movie
                            .score
                            .frame_labels
                            .iter()
                            .map(|fl| fl.frame_num as u32)
                            .collect();
                        frames.sort_unstable();
                        frames.dedup();
                        let current = player.movie.current_frame;
                        let offset: i32 = match key.as_str() {
                            "next" => 1,
                            "previous" => -1,
                            _ => 0, // loop
                        };
                        // marker(offset): index of marker(0) (largest marker <=
                        // current, i.e. current-if-marked else previous) is
                        // pos-1, where pos = count of markers <= current.
                        let dest_frame = if frames.is_empty() {
                            None
                        } else {
                            let pos = frames.partition_point(|&f| f <= current) as i32;
                            let target = (pos - 1) + offset;
                            if target >= 0 {
                                frames.get(target as usize).copied()
                            } else {
                                None
                            }
                        };
                        // No such marker (e.g. `go next` past the last marker) →
                        // stay on the current frame rather than erroring.
                        Some(dest_frame.unwrap_or(current))
                    } else {
                        // An unknown label is a no-op in Director — the playhead
                        // simply stays put; it is not an error. Same rule as the
                        // missing-marker case just above.
                        //
                        // Movies rely on this. snowcraft installs a debug
                        // `keyDownScript` that does `go("level" && the key)`
                        // whenever `integer(the key + 1) < 11`, and a non-numeric
                        // key coerces to 1 — so every arrow key, letter or
                        // modifier press builds a garbage label like
                        // "level <arrow char>". Raising a ScriptError there
                        // aborted the handler and surfaced an error for what
                        // Director treats as an ordinary miss.
                        Some(
                            player
                                .movie
                                .score
                                .frame_labels
                                .iter()
                                .find(|fl| fl.label.eq_ignore_ascii_case(&s))
                                .map(|fl| fl.frame_num as u32)
                                .unwrap_or(player.movie.current_frame),
                        )
                    }
                }

                _ => None,
            };

            let frame = match dest {
                Some(f) => f,
                None => {
                    return Err(ScriptError::new("Unsupported or invalid frame label passed to go()".to_string()));
                }
            };

            if player.next_frame.is_none() || frame != player.movie.current_frame {
                player.next_frame = Some(frame);

                if frame != enter_frame {
                    frame_advanced = true;
                }
            }

            Ok(frame)
        })?;

        if frame_advanced {
            let mut execute_frame_change = false;

            if enter_frame < destination_frame {
                reserve_player_mut(|player| {
                    player.go_direction = 2; // forwards
                });
                execute_frame_change = true;
            } else if enter_frame > destination_frame {
                reserve_player_mut(|player| {
                    player.go_direction = 1; // backwards
                });
                execute_frame_change = true;
            }

            if execute_frame_change {
                player_wait_available().await;

                // 1. Send endSprite: Frame behaviors -> Sprite behaviors
                let ended_sprite_nums = reserve_player_mut_async(|player| {
                    Box::pin(async move {
                        player.end_all_sprites().await
                    })
                }).await;

                player_wait_available().await;

                reserve_player_mut(|player| {
                    for (score_source, sprite_num) in ended_sprite_nums.iter() {
                        if let Some(sprite) = get_score_sprite_mut(
                            &mut player.movie,
                            &score_source,
                            *sprite_num as i16,
                        ) {
                            sprite.exited = true;
                        }
                    }

                    player.advance_frame();
                    // begin_all_sprites manages frame_script_instance lifecycle —
                    // it preserves the cached instance while the playhead stays within
                    // the same frame script's span and recreates it only when the active
                    // script changes or the span is exited.
                    player.begin_all_sprites();

                    // Apply tweening after sprites are initialized
                    player.movie.score.apply_tween_modifiers(player.movie.current_frame);
                });

                player_wait_available().await;

                // 2. Send beginSprite: Frame behaviors -> Sprite behaviors
                // Collect behaviors that need initialization
                let behaviors_to_init: Vec<(ScriptInstanceRef, u32)> = reserve_player_mut(|player| {
                    let mut behaviors = Vec::new();
                    for channel_number in player.active_stage_behavior_channels() {
                        let Some((sprite_num, fallback)) = player
                            .movie
                            .score
                            .channels
                            .get(channel_number)
                            .map(|channel| {
                                (
                                    channel.sprite.number as u32,
                                    channel.sprite.script_instance_list.clone(),
                                )
                            })
                        else {
                            continue;
                        };

                        for behavior_ref in player.get_sprite_script_instance_ids(
                            sprite_num as i16,
                            fallback.as_slice(),
                        ) {
                            if player
                                .allocator
                                .get_script_instance_entry(behavior_ref.id())
                                .is_some_and(|entry| !entry.script_instance.begin_sprite_called)
                            {
                                behaviors.push((behavior_ref, sprite_num));
                            }
                        }
                    }
                    behaviors
                });

                // Initialize behavior default properties
                for (behavior_ref, sprite_num) in &behaviors_to_init {
                    if let Err(err) = Score::initialize_behavior_defaults_async(behavior_ref.clone(), *sprite_num).await {
                        web_sys::console::warn_1(
                            &format!("Failed to initialize behavior defaults: {}", err.message).into()
                        );
                    }
                }

                player_wait_available().await;

                let begin_sprite_nums = player_dispatch_event_beginsprite(
                    Symbol::builtin(BuiltInSymbol::BeginSprite),
                    &vec![]
                ).await;

                player_wait_available().await;

                reserve_player_mut(|player| {
                    for sprite_list in begin_sprite_nums.iter() {
                        for (score_source, sprite_num) in sprite_list.iter() {
                            if let Some(sprite) = get_score_sprite_mut(
                                &mut player.movie,
                                score_source,
                                *sprite_num as i16,
                            ) {
                                for script_ref in &sprite.script_instance_list {
                                    if let Some(entry) =
                                        player.allocator.get_script_instance_entry_mut(script_ref.id())
                                    {
                                        entry.script_instance.begin_sprite_called = true;
                                    }
                                }
                            }
                        }
                    }
                });

                // Dispatch beginSprite to any remaining behaviors not handled above
                // (e.g., puppet sprites not in the score's sprite_spans)
                let remaining_behaviors: Vec<ScriptInstanceRef> = reserve_player_mut(|player| {
                    behaviors_to_init.iter()
                        .filter(|(behavior_ref, _)| {
                            player.allocator.get_script_instance_entry(behavior_ref.id())
                                .map_or(false, |entry| !entry.script_instance.begin_sprite_called)
                        })
                        .map(|(behavior_ref, _)| behavior_ref.clone())
                        .collect()
                });

                for behavior_ref in &remaining_behaviors {
                    let receivers = vec![behavior_ref.clone()];
                    let _ = player_invoke_targeted_event(
                        Symbol::builtin(BuiltInSymbol::BeginSprite),
                        &vec![],
                        Some(&receivers),
                    ).await;
                }

                if !remaining_behaviors.is_empty() {
                    reserve_player_mut(|player| {
                        for behavior_ref in &remaining_behaviors {
                            if let Some(entry) =
                                player.allocator.get_script_instance_entry_mut(behavior_ref.id())
                            {
                                entry.script_instance.begin_sprite_called = true;
                            }
                        }
                    });
                }

                player_wait_available().await;

                // 3. Send stepFrame to actorList — gate on in_step_frame so a
                // nested go() (e.g. enterFrame handler calling mach8_go) does
                // not re-dispatch stepFrame on the same actorList during the
                // current frame cycle.
                let step_frame_entered = reserve_player_mut(|player| {
                    if player.in_step_frame { return true; }
                    player.in_step_frame = true;
                    false
                });
                if !step_frame_entered {
                    let (actor_list_snapshot, mut active_actor_ids, mut actor_list_generation) =
                        reserve_player_ref(|player| player.actor_list_stepframe_snapshot());

                    for (idx, actor_ref) in actor_list_snapshot.iter().enumerate() {
                        let still_active = active_actor_ids.contains(&actor_ref.unwrap());

                        if still_active {
                            let result =
                                player_call_datum_handler(&actor_ref, Symbol::builtin(BuiltInSymbol::StepFrame), &vec![]).await;

                            if let Err(err) = result {
                                if err.code == ScriptErrorCode::Abort {
                                    reserve_player_mut(|player| {
                                        player.is_in_frame_update = false;
                                        player.in_step_frame = false;
                                    });
                                    return Ok(DatumRef::Void);
                                }
                                error!("⚠ stepFrame[{}] error: {}", idx, err.message);
                                reserve_player_mut(|player| {
                                    player.on_script_error(&err);
                                    player.is_in_frame_update = false;
                                    player.in_step_frame = false;
                                });
                                return Ok(DatumRef::Void);
                            }

                            let refreshed_active_ids = reserve_player_ref(|player| {
                                if player.actor_list_generation != actor_list_generation {
                                    Some(player.actor_list_active_ids())
                                } else {
                                    None
                                }
                            });

                            if let Some((next_active_actor_ids, next_actor_list_generation)) = refreshed_active_ids
                            {
                                active_actor_ids = next_active_actor_ids;
                                actor_list_generation = next_actor_list_generation;
                            }
                        }
                    }
                    reserve_player_mut(|player| { player.in_step_frame = false; });
                }

                player_wait_available().await;

                // Prevent re-entrant calls
                let already_updating = reserve_player_mut(|player| {
                    if player.is_in_frame_update {
                        return true;
                    }
                    player.is_in_frame_update = true;
                    false
                });

                if !already_updating {
                    reserve_player_mut(|player| {
                        player.in_prepare_frame = true;
                    });

                    // Relay prepareFrame to timeout targets
                    dispatch_system_event_to_timeouts(BuiltInSymbol::PrepareFrame, &vec![]).await;

                    // 4. Send prepareFrame: Sprite behaviors -> Frame behaviors
                    let _ = dispatch_event_to_all_behaviors(Symbol::builtin(BuiltInSymbol::PrepareFrame), &vec![]).await;

                    reserve_player_mut(|player| {
                        player.in_prepare_frame = false;
                    });

                    player_wait_available().await;

                    reserve_player_mut(|player| {
                        player.in_enter_frame = true;
                    });

                    // 5. Send enterFrame: Sprite behaviors -> Frame behaviors
                    let _ = dispatch_event_to_all_behaviors(Symbol::builtin(BuiltInSymbol::EnterFrame), &vec![]).await;

                    reserve_player_mut(|player| {
                        player.in_enter_frame = false;
                    });

                    player_wait_available().await;

                    reserve_player_mut(|player| {
                        player.is_in_frame_update = false;
                    });
                } else {
                    // Benign re-entrancy guard (a `go` fired while a frame update
                    // was already in progress); debug! to keep it out of the
                    // browser console.
                    debug!("Failed to run frame update in go function, already updating");
                }
            }
        }
        
        if frame_advanced {
            reserve_player_mut(|player| {
                player.has_frame_changed_in_go = true;
            });
        } else {
            // go(the frame) — stay on current frame
            // ONLY set go_same_frame, NOT has_frame_changed_in_go
            reserve_player_mut(|player| {
                player.go_same_frame = true;
            });
        }

        Ok(DatumRef::Void)
    }

    pub fn puppet_sprite(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let sprite_number = player.get_datum(&args[0]).int_value()?;
            let is_puppet = player.get_datum(&args[1]).int_value()? == 1;

            if !is_puppet {
                // Director defers reverting an unpuppeted sprite to the Score:
                // the sprite keeps its current member/position/appearance until
                // the NEXT frame update (begin_sprites / per-frame delta) reloads
                // the channel from the score. Clearing the visual state here is
                // wrong — it destroys a sprite the script is still reading in the
                // same handler.
                //
                // BrickOut's newLevel does, per brick channel:
                //     makeStage()                  -- set the memberNum (scene)
                //     puppetSprite(i, 0)           -- unpuppet
                //     puppetSprite(i, 1)           -- re-puppet
                //     add(vListRect, the rect of sprite i)
                // With the old clear, puppetSprite(i,0) wiped the member/loc the
                // score+makeStage had established, so `the rect` read (0,0,0,0)
                // and brick collision never fired. Preserving the visual state
                // (and letting the score re-drive it on the next frame if it is
                // NOT re-puppeted) matches Director's deferred reversion.
                //
                // Only the puppet flag and behavior lifecycle are cleared:
                // `entered = false` lets the next begin_sprites re-enter the span
                // and reload from the score (the deferred revert) when the sprite
                // stays unpuppeted; if it is re-puppeted first, it keeps its data.
                let sprite = player.movie.score.get_sprite_mut(sprite_number as i16);
                sprite.puppet = false;
                sprite.entered = false;
                sprite.exited = false;
                sprite.script_instance_list.clear();
                // Mark for revert on the NEXT frame tick. If the sprite is not
                // re-puppeted / re-membered before then it reverts to the Score
                // (a reset to empty for a pure-puppet channel with no span). This
                // matches Director's deferred revert AND keeps BrickOut working
                // (it re-puppets in the same handler, clearing the flag), while
                // fixing Coke Studios' WallItems which unpuppet furniture WITHOUT
                // setting visible=0 and relied on the old immediate wipe to clear.
                sprite.pending_unpuppet_revert = true;
                player.movie.score.invalidate_render_channel_cache();
                player.refresh_stage_behavior_channel_cache_entry(sprite_number as i16);
                player.invalidate_active_stage_filmloop_cache();
                return Ok(DatumRef::Void);
            }

            let sprite = player.movie.score.get_sprite_mut(sprite_number as i16);
            sprite.puppet = is_puppet;
            // Re-puppeted before the deferred revert ran → keep its data.
            sprite.pending_unpuppet_revert = false;
            player.movie.score.invalidate_render_channel_cache();
            player.refresh_stage_behavior_channel_cache_entry(sprite_number as i16);
            player.invalidate_active_stage_filmloop_cache();
            Ok(DatumRef::Void)
        })
    }

    pub fn sprite(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            // "nameOrNum Required. A string or integer that specifies the name
            // or index position of the sprite." (Director 11.5 Scripting
            // Dictionary, `sprite()`). A string names a span — the Property
            // Inspector's sprite name, stored in the score alongside the
            // span's behaviors.
            //
            // Without this a name fell through to `int_value()`, whose String
            // arm is `s.parse().unwrap_or(0)`, so every named lookup silently
            // became sprite 0 — no error, just a reference to nothing. Age of
            // Speed 2 builds its whole menu through
            // `script("OffGame").new(8, 6, 15, "off_game_sprite", 10)` and then
            // `getVariable(sprite(pFlashSprite), "_level0", 0)`, so the Flash
            // handle came back VOID, `StartOffGame` was never delivered to the
            // SWF, and the movie sat on its menu frame with a blank stage.
            let datum = player.get_datum(&args[0]);
            if let Datum::String(name) = datum {
                let name = name.clone();
                if let Some(number) = player.movie.score.find_sprite_number_by_name(&name) {
                    return Ok(player.alloc_datum(Datum::SpriteRef(number)));
                }
                // Documented miss behaviour: scriptExecutionStyle 10 (the
                // default for D10+ movies, which is where named sprites appear)
                // returns VOID; style 9 returns sprite 1.
                return Ok(DatumRef::Void);
            }
            let sprite_number = datum.int_value()?;
            Ok(player.alloc_datum(Datum::SpriteRef(sprite_number as i16)))
        })
    }

    pub async fn send_sprite(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        let (message, remaining_args, receivers) = reserve_player_mut(|player| {
            let sprite_num = player.get_datum(&args[0]).int_value()
                .map_err(|e| ScriptError::new(format!("sendSprite: invalid sprite number: {:?}", e)))?;
            let message = player.get_datum(&args[1]).symbol_value()
                .map_err(|e| ScriptError::new(format!("sendSprite: invalid message: {:?}", e)))?;
            let remaining_args = &args[2..].to_vec();
            let sprite = player.movie.score.get_sprite(sprite_num as i16)
                .ok_or_else(|| ScriptError::new(format!("sendSprite: sprite {} not found", sprite_num)))?;
            let fallback = sprite.script_instance_list.clone();
            let receivers = player.get_sprite_script_instance_ids(
                sprite_num as i16,
                fallback.as_slice(),
            );
            Ok((message.clone(), remaining_args.clone(), receivers))
        })?;

        // sendSprite returns the return value of the first handler that handles the message
        let mut last_return_value = DatumRef::Void;
        let mut handled_by_sprite = false;
        for receiver in receivers {
            let handler_pair = reserve_player_ref(|player| {
                ScriptInstanceUtils::get_script_instance_handler(
                    message,
                    &receiver,
                    player,
                )
            })?;

            if let Some(handler_ref) = handler_pair {
                match player_call_script_handler(Some(receiver), handler_ref, &remaining_args).await {
                    Ok(scope) => {
                        if !scope.passed {
                            handled_by_sprite = true;
                        }
                        // Capture the return value from the handler
                        if scope.return_value != DatumRef::Void {
                            last_return_value = scope.return_value;
                        }
                    }
                    Err(err) => {
                        if err.code != ScriptErrorCode::Abort {
                            web_sys::console::warn_1(
                                &format!("⚠ sendSprite continuing after error in handler '{}': {}", message, err.message).into()
                            );
                        } else {
                            return Err(err);
                        }
                    }
                }
            }
        }

        if !handled_by_sprite {
            player_invoke_static_event(message, &remaining_args).await?;
        }

        Ok(last_return_value)
    }

    pub async fn send_all_sprites(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        let (message, remaining_args, receivers) = reserve_player_mut(|player| {
            let message = player.get_datum(&args[0]).symbol_value()
                .map_err(|e| ScriptError::new(format!("sendAllSprites: invalid message: {:?}", e)))?;
            let remaining_args = &args[1..].to_vec();

            // Collect receivers from stage score
            let mut receivers: Vec<ScriptInstanceRef> = player.active_stage_script_instance_ids();

            // Also collect receivers from filmloop scores
            let active_filmloops = player.get_active_filmloop_scores();
            for (member_ref, filmloop_frame) in active_filmloops {
                if let Some(filmloop_score) = player
                    .movie
                    .cast_manager
                    .find_member_by_ref(&member_ref)
                    .and_then(|member| match &member.member_type {
                        crate::player::cast_member::CastMemberType::FilmLoop(film_loop) => {
                            Some(&film_loop.score)
                        }
                        _ => None,
                    })
                {
                    let filmloop_receivers =
                        filmloop_score.get_active_script_instance_list_for_frame(filmloop_frame);
                    receivers.extend(filmloop_receivers);
                }
            }

            Ok((message.clone(), remaining_args.clone(), receivers))
        })?;
        
        let mut handled_by_sprite = false;
        let mut last_return_value = DatumRef::Void;
        for receiver in receivers {
            let handler_pair = reserve_player_ref(|player| {
                ScriptInstanceUtils::get_script_instance_handler(message, &receiver, player)
            })?;
            if let Some(handler_ref) = handler_pair {
                match player_call_script_handler(Some(receiver), handler_ref, &remaining_args).await {
                    Ok(scope) => {
                        if !scope.passed {
                            handled_by_sprite = true;
                        }
                        if scope.return_value != DatumRef::Void {
                            last_return_value = scope.return_value;
                        }
                    }
                    Err(err) => {
                        web_sys::console::warn_1(
                            &format!("⚠ sendAllSprites continuing after error in handler: {}", err.message).into()
                        );
                    }
                }
            }
        }

        if !handled_by_sprite {
            player_invoke_static_event(message, &remaining_args).await?;
        }

        Ok(last_return_value)
    }

    pub fn external_param_count(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let count = player.external_params.len() as i32;
            Ok(player.alloc_datum(Datum::Int(count)))
        })
    }

    pub fn external_param_name(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let datum = player.get_datum(&args[0]);

            // Case 1: argument is a string (lookup by name, case-insensitive)
            if let Ok(key) = datum.string_value() {
                if player
                    .external_params
                    .keys()
                    .any(|k| k.to_lowercase() == key.to_lowercase())
                {
                    return Ok(player.alloc_datum(Datum::String(key)));
                } else {
                    return Ok(player.alloc_datum(Datum::Void));
                }
            }

            // Case 2: argument is an integer (index)
            if let Ok(index) = datum.int_value() {
                if index > 0 && (index as usize) <= player.external_params.len() {
                    if let Some((key, _)) = player.external_params.iter().nth(index as usize - 1) {
                        return Ok(player.alloc_datum(Datum::String(key.clone())));
                    }
                }
                return Ok(player.alloc_datum(Datum::Void));
            }

            // Invalid argument type
            log_i("external_param_name(): invalid argument type, returning Void");
            Ok(player.alloc_datum(Datum::Void))
        })
    }

    pub fn external_param_value(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let datum = player.get_datum(&args[0]);

            // Case 1: argument is a string (lookup by name)
            if let Ok(key) = datum.string_value() {
                if let Some((_k, value)) = player
                    .external_params
                    .iter()
                    .find(|(k, _)| k.to_lowercase() == key.to_lowercase())
                {
                    return Ok(player.alloc_datum(Datum::String(value.clone())));
                } else {
                    return Ok(player.alloc_datum(Datum::Void));
                }
            }

            // Case 2: argument is an integer (index)
            if let Ok(index) = datum.int_value() {
                if index > 0 && (index as usize) <= player.external_params.len() {
                    if let Some((_key, value)) =
                        player.external_params.iter().nth(index as usize - 1)
                    {
                        return Ok(player.alloc_datum(Datum::String(value.clone())));
                    }
                }
                return Ok(player.alloc_datum(Datum::Void));
            }

            // Invalid type
            log_i(&format!(
                "external_param_value(): invalid argument type, returning Void"
            ));
            Ok(player.alloc_datum(Datum::Void))
        })
    }

    /// `stopEvent()` — Director 11.5 Scripting Dictionary, Movie method:
    /// "prevents scripts from passing an event message to subsequent locations
    /// in the message hierarchy… Neither subsequent scripts nor other behaviors
    /// on the sprite receive the event if it is stopped in this manner."
    ///
    /// The event-dispatch loops read (and clear) this flag; see
    /// `player_invoke_event_to_instances` / `player_invoke_static_event`.
    pub fn stop_event(_: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            player.event_stopped = true;
        });
        Ok(DatumRef::Void)
    }

    pub fn get_pref(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let pref_name = player.get_datum(&args[0]).string_value()?;
            let storage = web_sys::window()
                .and_then(|w| w.local_storage().ok().flatten());
            if let Some(storage) = storage {
                let key = format!("dirplayer_pref_{}", pref_name);
                if let Ok(Some(value)) = storage.get_item(&key) {
                    return Ok(player.alloc_datum(Datum::String(value)));
                }
            }
            Ok(DatumRef::Void)
        })
    }

    pub fn set_pref(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let pref_name = player.get_datum(&args[0]).string_value()?;
            let pref_value = player.get_datum(&args[1]).string_value()?;
            let storage = web_sys::window()
                .and_then(|w| w.local_storage().ok().flatten());
            if let Some(storage) = storage {
                let key = format!("dirplayer_pref_{}", pref_name);
                let _ = storage.set_item(&key, &pref_value);
            }
            Ok(DatumRef::Void)
        })
    }

    pub fn go_to_net_page(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        if args.is_empty() {
            return Ok(DatumRef::Void);
        }
        // LeechProtectionRemovalHelp `disableGoToNetPage` — swallow the call so
        // a movie's leech check can't bounce the player to the original site.
        if reserve_player_ref(|player| player.env_overrides.disable_goto_net_page) {
            return Ok(DatumRef::Void);
        }
        let (url, target) = reserve_player_ref(|player| {
            let url = player.get_datum(&args[0]).string_value()?;
            let target = if args.len() > 1 {
                player
                    .get_datum(&args[1])
                    .string_value()
                    .unwrap_or_else(|_| "_blank".to_string())
            } else {
                "_blank".to_string()
            };
            Ok::<(String, String), ScriptError>((url, target))
        })?;

        if let Some(code) = url.strip_prefix("javascript:") {
            // Defer via setTimeout(...,0) so the current WASM call stack
            // fully unwinds before the host-page JS runs. Synchronous
            // callbacks from the host back into WASM (e.g. openMixer
            // touching a wasm_bindgen closure) otherwise trip the
            // "closure invoked recursively or after being dropped" guard.
            let escaped = code.replace('\\', "\\\\").replace('\'', "\\'");
            let wrapper = format!(
                "setTimeout(function(){{try{{eval('{}');}}catch(e){{console.warn('gotoNetPage eval:',e);}}}},0);",
                escaped
            );
            if let Err(e) = js_sys::eval(&wrapper) {
                log::warn!("gotoNetPage: schedule eval failed: {:?}", e);
            }
        } else if let Some(window) = web_sys::window() {
            if let Err(e) = window.open_with_url_and_target(&url, &target) {
                log::warn!("gotoNetPage: window.open failed: {:?}", e);
            }
        }
        Ok(DatumRef::Void)
    }

    pub fn go_to_net_movie(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        // LeechProtectionRemovalHelp `disableGoToNetMovie` — see
        // `go_to_net_page`. Note this pins the CURRENT movie in place, so a
        // movie that legitimately navigates by `gotoNetMovie` will stop
        // advancing once the movie's setup script calls this.
        if reserve_player_ref(|player| player.env_overrides.disable_goto_net_movie) {
            return Ok(DatumRef::Void);
        }
        reserve_player_mut(|player| {
            let raw_url = player.get_datum(&args[0]).string_value()?;

            // Parse URL and extract #fragment marker
            let (fetch_url, target) = if let Some(hash_pos) = raw_url.find('#') {
                let url_part = raw_url[..hash_pos].to_string();
                let fragment = raw_url[hash_pos + 1..].to_string();
                let target = if fragment.is_empty() {
                    MovieFrameTarget::Default
                } else {
                    MovieFrameTarget::Label(fragment)
                };
                (url_part, target)
            } else {
                (raw_url, MovieFrameTarget::Default)
            };

            // Start the network fetch (non-blocking)
            let task_id = player.net_manager.preload_net_thing(fetch_url.clone());

            // Store the pending operation (replaces any previous pending one, cancelling it)
            player.pending_goto_net_movie = Some((task_id, target));

            Ok(player.alloc_datum(Datum::Int(task_id as i32)))
        })
    }

    /// `pass` — "passes an event message to the next location in the message
    /// hierarchy and enables execution of more than one handler for a given
    /// event ... The pass command branches to the next location AS SOON AS THE
    /// COMMAND RUNS. Any Lingo that follows the pass command in the handler
    /// does not run." (Director 11.5 Scripting Dictionary, `pass`).
    ///
    /// The second half matters as much as the first: movies use `pass` as an
    /// early exit. NabiscoWorld Mini-Golf guards its per-frame hole logic with
    ///
    ///   on enterFrame
    ///     if voidp(ballState) then
    ///       pass()
    ///     end if
    ///     gameLogic()
    ///
    /// and gameLogic opens with `getAt(ballState, player)`. Setting the flag
    /// without stopping the handler ran gameLogic anyway and raised on exactly
    /// the VOID the guard existed to avoid.
    pub fn pass(_: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let scope_ref = player.current_scope_ref();
            let scope = player.scopes.get_mut(scope_ref).unwrap();
            scope.passed = true;
            scope.stop_requested = true;
            Ok(DatumRef::Void)
        })
    }

    pub async fn execute_frame_update() -> Result<(), ScriptError> {
        player_wait_available().await;

        // Prevent re-entrant calls, and skip the update when the playhead already
        // moved this tick.
        //
        // Both conditions must be tested BEFORE claiming `is_in_frame_update`.
        // Claiming first and then bailing on `has_player_frame_changed` leaked the
        // claim — the flag is only cleared on the normal path at the end of this
        // function — so from the first tick where the playhead had moved, every
        // later call saw `already_updating` and returned immediately. Frame scripts
        // then never ran again for the rest of the movie: no enterFrame, no
        // exitFrame, no stepFrame. AreaZero's menu goes through
        // `[FS] Hold Frame And Loop And Update`, whose enterFrame drives
        // `gSystem.ScriptManager.enterFrame()` — and with that dead, its camera
        // rig, timers, triggers and handler list all stopped updating while the
        // frame loop and timeout intervals kept running, so the movie looked alive
        // but frozen.
        let (proceed, already_updating, frame_changed, current_frame) =
            reserve_player_mut(|player| {
                let already_updating = player.is_in_frame_update;
                let frame_changed = player.has_player_frame_changed;
                let current_frame = player.movie.current_frame;
                if already_updating || frame_changed {
                    return (false, already_updating, frame_changed, current_frame);
                }
                player.is_in_frame_update = true;
                (true, already_updating, frame_changed, current_frame)
            });

        if !proceed {
            debug!("🔄 execute_frame_update SKIPPED (already_updating={}, frame_changed={}, frame={})",
                already_updating, frame_changed, current_frame);
            return Ok(());
        }

        player_wait_available().await;

        // Sync all cached scriptInstanceLists back to sprite Vecs.
        // Behaviors added via scriptInstanceList.add() only exist in the cache
        // until synced — this ensures all event dispatch within this frame sees them.
        reserve_player_mut(|player| {
            player.sync_all_script_instance_lists();
        });

        reserve_player_mut(|player| {
            player.movie.score.apply_tween_modifiers(player.movie.current_frame);
        });

        // 1. Send stepFrame to actorList — gate on in_step_frame so a nested
        // go() does not re-dispatch stepFrame on the same actorList during
        // the current frame cycle.
        let step_frame_entered = reserve_player_mut(|player| {
            if player.in_step_frame { return true; }
            player.in_step_frame = true;
            false
        });
        if !step_frame_entered {
            let (actor_list_snapshot, mut active_actor_ids, mut actor_list_generation) =
                reserve_player_ref(|player| player.actor_list_stepframe_snapshot());

            for (idx, actor_ref) in actor_list_snapshot.iter().enumerate() {
                let still_active = active_actor_ids.contains(&actor_ref.unwrap());

                if still_active {
                    let result =
                        player_call_datum_handler(&actor_ref, Symbol::builtin(BuiltInSymbol::StepFrame), &vec![]).await;

                    if let Err(err) = result {
                        if err.code == ScriptErrorCode::Abort {
                            reserve_player_mut(|player| {
                                player.is_in_frame_update = false;
                                player.in_step_frame = false;
                            });
                            return Err(err);
                        }
                        error!("⚠ stepFrame[{}] error: {}", idx, err.message);
                        reserve_player_mut(|player| {
                            player.on_script_error(&err);
                            player.is_in_frame_update = false;
                            player.in_step_frame = false;
                        });
                        return Err(err);
                    }

                    let refreshed_active_ids = reserve_player_ref(|player| {
                        if player.actor_list_generation != actor_list_generation {
                            Some(player.actor_list_active_ids())
                        } else {
                            None
                        }
                    });

                    if let Some((next_active_actor_ids, next_actor_list_generation)) =
                        refreshed_active_ids
                    {
                        active_actor_ids = next_active_actor_ids;
                        actor_list_generation = next_actor_list_generation;
                    }
                }
            }
            reserve_player_mut(|player| { player.in_step_frame = false; });
        }

        player_wait_available().await;

        reserve_player_mut(|player| {
            player.in_prepare_frame = true;
        });

        // mouseEnter/mouseWithin/mouseLeave are per-frame rollover events, not
        // movement events — Director keeps sending mouseWithin every frame the
        // pointer stays inside a sprite's active area. Re-evaluate the hovered
        // set here so a behaviour polling from mouseWithin runs even while the
        // cursor is still.
        crate::player::events::dispatch_rollover_events();

        // Animated GIF members: put up whichever frame the elapsed time calls
        // for. Done here, once per frame, so an animation runs at its own
        // delays regardless of the movie's tempo.
        crate::player::gif::tick_gif_animations();

        // Relay prepareFrame to timeout targets
        dispatch_system_event_to_timeouts(BuiltInSymbol::PrepareFrame, &vec![]).await;

        dispatch_event_to_all_behaviors(Symbol::builtin(BuiltInSymbol::PrepareFrame), &vec![]).await;

        // A prepareFrame handler mounted a new movie via eager go(): stop the
        // frame update; the new movie runs nothing until its init sequence.
        if reserve_player_ref(|player| player.pending_movie_init) {
            reserve_player_mut(|player| {
                player.in_prepare_frame = false;
                player.is_in_frame_update = false;
            });
            return Ok(());
        }

        // Tick W3D registered #timeMS events + animation clock + dispatch
        // any queued PhysX collision callbacks. This is the *real* per-frame
        // path (the one in mod.rs::start_movie_sequence only fires on
        // startup); without these the avatar froze on its first frame after
        // I moved the renderer's dt advance onto runtime_state.
        crate::player::events::dispatch_w3d_timer_events().await;
        crate::player::events::tick_w3d_animations().await;
        crate::player::events::tick_w3d_particles().await;
        crate::player::events::tick_w3d_collisions().await;
        crate::player::events::dispatch_physx_collision_callbacks().await;

        reserve_player_mut(|player| {
            player.in_prepare_frame = false;
        });

        player_wait_available().await;

        // Skip mid-frame render for performance. Director renders once per
        // frame after enterFrame. The post-enterFrame render below captures
        // the final visual state. If a game needs mid-frame visibility,
        // it can call updateStage() explicitly from prepareFrame.
        // crate::rendering::draw_frame_immediate();

        reserve_player_mut(|player| {
            player.in_enter_frame = true;
        });

        dispatch_event_to_all_behaviors(Symbol::builtin(BuiltInSymbol::EnterFrame), &vec![]).await;

        reserve_player_mut(|player| {
            player.in_enter_frame = false;
        });

        // An enterFrame handler mounted a new movie via eager go().
        if reserve_player_ref(|player| player.pending_movie_init) {
            reserve_player_mut(|player| {
                player.is_in_frame_update = false;
            });
            return Ok(());
        }

        // enterFrame handlers are allowed to change the current visual state
        // (camera/model transforms, tunnelDepth, etc.) without calling
        // updateStage(), so flush one more redraw before the frame ends.
        crate::rendering::draw_frame_immediate();

        player_wait_available().await;

        reserve_player_mut(|player| {
            player.is_in_frame_update = false;
        });

        Ok(())
    }

    pub async fn update_stage(_: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        // An explicit updateStage draws now, handler or not.
        reserve_player_mut(|player| player.draw_hold_since_ms = None);
        // While a keyDown busy-wait loop is running (command_handler_yielding),
        // the main frame loop is paused to keep its frame scripts from
        // interleaving with the handler's bytecodes and corrupting the shared
        // scope stack. But that also freezes any frame-driven animation (fish's
        // `on prepareFrame` swimming fish) for as long as the key is held. Run
        // the frame update HERE instead — on this task, nested in the keyDown
        // handler, so it's sequential (no concurrent scope-stack corruption) —
        // throttled to the movie tempo so a tight `repeat while keyPressed`
        // loop calling updateStage() rapidly doesn't fast-forward the movie.
        // execute_frame_update()'s is_in_frame_update guard blocks the recursive
        // updateStage() that fires from inside prepareFrame.
        let run_frame_anim = reserve_player_mut(|player| {
            if player.is_in_frame_update {
                return false;
            }
            // Two kinds of busy-wait block the main frame loop, and both need
            // the frame update run from here instead:
            //
            //  - keyboard (`command_handler_yielding`, set for keyDown)
            //  - mouse: `repeat while the stillDown` inside an `on mouseDown`,
            //    which runs under in_mouse_command with the frame loop skipping
            //    updates for as long as the button is held.
            //
            // snowcraft's throw is the mouse case: you press a kid, hold to
            // charge the power meter, and drag to aim, all inside that loop.
            // Shockwave keeps the rest of the playfield animating while you
            // hold — the other kids walk and duck, snowballs already in flight
            // keep travelling — because that motion is driven by `prepareFrame`
            // behaviors. Without this the whole game froze the instant you
            // grabbed a snowball and only resumed on release.
            //
            // execute_frame_update dispatches stepFrame/prepareFrame and
            // renders; it does NOT advance the playhead, so this animates the
            // current frame without letting the movie run on behind the
            // blocked handler.
            let in_busy_wait = player.command_handler_yielding
                || (player.in_mouse_command && player.movie.mouse_down);
            if !in_busy_wait {
                return false;
            }
            let now = crate::player::testing_shared::now_ms();
            let tempo = player.current_frame_tempo.max(1);
            let interval = 1000.0 / tempo as f64;
            if now - player.last_kb_loop_frame_ms >= interval {
                player.last_kb_loop_frame_ms = now;
                true
            } else {
                false
            }
        });
        if run_frame_anim {
            if let Err(err) = Self::execute_frame_update().await {
                if err.code != ScriptErrorCode::Abort {
                    reserve_player_mut(|player| player.on_script_error(&err));
                }
            }
        }

        // Director's updateStage() forces an immediate stage redraw even from
        // inside enterFrame/prepareFrame loops. A frame script can also poll
        // rollOver() while the mouse is UP, so browser yielding must not depend
        // on the button or handler type. It does not dispatch another frame.
        reserve_player_mut(|player| { player.stage_dirty = true; });
        crate::rendering::draw_frame_immediate();

        // Yield to allow the browser event loop to process pending events
        // (mouse up/move, keyboard, etc.). This is essential for scripts
        // using "repeat while the mouseDown" or similar busy-wait loops.
        // The mouse_up()/mouse_down() WASM exports update movie.mouse_down
        // immediately via reserve_player_mut, so the state is correct when
        // the script resumes. The MouseUp command stays queued and won't
        // dispatch until the current handler finishes.
        //
        // Rate-limited to once per YIELD_INTERVAL_MS, because the yield is not
        // free: `sleep` allocates a gloo_timers Timeout, costing a `setTimeout`
        // to arm and a `clearTimeout` when the future drops. Yielding on EVERY
        // updateStage() meant a script looping on it paid two JS timer
        // operations per iteration — in Argent Free Ride's level load that put
        // `clearTimeout` at 42% of self time with the tab unresponsive. Once
        // every 8 ms still hands the browser ~120 chances a second to deliver
        // input, which is what the busy-wait loops actually need.
        // `nothing_async` below already throttles for the same reason.
        const YIELD_INTERVAL_MS: f64 = 8.0;
        let yield_now = reserve_player_mut(|player| {
                let now = crate::player::testing_shared::now_ms();
                if now - player.last_update_stage_yield_ms >= YIELD_INTERVAL_MS {
                    player.last_update_stage_yield_ms = now;
                    true
                } else {
                    false
                }
        });
        if yield_now {
            async_std::task::sleep(std::time::Duration::from_millis(2)).await;
        }

        Ok(DatumRef::Void)
    }

    pub async fn nothing_async(_: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        let now = crate::player::testing_shared::now_ms();
        let should_yield = reserve_player_mut(|player| {
            // Only count calls inside frame scripts (busy-wait like waitABit).
            // Reset counter when not in a frame script to prevent accumulation
            // across unrelated nothing() calls (catalogue items, downloads, etc.)
            if player.in_frame_script {
                player.nothing_call_count += 1;
            } else {
                player.nothing_call_count = 0;
                return false;
            }
            let many_calls = player.nothing_call_count >= 50;
            let yield_due = now - player.last_nothing_yield_ms >= 16.0;
            many_calls && yield_due
        });

        if should_yield {
            reserve_player_mut(|player| {
                player.nothing_call_count = 0;
                player.last_nothing_yield_ms = now;
            });

            crate::rendering::draw_frame_immediate();

            async_std::task::sleep(std::time::Duration::from_millis(2)).await;
        }

        Ok(DatumRef::Void)
    }

    pub fn rollover(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            player.input_polled = true;
            if !args.is_empty() {
                // rollOver(spriteNum) - returns TRUE if the mouse is over the specified sprite
                let sprite_num = player.get_datum(&args[0]).int_value()?;
                let sprite = player.movie.score.get_sprite(sprite_num as i16);
                if let Some(sprite) = sprite {
                    let hit = sprite_rollover_test(player, sprite, player.mouse_loc.0, player.mouse_loc.1);
                    let result = if hit { 1 } else { 0 };
                    Ok(player.alloc_datum(Datum::Int(result)))
                } else {
                    Ok(player.alloc_datum(Datum::Int(0)))
                }
            } else {
                // the rollOver - returns the sprite number under the mouse
                let sprite = get_sprite_at(player, player.mouse_loc.0, player.mouse_loc.1, false);
                Ok(player.alloc_datum(Datum::Int(sprite.unwrap_or(0) as i32)))
            }
        })
    }

    pub fn puppet_sound(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        if args.is_empty() {
            return Err(ScriptError::new(
                "puppetSound requires at least 1 argument".to_string(),
            ));
        }
        
        reserve_player_mut(|player| {
            // If only one argument, use channel 1 by default
            let (channel_num, member_ref) = if args.len() == 1 {
                (1, args[0].clone())
            } else {
                // Director's puppetSound disambiguates its two arguments by type
                // rather than by strict position: the sound cast member may be
                // named by a string, and the channel is always an integer. The
                // documented order is `puppetSound whichChannel, whichCastMember`,
                // but many movies (e.g. BrickOut) write the member-first idiom
                // `puppetSound "Intro", 2`. When the first argument is a string
                // it is the member name and the second is the channel; otherwise
                // fall back to the documented channel-first order.
                if matches!(player.get_datum(&args[0]), Datum::String(_)) {
                    let channel = player.get_datum(&args[1]).int_value()?;
                    (channel, args[0].clone())
                } else {
                    let channel = player.get_datum(&args[0]).int_value()?;
                    (channel, args[1].clone())
                }
            };

            // `puppetSound channel, 0` (and the single-arg `puppetSound 0`)
            // turns off sound puppeting and STOPS the channel — it is not a
            // request to play cast member 0. Director 4 movies use this idiom
            // heavily. Routing it through the play path just fails to resolve a
            // member and logs a spurious error, so handle it as a stop here.
            let member_datum = player.get_datum(&member_ref);
            if matches!(&member_datum, Datum::Int(n) if *n <= 0) {
                player.sound_stop(channel_num)?;
                return Ok(DatumRef::Void);
            }

            player.puppet_sound(channel_num, member_ref)?;
            Ok(DatumRef::Void)
        })
    }

    pub fn delay(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let ticks = player.get_datum(&args[0]).int_value()?;
            // Only set delay if not already delaying (prevent reset on every enterFrame)
            if ticks > 0 && player.delay_until.is_none() {
                let delay_ms = (ticks as f64) * (1000.0 / 60.0);
                player.delay_until = Some(
                    chrono::Local::now() + chrono::Duration::milliseconds(delay_ms as i64),
                );
            }
            Ok(DatumRef::Void)
        })
    }

    pub fn halt(args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            // Stop movie playback
            player.movie.current_frame = 1;
            player.is_playing = false;
            Ok(DatumRef::Void)
        })
    }

    pub fn quit(_args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            // A portable host cannot close its browser tab; end the projector
            // session and let the surrounding UI offer a restart.
            player.stop();
            player.sound_manager.stop_all();
            Ok(DatumRef::Void)
        })
    }
}
