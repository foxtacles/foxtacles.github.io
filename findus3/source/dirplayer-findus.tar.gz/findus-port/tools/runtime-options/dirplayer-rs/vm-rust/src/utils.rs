use crate::js_api::safe_js_string;
use chrono::DateTime;
use itertools::Itertools;
use url::Url;

pub fn set_panic_hook() {
    // When the `console_error_panic_hook` feature is enabled, we can call the
    // `set_panic_hook` function at least once during initialization, and then
    // we will get better error messages if our code ever panics.
    //
    // For more details see
    // https://github.com/rustwasm/console_error_panic_hook#readme
    #[cfg(feature = "console_error_panic_hook")]
    console_error_panic_hook::set_once();
}

pub fn log_i(value: &str) {
    #[cfg(target_arch = "wasm32")]
    web_sys::console::log_1(&safe_js_string(value));
    #[cfg(not(target_arch = "wasm32"))]
    log::debug!("{}", value);
}

#[macro_export]
macro_rules! console_warn {
  ($($arg:tt)*) => {{
    #[cfg(target_arch = "wasm32")]
    web_sys::console::warn_1(&crate::js_api::safe_js_string(&format_args!($($arg)*).to_string().as_str()));
    #[cfg(not(target_arch = "wasm32"))]
    log::warn!("{}", format_args!($($arg)*));
  }}
}

#[macro_export]
macro_rules! console_error {
  ($($arg:tt)*) => {{
    #[cfg(target_arch = "wasm32")]
    web_sys::console::error_1(&crate::js_api::safe_js_string(&format_args!($($arg)*).to_string().as_str()));
    #[cfg(not(target_arch = "wasm32"))]
    log::error!("{}", format_args!($($arg)*));
  }}
}

pub fn get_basename_no_extension(path: &str) -> String {
    let segments = path.split("/");
    let file_name = segments.last().unwrap_or_default();
    let dot_segments = file_name.split(".").collect_vec();
    let basename = dot_segments[0..dot_segments.len() - 1].join(".");
    return basename;
}

pub fn get_base_url(url: &Url) -> Url {
    let mut result = url.clone();
    result.set_fragment(None);
    return result.join("./").unwrap();
}

pub const PATH_SEPARATOR: &str = "/";

pub trait ToHexString {
    fn to_hex_string(&self) -> String;
}

impl ToHexString for Vec<u8> {
    fn to_hex_string(&self) -> String {
        self.iter()
            .map(|b| format!("{:02x}", b))
            .collect::<Vec<String>>()
            .join(" ")
    }
}

/// Number of ticks (60 ticks/second) from epoch until endtime
/// Generic over the timezone so the "now" side can use `Utc`. Timestamps are
/// absolute epoch values, so `Utc` and `Local` give a bit-identical result —
/// but `Local::now()` re-resolves the timezone offset on every call, which under
/// WASM is expensive. `the ticks` is polled in every game loop, and a profile put
/// `chrono::offset::local::Local::now` at 6.5% of total frame time.
fn ticks_since_epoch<Tz: chrono::TimeZone>(endtime: DateTime<Tz>) -> i64 {
    // Split the integral/fractional seconds to avoid multiplying an epoch
    // nanosecond value past i64. A 1000 / 60 millisecond divisor truncates to
    // 16 ms and incorrectly runs Director's clock at 62.5 ticks per second.
    endtime.timestamp() * 60
        + (endtime.timestamp_subsec_nanos() as i64 * 60) / 1_000_000_000
}

pub fn get_elapsed_ticks(start_time: DateTime<chrono::Local>) -> i32 {
    let current_ticks = ticks_since_epoch(chrono::Utc::now());
    let start_ticks = ticks_since_epoch(start_time);
    (current_ticks - start_ticks) as i32
}

#[cfg(test)]
mod director_tick_tests {
    use super::ticks_since_epoch;
    use chrono::{DateTime, FixedOffset, Utc};

    #[test]
    fn clock_uses_sixty_ticks_per_second_without_millisecond_rounding() {
        for (seconds, nanos, expected) in [
            (0, 0, 0), (0, 16_000_000, 0), (0, 16_666_666, 0),
            (0, 16_666_667, 1), (0, 999_999_999, 59),
            (1, 0, 60), (60, 0, 3_600), (3_600, 0, 216_000),
            (-1, 999_999_999, -1),
        ] {
            let time = DateTime::<Utc>::from_timestamp(seconds, nanos).unwrap();
            assert_eq!(ticks_since_epoch(time), expected, "{seconds}s + {nanos}ns");
        }
    }

    #[test]
    fn tick_count_is_absolute_and_keeps_its_rate_at_current_epoch_sizes() {
        let start = DateTime::<Utc>::from_timestamp(1_800_000_000, 123_456_789).unwrap();
        let end = start + chrono::Duration::hours(1);
        assert_eq!(ticks_since_epoch(end) - ticks_since_epoch(start), 216_000);
        let offset = FixedOffset::west_opt(7 * 3_600).unwrap();
        assert_eq!(ticks_since_epoch(start), ticks_since_epoch(start.with_timezone(&offset)));
    }
}
