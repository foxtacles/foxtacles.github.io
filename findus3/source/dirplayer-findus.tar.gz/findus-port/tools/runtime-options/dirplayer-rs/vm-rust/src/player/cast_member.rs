use core::fmt;
use std::collections::HashMap;
use std::fmt::Formatter;

use itertools::Itertools;
use log::{debug, warn};

use crate::{CastMemberRef, player::symbols::{builtin::BuiltInSymbol, symbol::Symbol}};

use super::{
    bitmap::{
        bitmap::{decode_jpeg_bitmap, decompress_alpha_rle, decompress_bitmap, Bitmap, BuiltInPalette, PaletteRef},
        manager::{BitmapManager, BitmapRef},
    },
    score::Score,
    sprite::ColorRef,
    ScriptError,
};
use crate::director::{
    chunks::{cast_member::CastMemberDef, score::{ScoreChunk, ScoreChunkHeader, ScoreFrameData}, xmedia::PfrFont, xmedia::XMediaChunk, sound::SoundChunk, Chunk, cast_member::CastMemberChunk},
    enums::{
        BitmapInfo, FilmLoopInfo, FontInfo, MemberType, ScriptType, ShapeInfo, Shockwave3dInfo, TextMemberData, SoundInfo, FieldInfo, TextInfo,
    },
    lingo::script::ScriptContext,
};
use crate::player::handlers::datum_handlers::cast_member::font::{StyledSpan, TextAlignment};

#[derive(Clone)]
pub struct CastMember {
    pub number: u32,
    pub name: String,
    pub comments: String,
    pub member_type: CastMemberType,
    pub color: ColorRef,
    pub bg_color: ColorRef,
    pub reg_point: (i32, i32),
}

#[derive(Clone)]
pub enum Media {
    Field(FieldMember),
    Bitmap { bitmap: Bitmap, reg_point: (i16, i16) },
    Palette(PaletteMember),
    Sound(SoundMember),
}

#[derive(Clone)]
pub struct FieldMember {
    pub text: String,
    pub alignment: BuiltInSymbol,
    pub word_wrap: bool,
    pub font: String,
    pub font_style: String,
    pub font_size: u16,
    pub font_id: Option<u16>, // STXT font ID for lookup by ID
    /// All STXT formatting runs parsed for this field. Each run has a
    /// `start_position` (char index) and applies until the next run begins
    /// (or end of text). Director's `the textStyle of char N of member`
    /// and `member.char[N].fontStyle` resolve by walking these runs.
    /// Empty when the field has uniform styling (older parser behaviour).
    pub formatting_runs: Vec<crate::director::chunks::text::StxtFormattingRun>,
    pub text_height: u16,  // Text area height from FieldInfo (for dimension calculations)
    /// FieldInfo `max_height` (bytes 22-23) — the field's authored BOX height.
    ///
    /// This is NOT redundant with `rect_bottom - rect_top`. Director keeps
    /// `initialRect` at the height of the text the member CONTAINS, so a field
    /// authored empty and filled at runtime stores a one-line rect no matter how
    /// big its box is. Summer Resort's "sign.text" is the case: `#scroll`,
    /// initialRect 221x16 (authored empty), max_height 134 — Director displays
    /// 134. Its sibling "talk.text" was authored WITH content, so its two values
    /// coincide (156/156), which is why only one of the two ever looked wrong.
    pub max_height: u16,
    pub fixed_line_space: u16,  // Line spacing for text rendering
    pub top_spacing: i16,
    pub box_type: BuiltInSymbol,
    pub anti_alias: bool,
    pub width: u16,
    pub height: u16,  // Field member height from FieldInfo
    pub rect_left: i16,   // Initial rect from FieldInfo
    pub rect_top: i16,
    pub rect_right: i16,
    pub rect_bottom: i16,
    pub auto_tab: bool, // Tabbing order depends on sprite number order, not position on the Stage.
    pub editable: bool,
    pub border: u16,
    pub margin: u16,
    pub box_drop_shadow: u16,
    pub drop_shadow: u16,
    pub scroll_top: u16,
    pub hilite: bool,
    pub fore_color: Option<ColorRef>,  // From STXT formatting run color (>> 8)
    pub back_color: Option<ColorRef>,  // From FieldInfo bg RGB (& 0xff)
    // Runtime selection state. Convention: sel_start <= sel_end. Equal values mean caret;
    // otherwise it's a selection range. sel_anchor remembers the drag/shift origin so
    // shift+arrow and drag-to-select extend in the right direction.
    pub sel_start: i32,
    pub sel_end: i32,
    pub sel_anchor: i32,
    // Text rendering config
    pub kerning: bool,
    pub kerning_threshold: u16,
    pub use_hypertext_styles: bool,
    pub anti_alias_type: BuiltInSymbol,
    // Cast-member-attached script (Director's "BehaviorScript" export).
    // Mirrors ButtonMember/BitmapMember/ShapeMember so Field-typed buttons
    // with a member script are recognised by `is_active_sprite` and the
    // click-transparency check, instead of having clicks silently pass
    // through them.
    pub script_id: u32,
    pub member_script_ref: Option<CastMemberRef>,
}

impl Default for FieldMember {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum ButtonType {
    PushButton = 0,
    CheckBox = 1,
    RadioButton = 2,
}

impl ButtonType {
    pub fn from_raw(value: u16) -> ButtonType {
        match value {
            1 => ButtonType::CheckBox,
            2 => ButtonType::RadioButton,
            _ => ButtonType::PushButton,
        }
    }

    pub fn symbol(&self) -> BuiltInSymbol {
        match self {
            ButtonType::PushButton => BuiltInSymbol::PushButton,
            ButtonType::CheckBox => BuiltInSymbol::CheckBox,
            ButtonType::RadioButton => BuiltInSymbol::RadioButton,
        }
    }
}

#[derive(Clone)]
pub struct ButtonMember {
    pub field: FieldMember,
    pub button_type: ButtonType,
    pub hilite: bool,
    pub script_id: u32,
    pub member_script_ref: Option<CastMemberRef>,
}

/// A tab stop definition for text members.
/// Director supports #left, #center, and #right tab types.
#[derive(Clone, Debug)]
pub struct TabStop {
    pub tab_type: BuiltInSymbol,   // "left", "center", or "right"
    pub position: i32,      // pixel position from left edge
}

#[derive(Clone)]
pub struct TextMember {
    pub text: String,
    pub html_source: String,  // Original HTML string when set via html property
    pub rtf_source: String,   // Original RTF string when set via RTF property
    pub alignment: BuiltInSymbol,
    pub box_type: BuiltInSymbol,
    pub word_wrap: bool,
    pub anti_alias: bool,
    pub font: String,
    pub font_style: Vec<BuiltInSymbol>,
    pub font_size: u16,
    pub fixed_line_space: u16,
    pub top_spacing: i16,
    pub bottom_spacing: i16,
    pub width: u16,
    pub height: u16,
    /// True once Lingo explicitly sets `member.rect`/`member.height` at runtime
    /// (e.g. Habbo's Text-Wrapper does `member.rect = rect(0,0,w,h)`). Director
    /// honors such an explicit size even for `#adjust` members, and crucially
    /// `member.image.height` must then equal `member.rect.height` — otherwise the
    /// `pimage.copyPixels(member.image, dest=image-height, src=member.rect)` bake
    /// stretches the text vertically. Distinguishes the runtime-set case from a
    /// stale single-line authored height (wrap-only #adjust must still measure).
    pub rect_set_at_runtime: bool,
    /// True once Lingo has replaced the member's text at runtime (`member.text = …`,
    /// `.html`, `.rtf`). An `#adjust` member's authored width/height describe the
    /// AUTHORED layout only; once the text is rewritten Director re-adjusts the
    /// rect to the new content. SuperSonic RC's `textgenerator` is authored 513x65
    /// (2 paragraphs) and reused as a one-line label factory — trusting the stored
    /// 65 made `3d_textsprite` pick a 128-tall texture and push both HUD labels
    /// ("Time remaining", "Points") off the top of the screen.
    pub text_set_at_runtime: bool,
    pub char_spacing: i32,
    pub tab_stops: Vec<TabStop>,
    pub html_styled_spans: Vec<StyledSpan>,
    /// Per-paragraph par_info table from XMED Section 0x0007. Each
    /// entry holds line_spacing (Paige `dword270`) etc. Indexed by
    /// `par_runs[N].par_info_index`. Empty for non-XMED text members.
    pub par_infos: Vec<crate::director::chunks::xmedia_styled_text::ParInfo>,
    /// Per-text-position par_info refs from XMED Section 0x0005
    /// (par_run_key). Sorted by `position`. The active par_info for a
    /// given text offset is the one whose `position` is the largest
    /// value ≤ that offset. See `line_spacing_at()` helper.
    pub par_runs: Vec<crate::director::chunks::xmedia_styled_text::ParRun>,
    /// Hyperlink ranges from XMED Section 0x0129, as 1-based inclusive
    /// `[startChar, endChar]` pairs (Director's `the hyperlinks of member`
    /// format). Empty for members with no links.
    pub hyperlinks: Vec<(i32, i32)>,
    pub info: Option<TextInfo>,
    /// Embedded 3D world for Director's "3D Text" feature (text extrusion).
    /// Lazily initialized when 3D methods (.model(), .camera(), etc.) are called.
    pub w3d: Option<Box<Shockwave3dMember>>,
    // Runtime selection state. Convention: sel_start <= sel_end. Equal = caret;
    // otherwise selection range. sel_anchor is the drag/shift origin.
    pub sel_start: i32,
    pub sel_end: i32,
    pub sel_anchor: i32,
    /// Anti-alias method: "AutoAlias", "GrayScaleAllAlias", "SubpixelAllAlias",
    /// "GrayscaleLargerThanAlias", or "NoneAlias".
    pub anti_alias_type: BuiltInSymbol,
    // Cast-member-attached script (Director's "BehaviorScript" export).
    // See FieldMember::script_id for the rationale.
    pub script_id: u32,
    pub member_script_ref: Option<CastMemberRef>,
}

pub struct PfrBitmap {
    pub bitmap_ref: BitmapRef,
    pub char_width: u16,
    pub char_height: u16,
    pub grid_columns: u8,
    pub grid_rows: u8,
    pub char_widths: Option<Vec<u16>>,
    pub first_char: u8,
}

impl CastMember {
    pub fn new(number: u32, member_type: CastMemberType) -> CastMember {
        CastMember {
            number,
            name: "".to_string(),
            comments: String::new(),
            member_type,
            color: ColorRef::PaletteIndex(255),
            bg_color: ColorRef::PaletteIndex(0),
            reg_point: (0, 0),
        }
    }
}

/// Convert a Lingo textStyle/fontStyle string (e.g. "bold,underline",
/// "plain") into a QuickDraw style byte. bit0=bold(0x01),
/// bit1=italic(0x02), bit2=underline(0x04). "plain"/"normal"/unknown
/// tokens contribute no bits.
pub fn text_style_string_to_byte(s: &str) -> u8 {
    let mut style = 0u8;
    for part in s.split(',') {
        match part.trim().to_ascii_lowercase().as_str() {
            "bold" => style |= 0x01,
            "italic" => style |= 0x02,
            "underline" => style |= 0x04,
            _ => {}
        }
    }
    style
}

/// Ensure a formatting-run boundary exists at byte `pos` by splitting the
/// run that straddles it (cloning all props, only changing start_position).
/// No-op at pos 0 or when a boundary already exists there.
fn ensure_run_boundary(
    runs: &mut Vec<crate::director::chunks::text::StxtFormattingRun>,
    pos: u32,
) {
    if pos == 0 {
        return;
    }
    if let Some(idx) = runs.iter().rposition(|r| r.start_position <= pos) {
        if runs[idx].start_position == pos {
            return;
        }
        let mut copy = runs[idx].clone();
        copy.start_position = pos;
        runs.insert(idx + 1, copy);
    }
}

impl FieldMember {
    pub fn new() -> FieldMember {
        FieldMember {
            text: "".to_string(),
            alignment: BuiltInSymbol::Left,
            word_wrap: true,
            font: "Arial".to_string(),
            font_style: BuiltInSymbol::Plain.to_string(),
            font_size: 12,
            font_id: None,
            formatting_runs: Vec::new(),
            text_height: 100,
            max_height: 0,
            fixed_line_space: 0,
            top_spacing: 0,
            box_type: BuiltInSymbol::Adjust,
            anti_alias: false,
            width: 100,
            height: 100,
            rect_left: 0,
            rect_top: 0,
            rect_right: 100,
            rect_bottom: 100,
            auto_tab: false,
            editable: false,
            border: 0,
            margin: 0,
            box_drop_shadow: 0,
            drop_shadow: 0,
            scroll_top: 0,
            hilite: false,
            fore_color: None,
            back_color: None,
            sel_start: 0,
            sel_end: 0,
            sel_anchor: 0,
            kerning: false,
            kerning_threshold: 14,
            use_hypertext_styles: false,
            anti_alias_type: BuiltInSymbol::AutoAlias,
            script_id: 0,
            member_script_ref: None,
        }
    }

    /// Replace `text` and adjust the live caret/selection to a sensible
    /// position. When the caret was at the end of the old text, follow it
    /// to the end of the new text (handles password masks, chat-bot echoes,
    /// autocomplete, "put X into field" — all the cases where a script
    /// rewrites the text in lockstep with the user typing). Otherwise the
    /// caret stays at its byte offset, clamped to the new length, so a
    /// mid-edit refresh doesn't yank the caret to a surprising spot.
    /// Use this anywhere code mutates `field.text` outside the editor itself.
    pub fn set_text_preserving_caret(&mut self, new_text: String) {
        let old_len = self.text.len() as i32;
        let was_at_end = self.sel_start == self.sel_end && self.sel_end >= old_len;
        self.text = new_text;
        let new_len = self.text.len() as i32;
        let caret = if was_at_end { new_len } else { self.sel_end.clamp(0, new_len) };
        self.sel_start = caret;
        self.sel_end = caret;
        self.sel_anchor = caret;
    }

    /// Apply a QuickDraw style byte over the byte range [byte_start,
    /// byte_end) of this field's STXT formatting runs, splitting runs at the
    /// boundaries as needed. Director's `set the textStyle of line N of
    /// field` / `set the textStyle of field` REPLACE the style of the
    /// affected characters (they do not merge attributes). The renderer
    /// (webgl2 builds StyledSpans from these runs) and the `the textStyle
    /// of` getter both read formatting_runs, so this updates display and
    /// script reads together. The client (issue-188) movie's `markLine`
    /// handler relies on this to highlight the clicked topic line and clear
    /// the previous one.
    pub fn apply_style_to_byte_range(&mut self, byte_start: u32, byte_end: u32, new_style: u8) {
        use crate::director::chunks::text::StxtFormattingRun;
        let text_len = self.text.len() as u32;
        let end = byte_end.min(text_len);
        let start = byte_start.min(end);
        if start >= end {
            return;
        }
        // A field authored with uniform styling may have no runs; synthesize
        // a base run from the member-wide font so partial styling has
        // something to split.
        if self.formatting_runs.is_empty() {
            self.formatting_runs.push(StxtFormattingRun {
                start_position: 0,
                height: self.font_size.max(1),
                ascent: self.font_size,
                font_id: self.font_id.unwrap_or(0),
                style: text_style_string_to_byte(&self.font_style),
                font_size: self.font_size.max(1),
                color_r: 0,
                color_g: 0,
                color_b: 0,
            });
        }
        ensure_run_boundary(&mut self.formatting_runs, start);
        if end < text_len {
            ensure_run_boundary(&mut self.formatting_runs, end);
        }
        for r in self.formatting_runs.iter_mut() {
            if r.start_position >= start && r.start_position < end {
                r.style = new_style;
            }
        }
    }

    pub fn from_field_info(field_info: &FieldInfo) -> FieldMember {
        let (bg_r, bg_g, bg_b) = field_info.bg_color_rgb();
        // Director's bgpal_r/g/b are QuickDraw u16 RGB values — full
        // intensity per channel = 0xFFFF, zero = 0x0000. There is no
        // palette-index encoding in this struct. Verified against figure8
        // (Batman Supersonic): white-bg fields store (0xFFFF,0xFFFF,0xFFFF),
        // black-bg fields like `timerbox` store (0x0000,0x0000,0x0000).
        // An earlier heuristic remapped all-zero bgpal to PaletteIndex(0)
        // because it was thought to mean "authored white via System-Win
        // palette index 0"; that turned out to be a misreading and made
        // genuinely-black fields render white.
        let back_color = Some(ColorRef::Rgb(bg_r, bg_g, bg_b));
        FieldMember {
            text: "".to_string(),
            alignment: field_info.alignment(),
            word_wrap: field_info.wordwrap(),
            font: field_info.font_name().to_string(),
            font_style: BuiltInSymbol::Plain.to_string(),
            font_size: 12,
            font_id: None,
            formatting_runs: Vec::new(),
            text_height: field_info.text_height,  // Text area height for dimension calculations
            max_height: field_info.max_height,
            fixed_line_space: 0,  // Use default line spacing for text rendering
            top_spacing: field_info.scroll as i16,
            box_type: field_info.box_type(),
            anti_alias: false,
            width: field_info.width(),  // Calculated from rect
            height: (field_info.text_height + 2 * field_info.border as u16 + 2 * field_info.margin as u16),  // Member height: text_height + borders + margins
            rect_left: field_info.rect_left,
            rect_top: field_info.rect_top,
            rect_right: field_info.rect_right,
            rect_bottom: field_info.rect_bottom,
            auto_tab: field_info.auto_tab(),
            editable: field_info.editable(),
            border: field_info.border as u16,
            margin: field_info.margin as u16,
            box_drop_shadow: field_info.box_drop_shadow as u16,
            drop_shadow: field_info.text_shadow as u16,
            scroll_top: field_info.scroll,
            hilite: false,
            fore_color: None, // Set later from STXT formatting run
            back_color,
            sel_start: 0,
            sel_end: 0,
            sel_anchor: 0,
            kerning: false,
            kerning_threshold: 14,
            use_hypertext_styles: false,
            anti_alias_type: BuiltInSymbol::AutoAlias,
            script_id: 0,
            member_script_ref: None,
        }
    }
}

impl TextMember {
    /// Replace `text` and adjust caret/selection. See FieldMember docs.
    pub fn set_text_preserving_caret(&mut self, new_text: String) {
        let old_len = self.text.len() as i32;
        let was_at_end = self.sel_start == self.sel_end && self.sel_end >= old_len;
        self.text = new_text;
        let new_len = self.text.len() as i32;
        let caret = if was_at_end { new_len } else { self.sel_end.clamp(0, new_len) };
        self.sel_start = caret;
        self.sel_end = caret;
        self.sel_anchor = caret;
    }

    pub fn new() -> TextMember {
        TextMember {
            text: "".to_string(),
            html_source: String::new(),
            rtf_source: String::new(),
            alignment: BuiltInSymbol::Left,
            word_wrap: true,
            font: "Arial".to_string(),
            font_style: vec![BuiltInSymbol::Plain],
            font_size: 12,
            fixed_line_space: 0,
            top_spacing: 0,
            bottom_spacing: 0,
            box_type: BuiltInSymbol::Adjust,
            anti_alias: false,
            width: 100,
            height: 20,
            rect_set_at_runtime: false,
            text_set_at_runtime: false,
            char_spacing: 0,
            tab_stops: Vec::new(),
            html_styled_spans: Vec::new(),
            par_infos: Vec::new(),
            par_runs: Vec::new(),
            hyperlinks: Vec::new(),
            info: None,
            w3d: None,
            sel_start: 0,
            sel_end: 0,
            sel_anchor: 0,
            anti_alias_type: BuiltInSymbol::AutoAlias,
            script_id: 0,
            member_script_ref: None,
        }
    }

    /// Ensure the embedded 3D world is initialized for 3D text operations.
    /// Uses TextInfo's 3TEX section for camera, lights, and material colors.
    pub fn ensure_w3d(&mut self) {
        if self.w3d.is_some() {
            return;
        }
        use crate::director::chunks::w3d::types::*;
        use crate::director::enums::TextInfo;
        let mut scene = CastMember::create_empty_w3d_scene();
        let ti = self.info.as_ref();

        // Use TextInfo 3TEX colors for lighting, fall back to text foreground color
        let (cr, cg, cb) = self.html_styled_spans.first()
            .and_then(|s| s.style.color)
            .map(|c| (
                ((c >> 16) & 0xFF) as u8,
                ((c >> 8) & 0xFF) as u8,
                (c & 0xFF) as u8,
            ))
            .unwrap_or((255, 255, 255));
        let (dir_r, dir_g, dir_b) = ti
            .map(|i| TextInfo::color_to_rgb(i.directional_color))
            .unwrap_or((cr, cg, cb));
        let (amb_r, amb_g, amb_b) = ti
            .map(|i| TextInfo::color_to_rgb(i.ambient_color))
            .unwrap_or((64, 64, 64));
        let (spec_r, spec_g, spec_b) = ti
            .map(|i| TextInfo::color_to_rgb(i.specular_color))
            .unwrap_or((34, 34, 34));
        let reflectivity = ti.map(|i| i.reflectivity as f32 / 100.0).unwrap_or(0.3);

        // Set material from TextInfo colors
        scene.materials.push(W3dMaterial {
            name: BuiltInSymbol::TextMaterial.into(),
            diffuse: [0.0, 0.0, 0.0, 1.0], // Director text3D defaults diffuseColor to #000000
            ambient: [amb_r as f32 / 255.0, amb_g as f32 / 255.0, amb_b as f32 / 255.0, 1.0],
            emissive: [0.0, 0.0, 0.0, 1.0],
            specular: [spec_r as f32 / 255.0, spec_g as f32 / 255.0, spec_b as f32 / 255.0, 1.0],
            reflectivity,
            opacity: 1.0,
            shininess: 50.0,
        });
        if let Some(shader) = scene.shaders.first_mut() {
            shader.material_name = BuiltInSymbol::TextMaterial.into();
        }

        // Update directional light color from TextInfo
        if let Some(light) = scene.lights.iter_mut().find(|l| l.name == BuiltInSymbol::DefaultDirectional) {
            light.color = [dir_r as f32 / 255.0, dir_g as f32 / 255.0, dir_b as f32 / 255.0];
        }
        if let Some(light) = scene.lights.iter_mut().find(|l| l.name == BuiltInSymbol::DefaultAmbient) {
            light.color = [amb_r as f32 / 255.0, amb_g as f32 / 255.0, amb_b as f32 / 255.0];
        }

        // Apply directionalPreset to light node transform (3D Z-up version)
        if let Some(ti) = ti {
            if ti.directional_preset > 0 && ti.directional_preset <= 9 {
                if let Some(light_node) = scene.nodes.iter_mut().find(|n| n.name == BuiltInSymbol::DefaultDirectional) {
                    light_node.transform = Self::directional_preset_to_transform_3d(ti.directional_preset);
                }
            }
        }

        // Set camera position from TextInfo.
        // When TextInfo stores x=0,y=0 (default), Director auto-computes the camera
        // to center the text box in the viewport using the default FOV and aspect ratio.
        let default_fov = 34.516_f32;
        let cam_pos: Option<(f32, f32, f32)> = ti
            .map(|i| {
                let (mut px, mut py, mut pz) = (i.camera_position_x, i.camera_position_y, i.camera_position_z);
                if px == 0.0 && py == 0.0 {
                    // Auto-compute: center camera on text box
                    let w = self.width as f32;
                    let h = self.height as f32;
                    let aspect = w / h.max(1.0);
                    let v_fov_rad = (default_fov / 2.0).to_radians();
                    let h_half_fov = (v_fov_rad.tan() * aspect).atan();
                    px = w / 2.0;
                    py = h / 2.0;
                    pz = (w / 2.0) / h_half_fov.tan();
                }
                (px, py, pz)
            })
            .filter(|&(x, y, z)| x != 0.0 || y != 0.0 || z != 0.0);
        let cam_rot: Option<(f32, f32, f32)> = ti
            .map(|i| (i.camera_rotation_x, i.camera_rotation_y, i.camera_rotation_z));
        if let Some((px, py, pz)) = cam_pos {
            // Override DefaultView camera transform with TextInfo values
            if let Some(cam_node) = scene.nodes.iter_mut().find(|n| n.name == BuiltInSymbol::DefaultView) {
                // Build transform from position (rotation applied if non-zero)
                let (rx, ry, rz) = cam_rot.unwrap_or((0.0, 0.0, 0.0));
                let rx_rad = (-rx as f64).to_radians();
                let ry_rad = (-ry as f64).to_radians();
                let rz_rad = (-rz as f64).to_radians();
                let (sx, cx) = (rx_rad.sin(), rx_rad.cos());
                let (sy, cy) = (ry_rad.sin(), ry_rad.cos());
                let (sz, cz) = (rz_rad.sin(), rz_rad.cos());
                cam_node.transform = [
                    (cy*cz) as f32, (cy*sz) as f32, (-sy) as f32, 0.0,
                    (sx*sy*cz - cx*sz) as f32, (sx*sy*sz + cx*cz) as f32, (sx*cy) as f32, 0.0,
                    (cx*sy*cz + sx*sz) as f32, (cx*sy*sz - sx*cz) as f32, (cx*cy) as f32, 0.0,
                    px, py, pz, 1.0,
                ];
                // Text3D is rendered into a dynamically sized sprite/FBO. Using the
                // static empty-world 640x480 viewport here distorts the projection
                // and makes the text appear much closer than in Director.
                cam_node.screen_width = 0;
                cam_node.screen_height = 0;
            }
        }

        // Model resource for extruded text — mesh populated by ensure_text3d()
        scene.model_resources.insert(BuiltInSymbol::Text.into(), ModelResourceInfo {
            name: BuiltInSymbol::Text.into(),
            ..Default::default()
        });
        scene.nodes.push(W3dNode {
            name: BuiltInSymbol::Text.into(),
            node_type: W3dNodeType::Model,
            parent_name: BuiltInSymbol::World.into(),
            resource_name: BuiltInSymbol::Text.into(),
            model_resource_name: BuiltInSymbol::Text.into(),
            shader_name: BuiltInSymbol::DefaultShader.into(),
            transform: [1.0,0.0,0.0,0.0, 0.0,1.0,0.0,0.0, 0.0,0.0,1.0,0.0, 0.0,0.0,0.0,1.0],
            visibility: 1,
            near_plane: 1.0, far_plane: 10000.0, fov: 30.0,
            screen_width: 640, screen_height: 480,
        });

        let info = Shockwave3dInfo {
            loops: false,
            duration: 0,
            direct_to_stage: ti.map_or(false, |i| i.direct_to_stage),
            animation_enabled: ti.map_or(false, |i| i.display_mode == 1), // display_mode 1 = #mode3d
            preload: ti.map_or(false, |i| i.save_bitmap),
            reg_point: ti.map_or((0, 0), |i| (i.reg_x, i.reg_y)),
            default_rect: (0, 0, self.width as i32, self.height as i32),
            camera_position: cam_pos,
            camera_rotation: cam_rot.filter(|&(x, y, z)| x != 0.0 || y != 0.0 || z != 0.0),
            bg_color: None, // TODO: find bgColor field in TextInfo
            ambient_color: ti.map(|i| {
                let (r, g, b) = crate::director::enums::TextInfo::color_to_rgb(i.ambient_color);
                (r, g, b)
            }),
        };
        let rc_scene = std::rc::Rc::new(scene);
        let runtime_state = Shockwave3dRuntimeState::from_info(&info, Some(&rc_scene));
        self.w3d = Some(Box::new(Shockwave3dMember {
            info,
            w3d_data: Vec::new(),
            source_scene: Some(rc_scene.clone()),
            parsed_scene: Some(rc_scene),
            runtime_state,
            converted_from_text: false,
            text3d_state: ti.map(|i| Text3dState {
                tunnel_depth: i.tunnel_depth.max(1) as f32,
                smoothness: i.smoothness,
                bevel_depth: i.bevel_depth as f32,
                bevel_type: i.bevel_type,
                display_face: i.display_face,
                display_mode: i.display_mode,
                diffuse_color: (0, 0, 0),
            }),
            text3d_source: None,
        }));
    }

    /// Build a rotation matrix for the DefaultDirectional light node
    /// from a directionalPreset value (1-9).
    ///
    /// The mesh front-face normal is (0,0,-1) and edge normals are inverted
    /// (top edge = (0,-1,0), etc.) because of face winding conventions.
    /// L (surface-to-light) must have matching signs for dot(N,L)>0.
    pub(crate) fn directional_preset_to_transform(preset: u32) -> [f32; 16] {
        // L direction: x component from left/right, y from top/bottom, z always -1 for front face
        let (lx, ly): (f32, f32) = match preset {
            1 => (-1.0, -1.0), // topLeft
            2 => ( 0.0, -1.0), // topCenter
            3 => ( 1.0, -1.0), // topRight
            4 => (-1.0,  0.0), // middleLeft
            5 => ( 0.0,  0.0), // middleCenter
            6 => ( 1.0,  0.0), // middleRight
            7 => (-1.0,  1.0), // bottomLeft
            8 => ( 0.0,  1.0), // bottomCenter
            9 => ( 1.0,  1.0), // bottomRight
            _ => return [1.0,0.0,0.0,0.0, 0.0,1.0,0.0,0.0, 0.0,0.0,1.0,0.0, 0.0,0.0,0.0,1.0],
        };
        let lz: f32 = -1.0;
        let len = (lx * lx + ly * ly + lz * lz).sqrt();
        let l = [lx / len, ly / len, lz / len];
        // Z axis of transform = -L (shader extracts -Z as light direction)
        let z = [-l[0], -l[1], -l[2]];
        // Build orthonormal basis: X = normalize(up × Z), Y = Z × X
        let up = if z[1].abs() < 0.9 { [0.0, 1.0, 0.0] } else { [1.0, 0.0, 0.0] };
        let mut x = [
            up[1] * z[2] - up[2] * z[1],
            up[2] * z[0] - up[0] * z[2],
            up[0] * z[1] - up[1] * z[0],
        ];
        let xlen = (x[0] * x[0] + x[1] * x[1] + x[2] * x[2]).sqrt();
        x = [x[0] / xlen, x[1] / xlen, x[2] / xlen];
        let y = [
            z[1] * x[2] - z[2] * x[1],
            z[2] * x[0] - z[0] * x[2],
            z[0] * x[1] - z[1] * x[0],
        ];
        [
            x[0], x[1], x[2], 0.0,
            y[0], y[1], y[2], 0.0,
            z[0], z[1], z[2], 0.0,
            0.0,  0.0,  0.0,  1.0,
        ]
    }

    /// 3D directional preset: Z-up world space.
    /// "top" = +Z, "left" = -X, light has forward component toward -Y.
    pub(crate) fn directional_preset_to_transform_3d(preset: u32) -> [f32; 16] {
        let (lx, lz): (f32, f32) = match preset {
            1 => (-1.0,  1.0), 2 => ( 0.0,  1.0), 3 => ( 1.0,  1.0),
            4 => (-1.0,  0.0), 5 => ( 0.0,  0.0), 6 => ( 1.0,  0.0),
            7 => (-1.0, -1.0), 8 => ( 0.0, -1.0), 9 => ( 1.0, -1.0),
            _ => return [1.0,0.0,0.0,0.0, 0.0,1.0,0.0,0.0, 0.0,0.0,1.0,0.0, 0.0,0.0,0.0,1.0],
        };
        let ly: f32 = -0.75;
        let len = (lx*lx + ly*ly + lz*lz).sqrt();
        let l = [lx/len, ly/len, lz/len];
        let z = [l[0], l[1], l[2]];
        let up = if z[2].abs() < 0.9 { [0.0,0.0,1.0] } else { [0.0,1.0,0.0] };
        let mut x = [up[1]*z[2]-up[2]*z[1], up[2]*z[0]-up[0]*z[2], up[0]*z[1]-up[1]*z[0]];
        let xl = (x[0]*x[0]+x[1]*x[1]+x[2]*x[2]).sqrt();
        x = [x[0]/xl, x[1]/xl, x[2]/xl];
        let y = [z[1]*x[2]-z[2]*x[1], z[2]*x[0]-z[0]*x[2], z[0]*x[1]-z[1]*x[0]];
        [x[0],x[1],x[2],0.0, y[0],y[1],y[2],0.0, z[0],z[1],z[2],0.0, 0.0,0.0,0.0,1.0]
    }

    pub fn has_html_styling(&self) -> bool {
        !self.html_styled_spans.is_empty()
    }

    pub fn get_text_content(&self) -> &str {
        if self.has_html_styling() {
            // Extract plain text from HTML spans
            &self.text
        } else {
            &self.text
        }
    }
}

#[derive(Clone)]
pub struct ScriptMember {
    pub script_id: u32,
    pub script_type: ScriptType,
    pub name: String,
}

#[derive(Clone, Default)]
pub struct BitmapMember {
    pub image_ref: BitmapRef,
    pub reg_point: (i16, i16),
    pub script_id: u32,
    pub member_script_ref: Option<CastMemberRef>,
    pub info: BitmapInfo,
}

#[derive(Clone, Debug)]
pub struct PaletteMember {
    pub colors: Vec<(u8, u8, u8)>,
}

// `VectorShapeVertex` is defined in `crate::director::enums` and re-exported
// here so existing call sites (rasterizer, Lingo handlers) can continue to
// import it from `cast_member::*`. The FLSH payload parser is also there
// (as `VectorShapeInfo::from(&[u8])`) — the rest of player code keeps using
// this flat `VectorShapeMember` (which adds the runtime-computed bbox on
// top of the parsed `VectorShapeInfo`).
pub use crate::director::enums::VectorShapeVertex;

#[derive(Clone, Debug)]
pub struct VectorShapeMember {
    pub stroke_color: (u8, u8, u8),
    pub fill_color: (u8, u8, u8),
    pub bg_color: (u8, u8, u8),
    pub end_color: (u8, u8, u8),
    pub stroke_width: f32,
    pub fill_mode: u32,     // 0=none, 1=solid, 2=gradient
    pub closed: bool,
    pub vertices: Vec<VectorShapeVertex>,
    /// Bounding box computed from vertices + control points + stroke padding.
    /// Used by the rasterizer / image getter — Director's `member.width` and
    /// `member.height` come from `member_width` / `member_height` (the FLSH
    /// header's authored values), not this.
    pub bbox_left: f32,
    pub bbox_top: f32,
    pub bbox_right: f32,
    pub bbox_bottom: f32,
    /// Authored member rect from the FLSH header (offsets 0x20 / 0x24).
    /// `member.rect`, `.width`, `.height` should come from these — they
    /// match Director's report exactly, while a vertex-derived bbox is off
    /// by ~1 due to stroke padding rounding.
    pub member_width: u32,
    pub member_height: u32,
    // ---- Display / fill / origin properties surfaced via Lingo getters.
    // Confirmed offsets from triangulating two FLSH payloads (figure8
    // members #9 and #13 / Slider Groove). Enum / bool fields are still
    // mapped to defaults until a third payload disambiguates them.
    pub reg_point: (i16, i16),    // FLSH 0x14 / 0x10  (x / y)
    pub gradient_type: BuiltInSymbol,    // default "linear"  (FLSH offset TBD)
    pub fill_scale: f32,          // FLSH 0x38, default 100.0
    pub fill_direction: f32,      // FLSH 0x3C, degrees, default 0.0
    pub fill_offset: (i32, i32),  // FLSH 0x40 / 0x44, default (0, 0)
    pub fill_cycles: i32,         // default 1  (FLSH offset TBD)
    pub scale_mode: BuiltInSymbol,       // default "autoSize"  (FLSH offset TBD)
    pub scale: f32,               // FLSH 0x50, percent, default 100.0
    pub antialias: bool,          // default true  (FLSH offset TBD)
    pub center_reg_point: bool,   // default false (FLSH offset TBD)
    pub reg_point_vertex: i32,    // default 0     (FLSH offset TBD)
    pub direct_to_stage: bool,    // default false (FLSH offset TBD)
    pub origin_mode: BuiltInSymbol,      // default "center" (FLSH offset TBD)
    /// Count of trailing `#newCurve` markers in the vertex list (sub-path
    /// breaks). Preserved so the `vertexList` getter round-trips Director's
    /// output (e.g. ui_pratbubbla has 4).
    pub new_curve_count: usize,
}

impl VectorShapeMember {
    /// Director's `member.width` for vector shapes — the authored member
    /// width from the FLSH header (offset 0x24). We previously derived this
    /// from the vertex bounding box, which was off by 1 due to stroke
    /// padding. Falls back to bbox_right - bbox_left if member_width is 0
    /// (synthesized members from Lingo `new(#vectorShape)`).
    pub fn width(&self) -> f32 {
        if self.member_width > 0 {
            self.member_width as f32
        } else {
            self.bbox_right - self.bbox_left
        }
    }
    pub fn height(&self) -> f32 {
        if self.member_height > 0 {
            self.member_height as f32
        } else {
            self.bbox_bottom - self.bbox_top
        }
    }
    /// The vertex-bounding-box dimensions. Used by the rasterizer to size
    /// the bitmap that backs `member.image`.
    pub fn bbox_width(&self) -> f32 { self.bbox_right - self.bbox_left }
    pub fn bbox_height(&self) -> f32 { self.bbox_bottom - self.bbox_top }

    /// An empty vector shape, as produced by Lingo `new(#vectorShape)`
    /// (Director 11.5 Scripting Dictionary). No vertices yet; the script
    /// populates them via `addVertex` and sets fill/stroke/gradient props.
    /// `member_width`/`member_height` stay 0 so `width()`/`height()` fall
    /// back to the (vertex-derived) bbox once vertices are added.
    pub fn new() -> VectorShapeMember {
        VectorShapeMember {
            stroke_color: (0, 0, 0),
            fill_color: (0, 0, 0),
            bg_color: (255, 255, 255),
            end_color: (0, 0, 0),
            stroke_width: 1.0,
            fill_mode: 0, // #none
            closed: false,
            vertices: Vec::new(),
            bbox_left: 0.0,
            bbox_top: 0.0,
            bbox_right: 0.0,
            bbox_bottom: 0.0,
            member_width: 0,
            member_height: 0,
            reg_point: (0, 0),
            gradient_type: BuiltInSymbol::Linear,
            fill_scale: 100.0,
            fill_direction: 0.0,
            fill_offset: (0, 0),
            fill_cycles: 1,
            scale_mode: BuiltInSymbol::ShowAll,
            scale: 100.0,
            antialias: true,
            center_reg_point: false,
            reg_point_vertex: 0,
            direct_to_stage: false,
            origin_mode: BuiltInSymbol::Center,
            new_curve_count: 0,
        }
    }

    /// Recompute the bounding box from the current vertices + Bezier
    /// control points + stroke padding. Must be called after any runtime
    /// mutation of `vertices` (e.g. `addVertex`) so the `.image` rasterizer
    /// and `width()`/`height()` fallbacks stay correct. Mirrors the bbox
    /// computation in `From<VectorShapeInfo>`.
    pub fn recompute_bbox(&mut self) {
        let mut left = f32::MAX;
        let mut top = f32::MAX;
        let mut right = f32::MIN;
        let mut bottom = f32::MIN;
        for v in &self.vertices {
            for &(cx, cy) in &[
                (v.x, v.y),
                (v.x + v.handle1_x, v.y + v.handle1_y),
                (v.x + v.handle2_x, v.y + v.handle2_y),
            ] {
                left = left.min(cx);
                top = top.min(cy);
                right = right.max(cx);
                bottom = bottom.max(cy);
            }
        }
        if self.vertices.is_empty() {
            self.bbox_left = 0.0;
            self.bbox_top = 0.0;
            self.bbox_right = 0.0;
            self.bbox_bottom = 0.0;
            return;
        }
        let pad = self.stroke_width / 2.0;
        self.bbox_left = left - pad;
        self.bbox_top = top - pad;
        self.bbox_right = right + pad;
        self.bbox_bottom = bottom + pad;
    }
}

impl From<crate::director::enums::VectorShapeInfo> for VectorShapeMember {
    /// Build a runtime `VectorShapeMember` from a parsed FLSH
    /// `VectorShapeInfo`. The static fields are copied over verbatim; the
    /// (bbox_left, bbox_top, bbox_right, bbox_bottom) bounding box is
    /// computed here from the vertices + Bezier control points + stroke
    /// padding (used by the rasterizer to size the off-screen bitmap that
    /// backs `member.image`).
    fn from(info: crate::director::enums::VectorShapeInfo) -> Self {
        let mut bbox_left = f32::MAX;
        let mut bbox_top = f32::MAX;
        let mut bbox_right = f32::MIN;
        let mut bbox_bottom = f32::MIN;
        for v in &info.vertices {
            bbox_left = bbox_left.min(v.x);
            bbox_top = bbox_top.min(v.y);
            bbox_right = bbox_right.max(v.x);
            bbox_bottom = bbox_bottom.max(v.y);
            // include absolute control points (vertex + handle offsets)
            for &(cx, cy) in &[
                (v.x + v.handle1_x, v.y + v.handle1_y),
                (v.x + v.handle2_x, v.y + v.handle2_y),
            ] {
                bbox_left = bbox_left.min(cx);
                bbox_top = bbox_top.min(cy);
                bbox_right = bbox_right.max(cx);
                bbox_bottom = bbox_bottom.max(cy);
            }
        }
        let pad = info.stroke_width / 2.0;
        bbox_left -= pad;
        bbox_top -= pad;
        bbox_right += pad;
        bbox_bottom += pad;
        if info.vertices.is_empty() {
            bbox_left = 0.0;
            bbox_top = 0.0;
            bbox_right = 0.0;
            bbox_bottom = 0.0;
        }
        VectorShapeMember {
            stroke_color: info.stroke_color,
            fill_color: info.fill_color,
            bg_color: info.bg_color,
            end_color: info.end_color,
            stroke_width: info.stroke_width,
            fill_mode: info.fill_mode,
            closed: info.closed,
            vertices: info.vertices,
            bbox_left,
            bbox_top,
            bbox_right,
            bbox_bottom,
            member_width: info.member_width,
            member_height: info.member_height,
            reg_point: info.reg_point,
            gradient_type: info.gradient_type,
            fill_scale: info.fill_scale,
            fill_direction: info.fill_direction,
            fill_offset: info.fill_offset,
            fill_cycles: info.fill_cycles,
            scale_mode: info.scale_mode,
            scale: info.scale,
            antialias: info.antialias,
            center_reg_point: info.center_reg_point,
            reg_point_vertex: info.reg_point_vertex,
            direct_to_stage: info.direct_to_stage,
            origin_mode: info.origin_mode,
            new_curve_count: info.new_curve_count,
        }
    }
}

#[derive(Clone)]
pub struct ShapeMember {
    pub shape_info: ShapeInfo,
    pub script_id: u32,
    pub member_script_ref: Option<CastMemberRef>,
}

impl PaletteMember {
    pub fn new() -> PaletteMember {
        PaletteMember {
            colors: vec![(0, 0, 0); 256],
        }
    }
}

#[derive(Clone)]
pub struct FilmLoopMember {
    pub info: FilmLoopInfo,
    pub score_chunk: ScoreChunk,
    pub score: Score,
    pub current_frame: u32,
    /// The bounding rectangle encompassing all sprites in the filmloop.
    /// Used to translate sprite coordinates when rendering.
    pub initial_rect: super::geometry::IntRect,
    /// Cached total frame count (computed once from channel_initialization_data, sprite_spans, and keyframes).
    pub cached_total_frames: Option<u32>,
}

/// A Linked Movie cast member (`#movie`) — references an external Director
/// movie (.dir/.dcr) that plays inside a sprite (Director 11.5 Scripting
/// Dictionary "Linked Movie" media type). Created at runtime via
/// `new(#movie)`, linked via `member.fileName = <path/url>`, and played by
/// assigning it to a sprite. The parsed movie is held behind an `Rc` so the
/// member stays cheap to clone and the (large) file isn't deep-copied.
///
/// Phase 1 stores the parsed `DirectorFile` + the linked-movie properties;
/// nested score advancement + script execution + compositing into the host
/// sprite are Phase 2 (modelled on `FilmLoopMember`).
#[derive(Clone)]
pub struct MovieMember {
    /// The linked file path/URL (`the fileName of member`).
    pub file_name: String,
    /// Whether the linked movie's Lingo runs (`scriptsEnabled`). Director
    /// defaults linked-movie scripts OFF; callers opt in (DGS sets it to 1).
    pub scripts_enabled: bool,
    /// Crop (TRUE) vs scale-to-fit (FALSE) within the sprite rect.
    pub crop: bool,
    /// Center the movie within the sprite rect when cropping.
    pub center: bool,
    /// Play the linked movie's sound.
    pub sound: bool,
    /// Loop the linked movie's playback.
    pub loops: bool,
    /// Member width/height (from the authored rect: right-left, bottom-top).
    pub width: u16,
    pub height: u16,
    pub reg_point: (i16, i16),
    /// Raw .dir/.dcr bytes of the linked movie, captured by the `fileName`
    /// setter from the net preload cache. `None` until linked. Held behind an
    /// `Rc` so the member stays cheap to clone; the live nested `Movie` is
    /// parsed/built from these bytes at activation into the player's nested
    /// registry (a built `Movie` isn't `Clone`, so it can't live on the member).
    pub bytes: Option<std::rc::Rc<Vec<u8>>>,
    /// Base URL the linked movie's own relative references resolve against
    /// (derived from the resolved net-task URL at fileName time).
    pub base_url: String,
}

impl MovieMember {
    pub fn new() -> Self {
        Self {
            file_name: String::new(),
            scripts_enabled: false,
            crop: true,
            center: true,
            sound: true,
            loops: true,
            width: 0,
            height: 0,
            reg_point: (0, 0),
            bytes: None,
            base_url: String::new(),
        }
    }
}

#[derive(Clone)]
pub struct SoundMember {
    pub info: SoundInfo,
    pub sound: SoundChunk,
    /// Cue point times in milliseconds, parsed from the member's `cupt`
    /// child chunk. Exposed to Lingo as `member.cuePointTimes`. The
    /// SoundChannel reads these on `queue()` so playback can fire
    /// `on cuePassed` as the playhead crosses each entry.
    pub cue_point_times: Vec<u32>,
    /// Names parallel to `cue_point_times`. Empty string when the
    /// authoring tool didn't assign one.
    pub cue_point_names: Vec<String>,
}

#[derive(Clone)]
pub struct FlashMember {
    pub data: Vec<u8>,
    pub reg_point: (i16, i16),
    pub flash_info: Option<crate::director::enums::FlashInfo>,
}

impl FlashMember {
    /// Returns the effective stage rect (left, top, right, bottom) for this
    /// Flash member. Director caches the rect in the FLSH chunk's FlashInfo,
    /// but for some members it's left as 0,0,0,0 — fall back to parsing the
    /// SWF header so width/height aren't reported as zero.
    pub fn effective_rect(&self) -> (i32, i32, i32, i32) {
        let cached = self.flash_info.as_ref().map(|fi| fi.flash_rect).unwrap_or((0, 0, 0, 0));
        if cached != (0, 0, 0, 0) {
            return cached;
        }
        if let Some((w, h)) = CastMember::parse_swf_dimensions(&self.data) {
            return (0, 0, w as i32, h as i32);
        }
        cached
    }
}

#[derive(Clone, Debug)]
pub struct Text3dState {
    pub tunnel_depth: f32,
    pub smoothness: u32,
    pub bevel_depth: f32,
    pub bevel_type: u32,
    pub display_face: i32,
    pub display_mode: u32,
    pub diffuse_color: (u8, u8, u8), // Director defaults to #000000
}

#[derive(Clone, Debug)]
pub struct Text3dSource {
    pub spans: Vec<StyledSpan>,
    pub font_size: u16,
    pub width: u16,
    pub height: u16,
    pub alignment: BuiltInSymbol,
    pub word_wrap: bool,
    pub fixed_line_space: u16,
    pub top_spacing: i16,
    pub bottom_spacing: i16,
    pub tab_stops: Vec<TabStop>,
    pub native_alpha_mesh: bool,
}

#[derive(Clone, Debug)]
pub struct Shockwave3dMember {
    pub info: Shockwave3dInfo,
    pub w3d_data: Vec<u8>,
    pub source_scene: Option<std::rc::Rc<crate::director::chunks::w3d::types::W3dScene>>,
    pub parsed_scene: Option<std::rc::Rc<crate::director::chunks::w3d::types::W3dScene>>,
    pub runtime_state: Shockwave3dRuntimeState,
    /// True if this member was converted from a Text member (3D Text feature).
    /// Used to report member.type as #text instead of #shockwave3d.
    pub converted_from_text: bool,
    /// Live Text3D properties retained after Text -> Shockwave3d conversion.
    pub text3d_state: Option<Text3dState>,
    /// Source data retained so native-font Text3D meshes can be rebuilt.
    pub text3d_source: Option<Text3dSource>,
}

impl Shockwave3dMember {
    /// Get mutable access to the parsed scene (uses Rc::make_mut for copy-on-write)
    pub fn scene_mut(&mut self) -> Option<&mut crate::director::chunks::w3d::types::W3dScene> {
        self.parsed_scene.as_mut().map(|rc| std::rc::Rc::make_mut(rc))
    }

    /// Load `model_name`'s authored keyframe motion into its keyframePlayer if the
    /// player has nothing loaded yet.
    ///
    /// Director pre-loads each model's keyframePlayer with the keyframe motion
    /// authored for that node, so a script can drive it with `currentTime` /
    /// `playRate` without ever calling `play()`. dirplayer only ever set
    /// `current_motion` in `play()`, so touching a keyframePlayer materialized an
    /// UNBOUND player — and once two exist the renderer switches to its per-model
    /// path (`bones_players.len() > 1`), where an unbound player is skipped. Every
    /// animation in the member then froze: AreaZero's menu ran camera 1's fly-through
    /// once (off the member-level auto-play) and stuck the moment the script touched
    /// camera 2's carrier node.
    ///
    /// Falls back to the member-level motion so a model with no motion of its own
    /// still binds to something rather than poisoning the whole member.
    pub fn bind_keyframe_motion(&mut self, model_name: Symbol) {
        // Symbol identity is already case-insensitive (the interner lowercases),
        // so the explicit case folding this needed while names were Strings is
        // redundant — plain `==` is the case-insensitive compare.
        if self
            .runtime_state
            .bones_players
            .get(&model_name)
            .is_some_and(|bp| bp.current_motion.is_some())
        {
            return;
        }
        let resolved = self.parsed_scene.as_ref().and_then(|scene| {
            // Is `name` the model itself, or somewhere in its subtree? An exporter
            // that hoists a node's animation onto a carrier names the track after the
            // ORIGINAL node, which ends up a child of the carrier: AreaZero's
            // "Dummy Animation Node Camera1" carries motion "Camera1-Key", whose one
            // track is named "Camera1" — the camera parented under that dummy.
            let in_subtree = |name: Symbol| -> bool {
                if name == model_name {
                    return true;
                }
                let mut current = name;
                for _ in 0..20 {
                    let parent = match scene.nodes.iter().find(|n| n.name == current) {
                        Some(n) => n.parent_name.clone(),
                        None => return false,
                    };
                    if parent.is_empty() || parent == BuiltInSymbol::World {
                        return false;
                    }
                    if parent == model_name {
                        return true;
                    }
                    current = parent;
                }
                false
            };
            // A single-track object keyframe drives one node; prefer an exact name
            // match, then anything in the model's subtree.
            scene
                .motions
                .iter()
                .find(|m| m.tracks.len() == 1 && m.tracks[0].bone_name == model_name)
                .or_else(|| scene.motions.iter()
                    .find(|m| m.tracks.len() == 1 && in_subtree(m.tracks[0].bone_name)))
                // Otherwise fall back to a motion named after the model.
                .or_else(|| scene.motions.iter().find(|m| m.name == model_name))
                .map(|m| m.name.clone())
        });
        let motion = match resolved.or_else(|| self.runtime_state.current_motion.clone()) {
            Some(m) => m,
            None => return,
        };
        let loops = self.info.loops;
        let bp = self.runtime_state.bones_player_mut(model_name);
        bp.current_motion = Some(motion);
        bp.animation_playing = true;
        bp.animation_loop = loops;
        bp.motion_ended = false;
    }
}

#[derive(Clone, Debug)]
pub struct QueuedMotion {
    pub name: Symbol,
    pub looped: bool,
    pub start_time: f32,   // seconds
    pub end_time: f32,     // seconds, -1.0 = full duration
    pub scale: f32,
    pub offset: f32,       // seconds, -1.0 = #synchronized
}

/// Per-MODEL bonesPlayer/keyframePlayer animation state.
///
/// Director keeps animation state PER MODEL (each model carries its own
/// #bonesPlayer modifier), but the single fields on `Shockwave3dRuntimeState`
/// are per-MEMBER. When several skinned models are cloned into one 3D member
/// (e.g. Rasterwerks clones 5 bots into the single G3D world), they all shared
/// one motion + one clock — the last `play()` won, so every bot was posed with
/// the same motion's root rotation (wrong facing, frozen clock). The renderer
/// skinning and the `bone[]` getters read this per-model map instead; the
/// member-level single fields remain for the keyframe (motion_transforms) path.
#[derive(Clone, Debug)]
pub struct BonesPlayerState {
    pub animation_time: f32,
    pub animation_playing: bool,
    pub current_motion: Option<Symbol>,
    pub play_rate: f32,
    pub animation_loop: bool,
    pub motion_queue: Vec<QueuedMotion>,
    pub animation_start_time: f32,
    pub animation_end_time: f32,
    pub animation_blend_time: f32,
    pub root_lock: bool,
    pub animation_scale: f32,
    pub motion_ended: bool,
    pub previous_motion: Option<Symbol>,
    pub blend_weight: f32,
    pub blend_duration: f32,
    pub blend_elapsed: f32,
}

impl Default for BonesPlayerState {
    fn default() -> Self {
        Self {
            animation_time: 0.0,
            animation_playing: false,
            current_motion: None,
            play_rate: 1.0,
            animation_loop: true,
            motion_queue: Vec::new(),
            animation_start_time: 0.0,
            animation_end_time: -1.0,
            animation_blend_time: 0.0,
            root_lock: false,
            animation_scale: 1.0,
            motion_ended: false,
            previous_motion: None,
            blend_weight: 1.0,
            blend_duration: 0.0,
            blend_elapsed: 0.0,
        }
    }
}

/// Mutable runtime state for a Shockwave 3D member (animation, transforms, etc.)
#[derive(Clone, Debug, Default)]
pub struct Shockwave3dRuntimeState {
    // ─── Animation ───
    pub animation_time: f32,
    pub animation_playing: bool,
    pub current_motion: Option<Symbol>,
    pub play_rate: f32,
    pub animation_loop: bool,
    pub motion_queue: Vec<QueuedMotion>,
    pub animation_start_time: f32,
    pub animation_end_time: f32,
    pub animation_blend_time: f32,
    pub root_lock: bool,
    /// Per-motion playrate scale (arg 5 of play()), multiplied with play_rate
    pub animation_scale: f32,
    /// Whether the current non-looping motion has ended
    pub motion_ended: bool,
    /// Previous motion for crossfade blending
    pub previous_motion: Option<Symbol>,
    pub blend_weight: f32,       // 0.0 = all previous, 1.0 = all current
    pub blend_duration: f32,     // total blend time in seconds
    pub blend_elapsed: f32,      // time spent blending
    /// Per-model animation state, keyed by model node name (lowercase). The
    /// SOURCE OF TRUTH for skinned models — the single fields above are kept
    /// for the keyframe (motion_transforms / non-skinned) path. See
    /// [`BonesPlayerState`]. Access via `bones_player` / `bones_player_mut`.
    pub bones_players: std::collections::HashMap<Symbol, BonesPlayerState>,

    // ─── Per-node overrides (keyed by node name) ───
    /// Transform overrides for nodes (set via Lingo) — used by renderer
    pub node_transforms: std::collections::HashMap<Symbol, [f32; 16]>,
    /// Persistent Transform3d DatumRefs per node — returned by .transform getter
    /// so that chained mutations (model.transform.position = v) persist
    pub node_transform_datums: std::collections::HashMap<Symbol, crate::player::DatumRef>,
    /// Director-friendly Euler readback hints for nodes oriented via pointAt().
    pub node_rotation_hints: std::collections::HashMap<Symbol, [f64; 3]>,
    /// Visibility overrides for nodes: 0=#none, 1=#front, 2=#back, 3=#both
    pub node_visibility: std::collections::HashMap<Symbol, u8>,
    /// Shader overrides for nodes: model_name → (mesh_index → shader_name)
    /// mesh_index is 0-based; index 0 is also the whole-model fallback
    pub node_shaders: std::collections::HashMap<Symbol, std::collections::HashMap<usize, Symbol>>,
    /// Nodes whose `node_shaders` entries were written by an INDEXED assignment
    /// (`model.shaderList[i] = shd`), which in Director touches only mesh `i`.
    /// Without this the single-entry index-0 whole-model fallback could not tell
    /// `shaderList[1] = shd` apart from `shaderList = shd`, so Agent Free Ride 2
    /// voiding the enemy rider's weapon mesh (`shaderList[1] = void_mat`) made the
    /// WHOLE rider invisible — jet skis driving with nobody on them.
    pub node_shaders_indexed: std::collections::HashSet<Symbol>,
    /// Shader names (as authored) the script explicitly set `.transparent = 1` on.
    /// Such shaders alpha-BLEND softly (Director's default #blend), so a model
    /// carrying one is routed to the transparent pass even at blend=100 — instead
    /// of the hard-edged alpha-test cutout pass (which turned the galaxy glow plane
    /// into an opaque white disk). Only script-set shaders are tracked, so parsed
    /// .w3d cutout foliage (frog01) is unaffected.
    pub transparent_shaders: std::collections::HashSet<Symbol>,
    /// Per-shader `renderStyle` (Director 11.5 Scripting Dictionary): the mesh
    /// fill mode a model wearing this shader draws with. `0` = #fill (default,
    /// absent), `1` = #wire, `2` = #point. Director realizes this with
    /// `glPolygonMode`; WebGL2 has none, so the renderer emulates #wire as an
    /// edge line list and #point as GL_POINTS. Keyed by authored shader name.
    pub shader_render_style: std::collections::HashMap<Symbol, u8>,
    /// Text3D model resources created by `someTextMember.extrude3d(thisScene)`,
    /// keyed by the resource name in this member's scene. Retains the source
    /// glyphs + extrude state so the resource's tunnelDepth/bevelType/bevelDepth/
    /// smoothness setters can re-extrude the mesh into this scene.
    pub text3d_resources: std::collections::HashMap<Symbol, (Text3dSource, Text3dState)>,

    // ─── World state ───
    pub background_color: Option<(u8, u8, u8)>,
    pub ambient_color: Option<(f32, f32, f32)>,

    // ─── Fog ───
    pub fog_enabled: bool,
    pub fog_near: f32,
    pub fog_far: f32,
    pub fog_color: (f32, f32, f32),
    pub fog_mode: u8, // 0=linear, 1=exp, 2=exp2

    // ─── Post-processing effects ───
    pub bloom_enabled: bool,
    pub bloom_threshold: f32,
    pub bloom_intensity: f32,

    // ─── Camera ───
    /// Per-camera projection mode: 0=perspective (default), 1=orthographic
    pub camera_projection_mode: std::collections::HashMap<Symbol, u8>,
    /// Per-camera ortho height (world units visible vertically)
    pub camera_ortho_height: std::collections::HashMap<Symbol, f32>,
    /// Render-to-texture requests: camera_name → target_texture_name
    /// When set, the next render from this camera writes to the named texture instead of the main FBO
    pub render_targets: std::collections::HashMap<Symbol, Symbol>,

    // ─── Particle systems ───
    pub particles: std::collections::HashMap<Symbol, ParticleSystemState>,

    // ─── Shader persistent lists ───
    /// Per-shader persistent textureList DatumRefs: shader_name -> DatumRef to list
    pub shader_texture_lists: std::collections::HashMap<Symbol, crate::player::DatumRef>,
    /// Per-shader persistent textureTransformList DatumRefs: shader_name -> DatumRef to list of Transform3d
    pub shader_texture_transform_lists: std::collections::HashMap<Symbol, crate::player::DatumRef>,
    /// Per-shader persistent textureModeList DatumRefs: shader_name -> DatumRef to list of mode symbols.
    /// Synced into shader.texture_layers[].tex_mode by sync_shader_texture_lists before render.
    pub shader_texture_mode_lists: std::collections::HashMap<Symbol, crate::player::DatumRef>,
    /// Per-shader persistent blendConstantList DatumRefs: shader_name -> DatumRef to list of 0..100 floats.
    /// Synced into shader.texture_layers[].blend_const by sync_shader_texture_lists before render.
    /// Needed so `shader.blendConstantList[i] = N` (e.g. reflectionMap's 30% blend) persists.
    pub shader_blend_constant_lists: std::collections::HashMap<Symbol, crate::player::DatumRef>,

    // ─── MeshDeform state ───
    /// Per-model mesh deform data: model_name -> list of mesh texture layers
    /// Each mesh has a Vec of texture layers, each layer has texture coordinates
    pub mesh_deform: std::collections::HashMap<Symbol, MeshDeformState>,

    // ─── Particle emitter state ───
    /// Per-resource emitter state: resource_name -> emitter properties
    pub emitters: std::collections::HashMap<Symbol, EmitterState>,

    // ─── Level of Detail (LOD) state ───
    pub lod_state: std::collections::HashMap<Symbol, LodState>,

    // ─── Subdivision Surface (SDS) state ───
    pub sds_state: std::collections::HashMap<Symbol, SdsState>,

    // ─── Reset tracking ───
    pub world_reset: bool,

    // ─── Detached nodes (parent set to VOID) ───
    pub detached_nodes: std::collections::HashSet<Symbol>,

    /// Manual per-bone LOCAL transform overrides from `bonesPlayer.bone[i].transform = t`.
    /// Keyed by "modelname:boneindex" (lowercase). The skeleton build substitutes these
    /// (resolving the bone's rest length for a zero translation), letting procedural
    /// scripts like updateBoneRotation drive bones — the SweeTarts snake's S-wiggle.
    pub bone_transform_overrides: std::collections::HashMap<String, [f32; 16]>,

    // ─── pointAtOrientation per node ───
    /// Per-node pointAtOrientation: node_name -> (front_axis, up_axis)
    /// Default: ([0,0,1], [0,1,0]) — +Z front, +Y up
    pub point_at_orientations: std::collections::HashMap<Symbol, ([f32; 3], [f32; 3])>,

    // ─── Camera properties ───
    /// Per-camera rootNode: camera_name -> node_name (limits which subtree to render)
    pub camera_root_nodes: std::collections::HashMap<Symbol, Symbol>,
    /// Per-camera colorBuffer.clearAtRender: camera_name -> bool
    pub camera_clear_at_render: std::collections::HashMap<Symbol, bool>,

    // ─── Camera overlays/backdrops ───
    /// Per-camera overlay list: camera_name -> Vec<CameraOverlay>
    pub camera_overlays: std::collections::HashMap<Symbol, Vec<CameraOverlay>>,
    pub camera_backdrops: std::collections::HashMap<Symbol, Vec<CameraOverlay>>,

    // ─── Mesh build data (for newMesh() → build() workflow) ───
    /// Per-model-resource mesh build data: resource_name -> MeshBuildData
    pub mesh_build_data: std::collections::HashMap<Symbol, MeshBuildData>,

    // ─── Directional light preset ───
    /// member.directionalPreset value (1-9 matching topLeft..bottomRight,
    /// 0 = #None, 2 = #topCenter = Director default).
    pub directional_preset: u32,

    // ─── userData per node (Director chapter 15: model.userData / group.userData) ───
    /// Per-node `.userData` PropList datum-ref. Lazily allocated on first
    /// access — `model.userData` returns the cached DatumRef so subsequent
    /// `setaProp` / `addProp` mutations on the returned PropList stay
    /// visible across reads. Keyed by node name (case-insensitive lookup
    /// done at access time).
    pub user_data: std::collections::HashMap<Symbol, crate::player::DatumRef>,

    // ─── W3D event/timer registrations (registerForEvent / unregisterAllEvents) ───
    /// Per-member event subscriptions. Currently only `#timeMS` is honoured
    /// by the dispatcher; collision/animation events are stored but never
    /// fired (their producers aren't wired up). `unregisterAllEvents`
    /// truncates this Vec.
    pub registered_events: Vec<RegisteredW3dEvent>,

    // ─── Native #collision modifier (addModifier(#collision)) ───
    /// Per-model collision modifier state, keyed by model node name. Drives
    /// native W3D collision detection in `events::tick_w3d_collisions`.
    pub collision_modifiers: std::collections::HashMap<Symbol, W3dCollisionModifier>,
}

/// Native Shockwave3D #collision modifier state (Director 11.5 collision
/// modifier). Attached to a model via `model.addModifier(#collision)` and
/// exposed through the `model.collision` property. Detection runs each frame
/// in `events::tick_w3d_collisions`; only detection + callback dispatch are
/// implemented — resolution is a no-op (every consumer so far sets `resolve = 0`).
#[derive(Clone)]
pub struct W3dCollisionModifier {
    /// `collision.enabled` — whether collisions with this model are detected.
    pub enabled: bool,
    /// `collision.resolve` — whether collisions are auto-resolved. Stored, not applied.
    pub resolve: bool,
    /// `collision.immovable` — stored only.
    pub immovable: bool,
    /// `collision.mode` — #box / #sphere / #mesh. Detection uses an axis-aligned
    /// bounding box for every mode (sufficient for the gameplay callbacks).
    pub mode: String,
    /// Handler registered via `collision.setCollisionCallback(#handler, instance)`.
    pub callback_handler: Option<String>,
    pub callback_instance: Option<crate::player::script_ref::ScriptInstanceRef>,
    /// The raw 2nd arg of `setCollisionCallback(#handler, target)`. Director
    /// invokes a non-instance target's handler as `on handler target, collisionData`
    /// (the object is the handler's FIRST param), so we keep it to pass through.
    /// For a script-instance target this is unused (that path binds `me`).
    pub callback_target: Option<crate::director::lingo::datum::Datum>,
}

// Manual Debug: `Datum` doesn't implement Debug (it uses `format_datum`), so
// derive can't cover `callback_target`; just report whether one is set.
impl std::fmt::Debug for W3dCollisionModifier {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("W3dCollisionModifier")
            .field("enabled", &self.enabled)
            .field("resolve", &self.resolve)
            .field("immovable", &self.immovable)
            .field("mode", &self.mode)
            .field("callback_handler", &self.callback_handler)
            .field("callback_instance", &self.callback_instance)
            .field("callback_target", &self.callback_target.is_some())
            .finish()
    }
}

impl Default for W3dCollisionModifier {
    fn default() -> Self {
        Self {
            enabled: true,
            resolve: true,
            immovable: false,
            mode: "mesh".to_string(),
            callback_handler: None,
            callback_instance: None,
            callback_target: None,
        }
    }
}

#[derive(Clone, Debug)]
pub struct RegisteredW3dEvent {
    /// `#timeMS`, `#collideAny`, `#collideWith`, `#animationStarted`,
    /// `#animationEnded`, or any user-defined symbol.
    pub event_name: Symbol,
    pub handler_name: Symbol,
    /// Script instance to dispatch the handler on. `None` corresponds to
    /// passing `0` for `scriptObject` in Lingo — Director then searches
    /// movie scripts for the handler.
    pub script_instance: Option<crate::player::script_ref::ScriptInstanceRef>,
    /// Director's `begin`: ms after registration before the first fire.
    pub begin_ms: u32,
    /// Director's `period`: ms between fires when `repetitions > 1` or 0
    /// (infinite). Ignored for non-#timeMS events.
    pub period_ms: u32,
    /// 0 means infinite. Otherwise the total number of fires.
    pub repetitions: u32,
    /// Wall-clock ms when registerForEvent was called.
    pub registered_at_ms: f64,
    /// Number of times this event has fired so far.
    pub fires_so_far: u32,
    /// Wall-clock ms of the most recent fire (or `registered_at_ms` if
    /// not yet fired). Drives the inter-fire delta computation passed
    /// to the handler.
    pub last_fire_ms: f64,
}

/// Stores intermediate data for newMesh() model resources before build() is called.
/// Holds vertexList, textureCoordinateList, colorList, normalList, and the
/// generateNormals style.
#[derive(Clone, Debug, Default)]
pub struct MeshBuildData {
    pub vertex_list: Vec<[f32; 3]>,
    pub texture_coordinate_list: Vec<[f32; 2]>,
    pub color_list: Vec<(u8, u8, u8)>,
    pub normal_list: Vec<[f32; 3]>,
    /// #flat = 0, #smooth = 1, None = not called
    pub generate_normals_style: Option<u8>,
}

#[derive(Clone, Debug)]
pub struct CameraOverlay {
    pub source_texture: Symbol,
    pub source_texture_lower: Symbol, // pre-lowercased for GPU texture lookup
    pub loc: [f64; 2],
    pub rotation: f64,
    pub blend: f64,
    pub scale: f64,
    pub scale_x: f64,
    pub scale_y: f64,
    pub reg_point: [f64; 2],
    pub shader_name: Symbol,
}

impl Default for CameraOverlay {
    fn default() -> Self {
        Self {
            source_texture: Symbol::empty(),
            source_texture_lower: Symbol::empty(),
            loc: [0.0, 0.0],
            rotation: 0.0,
            blend: 100.0,
            scale: 1.0,
            scale_x: 1.0,
            scale_y: 1.0,
            reg_point: [0.0, 0.0],
            shader_name: Symbol::empty(),
        }
    }
}

#[derive(Clone, Debug)]
pub struct LodState {
    pub level: i32,
    pub auto_mode: bool,
    pub bias: f32,
}

impl Default for LodState {
    fn default() -> Self {
        Self { level: 100, auto_mode: true, bias: 100.0 }
    }
}

#[derive(Clone, Debug)]
pub struct SdsState {
    pub depth: i32,
    pub tension: f32,
    pub error: f32,
    pub enabled: bool,
}

impl Default for SdsState {
    fn default() -> Self {
        // Director defaults: depth 1, tension 65 (internal surfaceTension 0.65).
        // tension is Lingo's 0..100 scale.
        Self { depth: 1, tension: 65.0, error: 0.0, enabled: true }
    }
}

/// Runtime mesh deform state for a model
#[derive(Clone, Debug, Default)]
pub struct MeshDeformState {
    /// Per-mesh texture layer data
    pub meshes: Vec<MeshDeformMesh>,
}

#[derive(Clone, Debug, Default)]
pub struct MeshDeformMesh {
    /// Texture layers for this mesh
    pub texture_layers: Vec<MeshDeformTextureLayer>,
    /// Persistent DatumRef to the textureLayer list so add() persists
    pub texture_layer_datum_ref: Option<crate::player::DatumRef>,
}

#[derive(Clone, Debug, Default)]
pub struct MeshDeformTextureLayer {
    pub texture_coordinate_list: Vec<[f32; 2]>,
}

/// Emitter properties for a particle model resource
#[derive(Clone, Debug)]
pub struct EmitterState {
    pub num_particles: i32,
    pub mode: String,       // "burst" or "stream"
    pub is_loop: bool,
    pub direction: [f64; 3],
    pub region: [f64; 3],
    pub has_region: bool, // true once a script assigns emitter.region (emit there, not at the model node)
    pub distribution: String, // "linear", "gaussian"
    pub angle: f64,
    pub min_speed: f64,
    pub max_speed: f64,
    pub path_strength: f64,
}

impl Default for EmitterState {
    fn default() -> Self {
        Self {
            num_particles: 1000, // Director #particle default
            mode: "burst".to_string(),
            is_loop: true,
            direction: [0.0, 1.0, 0.0],
            region: [0.0, 0.0, 0.0],
            has_region: false,
            distribution: "linear".to_string(),
            angle: 180.0,
            min_speed: 1.0,
            max_speed: 1.0,
            path_strength: 0.0,
        }
    }
}

/// Runtime state for a particle system
#[derive(Clone, Debug)]
pub struct ParticleSystemState {
    pub positions: Vec<[f32; 3]>,
    pub velocities: Vec<[f32; 3]>,
    pub ages: Vec<f32>,
    pub alive: Vec<bool>,
    /// Per-particle "has been emitted at least once". `alive` goes false again
    /// when a particle dies, so it can't tell a first birth from a re-birth —
    /// which is exactly the distinction `emitter.loop = 0` needs.
    pub emitted: Vec<bool>,
    pub max_particles: usize,
    pub lifetime: f32,
    pub gravity: [f32; 3],
    pub wind: [f32; 3],
    pub drag: f32,
    pub initial_speed: f32,
    pub speed_range: f32,  // random speed variation
    pub direction: [f32; 3],
    pub emitter_position: [f32; 3],
    pub emitter_shape: u8,      // 0=point, 1=line, 2=plane, 3=sphere, 4=cube, 5=cylinder
    pub emitter_size: [f32; 3], // dimensions of emitter shape
    pub angle_range: f32,       // emission cone angle (0 = parallel, PI = hemisphere)
    pub particle_size: f32,
    pub max_speed: f32,         // upper bound of the emitter speed range
    pub stream: bool,           // #stream = continuous recycle, #burst = emit once
    /// `emitter.loop` — TRUE (default) reborns each particle at the end of its
    /// lifetime at the emitter region; FALSE lets it die there (Director 11.5
    /// Scripting Dictionary, "loop (emitter)"). A one-shot burst is
    /// `mode = #burst` + `loop = 0`; Agent Free Ride's landing dust / mine
    /// explosions are built that way, and without this they respawned forever
    /// as white blobs parked at the effect's last position.
    pub loop_enabled: bool,
    // Per-particle appearance interpolated from birth (start) to death (end), per
    // the Director #particle colorRange/sizeRange/blendRange properties.
    pub color_start: [f32; 3],  // RGB 0..1 at birth
    pub color_end: [f32; 3],    // RGB 0..1 at death
    pub size_start: f32,
    pub size_end: f32,
    pub blend_start: f32,       // blendRange.start — opacity PERCENT (0..100) at birth
    pub blend_end: f32,         // blendRange.end — opacity PERCENT (0..100) at death
    pub texture_name: String,   // particle billboard texture (lowercased gpu key)
    pub seed: u32,              // evolving RNG so respawns aren't a fixed per-index pattern
}

impl Shockwave3dRuntimeState {
    /// Per-model bonesPlayer state (read), case-insensitive by model node name.
    pub fn bones_player(&self, model: Symbol) -> Option<&BonesPlayerState> {
        self.bones_players.get(&model)
    }

    /// Per-model bonesPlayer state (mutable), creating a default entry on first
    /// use. Director attaches a #bonesPlayer per model; play()/queue()/setters
    /// route here so each model animates independently.
    pub fn bones_player_mut(&mut self, model: Symbol) -> &mut BonesPlayerState {
        self.bones_players.entry(model).or_default()
    }

    /// Mirror a model's per-node animation state into the member-level single
    /// fields. The renderer skinning + bone getters read per-node, but the
    /// keyframe (motion_transforms) block, auto-play, and legacy queue-pop
    /// still read the single fields — so we keep them pointed at the most
    /// recently-acted model (historical per-member behavior). Harmless for
    /// skinned models (which never consult the single fields).
    pub fn sync_legacy_from_bones_player(&mut self, model: Symbol) {
        if let Some(bp) = self.bones_players.get(&model).cloned() {
            self.animation_time = bp.animation_time;
            self.animation_playing = bp.animation_playing;
            self.current_motion = bp.current_motion;
            self.play_rate = bp.play_rate;
            self.animation_loop = bp.animation_loop;
            self.motion_queue = bp.motion_queue;
            self.animation_start_time = bp.animation_start_time;
            self.animation_end_time = bp.animation_end_time;
            self.animation_blend_time = bp.animation_blend_time;
            self.root_lock = bp.root_lock;
            self.animation_scale = bp.animation_scale;
            self.motion_ended = bp.motion_ended;
            self.previous_motion = bp.previous_motion;
            self.blend_weight = bp.blend_weight;
            self.blend_duration = bp.blend_duration;
            self.blend_elapsed = bp.blend_elapsed;
        }
    }

    /// Create runtime state initialized with camera data from the 3DPR info
    /// and optionally auto-start animation if animationEnabled is set.
    pub fn from_info(info: &Shockwave3dInfo, scene: Option<&crate::director::chunks::w3d::types::W3dScene>) -> Self {
        let mut state = Self {
            play_rate: 1.0,
            animation_scale: 1.0,
            animation_end_time: -1.0,
            directional_preset: 2, // Director default: #topCenter
            // IFX default fog decay is #exponential (IFXRenderFog: m_eMode = IFX_FOG_EXP),
            // NOT #linear. Movies that enable fog without setting decayMode (e.g. the
            // estate explore) rely on this; a linear default left distant geometry
            // unfogged because linear ignores everything closer than fog.near.
            fog_mode: 1, // 0=linear, 1=exp, 2=exp2
            ..Default::default()
        };
        // Seed camera transform from 3DPR camera position/rotation.
        // When stored position has x=0 and y=0, Director auto-computes the camera
        // to center the member's default_rect in the viewport using the default FOV.
        let camera_position = info.camera_position.map(|(px, py, pz)| {
            if px == 0.0 && py == 0.0 {
                let w = (info.default_rect.2 - info.default_rect.0) as f32;
                let h = (info.default_rect.3 - info.default_rect.1) as f32;
                if w > 0.0 && h > 0.0 {
                    let default_fov = 34.516_f32;
                    let aspect = w / h;
                    let h_half_fov = ((default_fov / 2.0).to_radians().tan() * aspect).atan();
                    ((w / 2.0), (h / 2.0), (w / 2.0) / h_half_fov.tan())
                } else {
                    (px, py, pz)
                }
            } else {
                (px, py, pz)
            }
        });
        if let Some((px, py, pz)) = camera_position {
            let (rx, ry, rz) = info.camera_rotation.unwrap_or((0.0, 0.0, 0.0));
            // Build camera transform from position + Euler rotation (degrees)
            // Rotation order: R = Rz * Ry * Rx
            let rx_rad = rx.to_radians();
            let ry_rad = ry.to_radians();
            let rz_rad = rz.to_radians();
            let (sx, cx) = (rx_rad.sin(), rx_rad.cos());
            let (sy, cy) = (ry_rad.sin(), ry_rad.cos());
            let (sz, cz) = (rz_rad.sin(), rz_rad.cos());

            // Rotation = Rz * Ry * Rx (column-major)
            let m = [
                cy*cz,              cy*sz,              -sy,     0.0,
                sx*sy*cz - cx*sz,   sx*sy*sz + cx*cz,   sx*cy,  0.0,
                cx*sy*cz + sx*sz,   cx*sy*sz - sx*cz,   cx*cy,  0.0,
                px,                 py,                 pz,      1.0,
            ];
            // Insert only under the scene node name (case-insensitive lookups handle the rest)
            let cam_key = scene.map(|s| {
                s.nodes.iter()
                    .find(|n| n.node_type == crate::director::chunks::w3d::types::W3dNodeType::View
                        && n.name == BuiltInSymbol::DefaultView)
                    .map(|n| n.name.clone())
            }).flatten().unwrap_or_else(|| BuiltInSymbol::DefaultView.into());
            state.node_transforms.insert(cam_key, m);
        }
        if let Some(bg) = info.bg_color {
            state.background_color = Some(bg);
        }
        // Seed authored model.visibility from the file. The renderer already honors
        // node_visibility (0 skips the draw, 2/3 flip culling) but the map was only
        // ever written by Lingo setters, so exporter-hidden helper nodes rendered and
        // authored #both foliage was drawn single-sided. Only non-default modes are
        // inserted, so a script reading .visibility on an ordinary model still gets
        // the #front fallback rather than a materialized entry.
        if let Some(scene) = scene {
            use crate::director::chunks::w3d::types::W3dNodeType;
            for node in scene.nodes.iter() {
                if node.node_type == W3dNodeType::Model && node.visibility != 1 {
                    state.node_visibility.insert(node.name.clone(), node.visibility);
                }
            }
        }
        // Note: animationEnabled auto-start is handled in the rendering path
        // when the sprite first appears on stage, not here at parse time.
        state
    }
}

impl Default for ParticleSystemState {
    fn default() -> Self {
        Self {
            positions: Vec::new(),
            velocities: Vec::new(),
            ages: Vec::new(),
            alive: Vec::new(),
            emitted: Vec::new(),
            max_particles: 100,
            lifetime: 10.0,
            gravity: [0.0, -9.8, 0.0],
            wind: [0.0; 3],
            drag: 0.0,
            initial_speed: 1.0,
            speed_range: 0.0,
            direction: [0.0, 1.0, 0.0],
            emitter_position: [0.0; 3],
            emitter_shape: 0,
            emitter_size: [1.0; 3],
            angle_range: 0.3,
            particle_size: 1.0,
            max_speed: 1.0,
            stream: true,
            loop_enabled: true,
            color_start: [1.0, 1.0, 1.0],
            color_end: [1.0, 1.0, 1.0],
            size_start: 1.0,
            size_end: 1.0,
            blend_start: 100.0,
            blend_end: 100.0,
            texture_name: String::new(),
            seed: 0x9E3779B9,
        }
    }
}

impl ParticleSystemState {
    pub fn initialize(&mut self, count: usize) {
        self.max_particles = count;
        self.positions = vec![[0.0; 3]; count];
        self.velocities = vec![[0.0; 3]; count];
        self.ages = vec![0.0; count];
        self.alive = vec![false; count];
        self.emitted = vec![false; count];

        // #stream emits a group of particles each frame, so stagger the birth
        // times: randomize initial ages across the lifetime, putting particles at
        // varied distances down the stream from the start (a uniform stagger plus
        // the constant emit speed left them at regular intervals — visible
        // banding). #burst emits ALL particles at the same time (Director 11.5
        // Scripting Dictionary, "mode (emitter)"), so start them due at once.
        for i in 0..count {
            self.seed = self.seed.wrapping_mul(1664525).wrapping_add(1013904223);
            let r = (self.seed >> 8) as f32 / 16_777_216.0; // 0..1
            self.ages[i] = if self.stream { r * self.lifetime } else { self.lifetime };
            self.alive[i] = false;
        }
    }

    pub fn update(&mut self, dt: f32) {
        for i in 0..self.max_particles {
            if i >= self.ages.len() { break; }

            self.ages[i] += dt;

            if self.ages[i] >= self.lifetime {
                // `emitter.loop = 0` means the particle DIES at the end of its
                // lifetime instead of being reborn at the emitter region. Without
                // this every one-shot burst (Agent Free Ride's landing dust, mine
                // explosions) respawned forever, leaving white blobs parked where
                // the effect last fired.
                // Only RE-births are suppressed: a one-shot burst still gets its
                // single emission, it just doesn't come back. `alive` can't carry
                // this — it goes false again the moment the particle dies — hence
                // the separate `emitted` flag.
                if !self.loop_enabled && self.emitted[i] {
                    self.alive[i] = false;
                    self.ages[i] = self.lifetime;
                    continue;
                }
                self.emitted[i] = true;
                // Recycle
                self.ages[i] -= self.lifetime;
                self.alive[i] = true;
                // Evolve the RNG each respawn so particles don't all return to the
                // same fixed per-index offset/velocity (that produced regular bands).
                self.seed = self.seed.wrapping_mul(1664525).wrapping_add(1013904223);
                let hash = self.seed;
                let r1 = (hash & 0xFF) as f32 / 255.0 - 0.5;
                let r2 = ((hash >> 8) & 0xFF) as f32 / 255.0 - 0.5;
                let r3 = ((hash >> 16) & 0xFF) as f32 / 255.0 - 0.5;
                let offset = match self.emitter_shape {
                    1 => [r1 * self.emitter_size[0], 0.0, 0.0],              // line
                    2 => [r1 * self.emitter_size[0], 0.0, r2 * self.emitter_size[2]], // plane
                    3 => {                                                      // sphere
                        let len = (r1*r1 + r2*r2 + r3*r3).sqrt().max(0.01);
                        let s = self.emitter_size[0] * ((hash & 0xFF) as f32 / 255.0);
                        [r1/len * s, r2/len * s, r3/len * s]
                    }
                    4 => [r1 * self.emitter_size[0], r2 * self.emitter_size[1], r3 * self.emitter_size[2]], // cube
                    _ => [0.0, 0.0, 0.0],                                      // point
                };
                self.positions[i] = [
                    self.emitter_position[0] + offset[0],
                    self.emitter_position[1] + offset[1],
                    self.emitter_position[2] + offset[2],
                ];
                // Direction with angle spread
                let spread = self.angle_range;
                let jx = r1 * spread;
                let jy = r2 * spread;
                let jz = r3 * spread;
                let speed = self.initial_speed + r1 * self.speed_range;
                self.velocities[i] = [
                    (self.direction[0] + jx) * speed,
                    (self.direction[1] + jy) * speed,
                    (self.direction[2] + jz) * speed,
                ];
            }

            if self.alive[i] {
                // Apply gravity
                self.velocities[i][0] += self.gravity[0] * dt;
                self.velocities[i][1] += self.gravity[1] * dt;
                self.velocities[i][2] += self.gravity[2] * dt;

                // Apply wind drag
                if self.drag > 0.0 {
                    let factor = 1.0 - self.drag * dt;
                    self.velocities[i][0] = self.velocities[i][0] * factor + self.wind[0] * self.drag * dt;
                    self.velocities[i][1] = self.velocities[i][1] * factor + self.wind[1] * self.drag * dt;
                    self.velocities[i][2] = self.velocities[i][2] * factor + self.wind[2] * self.drag * dt;
                }

                // Integrate position
                self.positions[i][0] += self.velocities[i][0] * dt;
                self.positions[i][1] += self.velocities[i][1] * dt;
                self.positions[i][2] += self.velocities[i][2] * dt;
            }
        }
    }
}

#[derive(Clone, Debug)]
pub struct FontMember {
    pub font_info: FontInfo,
    pub preview_text: String,
    pub preview_font_name: Option<String>,
    pub preview_html_spans: Vec<StyledSpan>,
    pub fixed_line_space: u16,
    pub top_spacing: i16,
    pub bitmap_ref: Option<BitmapRef>,
    pub char_width: Option<u16>,
    pub char_height: Option<u16>,
    pub grid_columns: Option<u8>,
    pub grid_rows: Option<u8>,
    pub char_widths: Option<Vec<u16>>,
    pub first_char_num: Option<u8>,
    pub alignment: TextAlignment,
    pub pfr_parsed: Option<crate::director::chunks::pfr1::types::Pfr1ParsedFont>,
    pub pfr_data: Option<Vec<u8>>,
}

// ---- Havok Physics Member ----



// RapierWorld and HavokCollisionFilter removed — replaced by native Havok physics

#[derive(Clone, Debug)]
pub struct HavokCorrector {
    pub enabled: bool,
    pub threshold: f64,
    pub multiplier: f64,
    pub level: i32,
    pub max_tries: i32,
    pub max_distance: f64,
}

impl Default for HavokCorrector {
    fn default() -> Self {
        Self {
            enabled: false,
            threshold: 0.1,
            multiplier: 5.0,
            level: 2,
            max_tries: 10,
            max_distance: 100.0,
        }
    }
}

#[derive(Clone, Debug)]
pub struct RestingContact {
    pub normal: [f64; 3],
    pub plane_point: [f64; 3],
    pub ground_friction: f64,
    pub aabb_min: [f64; 3],
    pub aabb_max: [f64; 3],
}

#[derive(Clone, Debug)]
pub struct HavokRigidBody {
    pub name: Symbol,
    pub position: [f64; 3],
    pub rotation_axis: [f64; 3],
    pub rotation_angle: f64,
    pub mass: f64,
    pub restitution: f64,
    pub friction: f64,
    pub active: bool,
    pub pinned: bool,
    /// HKE `COLLISIONS_DISABLED`: body integrates but is never registered for
    /// collision detection (skipped by the narrow phase).
    pub collisions_disabled: bool,
    /// HKE `CASTS_SHADOWS`: render metadata (display-body shadow); physics no-op.
    pub casts_shadows: bool,
    pub linear_velocity: [f64; 3],
    pub angular_velocity: [f64; 3],
    pub linear_momentum: [f64; 3],
    pub angular_momentum: [f64; 3],
    pub force: [f64; 3],
    pub torque: [f64; 3],
    /// Force/torque applied from a Havok STEP CALLBACK (registerStepCallback).
    /// The docs say a step callback fires once per sub-step, so these are applied
    /// at FULL strength every sub-step — NOT attenuated by `force_scale`, which is
    /// calibrated for once-per-frame game forces. Age-of-speed applies gravity this
    /// way (`rb.applyForce(gravity*mass)` in its callback); without this the gravity
    /// came out ~1/6 strength and cars launched off ramps never landed.
    pub step_force: [f64; 3],
    pub step_torque: [f64; 3],
    pub center_of_mass: [f64; 3],
    pub corrector: HavokCorrector,
    pub is_fixed: bool,
    pub is_convex: bool,
    /// Half-extents of the mesh bounding box, for box inertia computation.
    pub inertia_half_extents: [f64; 3],
    /// The body's collision hull vertices in BODY-LOCAL space (relative to
    /// `position`, un-rotated by the spawn orientation). Populated for HKE movable
    /// bodies from their own collision mesh. When present, a hover vehicle
    /// (`received_force`) collides against static scenery using these actual
    /// vertices (transformed to the live pose) instead of its bounding box — a car
    /// chassis is far thinner than its box, whose corners otherwise ram a rising
    /// loop wall the real hull would clear. Empty ⇒ fall back to the box.
    pub collision_hull_local: Vec<[f64; 3]>,
    /// A Lingo-created movable body defaults to the script-driven vehicle path
    /// (raycast cars: held up by hover forces, off the box-stacking path). HKE
    /// bodies load as `false` (passive). A force-free body that is positioned
    /// kinematically (interpolatingMoveTo) is reclassified to `false` so the
    /// add-cubes demo box-stacks — see `received_force`.
    pub driven: bool,
    /// Set once any applied force/torque (applyForce/applyForceAtPoint/
    /// applyTorque) hits this body. A raycast car hovers every frame, so this is
    /// true before its recovery interpolatingMoveTo runs — which is how we tell a
    /// hover vehicle (keep `driven`) from a kinematically-placed stacking block
    /// (clear `driven`). Never set for the falling cubes.
    pub received_force: bool,
    /// True for #box-primitive bodies. A box must not be given the sphere
    /// "rolling" (ω = v/r) the resting-surface constraint applies to round
    /// bodies — it slides/tumbles instead. Spheres, cylinders/coins, cars and
    /// meshes leave this false and keep rolling.
    pub is_box: bool,
    /// Authored per-axis model scale from the W3D transform, preserved so the
    /// rendered model keeps its size when physics writes back its transform
    /// (the finaldrive car is authored at 0.296×; losing it makes the RaycastCar
    /// compute wheel/hover points at the wrong scale and tumble).
    pub sync_scale: [f64; 3],
    // --- Full Havok engine state (ported from C# reference) ---
    /// Orientation quaternion [w, x, y, z]. Internal physics state.
    pub orientation: [f64; 4],
    /// Inverse mass (0 if pinned/fixed).
    pub inverse_mass: f64,
    /// 3x3 inertia tensor (row-major). I = UnitInertiaTensor * mass.
    pub inertia_tensor: [f64; 9],
    /// 3x3 inverse inertia tensor (row-major).
    pub inverse_inertia_tensor: [f64; 9],
    /// Mass-independent unit inertia tensor.
    pub unit_inertia_tensor: [f64; 9],
    /// Saved state for bisection rollback.
    pub saved_position: [f64; 3],
    pub saved_orientation: [f64; 4],
    pub saved_linear_velocity: [f64; 3],
    pub saved_angular_velocity: [f64; 3],
    /// Resting contact: surface normal, plane point, ground friction, mesh AABB.
    /// Set on first collision with a rigid-body-owned mesh. Used each
    /// substep to keep the body on the surface analytically.
    pub resting_normal: Option<RestingContact>,
    /// Auto-sleep: seconds of continuous stillness left before the body
    /// deactivates (so resting stacks stop jittering). Reset whenever the body
    /// moves above threshold or is disturbed by Lingo.
    pub sleep_countdown: f64,
    /// Set by the Lingo apply*/velocity setters each step so a per-frame-forced
    /// body (a driven car) never auto-sleeps. Cleared after the sleep check.
    pub lingo_disturbed: bool,
    /// Authored initial state, snapshotted when the body is created, so
    /// `havok.reset()` can revert the scene to the .hke-defined state.
    pub initial_position: [f64; 3],
    pub initial_orientation: [f64; 4],
    pub initial_linear_velocity: [f64; 3],
    pub initial_angular_velocity: [f64; 3],
    pub initial_active: bool,
}

impl HavokRigidBody {
    pub fn new_movable(name: Symbol, mass: f64, is_convex: bool) -> Self {
        // Placeholder isotropic box inertia for a 20×20×20 AABB.
        // Callers that know the real mesh geometry must overwrite
        // `unit_inertia_tensor` and then call `recompute_body_inertia`
        // — see `make_movable_rigid_body` which runs the Mirtich
        // polyhedron integrator (PPC InertialTensorComputer 0x5d3c0).
        let d = 20.0_f64;
        let f = 1.0 / 12.0;
        let unit_diag = f * (d*d + d*d); // (dy²+dz²)/12 with dx=dy=dz
        let unit_i = [unit_diag, 0.0, 0.0, 0.0, unit_diag, 0.0, 0.0, 0.0, unit_diag];
        let i_tensor = [unit_i[0]*mass, 0.0, 0.0, 0.0, unit_i[4]*mass, 0.0, 0.0, 0.0, unit_i[8]*mass];
        let inv_i = if mass > 0.0 && unit_diag > 0.0 {
            [1.0/i_tensor[0], 0.0, 0.0, 0.0, 1.0/i_tensor[4], 0.0, 0.0, 0.0, 1.0/i_tensor[8]]
        } else { [0.0; 9] };
        Self {
            name,
            position: [0.0; 3],
            rotation_axis: [0.0, 1.0, 0.0],
            rotation_angle: 0.0,
            mass,
            restitution: 0.3,
            friction: 0.5,
            active: true,
            pinned: false,
            collisions_disabled: false,
            casts_shadows: false,
            linear_velocity: [0.0; 3],
            angular_velocity: [0.0; 3],
            linear_momentum: [0.0; 3],
            angular_momentum: [0.0; 3],
            force: [0.0; 3],
            torque: [0.0; 3],
            step_force: [0.0; 3],
            step_torque: [0.0; 3],
            center_of_mass: [0.0; 3],
            corrector: HavokCorrector::default(),
            is_fixed: false,
            is_convex,
            inertia_half_extents: [10.0; 3],
            collision_hull_local: Vec::new(),
            driven: false,
            received_force: false,
            is_box: false,
            sync_scale: [1.0; 3],
            orientation: [1.0, 0.0, 0.0, 0.0],
            inverse_mass: if mass > 0.0 { 1.0 / mass } else { 0.0 },
            inertia_tensor: i_tensor,
            inverse_inertia_tensor: inv_i,
            unit_inertia_tensor: unit_i,
            saved_position: [0.0; 3],
            saved_orientation: [1.0, 0.0, 0.0, 0.0],
            saved_linear_velocity: [0.0; 3],
            saved_angular_velocity: [0.0; 3],
            resting_normal: None,
            sleep_countdown: 0.5,
            lingo_disturbed: false,
            initial_position: [0.0; 3],
            initial_orientation: [1.0, 0.0, 0.0, 0.0],
            initial_linear_velocity: [0.0; 3],
            initial_angular_velocity: [0.0; 3],
            initial_active: true,
        }
    }

    pub fn new_fixed(name: Symbol, is_convex: bool) -> Self {
        Self {
            name,
            position: [0.0; 3],
            rotation_axis: [0.0, 1.0, 0.0],
            rotation_angle: 0.0,
            mass: 0.0,
            restitution: 0.3,
            friction: 0.5,
            active: false,
            pinned: true,
            collisions_disabled: false,
            casts_shadows: false,
            linear_velocity: [0.0; 3],
            angular_velocity: [0.0; 3],
            linear_momentum: [0.0; 3],
            angular_momentum: [0.0; 3],
            force: [0.0; 3],
            torque: [0.0; 3],
            step_force: [0.0; 3],
            step_torque: [0.0; 3],
            center_of_mass: [0.0; 3],
            corrector: HavokCorrector::default(),
            is_fixed: true,
            is_convex,
            inertia_half_extents: [10.0; 3],
            collision_hull_local: Vec::new(),
            driven: false,
            received_force: false,
            is_box: false,
            sync_scale: [1.0; 3],
            orientation: [1.0, 0.0, 0.0, 0.0],
            inverse_mass: 0.0,
            inertia_tensor: [0.0; 9],
            inverse_inertia_tensor: [0.0; 9],
            unit_inertia_tensor: [0.0; 9],
            saved_position: [0.0; 3],
            saved_orientation: [1.0, 0.0, 0.0, 0.0],
            saved_linear_velocity: [0.0; 3],
            saved_angular_velocity: [0.0; 3],
            resting_normal: None,
            sleep_countdown: 0.5,
            lingo_disturbed: false,
            initial_position: [0.0; 3],
            initial_orientation: [1.0, 0.0, 0.0, 0.0],
            initial_linear_velocity: [0.0; 3],
            initial_angular_velocity: [0.0; 3],
            initial_active: true,
        }
    }

    /// Record the current transform/velocity as the authored initial state,
    /// so `havok.reset()` can revert to it.
    pub fn snapshot_initial(&mut self) {
        self.initial_position = self.position;
        self.initial_orientation = self.orientation;
        self.initial_linear_velocity = self.linear_velocity;
        self.initial_angular_velocity = self.angular_velocity;
        self.initial_active = self.active;
    }

    /// Revert to the snapshotted initial state and clear all accumulated/derived
    /// runtime state (forces, momenta, resting + sleep state). `havok.reset()`.
    pub fn restore_initial(&mut self) {
        self.position = self.initial_position;
        self.orientation = self.initial_orientation;
        self.linear_velocity = self.initial_linear_velocity;
        self.angular_velocity = self.initial_angular_velocity;
        self.active = self.initial_active;
        self.force = [0.0; 3];
        self.torque = [0.0; 3];
        self.linear_momentum = [0.0; 3];
        self.angular_momentum = [0.0; 3];
        self.resting_normal = None;
        self.sleep_countdown = 0.5;
        self.lingo_disturbed = false;
    }
}

/// Cable / point-to-point distance constraint: keeps `body_index`'s attach
/// point at `length` from a fixed world `anchor` (a pendulum), so e.g. the
/// lamp hangs and swings instead of falling.
#[derive(Clone, Debug)]
pub struct HavokCable {
    pub body_index: usize,
    /// Fixed world anchor (Director units).
    pub anchor: [f64; 3],
    /// Attachment point on the body, body-local (Director units).
    pub attach_local: [f64; 3],
    /// Constraint distance (Director units).
    pub length: f64,
}

#[derive(Clone, Debug)]
pub struct HavokSpring {
    pub name: Symbol,
    pub rigid_body_a: Option<Symbol>,
    pub rigid_body_b: Option<Symbol>,
    pub point_a: [f64; 3],
    pub point_b: [f64; 3],
    pub rest_length: f64,
    pub elasticity: f64,
    pub damping: f64,
    pub on_compression: bool,
    pub on_extension: bool,
}

impl HavokSpring {
    pub fn new(name: Symbol) -> Self {
        Self {
            name,
            rigid_body_a: None,
            rigid_body_b: None,
            point_a: [0.0; 3],
            point_b: [0.0; 3],
            rest_length: 0.0,
            elasticity: 0.5,
            damping: 0.1,
            on_compression: true,
            on_extension: true,
        }
    }
}

#[derive(Clone, Debug)]
pub struct HavokLinearDashpot {
    pub name: Symbol,
    pub rigid_body_a: Option<Symbol>,
    pub rigid_body_b: Option<Symbol>,
    pub point_a: [f64; 3],
    pub point_b: [f64; 3],
    pub strength: f64,
    pub damping: f64,
}

impl HavokLinearDashpot {
    pub fn new(name: Symbol) -> Self {
        Self {
            name,
            rigid_body_a: None,
            rigid_body_b: None,
            point_a: [0.0; 3],
            point_b: [0.0; 3],
            strength: 0.5,
            damping: 0.1,
        }
    }
}

#[derive(Clone, Debug)]
pub struct HavokAngularDashpot {
    pub name: Symbol,
    pub rigid_body_a: Option<Symbol>,
    pub rigid_body_b: Option<Symbol>,
    pub rotation_axis: [f64; 3],
    pub rotation_angle: f64,
    pub strength: f64,
    pub damping: f64,
}

impl HavokAngularDashpot {
    pub fn new(name: Symbol) -> Self {
        Self {
            name,
            rigid_body_a: None,
            rigid_body_b: None,
            rotation_axis: [0.0, 1.0, 0.0],
            rotation_angle: 0.0,
            strength: 0.5,
            damping: 0.1,
        }
    }
}

#[derive(Clone, Debug)]
pub struct HavokCollisionInterest {
    pub rb_name1: Symbol,
    pub rb_name2: Symbol,  // or "#all"
    pub frequency: f64,
    pub threshold: f64,
    pub handler_name: Option<Symbol>,
    pub script_instance: Option<crate::player::DatumRef>,
}

/// Collision contact info for the collisionList property
#[derive(Clone, Debug)]
pub struct HavokCollisionInfo {
    pub body_a: Symbol,
    pub body_b: Symbol,
    pub point: [f64; 3],
    pub normal: [f64; 3],
    /// Impact speed (|normal relative velocity|) at the contact. Passed to Lingo
    /// collision callbacks as the 5th argument and gated against the
    /// registerInterest threshold.
    pub normal_rel_vel: f64,
}

pub struct HavokPhysicsState {
    pub initialized: bool,
    pub w3d_cast_lib: i32,
    pub w3d_cast_member: i32,
    pub tolerance: f64,
    pub scale: f64,
    pub gravity: [f64; 3],
    pub sim_time: f64,
    pub time_step: f64,
    pub sub_steps: i32,
    pub deactivation_params: [f64; 2],
    pub drag_params: [f64; 2],
    pub rigid_bodies: Vec<HavokRigidBody>,
    pub springs: Vec<HavokSpring>,
    pub linear_dashpots: Vec<HavokLinearDashpot>,
    pub angular_dashpots: Vec<HavokAngularDashpot>,
    /// Cable / point-to-point constraints (e.g. the hanging lamp). Distinct
    /// from `springs` so they don't flip the scene out of the passive
    /// collision path.
    pub cable_constraints: Vec<HavokCable>,
    pub collision_interests: Vec<HavokCollisionInterest>,
    pub step_callbacks: Vec<(Symbol, crate::player::DatumRef)>,  // (handler_name, script_instance)
    pub disabled_collision_pairs: Vec<(Symbol, Symbol)>,
    pub hke_data: Vec<u8>,
    /// Ground Z for native Havok ground constraint (flat plane fallback)
    pub ground_z: f64,
    /// Half-extent Z for ground collision (car body extends this far below position)
    pub ground_body_half_z: f64,
    /// Collision meshes from HKE data (positioned in world space)
    pub collision_meshes: Vec<crate::player::handlers::datum_handlers::cast_member::havok_physics::CollisionMesh>,
    /// Cached collision list from last step (for Lingo collisionList property)
    pub collision_list_cache: Vec<HavokCollisionInfo>,
    /// Whether to use the raycast-based ground constraint hack (SuperSonic-specific).
    /// Disabled for HKE scene games where bodies are auto-created from W3D nodes,
    /// because those scenes need proper GJK collision instead of a simple ground clamp.
    pub use_ground_constraint: bool,
}

impl Clone for HavokPhysicsState {
    fn clone(&self) -> Self {
        Self {
            initialized: self.initialized,
            w3d_cast_lib: self.w3d_cast_lib,
            w3d_cast_member: self.w3d_cast_member,
            tolerance: self.tolerance,
            scale: self.scale,
            gravity: self.gravity,
            sim_time: self.sim_time,
            time_step: self.time_step,
            sub_steps: self.sub_steps,
            deactivation_params: self.deactivation_params,
            drag_params: self.drag_params,
            rigid_bodies: self.rigid_bodies.clone(),
            springs: self.springs.clone(),
            cable_constraints: self.cable_constraints.clone(),
            linear_dashpots: self.linear_dashpots.clone(),
            angular_dashpots: self.angular_dashpots.clone(),
            collision_interests: self.collision_interests.clone(),
            step_callbacks: self.step_callbacks.clone(),
            disabled_collision_pairs: self.disabled_collision_pairs.clone(),
            hke_data: self.hke_data.clone(),
            ground_z: self.ground_z,
            ground_body_half_z: self.ground_body_half_z,
            collision_meshes: Vec::new(), // Not cloned — rebuilt on initialize
            collision_list_cache: Vec::new(),
            use_ground_constraint: self.use_ground_constraint,
        }
    }
}

impl fmt::Debug for HavokPhysicsState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("HavokPhysicsState")
            .field("initialized", &self.initialized)
            .field("rigid_bodies", &self.rigid_bodies.len())
            .finish()
    }
}

impl Default for HavokPhysicsState {
    fn default() -> Self {
        Self {
            initialized: false,
            w3d_cast_lib: 0,
            w3d_cast_member: 0,
            tolerance: 0.1,
            scale: 0.0254,
            gravity: [0.0, 0.0, -386.22],
            sim_time: 0.0,
            time_step: 1.0 / 60.0,
            sub_steps: 4,
            deactivation_params: [2.0, 0.1],
            drag_params: [0.0, 0.0],
            rigid_bodies: Vec::new(),
            springs: Vec::new(),
            cable_constraints: Vec::new(),
            linear_dashpots: Vec::new(),
            angular_dashpots: Vec::new(),
            collision_interests: Vec::new(),
            step_callbacks: Vec::new(),
            disabled_collision_pairs: Vec::new(),
            hke_data: Vec::new(),
            ground_z: -1e20,
            ground_body_half_z: 8.0,
            collision_meshes: Vec::new(),
            collision_list_cache: Vec::new(),
            use_ground_constraint: true,
        }
    }
}

#[derive(Clone)]
pub struct HavokPhysicsMember {
    pub state: HavokPhysicsState,
}

impl fmt::Debug for HavokPhysicsMember {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(f, "HavokPhysicsMember(initialized={}, bodies={}, springs={})",
            self.state.initialized,
            self.state.rigid_bodies.len(),
            self.state.springs.len())
    }
}

impl HavokPhysicsMember {
    pub fn new(hke_data: Vec<u8>) -> Self {
        let mut state = HavokPhysicsState::default();
        state.hke_data = hke_data;
        Self { state }
    }
}

// ---- PhysX (AGEIA) Physics Member ----
//
// Direct Rust port of the C# AGEIA wrapper layer in
// `E:\Claude Project\PhysXReference\`. Mirrors how Havok is wired above.
//
// PhysX members carry NO authored binary state on disk — they're
// MemberType::Ole with PROGID "Physics" and an empty children list.
// All world state is constructed at runtime via Lingo calls.
//
// Property names align with the Director Physics Xtra reference docs
// (E:\Documents\Director\director_reference.md ch. 15).

/// A single rigid body in the PhysX world. Mirrors the C# wrapper class
/// `CPhysicsRigidBodyAGEIA` plus its Director-visible cached state.
#[derive(Debug, Clone)]
pub struct PhysXRigidBody {
    pub id: u32,
    pub name: Symbol,
    pub model_name: String,
    pub body_type: PhysXBodyType,           // Static / Dynamic / Kinematic
    pub shape: PhysXShapeKind,              // box / sphere / convex / concave
    pub position: [f64; 3],
    /// Axis-angle: (axis.x, axis.y, axis.z, angleDeg). Director's
    /// `Orientation` type — NOT a quaternion despite the typedef.
    pub orientation: [f64; 4],
    pub linear_velocity: [f64; 3],
    pub angular_velocity: [f64; 3],
    pub mass: f64,
    pub center_of_mass: [f64; 3],
    pub use_center_of_mass: bool,
    pub friction: f64,
    pub restitution: f64,
    pub linear_damping: f64,
    pub angular_damping: f64,
    pub sleep_threshold: f64,
    pub sleep_mode: i32,
    pub collision_group: i32,
    pub is_trigger: bool,
    pub ccd_enabled: bool,
    pub pinned: bool,                       // Director "isPinned" (chapter 15)
    pub axis_affinity: bool,                // Director "axisAffinity"; default true
    pub cached_is_sleeping: bool,           // mirrors C# byte +176 cache
    pub user_data: i32,                     // opaque pointer-equivalent
    pub constraint_ids: Vec<u32>,
    // ---- Shape dimensions ----
    // Populated by createRigidBody from the Lingo-side shape parameters
    // (Director chapter 15: `#box`, `#sphere`, `#convexShape`, etc.). Read
    // by the Gu* narrowphase. Defaults are 1.0 sphere when no info given.
    pub radius: f64,                        // sphere / capsule
    pub half_extents: [f64; 3],             // box (and convex/concave AABB fallback)
    pub half_height: f64,                   // capsule (axis along body local +X)

    /// Convex hull data — set by `setConvexHull(verts, faces)` on the
    /// rigid-body Datum, consumed by the convex narrowphase. None until
    /// a script populates it (or the cooked mesh gets wired in later).
    pub convex_hull: Option<crate::player::handlers::datum_handlers::cast_member::physx_gu_convex::PolygonalData>,

    /// Triangle-mesh data for #concaveShape bodies. Set by
    /// `setTriangleMesh(verts, triangles)` on the rigid-body Datum, consumed
    /// by the mesh-vs-shape narrowphase in `physx_gu_mesh`. None until a
    /// script populates it (typical: `createConcaveMesh` ⇒ assign verts/faces).
    pub triangle_mesh: Option<crate::player::handlers::datum_handlers::cast_member::physx_gu_mesh::GuTriangleMesh>,

    /// Authored scale of the bound 3D model, captured at `createRigidBody`.
    /// `simulate()` writes each body's pose back onto its model, and that write
    /// replaces the whole 4x4 — so without the authored scale folded back in,
    /// a model authored at anything other than 1x would snap to unit size on
    /// the first step. Mirrors `HavokRigidBody::sync_scale`.
    pub sync_scale: [f64; 3],

    /// Body-LOCAL offset from the body origin to the centre of a PRIMITIVE or
    /// convex collision shape, captured at `createRigidBody` as the cooked
    /// geometry's AABB centre. Director/PhysX pose a shape relative to the
    /// actor, and an authored proxy is often not centred on its own origin — a
    /// character capsule has its origin at the FEET (AreaZero's
    /// `FPSPlayer1Stand`: half-height 1.0, AABB centre +1.0, so the geometry
    /// spans 0..2 above the origin). Centring the box on the origin instead
    /// buried the character half its height in the floor, which put its ground
    /// ray 1.1 above the surface and left it permanently "airborne".
    ///
    /// NOT applied to #concaveShape: those cook their real vertex positions, so
    /// the offset is already baked into the triangle mesh.
    pub shape_offset: [f64; 3],

    /// Accumulated Lingo `applyForce` (PxForceMode::eFORCE): integrated as
    /// `v += F/m·dt` across the NEXT simulate() and then cleared, matching
    /// PxRigidBody::addForce semantics (force lives until the step consumes it).
    pub pending_force: [f64; 3],
    /// Accumulated Lingo `applyTorque` / point-offset torque from
    /// `applyForce(F, point)`: integrated as `ω += I⁻¹·T·dt`, then cleared.
    pub pending_torque: [f64; 3],
}

impl Default for PhysXRigidBody {
    fn default() -> Self {
        Self {
            id: 0, name: Symbol::default(), model_name: String::new(),
            body_type: PhysXBodyType::Dynamic,
            shape: PhysXShapeKind::Box,
            position: [0.0; 3], orientation: [1.0, 0.0, 0.0, 0.0],
            linear_velocity: [0.0; 3], angular_velocity: [0.0; 3],
            mass: 1.0, center_of_mass: [0.0; 3], use_center_of_mass: false,
            friction: 0.5, restitution: 0.5,
            linear_damping: 0.0, angular_damping: 0.0,
            sleep_threshold: 0.0316, sleep_mode: 0,
            collision_group: 0, is_trigger: false, ccd_enabled: false,
            pinned: false, axis_affinity: true, cached_is_sleeping: false,
            user_data: 0, constraint_ids: Vec::new(),
            radius: 1.0, half_extents: [0.5, 0.5, 0.5], half_height: 1.0,
            convex_hull: None,
            triangle_mesh: None,
            sync_scale: [1.0; 3],
            shape_offset: [0.0; 3],
            pending_force: [0.0; 3],
            pending_torque: [0.0; 3],
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PhysXBodyType { Static, Dynamic, Kinematic }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PhysXShapeKind { Box, Sphere, Capsule, ConvexShape, ConcaveShape }

/// Joints + springs share one Vec keyed by ID; the variant tells us which.
/// Mirrors the C# `CPhysicsConstraintAGEIA` hierarchy.
#[derive(Debug, Clone)]
pub struct PhysXConstraint {
    pub id: u32,
    pub name: Symbol,
    pub kind: PhysXConstraintKind,
    pub body_a: Option<u32>,                 // body id
    pub body_b: Option<u32>,
    pub anchor_a: [f64; 3],
    pub anchor_b: [f64; 3],
    pub stiffness: f64,
    pub damping: f64,
    pub rest_length: f64,
    /// Axis-angle (LinearJoint stores its own orientation; D6 has axis-angle drive too).
    pub orientation: [f64; 4],
    /// D6-only: per-axis motion[XYZ TwistSwing1Swing2] (0=Locked / 1=Limited / 2=Free).
    pub d6_linear_motion: [u8; 3],
    pub d6_angular_motion: [u8; 3],
    /// D6-only local joint frame. Per the 11.5 dictionary these read back as a VOID
    /// vector until explicitly set, hence Option rather than a zero default:
    /// "available only after you set the values explicitly for these properties".
    /// Order: axisA, normalA, axisB, normalB, anchorA, anchorB.
    pub d6_local_axis_a: Option<[f64; 3]>,
    pub d6_local_normal_a: Option<[f64; 3]>,
    pub d6_local_axis_b: Option<[f64; 3]>,
    pub d6_local_normal_b: Option<[f64; 3]>,
    pub d6_local_anchor_a: Option<[f64; 3]>,
    pub d6_local_anchor_b: Option<[f64; 3]>,
    /// D6-only limits, each `[limitValue, stiffness, damping, restitution]`.
    pub d6_twist_limit: Option<[f64; 4]>,
    pub d6_swing1_limit: Option<[f64; 4]>,
    pub d6_swing2_limit: Option<[f64; 4]>,
    pub d6_linear_limit: Option<[f64; 4]>,
}

impl Default for PhysXConstraint {
    fn default() -> Self {
        Self {
            id: 0, name: Symbol::default(),
            kind: PhysXConstraintKind::Spring,
            body_a: None, body_b: None,
            anchor_a: [0.0; 3], anchor_b: [0.0; 3],
            stiffness: 0.0, damping: 0.0, rest_length: 0.0,
            orientation: [1.0, 0.0, 0.0, 0.0],
            d6_linear_motion: [0; 3], d6_angular_motion: [0; 3],
            d6_local_axis_a: None, d6_local_normal_a: None,
            d6_local_axis_b: None, d6_local_normal_b: None,
            d6_local_anchor_a: None, d6_local_anchor_b: None,
            d6_twist_limit: None, d6_swing1_limit: None,
            d6_swing2_limit: None, d6_linear_limit: None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PhysXConstraintKind { Spring, LinearJoint, AngularJoint, D6Joint }

/// A static heightfield terrain. Director chapter 15: created via
/// `world.createTerrain(name, desc, position, orientation, rowScale,
/// columnScale, heightScale)`. The terrain is treated as a static-only
/// collider — it never integrates and never receives impulses.
#[derive(Debug, Clone)]
pub struct PhysXTerrain {
    pub id: u32,
    pub name: Symbol,
    pub height_field: crate::player::handlers::datum_handlers::cast_member::physx_gu_heightfield::GuHeightField,
    pub friction: f64,
    pub restitution: f64,
    /// World-space position offset applied to the heightfield's local origin.
    pub position: [f64; 3],
    /// Axis-angle (axis.x, axis.y, axis.z, angle_deg) — same convention as
    /// `PhysXRigidBody.orientation`.
    pub orientation: [f64; 4],
}

/// The full simulation world. Direct port of the C#
/// `CPhysicsWorldAGEIA` field set, minus shape/cooking helpers.
#[derive(Debug, Clone)]
pub struct PhysXPhysicsState {
    // ---- World props (Lingo getters/setters) ----
    pub initialized: bool,                    // Lingo `isInitialized`
    pub paused: bool,
    pub gravity: [f64; 3],
    pub friction: f64,
    pub restitution: f64,
    pub linear_damping: f64,
    pub angular_damping: f64,
    pub contact_tolerance: f64,
    pub sleep_threshold: f64,
    pub sleep_mode: PhysXSleepMode,
    pub scaling_factor: [f64; 3],             // length, mass, time scales
    pub time_step: f64,
    pub time_step_mode: PhysXTimeStepMode,
    pub sub_steps: u32,                       // Director: `subSteps` (NOT `subStepCount`)
    pub sim_time: f64,                        // accumulated sim time → getSimulationTime()
    pub three_d_member_name: String,          // associated 3D world member

    // ---- Containers ----
    pub bodies: Vec<PhysXRigidBody>,
    pub constraints: Vec<PhysXConstraint>,    // joints + springs (kind tags)
    /// Static heightfield terrains (Director chapter 15: createTerrain).
    /// Treated as static-only; not integrated, no impulses applied.
    pub terrains: Vec<PhysXTerrain>,

    // ---- Collision callbacks (Director chapter 15) ----
    /// `disableCollision()` global flag.
    pub all_collisions_disabled: bool,
    pub all_callbacks_disabled: bool,
    /// Body-name pairs where collision is filtered. Canonical (min, max) order.
    pub disabled_collision_pairs: std::collections::HashSet<(Symbol, Symbol)>,
    pub disabled_callback_pairs: std::collections::HashSet<(Symbol, Symbol)>,
    /// Single bodies whose collisions are globally disabled.
    pub body_collision_disabled: std::collections::HashSet<Symbol>,
    pub body_callback_disabled: std::collections::HashSet<Symbol>,
    /// `registerCollisionCallback(#handler, scriptRef)`.
    pub collision_callback_handler: Option<Symbol>,
    pub collision_callback_script_ref: Option<crate::player::DatumRef>,
    /// Reports captured during the last Simulate(); drained by NotifyCollisions.
    /// Each entry: (bodyA_id, bodyB_id, contact_points, contact_normals).
    pub pending_collisions: Vec<(u32, u32, Vec<[f64; 3]>, Vec<[f64; 3]>)>,

    // ---- Bookkeeping ----
    pub next_body_id: u32,
    pub next_constraint_id: u32,
    pub next_terrain_id: u32,
    pub last_tick_ms: u64,

    /// When true, the body-vs-body iterative solver routes through the
    /// verbatim PhysX 3.4 SOA path (`PxsSolverSoa` in
    /// `physx_soa_solver.rs`) instead of the in-place AoS sequential-impulse
    /// loop. Body-vs-terrain pairs always run on the AoS path. Default off —
    /// the SoA path is parity-validated in C# but extra wiring (warm-start
    /// cache, synthetic static body for terrains) is still pending.
    pub use_soa_solver: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PhysXSleepMode { Energy, LinearVelocity }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PhysXTimeStepMode { Equal, Automatic }

impl Default for PhysXPhysicsState {
    fn default() -> Self {
        Self {
            initialized: false, paused: false,
            gravity: [0.0, -9.81, 0.0],
            friction: 0.5, restitution: 0.5,
            linear_damping: 0.0, angular_damping: 0.0,
            contact_tolerance: 0.01,
            sleep_threshold: 0.0316, sleep_mode: PhysXSleepMode::Energy,
            scaling_factor: [1.0, 1.0, 1.0],
            time_step: 1.0 / 60.0,
            time_step_mode: PhysXTimeStepMode::Equal,
            sub_steps: 1,
            sim_time: 0.0,
            three_d_member_name: String::new(),
            bodies: Vec::new(),
            constraints: Vec::new(),
            terrains: Vec::new(),
            all_collisions_disabled: false,
            all_callbacks_disabled: false,
            disabled_collision_pairs: std::collections::HashSet::new(),
            disabled_callback_pairs: std::collections::HashSet::new(),
            body_collision_disabled: std::collections::HashSet::new(),
            body_callback_disabled: std::collections::HashSet::new(),
            collision_callback_handler: None,
            collision_callback_script_ref: None,
            pending_collisions: Vec::new(),
            next_body_id: 1,
            next_constraint_id: 1,
            next_terrain_id: 1,
            last_tick_ms: 0,
            use_soa_solver: false,
        }
    }
}

#[derive(Clone)]
pub struct PhysXPhysicsMember {
    pub state: PhysXPhysicsState,
}

impl fmt::Debug for PhysXPhysicsMember {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        write!(f, "PhysXPhysicsMember(initialized={}, bodies={}, constraints={})",
            self.state.initialized,
            self.state.bodies.len(),
            self.state.constraints.len())
    }
}

impl PhysXPhysicsMember {
    pub fn new() -> Self { Self { state: PhysXPhysicsState::default() } }
}

/// A 3D Groove `.3GM` model cast member (type-15 Xtra media whose XMED payload
/// begins with the `3DGM` magic). Holds the raw bytes; the Groove Xtra parses
/// them into a model when the movie calls `LoadShape(memberName)`.
#[derive(Clone, Debug, PartialEq)]
pub struct Groove3gmMember {
    pub data: Vec<u8>,
}

#[allow(dead_code)]
#[derive(Clone)]
pub enum CastMemberType {
    Field(FieldMember),
    Text(TextMember),
    Button(ButtonMember),
    Script(ScriptMember),
    Bitmap(BitmapMember),
    Palette(PaletteMember),
    Shape(ShapeMember),
    VectorShape(VectorShapeMember),
    FilmLoop(FilmLoopMember),
    Sound(SoundMember),
    Font(FontMember),
    Flash(FlashMember),
    Movie(MovieMember),
    Shockwave3d(Shockwave3dMember),
    HavokPhysics(HavokPhysicsMember),
    PhysXPhysics(PhysXPhysicsMember),
    Groove3gm(Groove3gmMember),
    Transition(TransitionMember),
    Unknown,
}

/// A score/puppet transition member. Director stores these as raw member-type 14,
/// so they're detected by their transition-shaped specific data rather than the type
/// id. `info` carries the built-in effect (Director 11.5 Dictionary `puppetTransition`).
#[derive(Clone, Debug)]
pub struct TransitionMember {
    pub info: TransitionInfo,
}

/// Decoded from a transition member's 6-byte specific data:
/// `[reserved][chunkSize][type][flags=02][duration u16 BE]`.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TransitionInfo {
    /// Built-in transition code, 1-52.
    pub transition_type: u8,
    /// Chunk size in pixels (1-128); smaller = smoother/slower.
    pub chunk_size: u8,
    /// Duration in milliseconds.
    pub duration_ms: u16,
}

impl TransitionInfo {
    /// Parse from a transition member's specific data. Returns None unless it looks
    /// like a transition (>=6 bytes with a valid 1-52 type code) — this is what
    /// distinguishes a built-in transition (raw type 14) from a real Xtra member.
    pub fn from_member_bytes(b: &[u8]) -> Option<TransitionInfo> {
        if b.len() < 6 { return None; }
        let ty = b[2];
        if ty == 0 || ty > 52 { return None; }
        Some(TransitionInfo {
            transition_type: ty,
            chunk_size: b[1].max(1),
            duration_ms: ((b[4] as u16) << 8) | (b[5] as u16),
        })
    }
}

#[derive(Debug, PartialEq)]
pub enum CastMemberTypeId {
    Field,
    Text,
    Button,
    Script,
    Bitmap,
    Palette,
    Shape,
    VectorShape,
    FilmLoop,
    Sound,
    Font,
    Flash,
    Movie,
    Shockwave3d,
    HavokPhysics,
    PhysXPhysics,
    Groove3gm,
    Transition,
    Unknown,
}

impl fmt::Debug for CastMemberType {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        match self {
            Self::Field(_) => {
                write!(f, "Field")
            }
            Self::Text(_) => {
                write!(f, "Text")
            }
            Self::Button(_) => {
                write!(f, "Button")
            }
            Self::Script(_) => {
                write!(f, "Script")
            }
            Self::Bitmap(_) => {
                write!(f, "Bitmap")
            }
            Self::Palette(_) => {
                write!(f, "Palette")
            }
            Self::Shape(_) => {
                write!(f, "Shape")
            }
            Self::VectorShape(_) => {
                write!(f, "VectorShape")
            }
            Self::FilmLoop(_) => {
                write!(f, "FilmLoop")
            }
            Self::Sound(_) => {
                write!(f, "Sound")
            }
            Self::Font(_) => {
                write!(f, "Font")
            }
            Self::Flash(_) => {
                write!(f, "Flash")
            }
            Self::Movie(_) => {
                write!(f, "Movie")
            }
            Self::Shockwave3d(_) => {
                write!(f, "Shockwave3d")
            }
            Self::HavokPhysics(_) => {
                write!(f, "HavokPhysics")
            }
            Self::PhysXPhysics(_) => {
                write!(f, "PhysXPhysics")
            }
            Self::Transition(_) => {
                write!(f, "Transition")
            }
            Self::Groove3gm(_) => {
                write!(f, "Groove3gm")
            }
            Self::Unknown => {
                write!(f, "Unknown")
            }
        }
    }
}

impl CastMemberTypeId {
    pub fn symbol_string(&self) -> Result<&str, ScriptError> {
        return match self {
            Self::Field => Ok("field"),
            Self::Text => Ok("text"),
            Self::Button => Ok("button"),
            Self::Script => Ok("script"),
            Self::Bitmap => Ok("bitmap"),
            Self::Palette => Ok("palette"),
            Self::Shape => Ok("shape"),
            Self::VectorShape => Ok("vectorShape"),
            Self::FilmLoop => Ok("filmLoop"),
            Self::Sound => Ok("sound"),
            Self::Font => Ok("font"),
            Self::Flash => Ok("flash"),
            Self::Movie => Ok("movie"),
            Self::Shockwave3d => Ok("shockwave3d"),
            Self::HavokPhysics => Ok("havok"),
            Self::PhysXPhysics => Ok("physics"),
            // Director/Groove report .3GM shape members as #G3D — the Groove
            // Lingo gates shape loading on `member.type = #G3D`
            // (gGroove: LoadShape only if #G3D), so returning #groove made every
            // shape get skipped → ShapeID -1 → no 3D world.
            Self::Groove3gm => Ok("g3d"),
            Self::Transition => Ok("transition"),
            Self::Unknown => Ok("unknown"),
        };
    }
}

impl CastMemberType {
    pub fn member_type_id(&self) -> CastMemberTypeId {
        return match self {
            Self::Field(_) => CastMemberTypeId::Field,
            Self::Text(_) => CastMemberTypeId::Text,
            Self::Button(_) => CastMemberTypeId::Button,
            Self::Script(_) => CastMemberTypeId::Script,
            Self::Bitmap(_) => CastMemberTypeId::Bitmap,
            Self::Palette(_) => CastMemberTypeId::Palette,
            Self::Shape(_) => CastMemberTypeId::Shape,
            Self::VectorShape(_) => CastMemberTypeId::VectorShape,
            Self::FilmLoop(_) => CastMemberTypeId::FilmLoop,
            Self::Sound(_) => CastMemberTypeId::Sound,
            Self::Font(_) => CastMemberTypeId::Font,
            Self::Flash(_) => CastMemberTypeId::Flash,
            Self::Movie(_) => CastMemberTypeId::Movie,
            Self::Shockwave3d(_) => CastMemberTypeId::Shockwave3d,
            Self::HavokPhysics(_) => CastMemberTypeId::HavokPhysics,
            Self::PhysXPhysics(_) => CastMemberTypeId::PhysXPhysics,
            Self::Groove3gm(_) => CastMemberTypeId::Groove3gm,
            // No dedicated CastMemberTypeId; transitions are score-driven, not queried
            // via `the type of member`, so Unknown is adequate here.
            Self::Transition(_) => CastMemberTypeId::Transition,
            Self::Unknown => CastMemberTypeId::Unknown,
        };
    }

    pub fn type_string(&self) -> &str {
        return match self {
            Self::Field(_) => "field",
            Self::Text(_) => "text",
            Self::Button(_) => "button",
            Self::Script(_) => "script",
            Self::Bitmap(_) => "bitmap",
            Self::Palette(_) => "palette",
            Self::Shape(_) => "shape",
            Self::VectorShape(_) => "vectorShape",
            Self::FilmLoop(_) => "filmLoop",
            Self::Sound(_) => "sound",
            Self::Font(_) => "font",
            Self::Flash(_) => "flash",
            Self::Movie(_) => "movie",
            Self::Shockwave3d(w3d) => if w3d.converted_from_text { "text" } else { "shockwave3d" },
            Self::HavokPhysics(_) => "havok",
            Self::PhysXPhysics(_) => "physics",
            Self::Groove3gm(_) => "groove3gm",
            Self::Transition(_) => "transition",
            _ => "unknown",
        };
    }

    #[allow(dead_code)]
    pub fn as_script(&self) -> Option<&ScriptMember> {
        return match self {
            Self::Script(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_field(&self) -> Option<&FieldMember> {
        return match self {
            Self::Field(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_field_mut(&mut self) -> Option<&mut FieldMember> {
        return match self {
            Self::Field(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_text(&self) -> Option<&TextMember> {
        return match self {
            Self::Text(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_text_mut(&mut self) -> Option<&mut TextMember> {
        return match self {
            Self::Text(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_button(&self) -> Option<&ButtonMember> {
        return match self {
            Self::Button(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_button_mut(&mut self) -> Option<&mut ButtonMember> {
        return match self {
            Self::Button(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_bitmap(&self) -> Option<&BitmapMember> {
        return match self {
            Self::Bitmap(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_bitmap_mut(&mut self) -> Option<&mut BitmapMember> {
        return match self {
            Self::Bitmap(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_palette(&self) -> Option<&PaletteMember> {
        return match self {
            Self::Palette(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_film_loop(&self) -> Option<&FilmLoopMember> {
        return match self {
            Self::FilmLoop(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_film_loop_mut(&mut self) -> Option<&mut FilmLoopMember> {
        return match self {
            Self::FilmLoop(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_sound(&self) -> Option<&SoundMember> {
        return match self {
            Self::Sound(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_sound_mut(&mut self) -> Option<&mut SoundMember> {
        return match self {
            Self::Sound(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_font(&self) -> Option<&FontMember> {
        return match self {
            Self::Font(data) => Some(data),
            _ => None,
        };
    }

    pub fn as_flash(&self) -> Option<&FlashMember> {
        return match self {
            Self::Flash(data) => { Some(data) }
            _ => { None }
        }
    }

    pub fn as_flash_mut(&mut self) -> Option<&mut FlashMember> {
        return match self {
            Self::Flash(data) => { Some(data) }
            _ => { None }
        }
    }

    pub fn as_movie(&self) -> Option<&MovieMember> {
        return match self {
            Self::Movie(data) => { Some(data) }
            _ => { None }
        }
    }

    pub fn as_movie_mut(&mut self) -> Option<&mut MovieMember> {
        return match self {
            Self::Movie(data) => { Some(data) }
            _ => { None }
        }
    }

    pub fn as_shockwave3d(&self) -> Option<&Shockwave3dMember> {
        match self {
            Self::Shockwave3d(data) => Some(data),
            Self::Text(text) => text.w3d.as_deref(),
            _ => None,
        }
    }

    pub fn as_shockwave3d_mut(&mut self) -> Option<&mut Shockwave3dMember> {
        match self {
            Self::Shockwave3d(data) => Some(data),
            Self::Text(text) => text.w3d.as_deref_mut(),
            _ => None,
        }
    }

    pub fn as_physx_physics(&self) -> Option<&PhysXPhysicsMember> {
        match self {
            Self::PhysXPhysics(data) => Some(data),
            _ => None,
        }
    }

    pub fn as_physx_physics_mut(&mut self) -> Option<&mut PhysXPhysicsMember> {
        match self {
            Self::PhysXPhysics(data) => Some(data),
            _ => None,
        }
    }
}

/// Decode an RTE member's RTE2 pre-rendered bitmap into 32-bit RGBA.
///
/// Format (matches ScummVM's Director `RTE2::createSurface`):
/// - Header: width (BE u16), height (BE u16), bpp (BE u16, =4), flags (2) = 8B.
/// - Body, scanned per row left-to-right. Each step reads a `check` byte:
///   - `check == 0x1f`: color-change escape — the next 3 bytes are r,g,b for
///     subsequent pixels.
///   - otherwise alpha = `check * 255 / max` where `max = (1<<bpp)-1` (15).
///     - if `check == 0` or `check == max` (the run-coded extremes): read a
///       `count` byte and emit `count` pixels of that alpha. The special
///       `check==0, count==0` means end-of-line (rest stays transparent).
///     - else (intermediate alpha): a single pixel.
///
/// `fg` is the default foreground color (from the cast member's info); inline
/// `0x1f` escapes override it. Returns (width, height, rgba) or None.
fn decode_rte2_bitmap(data: &[u8], fg: (u8, u8, u8)) -> Option<(u16, u16, Vec<u8>)> {
    if data.len() < 8 {
        return None;
    }
    let w = ((data[0] as usize) << 8) | data[1] as usize;
    let h = ((data[2] as usize) << 8) | data[3] as usize;
    if w == 0 || h == 0 || w > 4096 || h > 4096 {
        return None;
    }
    let mut bpp = ((data[4] as u32) << 8) | data[5] as u32;
    if bpp == 0 || bpp > 8 {
        bpp = 4;
    }
    let max = (1u32 << bpp) - 1;
    let p = &data[8..];
    let mut rgba = vec![0u8; w * h * 4];
    let (mut r, mut g, mut b) = fg;
    let mut i = 0usize;
    for y in 0..h {
        let mut x = 0usize;
        while x < w {
            if i >= p.len() {
                break;
            }
            let check = p[i] as u32;
            i += 1;
            if check == 0x1f {
                // Color-change escape: next 3 bytes are r,g,b.
                if i + 2 < p.len() {
                    r = p[i];
                    g = p[i + 1];
                    b = p[i + 2];
                    i += 3;
                }
                continue;
            }
            let alpha = (check * 255 / max) as u8;
            if check == 0 || check == max {
                // Run-coded extreme: a count byte follows.
                if i >= p.len() {
                    break;
                }
                let count = p[i];
                i += 1;
                if count == 0 && check == 0 {
                    // End of line — remaining pixels stay transparent.
                    break;
                }
                for _ in 0..count {
                    if x >= w {
                        break;
                    }
                    let idx = (y * w + x) * 4;
                    rgba[idx] = r;
                    rgba[idx + 1] = g;
                    rgba[idx + 2] = b;
                    rgba[idx + 3] = alpha;
                    x += 1;
                }
            } else {
                // Intermediate alpha: single pixel.
                let idx = (y * w + x) * 4;
                rgba[idx] = r;
                rgba[idx + 1] = g;
                rgba[idx + 2] = b;
                rgba[idx + 3] = alpha;
                x += 1;
            }
        }
    }
    Some((w as u16, h as u16, rgba))
}

impl CastMember {
    fn chunk_type_name(c: &Chunk) -> &'static str {
        match c {
            Chunk::Cast(_) => "Cast",
            Chunk::CastList(_) => "CastList",
            Chunk::CastMember(_) => "CastMember",
            Chunk::CastInfo(_) => "CastInfo",
            Chunk::Config(_) => "Config",
            Chunk::InitialMap(_) => "InitialMap",
            Chunk::KeyTable(_) => "KeyTable",
            Chunk::MemoryMap(_) => "MemoryMap",
            Chunk::Script(_) => "Script",
            Chunk::ScriptContext(_) => "ScriptContext",
            Chunk::ScriptNames(_) => "ScriptNames",
            Chunk::FrameLabels(_) => "FrameLabels",
            Chunk::Score(_) => "Score",
            Chunk::ScoreOrder(_) => "ScoreOrder",
            Chunk::TileList(_) => "TileList",
            Chunk::Text(_) => "Text",
            Chunk::RteText(_) => "RteText",
            Chunk::RteBitmap(_) => "RteBitmap",
            Chunk::Bitmap(_) => "Bitmap",
            Chunk::Palette(_) => "Palette",
            Chunk::Sound(_) => "Sound",
            Chunk::SndHeader(_) => "SndHeader",
            Chunk::SndSamples(_) => "SndSamples",
            Chunk::Media(_) => "Media",
            Chunk::XMedia(_) => "XMedia",
            Chunk::CstInfo(_) => "Cinf",
            Chunk::Effect(_) => "FXmp",
            Chunk::Thum(_) => "Thum",
            Chunk::XtraList(_) => "XTRl",
            Chunk::CuePoints(_) => "cupt",
            Chunk::Raw(_) => "Raw",
        }
    }

    /// Recursively searches children of a CastMemberDef for a sound chunk
    fn find_sound_chunk_in_def(def: &CastMemberDef) -> Option<SoundChunk> {
        // First check for direct sound/media chunks
        for child_opt in &def.children {
            if let Some(child) = child_opt {
                match child {
                    Chunk::Sound(s) => return Some(s.clone()),
                    Chunk::Media(m) => {
                        if !m.audio_data.is_empty() {
                            let mut sc = SoundChunk::new(m.audio_data.clone());
                            sc.set_metadata(m.sample_rate, 1, if m.is_compressed { 0 } else { 16 });
                            return Some(sc);
                        }
                    }
                    Chunk::CastMember(_) => {
                        // `CastMemberChunk` has no children, so nothing to recurse into
                        continue;
                    }
                    _ => {}
                }
            }
        }
        // Then try sndH + sndS combination
        let snd_header = def.children.iter()
            .filter_map(|c| c.as_ref())
            .find_map(|c| match c { Chunk::SndHeader(h) => Some(h), _ => None });
        let snd_samples = def.children.iter()
            .filter_map(|c| c.as_ref())
            .find_map(|c| match c { Chunk::SndSamples(d) => Some(d), _ => None });
        if let (Some(header), Some(samples)) = (snd_header, snd_samples) {
            return Some(SoundChunk::from_snd_header_and_samples(header, samples));
        }
        None
    }

    fn child_has_sound_in_def(def: &CastMemberDef) -> bool {
        let has_direct = def.children.iter().any(|c| match c {
            Some(Chunk::Sound(_)) => true,
            Some(Chunk::Media(m)) => !m.audio_data.is_empty(),
            Some(Chunk::CastMember(_)) => false,
            _ => false,
        });
        if has_direct { return true; }
        // Check for sndH + sndS
        let has_header = def.children.iter().any(|c| matches!(c, Some(Chunk::SndHeader(_))));
        let has_samples = def.children.iter().any(|c| matches!(c, Some(Chunk::SndSamples(_))));
        has_header && has_samples
    }

    /// Recursively find a SoundChunk in a Chunk (handles Media & nested CastMembers)
    fn find_sound_chunk_in_chunk(chunk: &Chunk) -> Option<SoundChunk> {
        match chunk {
            Chunk::Sound(s) => Some(s.clone()),
            Chunk::Media(m) if !m.audio_data.is_empty() => {
                let mut sc = SoundChunk::new(m.audio_data.clone());
                sc.set_metadata(m.sample_rate, 1, if m.is_compressed { 0 } else { 16 });
                Some(sc)
            }
            Chunk::CastMember(cm) => {
                // CastMemberChunk has no children; nothing to recurse
                None
            }
            _ => None,
        }
    }

    // Check if an Option<Chunk> contains sound
    fn chunk_has_sound(chunk_opt: &Option<Chunk>) -> bool {
        match chunk_opt {
            Some(c) => match c {
                Chunk::Sound(_) => true,
                Chunk::Media(m) => !m.audio_data.is_empty(),
                _ => false,
            },
            None => false,
        }
    }

    // Extract SoundChunk from an Option<Chunk>
    fn find_sound_chunk(chunk_opt: &Option<Chunk>) -> Option<SoundChunk> {
        match chunk_opt {
            Some(c) => match c {
                Chunk::Sound(s) => Some(s.clone()),
                Chunk::Media(m) => {
                    if !m.audio_data.is_empty() {
                        Some(SoundChunk::from_media(m))
                    } else {
                        None
                    }
                }
                _ => None,
            },
            None => None,
        }
    }

    /// Compute the initial bounding rectangle for a filmloop by finding the
    /// bounding box of all sprites across all frames.
    ///
    /// The coordinate system for filmloop sprites is relative to this initial_rect.
    /// When rendering, sprite positions are translated by subtracting initial_rect.left/top.
    fn compute_filmloop_initial_rect(
        frame_channel_data: &[(u32, u16, crate::director::chunks::score::ScoreFrameChannelData)],
        _reg_point: (i16, i16),
    ) -> super::geometry::IntRect {
        let mut min_x = i32::MAX;
        let mut min_y = i32::MAX;
        let mut max_x = i32::MIN;
        let mut max_y = i32::MIN;
        let mut found_any = false;

        for (_frame_idx, channel_idx, data) in frame_channel_data.iter() {
            // Skip effect channels (channels 0-5 in the raw data)
            // Real sprite channels start at index 6
            if *channel_idx < 6 {
                continue;
            }

            // Inline shape sprites (no cast member): cast_lib=0xFFFE, cast_member=0,
            // with non-zero width/height and the sprite-record geometry encoding
            // an oval/rect/etc. directly. Coke Studios' nav_circleanim uses this
            // to draw a radar-ping animation as growing concentric ovals.
            let is_inline_shape = data.cast_lib == 0xFFFE && data.cast_member == 0
                && (data.width > 0 || data.height > 0);

            // Skip empty sprites (no cast member assigned, and not an inline shape).
            // Also skip sprites with cast_lib == 0 which are typically invalid/placeholder entries
            // (cast_lib 65535 is valid - it's used for internal/embedded casts;
            //  cast_lib 65534 is the inline-shape sentinel handled above).
            if (data.cast_member == 0 && !is_inline_shape) || data.cast_lib == 0
                || (data.width == 0 && data.height == 0)
            {
                continue;
            }

            // Director shape sprites — including inline shapes here — center on
            // (pos_x, pos_y). Same offset as bitmaps.
            let (reg_offset_x, reg_offset_y) = (data.width as i32 / 2, data.height as i32 / 2);
            let sprite_left = data.pos_x as i32 - reg_offset_x;
            let sprite_top = data.pos_y as i32 - reg_offset_y;
            let sprite_right = sprite_left + data.width as i32;
            let sprite_bottom = sprite_top + data.height as i32;

            debug!(
                "FilmLoop initial_rect: frame {} channel {} cast {}:{} pos ({}, {}) size {}x{} -> bounds ({}, {}, {}, {})",
                _frame_idx, channel_idx, data.cast_lib, data.cast_member,
                data.pos_x, data.pos_y, data.width, data.height,
                sprite_left, sprite_top, sprite_right, sprite_bottom
            );

            if sprite_left < min_x {
                min_x = sprite_left;
            }
            if sprite_top < min_y {
                min_y = sprite_top;
            }
            if sprite_right > max_x {
                max_x = sprite_right;
            }
            if sprite_bottom > max_y {
                max_y = sprite_bottom;
            }
            found_any = true;
        }

        if !found_any {
            // No sprites found, return a default rect at origin
            debug!("FilmLoop initial_rect: no sprites found, using default (0, 0, 1, 1)");
            return super::geometry::IntRect::from(0, 0, 1, 1);
        }

        debug!(
            "FilmLoop initial_rect computed: ({}, {}, {}, {})",
            min_x, min_y, max_x, max_y
        );
        super::geometry::IntRect::from(min_x, min_y, max_x, max_y)
    }

    fn decode_bitmap_from_bitd(
        member_def: &CastMemberDef,
        bitmap_info: &BitmapInfo,
        cast_lib: u32,
        number: u32,
        bitmap_manager: &mut BitmapManager,
    ) -> BitmapRef {
        // Search all children for the first Bitmap(BITD) chunk
        // (it may not be at index 0 — other slots can be None or other chunk types)
        let bitd_chunk = member_def.children.iter()
            .find_map(|c| c.as_ref().and_then(|chunk| chunk.as_bitmap()));

        if let Some(bitd_chunk) = bitd_chunk {
            // Check if BITD contains JPEG data with a separate ALFA chunk
            let is_jpeg = bitd_chunk.data.len() >= 3
                && bitd_chunk.data[0] == 0xFF
                && bitd_chunk.data[1] == 0xD8
                && bitd_chunk.data[2] == 0xFF;

            let alfa_data: Option<&Vec<u8>> = member_def.children.iter().find_map(|c| {
                c.as_ref().and_then(|chunk| match chunk {
                    Chunk::Raw(data) if !data.is_empty() => Some(data),
                    _ => None,
                })
            });

            if is_jpeg && alfa_data.is_some() {
                // JPEG in BITD + separate ALFA chunk: use decode_jpeg_bitmap which
                // correctly combines JPEG RGB with ALFA alpha channel.
                // decode_jpeg_bitd only looks for alpha AFTER FFD9 inside the BITD data,
                // missing the separate ALFA chunk entirely.
                match decode_jpeg_bitmap(&bitd_chunk.data, bitmap_info, alfa_data) {
                    Ok(new_bitmap) => bitmap_manager.add_bitmap(new_bitmap),
                    Err(e) => {
                        warn!(
                            "Failed to decode JPEG+ALFA bitmap {}: {:?}. Using empty image.",
                            number, e
                        );
                        bitmap_manager.add_bitmap(Bitmap::new(
                            1, 1, 8, 8, 0,
                            PaletteRef::BuiltIn(BuiltInPalette::GrayScale),
                        ))
                    }
                }
            } else {
                let decompressed =
                    decompress_bitmap(&bitd_chunk.data, bitmap_info, cast_lib, bitd_chunk.version);
                match decompressed {
                    Ok(new_bitmap) => bitmap_manager.add_bitmap(new_bitmap),
                    Err(e) => {
                        warn!(
                            "Failed to decompress bitmap {}: {:?}. Using empty image.",
                            number, e
                        );
                        bitmap_manager.add_bitmap(Bitmap::new(
                            1, 1, 8, 8, 0,
                            PaletteRef::BuiltIn(BuiltInPalette::GrayScale),
                        ))
                    }
                }
            }
        } else {
            // Some 32-bit members store the colour image as a JPEG in an `ediM`
            // (Media) chunk plus a separate `ALFA` alpha plane, with NO BITD.
            // Route those to the JPEG+ALFA decoder. Without this, the Raw fallback
            // below feeds the ALFA alpha plane (w*h bytes) into the 32-bit RLE
            // decoder, which expects w*h*4 bytes — it decodes only height/4 rows
            // and leaves the rest of the image black.
            let edim_jpeg: Option<&Vec<u8>> = member_def.children.iter().find_map(|c| {
                c.as_ref().and_then(|chunk| match chunk {
                    Chunk::Media(m)
                        if m.audio_data.len() >= 3
                            && m.audio_data[0] == 0xFF
                            && m.audio_data[1] == 0xD8
                            && m.audio_data[2] == 0xFF => Some(&m.audio_data),
                    _ => None,
                })
            });
            if let Some(jpeg) = edim_jpeg {
                let alfa: Option<&Vec<u8>> = member_def.children.iter().find_map(|c| {
                    c.as_ref().and_then(|chunk| match chunk {
                        Chunk::Raw(d) if !d.is_empty() => Some(d),
                        _ => None,
                    })
                });
                return match decode_jpeg_bitmap(jpeg, bitmap_info, alfa) {
                    Ok(new_bitmap) => bitmap_manager.add_bitmap(new_bitmap),
                    Err(e) => {
                        warn!("Failed to decode ediM JPEG bitmap {}: {:?}. Using empty image.", number, e);
                        bitmap_manager.add_bitmap(Bitmap::new(
                            1, 1, 8, 8, 0, PaletteRef::BuiltIn(BuiltInPalette::GrayScale),
                        ))
                    }
                };
            }

            // A 32-bit alpha+JPEG member whose ediM (colour) chunk is unresolvable —
            // e.g. an afterburned .dcr whose ABMP omits the per-member ediM while the
            // KEY* table still references it — arrives here with ONLY the ALFA plane.
            // The ALFA RLE-decompresses to w*h bytes; feeding it to the 32-bit decoder
            // (which expects w*h*4) over-reads at row height/4 and renders black with a
            // warning per bitmap. Build a transparent bitmap from the alpha plane
            // instead (the colour is genuinely absent from this file).
            if bitmap_info.bit_depth == 32 {
                let alfa = member_def.children.iter().find_map(|c| {
                    c.as_ref().and_then(|chunk| match chunk {
                        Chunk::Raw(d) if !d.is_empty() => Some(d),
                        _ => None,
                    })
                });
                if let Some(alfa) = alfa {
                    let (w, h) = (bitmap_info.width as usize, bitmap_info.height as usize);
                    let alpha = decompress_alpha_rle(alfa, w, h);
                    let mut rgba = vec![0u8; w * h * 4];
                    for i in 0..(w * h) {
                        rgba[i * 4 + 3] = alpha.get(i).copied().unwrap_or(0);
                    }
                    return bitmap_manager.add_bitmap(Bitmap {
                        width: bitmap_info.width,
                        height: bitmap_info.height,
                        bit_depth: 32,
                        original_bit_depth: 32,
                        data: rgba,
                        palette_ref: PaletteRef::BuiltIn(BuiltInPalette::SystemWin),
                        matte: None,
                        use_alpha: bitmap_info.use_alpha,
                        trim_white_space: bitmap_info.trim_white_space,
                        was_trimmed: false,
                        version: 0,
                    });
                }
            }

            // No BITD chunk — try Raw chunk data as bitmap pixel data.
            // Chunk::Raw can be either ALFA data or an unrecognized chunk type
            // that contains actual bitmap pixel data, so we must try decompression.
            let raw_data = member_def.children.iter().find_map(|c| {
                c.as_ref().and_then(|chunk| match chunk {
                    Chunk::Raw(data) if !data.is_empty() => Some(data.as_slice()),
                    _ => None,
                })
            });
            if let Some(data) = raw_data {
                let decompressed = decompress_bitmap(data, bitmap_info, cast_lib, 0);
                match decompressed {
                    Ok(new_bitmap) => bitmap_manager.add_bitmap(new_bitmap),
                    Err(e) => {
                        warn!("[BMP] Failed to decode Raw data for member {}:{}: {}", cast_lib, number, e);
                        bitmap_manager.add_bitmap(Bitmap::new(1, 1, 8, 8, 0, PaletteRef::BuiltIn(BuiltInPalette::GrayScale)))
                    }
                }
            } else {
                warn!("No bitmap chunk found for member {}", number);
                bitmap_manager.add_bitmap(Bitmap::new(1, 1, 8, 8, 0, PaletteRef::BuiltIn(BuiltInPalette::GrayScale)))
            }
        }
    }

    fn extract_text_from_xmedia(data: &[u8]) -> Option<String> {
        let mut i = 0;

        while i < data.len() {
            // find '2C' which marks the start of text
            if data[i] != 0x2C {
                i += 1;
                continue;
            }

            let start = i + 1;

            // find following 03 byte
            let mut end = start;
            while end < data.len() && data[end] != 0x03 {
                end += 1;
            }

            // if 03 not found â†’ no valid text block
            if end >= data.len() {
                return None;
            }

            // extract text bytes
            let raw = &data[start..end];
            let mut text = String::new();

            for &b in raw {
                match b {
                    0x20..=0x7E => text.push(b as char), // printable ASCII
                    0x09 => text.push('\t'),             // preserve TAB
                    0x0D => text.push('\r'),             // preserve CR
                    0x0A => text.push('\n'),             // preserve LF
                    _ => {}                              // skip weird bytes
                }
            }

            let cleaned = text.trim().to_string();
            if !cleaned.is_empty() {
                return Some(cleaned);
            }

            i = end + 1;
        }

        None
    }

    fn scan_font_name_from_xmedia(xmedia: &XMediaChunk) -> Option<String> {
        let data = &xmedia.raw_data;

        for i in 0..data.len().saturating_sub(20) {
            // Look for the exact prefix
            if data[i..].starts_with(b"FFF Reaction") {
                // Extract until the null terminator
                let mut name = Vec::new();

                for &b in &data[i..] {
                    if b == 0 { break; }
                    if b.is_ascii_graphic() || b == b' ' {
                        name.push(b);
                    }
                }

                if !name.is_empty() {
                    return Some(String::from_utf8_lossy(&name).to_string());
                }
            }
        }

        None
    }

    fn extract_pfr(member_def: &CastMemberDef) -> Option<PfrFont> {
        member_def.children.iter()
            .find_map(|c| match c {
                Some(Chunk::XMedia(x)) if x.is_pfr_font() => x.parse_pfr_font(),
                _ => None
            })
    }

    fn resolve_font_name(chunk: &CastMemberChunk, pfr: &Option<PfrFont>, number: u32) -> String {
        if let Some(name) = chunk.member_info.as_ref().map(|i| i.name.clone()).filter(|n| !n.is_empty()) {
            return name;
        }

        if let Some(pfr) = pfr {
            if !pfr.font_name.is_empty() {
                return pfr.font_name.clone();
            }
        }

        if let Some(info) = chunk.specific_data.font_info() {
            if !info.name.is_empty() {
                return info.name.clone();
            }
        }

        format!("Font_{}", number)
    }

    fn render_pfr_to_bitmap(
        pfr: &PfrFont,
        bitmap_manager: &mut BitmapManager,
        target_height: usize,
    ) -> PfrBitmap {
        use crate::director::chunks::pfr1::{rasterizer, parse_pfr1_font_with_target};

        // Parse at target=0 to keep coordinates in ORU space. The rasterizer
        // handles ORU→pixel scaling using target_height / outline_res.
        let parsed_for_size = match parse_pfr1_font_with_target(&pfr.raw_data, 0) {
            Ok(p) => p,
            Err(_) => pfr.parsed.clone(),
        };

        // Use the PFR1 rasterizer to render the parsed font
        let rasterized = rasterizer::rasterize_pfr1_font(&parsed_for_size, target_height, 0);

        let bitmap_width = rasterized.bitmap_width as u16;
        let bitmap_height = rasterized.bitmap_height as u16;

        debug!(
            "🎨 Creating bitmap for PFR font '{}' ({}x{}, grid {}x{}, cell {}x{})",
            pfr.font_name,
            bitmap_width,
            bitmap_height,
            rasterized.grid_columns,
            rasterized.grid_rows,
            rasterized.cell_width,
            rasterized.cell_height,
        );

        // Create a 32-bit bitmap from the rasterized RGBA data
        let mut bitmap = Bitmap::new(
            bitmap_width,
            bitmap_height,
            32,
            32,
            0,
            PaletteRef::BuiltIn(BuiltInPalette::SystemWin),
        );

        // Copy RGBA data
        let data_len = rasterized.bitmap_data.len().min(bitmap.data.len());
        bitmap.data[..data_len].copy_from_slice(&rasterized.bitmap_data[..data_len]);

        // Ensure transparent background is white (avoids black-square artifacts in text rendering)
        for i in (0..data_len).step_by(4) {
            let a = bitmap.data[i + 3];
            if a == 0 {
                bitmap.data[i] = 255;
                bitmap.data[i + 1] = 255;
                bitmap.data[i + 2] = 255;
            }
        }

        bitmap.use_alpha = true;

        debug!("✅ Finished assembling PFR bitmap ({} glyphs rendered).",
            parsed_for_size.glyphs.len() + parsed_for_size.bitmap_glyphs.len());

        let bitmap_ref = bitmap_manager.add_bitmap(bitmap);

        PfrBitmap {
            bitmap_ref,
            char_width: rasterized.cell_width as u16,
            char_height: rasterized.cell_height as u16,
            grid_columns: rasterized.grid_columns as u8,
            grid_rows: rasterized.grid_rows as u8,
            char_widths: Some(rasterized.char_widths),
            first_char: rasterized.first_char,
        }
    }

    fn log_ole_start(number: u32, cast_lib: u32, chunk: &CastMemberChunk) {
        debug!(
            "Processing Ole member #{} in cast lib {} (name: {})",
            number,
            cast_lib,
            chunk.member_info.as_ref().map(|x| x.name.as_str()).unwrap_or("")
        );
    }

    fn log_found_swf(number: u32, sig: &[u8], len: usize) {
        debug!("✅ Found SWF data in Ole member #{} (signature: {:?}, {} bytes)", number, sig, len);
    }

    fn log_found_swf_at_offset(number: u32, sig: &[u8]) {
        debug!("✅ Found SWF signature at offset 12 in Ole member #{}: {:?}", number, sig);
    }

    fn log_unknown_ole(number: u32, chunk: &CastMemberChunk) {
        let name = chunk.member_info.as_ref().map(|x| x.name.as_str()).unwrap_or("");
        // Include the OLE type string — it names the owning Xtra and is the
        // fastest way to identify what an unimplemented member actually is.
        let type_str = Self::ole_type_string(&chunk.specific_data_raw).unwrap_or_default();
        warn!(
            "Cast member #{} has unimplemented type: Ole (name: '{}', typeStr: '{}', rawLen: {})",
            number, name, type_str, chunk.specific_data_raw.len()
        );
    }

    /// The length-prefixed Xtra type string an OLE member's `specific_data_raw`
    /// opens with (4-byte BE length, then the name) — e.g. `"vectorShape"`.
    /// This is the authoritative identifier for which Xtra owns the member.
    fn ole_type_string(raw: &[u8]) -> Option<String> {
        if raw.len() < 5 {
            return None;
        }
        let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
        if str_len == 0 || str_len > 64 || raw.len() < 4 + str_len {
            return None;
        }
        std::str::from_utf8(&raw[4..4 + str_len]).ok().map(|s| s.to_string())
    }

    /// Parse SWF stage dimensions from uncompressed SWF header.
    /// Returns (width, height) in pixels, or None if parsing fails.
    pub fn parse_swf_dimensions(data: &[u8]) -> Option<(u16, u16)> {
        if data.len() < 9 {
            return None;
        }
        // For compressed SWF (CWS/ZWS), we can't easily read the rect without decompressing
        let sig = &data[0..3];
        if sig != b"FWS" {
            return None; // Only uncompressed SWF for now
        }
        // SWF RECT starts at byte 8
        // RECT format: Nbits (5 bits) then 4 fields of Nbits each
        let rect_start = 8;
        if data.len() <= rect_start {
            return None;
        }
        let nbits = (data[rect_start] >> 3) as usize;
        let total_bits = 5 + nbits * 4;
        let total_bytes = (total_bits + 7) / 8;
        if data.len() < rect_start + total_bytes {
            return None;
        }

        // Read bit fields
        let mut bit_pos = rect_start * 8 + 5; // skip 5-bit nbits field
        let read_bits = |pos: usize, n: usize| -> i32 {
            let mut val: i32 = 0;
            for i in 0..n {
                let byte_idx = (pos + i) / 8;
                let bit_idx = 7 - ((pos + i) % 8);
                if (data[byte_idx] >> bit_idx) & 1 != 0 {
                    val |= 1 << (n - 1 - i);
                }
            }
            // Sign extend
            if n > 0 && (val >> (n - 1)) & 1 != 0 {
                val |= !0 << n;
            }
            val
        };

        let x_min = read_bits(bit_pos, nbits); bit_pos += nbits;
        let x_max = read_bits(bit_pos, nbits); bit_pos += nbits;
        let y_min = read_bits(bit_pos, nbits); bit_pos += nbits;
        let y_max = read_bits(bit_pos, nbits);
        let _ = bit_pos;

        // SWF uses twips (1/20 pixel)
        let width = ((x_max - x_min) / 20) as u16;
        let height = ((y_max - y_min) / 20) as u16;
        Some((width, height))
    }

    /// Parse the SWF header's FrameCount (the root timeline's total frame
    /// count) straight from the movie bytes — the authoritative value for
    /// Director's Flash `member.frameCount` property. Reading it from the SWF
    /// header (always present in `data`) is correct even while the Ruffle
    /// instance is still (re)loading; asking Ruffle returns 0 during that
    /// window, which poisons movies that seed state from `frameCount`
    /// (bogey_nights' #hiding does `sprite.frame = member.frameCount`, and a 0
    /// there pins the SWF root at frame 0 and stalls the grab machine).
    ///
    /// Header layout after the 8-byte prefix (FWS): RECT (variable), then u16
    /// FrameRate (8.8 fixed), then u16 FrameCount. Only uncompressed FWS is
    /// handled here (bogey_nights' straw/longarm are FWS); compressed CWS/ZWS
    /// fall back to the Ruffle query at the call site.
    pub fn parse_swf_frame_count(data: &[u8]) -> Option<u16> {
        if data.len() < 9 || &data[0..3] != b"FWS" {
            return None;
        }
        let rect_start = 8;
        let nbits = (data[rect_start] >> 3) as usize;
        let total_bits = 5 + nbits * 4;
        let rect_bytes = (total_bits + 7) / 8;
        // rect, then FrameRate (2), then FrameCount (2)
        let fc_off = rect_start + rect_bytes + 2;
        if data.len() < fc_off + 2 {
            return None;
        }
        Some(u16::from_le_bytes([data[fc_off], data[fc_off + 1]]))
    }

    /// Parse the SWF root timeline's FrameLabel tags into `(label, frame)`
    /// pairs, with 1-based frame numbers — the data behind Director's Flash
    /// `sprite(N).findLabel(name)`.
    ///
    /// Read from the SWF bytes rather than queried from Ruffle for the same
    /// reason as `parse_swf_frame_count`: labels are static SWF content, so
    /// the bytes are authoritative and available immediately, whereas the
    /// Ruffle instance returns nothing until it has loaded. The legacy Flash
    /// Player JS API exposes no label lookup at all, so there is nothing to
    /// ask even once it is ready.
    ///
    /// Walk: after the 8-byte prefix comes RECT (variable), u16 FrameRate,
    /// u16 FrameCount, then the tag stream. FrameLabel (43) names the frame
    /// currently being built; ShowFrame (1) commits it and advances the
    /// counter. Nested timelines (DefineSprite, 39) carry their own
    /// ShowFrame/FrameLabel tags inside their tag body — we skip whole tag
    /// bodies, so those correctly do not affect root frame numbering.
    pub fn parse_swf_frame_labels(data: &[u8]) -> Vec<(String, u32)> {
        if data.len() < 9 {
            return Vec::new();
        }
        // Both FWS and CWS/ZWS put the compressed/uncompressed remainder at
        // offset 8, starting at RECT. Normalise to "body starts at RECT".
        let decompressed;
        let body: &[u8] = match &data[0..3] {
            b"FWS" => &data[8..],
            b"CWS" => {
                use std::io::Read;
                let mut out = Vec::new();
                let mut dec = flate2::read::ZlibDecoder::new(&data[8..]);
                if dec.read_to_end(&mut out).is_err() || out.is_empty() {
                    return Vec::new();
                }
                decompressed = out;
                &decompressed
            }
            // ZWS is LZMA — no LZMA decoder is linked in, so treat as no
            // labels rather than pulling in a dependency for a format no
            // Director-era SWF uses (LZMA arrived in SWF 13 / Flash 11).
            _ => return Vec::new(),
        };

        if body.is_empty() {
            return Vec::new();
        }
        let nbits = (body[0] >> 3) as usize;
        let rect_bytes = (5 + nbits * 4 + 7) / 8;
        // rect, then FrameRate (2) + FrameCount (2)
        let mut pos = rect_bytes + 4;

        let mut labels = Vec::new();
        let mut frame: u32 = 1;
        while pos + 2 <= body.len() {
            let tag_header = u16::from_le_bytes([body[pos], body[pos + 1]]);
            pos += 2;
            let code = tag_header >> 6;
            let mut len = (tag_header & 0x3F) as usize;
            if len == 0x3F {
                if pos + 4 > body.len() {
                    break;
                }
                len = u32::from_le_bytes([body[pos], body[pos + 1], body[pos + 2], body[pos + 3]])
                    as usize;
                pos += 4;
            }
            if pos + len > body.len() {
                break;
            }
            match code {
                0 => break,  // End
                1 => frame += 1, // ShowFrame
                43 => {
                    // FrameLabel: null-terminated string, optionally followed
                    // by a named-anchor flag byte (SWF 6+) we don't need.
                    let raw = &body[pos..pos + len];
                    let end = raw.iter().position(|&b| b == 0).unwrap_or(raw.len());
                    let name = String::from_utf8_lossy(&raw[..end]).into_owned();
                    if !name.is_empty() {
                        labels.push((name, frame));
                    }
                }
                _ => {}
            }
            pos += len;
        }
        labels
    }

    /// Look up a single frame label, matching Director's `findLabel()`:
    /// "returns the frame number (within the Flash movie) that is associated
    /// with the label name requested. A 0 is returned if the label doesn't
    /// exist, or if that portion of the Flash movie has not yet been streamed
    /// in" (Director 11.5 Scripting Dictionary, `findLabel()`). Note the
    /// sentinel is 0, never VOID — callers do arithmetic on the result
    /// (`sprite.frame = start + counter`), so a non-numeric miss would poison
    /// the expression.
    ///
    /// Matching is case-insensitive. The dictionary doesn't state this, but
    /// it is required by shipping content: monsterattack asks for
    /// `findLabel("Intro")` while its character SWFs store the label as
    /// `intro`, and the same movie's hardcoded fallback frame numbers confirm
    /// the lookup is expected to succeed.
    pub fn find_swf_frame_label(data: &[u8], label: &str) -> u32 {
        Self::parse_swf_frame_labels(data)
            .into_iter()
            .find(|(name, _)| name.eq_ignore_ascii_case(label))
            .map(|(_, frame)| frame)
            .unwrap_or(0)
    }

    /// Resolve a Flash member's registration point, matching Director's
    /// `member.regPoint`:
    /// - `centerRegPoint == true` → the CENTER of the member rect. Director
    ///   resets the regPoint to center and returns that (pengapop's
    ///   menuAdOnline: 380×413 → point(190, 206)).
    /// - `centerRegPoint == false` → the stored authored regPoint
    ///   (QuickDraw-swapped in FlashInfo::from) — bogey_nights' straw/longarm:
    ///   point(109, 63).
    /// `swf_data` is the SWF bytes, used only as a size fallback when the member
    /// rect is empty. Returns (0, 0) when no FlashInfo is available.
    fn flash_reg_point(
        flash_info: Option<&crate::director::enums::FlashInfo>,
        swf_data: &[u8],
    ) -> (i16, i16) {
        match flash_info {
            Some(info) if info.center_reg_point => {
                let (l, t, r, b) = info.flash_rect;
                if r - l > 0 && b - t > 0 {
                    (((r - l) / 2) as i16, ((b - t) / 2) as i16)
                } else if let Some((w, h)) = Self::parse_swf_dimensions(swf_data) {
                    ((w / 2) as i16, (h / 2) as i16)
                } else {
                    (0, 0)
                }
            }
            Some(info) if info.reg_point != (0, 0) => {
                (info.reg_point.0 as i16, info.reg_point.1 as i16)
            }
            Some(info) => (info.origin_h as i16, info.origin_v as i16),
            None => {
                // No FlashInfo: default to center registration from SWF dims.
                if let Some((w, h)) = Self::parse_swf_dimensions(swf_data) {
                    ((w / 2) as i16, (h / 2) as i16)
                } else {
                    (0, 0)
                }
            }
        }
    }

    fn make_swf_member(number: u32, chunk: &CastMemberChunk, data: Vec<u8>) -> CastMember {
        // For native Flash members the FlashInfo was parsed during chunk
        // ingest (cast_member.rs:140 `MemberType::Flash` branch). For
        // OLE-wrapped SWFs that path never fires — the chunk comes in
        // as `MemberType::Ole` and `specific_data` is `None`. The OLE
        // wrapper, however, still contains a "flash" / "FLSH" payload
        // in `specific_data_raw` that FlashInfo::from can parse. Try it
        // here so properties like `pausedAtStart`, `directToStage`,
        // `scaleMode` etc. are populated for OLE-wrapped Flash too.
        let flash_info = chunk
            .specific_data
            .flash_info()
            .cloned()
            .or_else(|| crate::director::enums::FlashInfo::from(&chunk.specific_data_raw));
        // Director's `centerRegPoint=true` semantically means "draw the SWF
        // centered on the sprite's loc". The renderer computes
        // `screen_pos = sprite.loc - member.reg_point`, so to get a centered
        // draw we set reg_point to (W/2, H/2) — i.e. the same outcome
        // `sprite.loc_h - W/2` would give in a screen-position formulation,
        // just expressed at member-construction time.
        //
        // Prefer the actual SWF header dimensions over FlashInfo's
        // cached `reg_point` field: FlashInfo's value can be stale /
        // wrong (the old code halved it, getting quarter-size offsets),
        // while parse_swf_dimensions reads straight from the SWF's
        // FrameSize record so it always matches what Ruffle renders.
        let reg_point = Self::flash_reg_point(flash_info.as_ref(), &data);

        CastMember {
            number,
            name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
            comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
            member_type: CastMemberType::Flash(FlashMember { data, reg_point, flash_info }),
            color: ColorRef::PaletteIndex(255),
            bg_color: ColorRef::PaletteIndex(0),
            reg_point: (reg_point.0 as i32, reg_point.1 as i32),
        }
    }

    fn get_first_child_bytes(member_def: &CastMemberDef) -> Option<Vec<u8>> {
        if let Some(Some(ch)) = member_def.children.get(0) {
            if let Some(bytes) = ch.as_bytes() {
                return Some(bytes.to_vec());
            }
        }
        None
    }

    /// Create an empty W3D scene with a DefaultView camera, matching Director's behavior.
    pub(crate) fn create_empty_w3d_scene() -> crate::director::chunks::w3d::types::W3dScene {
        use crate::director::chunks::w3d::types::*;
        let mut scene = W3dScene::default();
        // Director always has a DefaultShader that cannot be deleted
        scene.shaders.push(W3dShader {
            name: BuiltInSymbol::DefaultShader.into(),
            ..Default::default()
        });
        // Director always creates a DefaultView camera in empty 3D members
        scene.nodes.push(W3dNode {
            name: BuiltInSymbol::DefaultView.into(),
            node_type: W3dNodeType::View,
            parent_name: BuiltInSymbol::World.into(),
            resource_name: Symbol::empty(),
            model_resource_name: Symbol::empty(),
            shader_name: Symbol::empty(),
            visibility: 1,
            near_plane: 1.0,
            far_plane: 10000.0,
            fov: 34.516,
            screen_width: 640,
            screen_height: 480,
            transform: [1.0,0.0,0.0,0.0, 0.0,1.0,0.0,0.0, 0.0,0.0,1.0,0.0, 0.0,0.0,100.0,1.0],
        });
        // Default ambient light
        scene.lights.push(W3dLight {
            name: BuiltInSymbol::DefaultAmbient.into(),
            light_type: W3dLightType::Ambient,
            color: [0.3, 0.3, 0.3],
            enabled: true,
            spot_angle: 90.0,
            attenuation: [1.0, 0.0, 0.0],
            ..Default::default()
        });
        // Default directional light (IFX default: 0.75)
        scene.lights.push(W3dLight {
            name: BuiltInSymbol::DefaultDirectional.into(),
            light_type: W3dLightType::Directional,
            color: [0.75, 0.75, 0.75],
            enabled: true,
            spot_angle: 90.0,
            attenuation: [1.0, 0.0, 0.0],
            ..Default::default()
        });
        // Light node for the directional light — rotated to point from upper-right
        scene.nodes.push(W3dNode {
            name: BuiltInSymbol::DefaultDirectional.into(),
            node_type: W3dNodeType::Light,
            parent_name: BuiltInSymbol::World.into(),
            resource_name: BuiltInSymbol::DefaultDirectional.into(),
            model_resource_name: Symbol::empty(),
            shader_name: Symbol::empty(),
            visibility: 1,
            near_plane: 1.0, far_plane: 10000.0, fov: 30.0,
            screen_width: 640, screen_height: 480,
            // Rotation: Z-axis points toward (0.5, 1.0, 0.7) normalized
            // -Z axis = (-0.37, -0.74, -0.52) is the light direction
            transform: [
                0.88, 0.0, -0.47, 0.0,
                -0.35, 0.67, -0.65, 0.0,
                0.32, 0.74, 0.59, 0.0,
                0.0, 0.0, 0.0, 1.0,
            ],
        });
        scene
    }

    /// Check if OLE specific_data_raw is a Shockwave3D member.
    /// Format: 4-byte BE string length + "shockwave3d" + 3DPR data
    fn is_shockwave3d_ole(raw: &[u8]) -> bool {
        if raw.len() < 15 { return false; }
        let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
        if str_len == 0 || raw.len() < 4 + str_len { return false; }
        std::str::from_utf8(&raw[4..4 + str_len]).ok() == Some("shockwave3d")
    }

    /// Check if OLE specific_data_raw is a SWA (Shockwave Audio) member.
    /// Format: 4-byte BE string length + "swa" + Xtra-specific data with file path
    fn is_swa_ole(raw: &[u8]) -> bool {
        if raw.len() < 7 { return false; }
        let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
        if str_len == 0 || raw.len() < 4 + str_len { return false; }
        std::str::from_utf8(&raw[4..4 + str_len]).ok() == Some("swa")
    }

    fn is_havok_ole(raw: &[u8]) -> bool {
        if raw.len() < 8 { return false; }
        let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
        if str_len == 0 || str_len > 256 || raw.len() < 4 + str_len { return false; }
        let type_str = std::str::from_utf8(&raw[4..4 + str_len]).ok().unwrap_or("");
        type_str.eq_ignore_ascii_case("havok")
    }

    /// Check if this OLE member is a Havok member by examining both the specific_data_raw
    /// type string and the member info name/file_name fields.
    fn is_havok_member_any(raw: &[u8], member_info: &Option<crate::director::chunks::cast_member_info::CastMemberInfoChunk>) -> bool {
        // Check OLE type string first
        if Self::is_havok_ole(raw) {
            return true;
        }
        // Fall back to checking member_info file_name or exact name "havok"
        if let Some(info) = member_info {
            if info.file_name.to_lowercase().contains("havok") || info.name.eq_ignore_ascii_case("havok") {
                return true;
            }
        }
        false
    }

    /// Detect a PhysX (AGEIA) Physics Xtra OLE member by sniffing the
    /// length-prefixed PROGID string in specific_data_raw. The Director
    /// Physics Xtra registers itself with PROGID "Physics".
    fn is_physx_ole(raw: &[u8]) -> bool {
        if raw.len() < 8 { return false; }
        let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
        if str_len == 0 || str_len > 256 || raw.len() < 4 + str_len { return false; }
        let type_str = std::str::from_utf8(&raw[4..4 + str_len]).ok().unwrap_or("");
        type_str.eq_ignore_ascii_case("physics")
    }

    /// PhysX detection by either OLE PROGID, file_name hint, or name == "PhysX".
    /// Mirrors `is_havok_member_any`.
    fn is_physx_member_any(raw: &[u8], member_info: &Option<crate::director::chunks::cast_member_info::CastMemberInfoChunk>) -> bool {
        if Self::is_physx_ole(raw) {
            return true;
        }
        if let Some(info) = member_info {
            let fn_lower = info.file_name.to_lowercase();
            if fn_lower.contains("physx") || fn_lower.contains("dynamiks")
                || info.name.eq_ignore_ascii_case("physx")
                || info.name.eq_ignore_ascii_case("physics") {
                return true;
            }
        }
        false
    }

    /// Try to parse OLE specific_data_raw as a vectorShape member.
    /// Format: 4-byte BE string length + "vectorShape" + 4-byte FLSH size + "FLSH" fourCC + 4-byte size + payload
    fn try_parse_vector_shape(raw: &[u8], number: u32, chunk: &CastMemberChunk) -> Option<CastMember> {
        if raw.len() < 15 {
            return None;
        }
        // Read length-prefixed type string
        let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
        if str_len == 0 || raw.len() < 4 + str_len {
            return None;
        }
        let type_str = std::str::from_utf8(&raw[4..4 + str_len]).ok()?;
        if type_str != "vectorShape" {
            return None;
        }

        // Parse FLSH block: after type string, we have 4-byte size + "FLSH" fourCC + payload
        let flsh_start = 4 + str_len;
        if raw.len() < flsh_start + 8 {
            debug!("OLE member #{}: vectorShape too short for FLSH header", number);
            return None;
        }
        let flsh_fourcc = &raw[flsh_start + 4..flsh_start + 8];
        if flsh_fourcc != b"FLSH" {
            debug!("OLE member #{}: vectorShape missing FLSH fourCC", number);
            return None;
        }

        // FLSH payload starts after: 4-byte size + "FLSH" = 8 bytes
        // (the size field covers everything from "FLSH" onwards)
        let payload = &raw[flsh_start + 8..];
        let vector_member = Self::parse_flsh_payload(payload);

        web_sys::console::log_1(
            &format!(
                "OLE member #{} identified as vectorShape: {} vertices, strokeWidth={}, fillMode={}, closed={}, bbox=({},{},{},{})",
                number,
                vector_member.vertices.len(),
                vector_member.stroke_width,
                vector_member.fill_mode,
                vector_member.closed,
                vector_member.bbox_left, vector_member.bbox_top,
                vector_member.bbox_right, vector_member.bbox_bottom,
            ).into(),
        );

        let reg_point = (
            vector_member.reg_point.0 as i32,
            vector_member.reg_point.1 as i32,
        );
        Some(CastMember {
            number,
            name: chunk
                .member_info
                .as_ref()
                .map(|x| x.name.to_owned())
                .unwrap_or_default(),
            comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
            member_type: CastMemberType::VectorShape(vector_member),
            color: ColorRef::PaletteIndex(255),
            bg_color: ColorRef::PaletteIndex(0),
            reg_point,
        })
    }

    /// Parse the FLSH payload into VectorShapeMember.
    /// Fixed header (160 bytes) + 4 colors (64 bytes) + vertex list.
    /// Parse a FLSH chunk payload into a `VectorShapeMember`. The actual
    /// FLSH byte-layout decoding now lives in
    /// `crate::director::enums::VectorShapeInfo::from(&[u8])`; this thin
    /// wrapper converts the parsed info into a player-side
    /// `VectorShapeMember` and computes the runtime bbox (vertices +
    /// control points + stroke padding) used by the rasterizer.
    fn parse_flsh_payload(data: &[u8]) -> VectorShapeMember {
        VectorShapeMember::from(crate::director::enums::VectorShapeInfo::from(data))
    }

    fn try_parse_swf(bytes: Vec<u8>, number: u32, chunk: &CastMemberChunk) -> Option<CastMember> {
        if bytes.len() < 3 {
            return None;
        }

        let sig = &bytes[0..3];

        let is_swf = sig == b"FWS" || sig == b"CWS" || sig == b"ZWS";
        if is_swf {
            Self::log_found_swf(number, sig, bytes.len());
            return Some(Self::make_swf_member(number, chunk, bytes));
        }

        // Try offset 12 SWF (OLE wrapped SWF)
        if bytes.len() > 15 {
            let sig2 = &bytes[12..15];
            let is_swf2 = sig2 == b"FWS" || sig2 == b"CWS" || sig2 == b"ZWS";
            if is_swf2 {
                Self::log_found_swf_at_offset(number, sig2);
                return Some(Self::make_swf_member(number, chunk, bytes[12..].to_vec()));
            }
        }

        None
    }

    fn scan_children_for_ole(
        member_def: &CastMemberDef,
        number: u32,
        chunk: &CastMemberChunk,
        bitmap_manager: &mut BitmapManager,
        cast_lib: u32,
    ) -> Option<CastMember>
    {
        for opt_child in &member_def.children {
            let Some(Chunk::XMedia(xm)) = opt_child else { continue };

            let member_name = chunk.member_info.as_ref().map(|i| i.name.as_str()).unwrap_or("");
            debug!("Checking XMedia child (member #{}, name='{}', {} bytes)", number, member_name, xm.raw_data.len());

            // 1) If SWF: return SWF
            if let Some(cm) = Self::try_parse_swf(xm.raw_data.to_vec(), number, chunk) {
                debug!("Detected as SWF");
                return Some(cm);
            }

            // 1.5) Check for Havok Physics BEFORE text detection
            // (HKE binary data can be mis-parsed as styled text)
            if Self::is_havok_member_any(&chunk.specific_data_raw, &chunk.member_info) {
                let hke_data = xm.raw_data.clone();
                debug!(
                    "Havok Physics member #{} detected in scan_children_for_ole (early), HKE data={} bytes",
                    number, hke_data.len()
                );
                return Some(CastMember {
                    number,
                    name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                    comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                    member_type: CastMemberType::HavokPhysics(HavokPhysicsMember::new(hke_data)),
                    color: ColorRef::PaletteIndex(255),
                    bg_color: ColorRef::PaletteIndex(0),
                    reg_point: (0, 0),
                });
            }

            // 1b) 3D Groove `.3GM` model — XMED payload starts with the `3DGM` magic.
            // Retain the raw bytes so the Groove Xtra can build a shape from them
            // when the movie calls `LoadShape(memberName)`.
            if xm.raw_data.len() >= 4 && &xm.raw_data[0..4] == b"3DGM" {
                debug!("Groove .3GM member #{} detected ({} bytes)", number, xm.raw_data.len());
                return Some(CastMember {
                    number,
                    name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                    comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                    member_type: CastMemberType::Groove3gm(Groove3gmMember { data: xm.raw_data.clone() }),
                    color: ColorRef::PaletteIndex(255),
                    bg_color: ColorRef::PaletteIndex(0),
                    reg_point: (0, 0),
                });
            }

            // 1c) Animated GIF. Director's "Animated GIF Asset" Xtra stores
            // the whole .gif file as the XMED payload. Decode the frames and
            // hand back a plain Bitmap member on frame 0, so every ink and
            // stretch path treats it as an ordinary bitmap;
            // `player.gif_animations` swaps the frame as time passes. Without
            // this the payload fell through to the text parser below.
            if crate::player::gif::is_gif(&xm.raw_data) {
                if let Some(anim) = crate::player::gif::decode_gif(&xm.raw_data, bitmap_manager) {
                    debug!(
                        "GIF member #{} '{}': {} frames, {}x{}",
                        number,
                        chunk.member_info.as_ref().map(|x| x.name.as_str()).unwrap_or(""),
                        anim.frames.len(), anim.width, anim.height
                    );
                    let info = crate::player::gif::gif_bitmap_info(anim.width, anim.height);
                    let first = anim.frames[0];
                    // Carry the GIF's own background colour so a sprite drawn
                    // with ink 36 keys out the right thing.
                    let bg = crate::player::gif::background_color(&xm.raw_data)
                        .map(|(r, g, b)| ColorRef::Rgb(r, g, b))
                        .unwrap_or(ColorRef::PaletteIndex(0));
                    crate::player::gif::register_pending(cast_lib, number, anim);
                    return Some(CastMember {
                        number,
                        name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                        member_type: CastMemberType::Bitmap(BitmapMember {
                            image_ref: first,
                            reg_point: (info.reg_x, info.reg_y),
                            script_id: 0,
                            member_script_ref: None,
                            info,
                        }),
                        color: ColorRef::PaletteIndex(255),
                        bg_color: bg,
                        reg_point: (0, 0),
                    });
                }
            }
            // 2) Check if styled text (XMED format)
            // Only parse as styled text if the Ole type string is "text" or empty
            // (avoid mis-parsing raw binary data like lightmap coordinates as text)
            let ole_type = if chunk.specific_data_raw.len() >= 4 {
                let str_len = u32::from_be_bytes([chunk.specific_data_raw[0], chunk.specific_data_raw[1], chunk.specific_data_raw[2], chunk.specific_data_raw[3]]) as usize;
                if str_len > 0 && chunk.specific_data_raw.len() >= 4 + str_len {
                    std::str::from_utf8(&chunk.specific_data_raw[4..4 + str_len]).unwrap_or("")
                } else {
                    ""
                }
            } else {
                ""
            };
            let is_text_ole = ole_type.is_empty() || ole_type == "text";
            if is_text_ole {
                let hex_dump = xm.raw_data.clone()
                    .iter()
                    .map(|b| format!("{:02X} ", b))
                    .collect::<Vec<String>>()
                    .join(" ");
                debug!(
                    "XMED X2 (text member #{} '{}', {} bytes):\n{}",
                    number,
                    chunk.member_info.as_ref().map(|x| x.name.as_str()).unwrap_or(""),
                    xm.raw_data.len(),
                    hex_dump
                );

                if let Some(styled_text) = xm.parse_styled_text() {
                    debug!("Detected as XMED styled text");
                    let stxt_font_size: Option<u16> = None;
                    return Some(Self::create_text_member_from_xmed(
                        number,
                        chunk,
                        styled_text,
                        stxt_font_size,
                        cast_lib,
                    ));
                }
            }

            // 3) Shockwave3D — IFX IFF container; not a font
            if xm.is_shockwave3d() {
                debug!(
                    "Detected as Shockwave3D (IFX) member #{}, {} bytes",
                    number, xm.raw_data.len()
                );
                let w3d_data = xm.raw_data.clone();
                let parsed_scene = if !w3d_data.is_empty() {
                    match crate::director::chunks::w3d::parse_w3d(&w3d_data) {
                        Ok(mut scene) => {
                            debug!("W3D parsed: {} materials, {} nodes, {} meshes",
                                scene.materials.len(), scene.nodes.len(), scene.clod_meshes.len());
                            // Ensure DefaultShader exists
                            if !scene.shaders.iter().any(|s| s.name == BuiltInSymbol::DefaultShader) {
                                scene.shaders.push(crate::director::chunks::w3d::types::W3dShader {
                                    name: BuiltInSymbol::DefaultShader.into(),
                                    ..Default::default()
                                });
                            }
                            Some(std::rc::Rc::new(scene))
                        }
                        Err(e) => {
                            warn!("W3D parse error: {}", e);
                            Some(std::rc::Rc::new(Self::create_empty_w3d_scene()))
                        }
                    }
                } else {
                    Some(std::rc::Rc::new(Self::create_empty_w3d_scene()))
                };
                let info = Shockwave3dInfo::from(&chunk.specific_data_raw)
                    .unwrap_or(Shockwave3dInfo {
                        loops: false, duration: 0, direct_to_stage: false,
                        animation_enabled: false, preload: false,
                        reg_point: (0, 0), default_rect: (0, 0, 320, 240),
                        camera_position: None, camera_rotation: None,
                        bg_color: None, ambient_color: None,
                    });
                let source_scene = parsed_scene.clone();
                return Some(CastMember {
                    number,
                    name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                    comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                    member_type: { let rs = Shockwave3dRuntimeState::from_info(&info, parsed_scene.as_deref()); CastMemberType::Shockwave3d(Shockwave3dMember { info: info.clone(), w3d_data, source_scene, parsed_scene, runtime_state: rs, converted_from_text: false, text3d_state: None, text3d_source: None }) },
                    color: ColorRef::PaletteIndex(255),
                    bg_color: ColorRef::PaletteIndex(0),
                    reg_point: info.reg_point,
                });
            }

            // 4) Check if this is a real PFR font or just text content
            let has_pfr = Self::extract_pfr(member_def).is_some();
            if has_pfr {
                debug!("Detected as PFR font");
                return Some(Self::parse_xmedia_font(member_def, number, chunk, xm, bitmap_manager));
            }

            // 5) No PFR font data — create a TextMember from the XMedia text content
            // Use the proper XMED parser to get clean text, fall back to empty
            let text = xm.parse_styled_text()
                .map(|st| st.text.clone())
                .unwrap_or_default();
            let member_name = chunk.member_info.as_ref()
                .map(|x| x.name.to_owned())
                .unwrap_or_default();
            let mut text_member = TextMember::new();
            text_member.text = text;
            // NOTE: a previous attempt to read the authored font/size from
            // XMED raw bytes (`scan_xmed_for_font_info`) was REMOVED because
            // its u16-in-range heuristic picked up arbitrary nearby bytes —
            // bubbletext member ended up with fontsize=44 from random data
            // following the "Arial" name. Until we have a real Section 7
            // parse, this fallback keeps TextMember::new()'s Arial/12
            // defaults. Text members authored at smaller sizes (Verdana 9
            // in spineworld_dcr's txt_password) render a few pixels taller
            // than Director — visible but tolerable; better than wildly
            // wrong values.
            // Pull authored width/height (and other text-shaped settings) from
            // chunk.specific_data when it parsed as TextInfo. Without this,
            // text members that take this fallback path keep TextMember::new()'s
            // 100×20 defaults and word_wrap clamps text to a 100px box even
            // when the author set width=349 (e.g. spineworld_dcr's
            // `txt_droplist`, which is empty at authoring and gets populated by
            // Lingo at runtime — the dropdown list then wrapped "Antigua and
            // Barbuda" mid-string because the wrap budget was 100 instead of
            // the authored 349).
            let text_info_to_apply: Option<crate::director::enums::TextInfo> = match &chunk.specific_data {
                crate::director::chunks::cast_member::CastMemberSpecificData::Text(ti) => Some(ti.clone()),
                _ if !chunk.specific_data_raw.is_empty()
                    && crate::director::enums::TextInfo::looks_like_text_info(chunk.specific_data_raw.as_slice()) =>
                {
                    Some(crate::director::enums::TextInfo::from(chunk.specific_data_raw.as_slice()))
                }
                _ => None,
            };
            if let Some(text_info) = text_info_to_apply {
                if text_info.width > 0 {
                    text_member.width = text_info.width as u16;
                }
                if text_info.height > 0 {
                    text_member.height = text_info.height as u16;
                }
                text_member.word_wrap = !text_info.dont_wrap;
                text_member.box_type = text_info.box_type_symbol();
                // Propagate anti_alias from the TextInfo so the text-image
                // setter's alpha-threshold branch (which only fires when
                // anti_alias=false) doesn't promote anti-aliased halo pixels
                // to fully opaque. TextMember::new() defaults anti_alias to
                // false; without this propagation, modern #text members
                // authored with AA on still get rendered with the alpha
                // threshold, which makes Arial 12 look thick/double-struck
                // (verified in spineworld_dcr's txt_droplist after the
                // earlier "info=Some" change).
                text_member.anti_alias = text_info.anti_alias;
                text_member.info = Some(text_info);
            }
            let xmed_script_id = chunk
                .member_info
                .as_ref()
                .map(|info| info.header.script_id)
                .unwrap_or(0);
            if xmed_script_id > 0 {
                text_member.script_id = xmed_script_id;
                text_member.member_script_ref = Some(CastMemberRef {
                    cast_lib: cast_lib as i32,
                    cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
                });
            }
            return Some(CastMember {
                number,
                name: member_name,
                comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                member_type: CastMemberType::Text(text_member),
                color: ColorRef::PaletteIndex(255),
                bg_color: ColorRef::PaletteIndex(0),
                reg_point: (0, 0),
            });
        }
        None
    }

    fn parse_xmedia_font(
        member_def: &CastMemberDef,
        number: u32,
        chunk: &CastMemberChunk,
        xm: &XMediaChunk,
        bitmap_manager: &mut BitmapManager,
    ) -> CastMember {
        let pfr = Self::extract_pfr(member_def);

        // Extract preview text using proper XMED parser.
        // PFR fonts don't have preview text.
        let preview_text = if pfr.is_some() {
            String::new()
        } else {
            xm.parse_styled_text()
                .map(|st| st.text.clone())
                .filter(|s| s.len() > 3)
                .unwrap_or_default()
        };
        let preview_font_name = Self::scan_font_name_from_xmedia(xm);
        let font_name = Self::resolve_font_name(chunk, &pfr, number);

        let info_and_bitmap = Self::build_font_info_and_bitmap(
            pfr,
            chunk,
            &font_name,
            bitmap_manager,
        );

        let (font_info, bitmap_ref, char_w, char_h, gc, gr, char_widths, first_char, pfr_parsed, pfr_data) = info_and_bitmap;

        let member_name = chunk
            .member_info
            .as_ref()
            .map(|x| x.name.to_owned())
            .unwrap_or_default();

        debug!(
            "FontMember #{} name='{}' font_name='{}' preview_text='{}' preview_font_name={:?} \
             fixed_line_space=14 top_spacing=0 char_width={:?} char_height={:?} \
             grid_columns={:?} grid_rows={:?} first_char_num={:?} char_widths_len={} \
             bitmap_ref={:?} pfr_parsed={} pfr_data_len={}",
            number, member_name, font_name, preview_text, preview_font_name,
            char_w, char_h, gc, gr, first_char,
            char_widths.as_ref().map_or(0, |v| v.len()),
            bitmap_ref, pfr_parsed.is_some(), pfr_data.as_ref().map_or(0, |d| d.len()),
        );

        CastMember {
            number,
            name: member_name,
            comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
            member_type: CastMemberType::Font(FontMember {
                font_info,
                preview_text,
                preview_font_name,
                preview_html_spans: Vec::new(),
                fixed_line_space: 14,
                top_spacing: 0,
                bitmap_ref,
                char_width: char_w,
                char_height: char_h,
                grid_columns: gc,
                grid_rows: gr,
                char_widths,
                first_char_num: first_char,
                alignment: TextAlignment::Left,
                pfr_parsed,
                pfr_data,
            }),
            color: ColorRef::PaletteIndex(255),
            bg_color: ColorRef::PaletteIndex(0),
            reg_point: (0, 0),
        }
    }

    fn create_text_member_from_xmed(
        number: u32,
        chunk: &CastMemberChunk,
        mut styled_text: crate::director::chunks::xmedia::XmedStyledText,
        stxt_font_size: Option<u16>,
        cast_lib: u32,
    ) -> CastMember {

        debug!(
            "[XMED] Creating TextMember from XMED styled text (member #{})", number
        );

        let alignment: BuiltInSymbol = styled_text.alignment.into();

        // Use the FIRST styled span's font face and font size — i.e. the
        // style covering text offset 0. This matches Paige's
        // `pgFindStyleRun(pg, 0, NULL)` lookup that Director uses for
        // `member.fontSize` (and `member.font`) when no selection is
        // active. The C# PgWalkStyle reader confirms it walks Section 6's
        // first character run → its `style_index` → Section 7's font_size.
        //
        // We previously took `max(span_sizes)` to guard against XMED
        // members whose spans store cell-height instead of point size, but
        // that diverged from Director for mixed-style text (e.g. a member
        // with a 24pt heading + 12pt body would report 24 here whereas
        // Director reports whichever style covers offset 0). The STXT
        // correction below still re-anchors `font_size` proportionally
        // when XMED's value disagrees with STXT, so the cell-height case
        // remains protected — we just seed the ratio from the first span
        // instead of the largest.
        //
        // `max` is kept ONLY as a last-ditch fallback when the first span
        // has no font_size at all (rare), so we don't regress to the
        // hardcoded 12 default.
        let (font_name, mut font_size) = if !styled_text.styled_spans.is_empty() {
            let first_style = &styled_text.styled_spans[0].style;
            // Member-level font_size: prefer XMED Section 0x0005 (the
            // par_run_key in Paige's enum, but used as the character-run
            // table by Director) — Director's `the fontSize of member`
            // reads this. Falls back to the first styled span's size, then
            // to max-of-spans, then to 12 (matches the prior behaviour
            // when 0x0005 is absent or empty).
            let first_span_size = first_style
                .font_size
                .filter(|s| *s > 0)
                .map(|s| s as u16);
            let fallback_max = styled_text
                .styled_spans
                .iter()
                .filter_map(|s| s.style.font_size)
                .filter(|s| *s > 0)
                .max()
                .unwrap_or(12) as u16;
            let chosen_size = styled_text
                .default_font_size
                .or(first_span_size)
                .unwrap_or(fallback_max);
            // Same precedence for font NAME — pull from the char-run
            // → Section 7 lookup so the (font, size) pair stays consistent.
            // `styled_spans[0]` can hold Arial 12 (style[0]) while the real
            // authored style is later in the table (style[3] = Verdana 9 for
            // spineworld_dcr txt_password). default_font_name covers that.
            let chosen_name = styled_text
                .default_font_name
                .clone()
                .or_else(|| first_style.font_face.clone())
                .filter(|n| !n.is_empty())
                .unwrap_or_else(|| "Arial".to_string());
            (chosen_name, chosen_size)
        } else {
            // Empty char-run section (member with no styled text). Still try
            // the default_font_name (sourced from par-run table) before
            // falling back to Arial/12.
            let name = styled_text.default_font_name.clone().unwrap_or_else(|| "Arial".to_string());
            let size = styled_text.default_font_size.unwrap_or(12);
            (name, size)
        };
        // Correct XMED font sizes using STXT point size when available
        if let Some(stxt_size) = stxt_font_size {
            if stxt_size > 0 && stxt_size != font_size && font_size > 0 {
                let ratio = stxt_size as f32 / font_size as f32;
                for span in &mut styled_text.styled_spans {
                    if let Some(ref mut sz) = span.style.font_size {
                        *sz = ((*sz as f32 * ratio).round() as i32).max(1);
                    }
                }
                font_size = stxt_size;
            }
        }

        debug!(
            "[XMED]   text='{}', alignment={}, font='{}', size={}, spans={}, word_wrap={}",
            styled_text.text, alignment, font_name, font_size, styled_text.styled_spans.len(),
            styled_text.word_wrap
        );

        // Get TextInfo from specific_data if available; otherwise synthesize a default one
        // so runtime properties like centerRegPoint are always present on parsed text members.
        let text_info_from_chunk = chunk.specific_data.text_info().cloned();
        let raw_looks_like_text_info = TextInfo::looks_like_text_info(chunk.specific_data_raw.as_slice());
        let text_info_from_raw = if text_info_from_chunk.is_none() && raw_looks_like_text_info {
            Some(TextInfo::from(chunk.specific_data_raw.as_slice()))
        } else {
            None
        };
        let text_info_from_chunk = text_info_from_chunk.or(text_info_from_raw);
        let field_info_from_chunk = chunk.specific_data.field_info();
        let mut text_info = text_info_from_chunk.unwrap_or_else(|| {
            let mut info = TextInfo::default();
            if let Some(field_info) = field_info_from_chunk {
                info.box_type = field_info.box_type as u32;
                info.scroll_top = field_info.scroll as u32;
                info.auto_tab = field_info.auto_tab();
                info.editable = field_info.editable();
                info.dont_wrap = !field_info.wordwrap();
                info.width = field_info.width() as u32;
                info.height = field_info.height() as u32;
            }
            info
        });
        // Prefer XMED Section 1 dword8C ("fallback height" → `styled_text
        // .height`) for the authored member box height. The `text_info`
        // chunk's height (offset 48-51 of its binary header) tracks a
        // post-layout content extent in many cast versions and grows when
        // multi-line text wraps inside a fixed-size box (CS / FurniFactory
        // clock display: authored 52×18, but `text_info.height = 48` once
        // "Time" + RETURN + value has been laid out — so member.rect was
        // returning 52×48 instead of Director's 52×18).
        // dword8C reflects the authored member dimensions and is stable
        // across content changes, so it's the right source for member.rect.
        let mut box_w = if styled_text.width > 0 {
            styled_text.width as u16
        } else if text_info.width > 0 {
            text_info.width as u16
        } else {
            0
        };
        // For `#fixed` (and other non-adjust) box types, Director reports
        // the AUTHORED single-line height regardless of how many lines of
        // text the member currently holds. The XMED Section 1 dword90
        // ("pageHeight" in the C# parser, Paige's `doc_bottom`) stores the
        // total laid-out height = lines * line_height; dividing by the
        // text's line count yields the stable per-line authored height
        // that matches Director's `member.rect.height`.
        //
        // Verified in PgWalkStyle (C# Paige reader) against the FurniFactory
        // clock display (member 74, "Time"+RETURN+timeValue): page_height=36,
        // line_count=2 → 18, matches Director's `rect(0,0,52,18)`.
        //
        // We compute this BEFORE consulting `text_info.height`, because
        // text_info.height (TextInfo header offset 48-51) is the laid-out
        // content extent — it equals page_height for these members and
        // grows with content. Using it as box_h would balloon a #fixed
        // 52×18 member to 52×48 once two lines of text are written.
        let line_count_for_box = styled_text
            .text
            .replace("\r\n", "\n")
            .replace('\r', "\n")
            .split('\n')
            .filter(|l| !l.is_empty())
            .count()
            .max(1) as u32;
        let box_type_is_adjust = text_info.box_type == 0; // 0=#adjust, 2=#fixed, 3=#limit
        // For non-#adjust members, choose between two interpretations of
        // `text_info.height`:
        //
        //   A. AUTHORED FULL LAYOUT — the value matches the laid-out
        //      `page_height` exactly. Junkbot's level-name member
        //      (#fixed, 15 paragraphs): info_h=page_h=331. Director
        //      reports `member.height = 331` (full authored rect), so we
        //      trust `info_h` verbatim.
        //
        //   B. POST-LAYOUT BALLOON — `info_h > page_h`, the TextInfo
        //      header has grown past the layout extent because content
        //      was added after the member was authored. FurniFactory
        //      clock (#fixed, authored 52×18): info_h=48 once "Time" +
        //      RETURN + value has been laid out, while page_h=36 reflects
        //      the layout. Director reports the AUTHORED 18 here, which
        //      we recover via `page_h / line_count`.
        //
        // The `info_h == page_h` test cleanly separates the two: when
        // they agree, info_h is the authored full layout. When they
        // disagree (info_h > page_h), info_h has ballooned and we divide.
        let per_line_from_page = if !box_type_is_adjust && styled_text.page_height > 0 {
            let info_h = text_info.height;
            let page_h = styled_text.page_height as u32;
            let per_line = if line_count_for_box > 0 {
                page_h / line_count_for_box
            } else {
                0
            };
            // When `info_h` is too small to be multi-line authored
            // (< 2 × per_line) but `page_h` clearly is multi-line
            // (page_h > per_line), prefer page_h. Junkbot V2 names
            // member 6: info_h=24, per_line=24 (page_h=361, 15 lines),
            // 24 % 24 = 0 would trip the multiple-rule and trust 24,
            // but the AUTHORED member.height is 361.
            // Member-height resolution for non-#adjust (boxType=#fixed/
            // #limit/#scroll) text members. Three observed patterns:
            //
            //   • info_h < page_h: page_h is the laid-out total of
            //     current authored content. Use page_h.
            //     Junkbot V2 names (cast 11 member 5): info=348,
            //     page=361 → 361 (Director).
            //
            //   • info_h ≥ page_h with info_h being "real" multi-row
            //     authored:
            //       - info_h == page_h  (member 124: info=page=331)
            //       - info_h is an integer multiple of per_line
            //       - info_h has ≥1 full extra row past page_h
            //         (hint_text member 174: info=107, page=68,
            //          per_line=34, diff=39 ≥ 34 → 107)
            //
            //   • Otherwise (FurniFactory clock balloon: info=48,
            //     page=36, per_line=18 → divide to 18).
            let result = if info_h > 0 && page_h > 0 && per_line > 0 {
                if info_h < page_h {
                    page_h as u16
                } else if info_h == page_h
                    || info_h % per_line == 0
                    || info_h.saturating_sub(page_h) >= per_line
                {
                    info_h as u16
                } else {
                    // info_h ballooned past page_h by less than one row —
                    // a runtime balloon (Lingo wrote text and TextInfo
                    // grew but Paige's doc_bottom = page_h is still the
                    // laid-out total). Use page_h, which matches Director's
                    // reported `member.rect.height` for FurniFactory
                    // displayComputer (member 7) and the clock display
                    // (member 74): both have info_h=48, page_h=36,
                    // per_line=18, line_count=2 and Director returns 36.
                    // Earlier this branch returned `per_line` (18), giving
                    // a single-line height that clipped the second row.
                    page_h as u16
                }
            } else if per_line > 0 {
                per_line as u16
            } else {
                0
            };
            result
        } else {
            0
        };

        // For `#adjust` members whose text has EXPLICIT line breaks
        // (\n / \r), Paige's `doc_bottom` (XMED Section 1 dword90 →
        // `page_height`) is the laid-out total Director reports for
        // member.height. CS Junkbot credits (member 16, 16 \n breaks):
        // page_height=375 matches Director exactly, while text_info.height
        // baked at 483 disagrees. For single-paragraph wrap-only #adjust
        // members (member 82 recycler help: 0 \n, page_height=36, Director
        // dynamically measures wrap to 108) the rule must NOT fire — we
        // fall through to `text_info.height` like before.
        let adjust_use_page_height = box_type_is_adjust
            && styled_text.page_height > 0
            && (styled_text.text.contains('\n') || styled_text.text.contains('\r'));
        let mut box_h = if per_line_from_page > 0 {
            per_line_from_page
        } else if adjust_use_page_height {
            styled_text.page_height as u16
        } else if styled_text.height > 0 {
            styled_text.height as u16
        } else if text_info.height > 0 {
            text_info.height as u16
        } else {
            0
        };

        // Fallback for older text member formats: parse raw text member data for dimensions.
        if box_w == 0 || box_h == 0 {
            if let Some(text_member_data) = TextMemberData::from_raw_bytes(chunk.specific_data_raw.as_slice()) {
                if box_w == 0 && text_member_data.width > 0 {
                    box_w = text_member_data.width as u16;
                }
                if box_h == 0 && text_member_data.height > 0 {
                    box_h = text_member_data.height as u16;
                }
            }
        }

        // Final fallback: full page_height (overshoots #fixed but we already
        // tried per-line above; this branch is reached only when both
        // styled_text.height and text_info.height were 0).
        if box_h == 0 && styled_text.page_height > 0 {
            box_h = styled_text.page_height as u16;
        }

        if box_w == 0 { box_w = 100; }
        if box_h == 0 { box_h = 20; }

        // Keep synthesized TextInfo dimensions aligned with effective member box.
        text_info.width = box_w as u32;
        text_info.height = box_h as u32;

        let box_type = text_info.box_type_symbol();
        let word_wrap = text_info.word_wrap();
        let xmed_bg_color = styled_text.bg_color;
        // Member-level fontStyle list: derived from the first styled span's
        // bold/italic/underline flags so `member.fontStyle` matches Director's
        // getter (which returns [#italic] for member 35 etc.). The XMED parse
        // already applies Paige's gap2 -> bool conversion, so we just collect
        // the active span's flags here.
        let member_font_style: Vec<BuiltInSymbol> = styled_text
            .styled_spans
            .first()
            .map(|s| {
                let mut v = Vec::new();
                if s.style.bold      { v.push(BuiltInSymbol::Bold); }
                if s.style.italic    { v.push(BuiltInSymbol::Italic); }
                if s.style.underline { v.push(BuiltInSymbol::Underline); }
                v
            })
            .unwrap_or_default();
        let xmed_script_id = chunk
            .member_info
            .as_ref()
            .map(|info| info.header.script_id)
            .unwrap_or(0);
        let xmed_member_script_ref = if xmed_script_id > 0 {
            Some(CastMemberRef {
                cast_lib: cast_lib as i32,
                cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
            })
        } else {
            None
        };
        let text_member = TextMember {
            text: styled_text.text.clone(),
            html_source: String::new(),
            rtf_source: String::new(),
            alignment,
            box_type,
            word_wrap,
            anti_alias: true,
            font: font_name,
            font_style: member_font_style,
            font_size,
            // `styled_text.fixed_line_space` is now derived from par_run[0]'s
            // par_info (the paragraph applied at text position 0) — that's
            // Director's `member.fixedLineSpace` value and is the
            // authoritative source. The older `styled_text.line_spacing`
            // field still exists from the legacy heuristic in
            // `parse_section_8` but is unreliable (lands on 16 for
            // Junkbot v1 level.num where Director reports 21). Use
            // `fixed_line_space` directly; falling through to
            // `styled_text.line_spacing` would re-introduce that bug.
            fixed_line_space: styled_text.fixed_line_space,
            top_spacing: styled_text.top_spacing as i16,
            bottom_spacing: styled_text.bottom_spacing as i16,
            width: box_w,
            height: box_h,
            rect_set_at_runtime: false,
            text_set_at_runtime: false,
            char_spacing: styled_text.styled_spans.first()
                .map(|s| s.style.char_spacing as i32)
                .unwrap_or(0),
            tab_stops: Vec::new(),
            par_infos: styled_text.par_infos.clone(),
            par_runs: styled_text.par_runs.clone(),
            hyperlinks: styled_text.hyperlinks.clone(),
            html_styled_spans: styled_text.styled_spans,
            info: Some(text_info),
            w3d: None,
            sel_start: 0,
            sel_end: 0,
            sel_anchor: 0,
            anti_alias_type: BuiltInSymbol::AutoAlias,
            script_id: xmed_script_id,
            member_script_ref: xmed_member_script_ref,
        };

        let member_name = chunk
            .member_info
            .as_ref()
            .map(|x| x.name.to_owned())
            .unwrap_or_default();

        debug!(
            "[XMED] TextMember #{} name='{}' text='{}' alignment='{}' box_type='{}' word_wrap={} \
             anti_alias={} font='{}' font_style={:?} font_size={} fixed_line_space={} \
             top_spacing={} width={} height={} styled_spans={}",
            number,
            member_name,
            text_member.text,
            text_member.alignment,
            text_member.box_type,
            text_member.word_wrap,
            text_member.anti_alias,
            text_member.font,
            text_member.font_style,
            text_member.font_size,
            text_member.fixed_line_space,
            text_member.top_spacing,
            text_member.width,
            text_member.height,
            text_member.html_styled_spans.len(),
        );

        // Preserve XMED foreColor at the member level so it persists
        // even when Lingo sets member.text or member.html (which may clear styled span colors)
        let member_color = text_member.html_styled_spans.first()
            .and_then(|s| s.style.color)
            .map(|c| ColorRef::Rgb(
                ((c >> 16) & 0xFF) as u8,
                ((c >> 8) & 0xFF) as u8,
                (c & 0xFF) as u8,
            ))
            .unwrap_or(ColorRef::PaletteIndex(255));

        // Extract XMED backColor from Section 0x0000 document header (indices 30-32).
        let member_bg_color = xmed_bg_color
            .map(|(r, g, b)| ColorRef::Rgb(r, g, b))
            .unwrap_or(ColorRef::PaletteIndex(0));

        let reg_point = text_member.info.as_ref()
            .map(|info| (info.reg_x, info.reg_y))
            .unwrap_or((0, 0));
        CastMember {
            number,
            name: member_name,
            comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
            member_type: CastMemberType::Text(text_member),
            color: member_color,
            bg_color: member_bg_color,
            reg_point,
        }
    }

    fn build_font_info_and_bitmap(
        pfr: Option<PfrFont>,
        chunk: &CastMemberChunk,
        default_name: &str,
        bitmap_manager: &mut BitmapManager,
    ) -> (
        FontInfo,
        Option<BitmapRef>,
        Option<u16>, // char width
        Option<u16>, // char height
        Option<u8>, // grid columns
        Option<u8>, // grid rows
        Option<Vec<u16>>, // char widths
        Option<u8>, // first_char_num
        Option<crate::director::chunks::pfr1::types::Pfr1ParsedFont>,
        Option<Vec<u8>>,
        ) {
        let specific_bytes = chunk.specific_data_raw.clone();

        if let Some(pfr) = pfr {
            let requested_size = chunk
                .specific_data
                .font_info()
                .map(|fi| fi.size)
                .unwrap_or(0);
            let target_height = if requested_size > 0 {
                requested_size as usize
            } else {
                16usize
            };

            debug!(
                "[font.load] font='{}' FontInfo.size={} target_height={}",
                if pfr.font_name.is_empty() { default_name } else { &pfr.font_name },
                requested_size, target_height
            );

            let bmp = Self::render_pfr_to_bitmap(&pfr, bitmap_manager, target_height);

            let info = FontInfo {
                font_id: 0,
                size: target_height as u16,
                style: 0,
                name: if pfr.font_name.is_empty() {
                    default_name.to_string()
                } else {
                    pfr.font_name.clone()
                }
            };

            debug!("Rendered PFR: {:?}", info);

            return (
                info,
                Some(bmp.bitmap_ref),
                Some(bmp.char_width),
                Some(bmp.char_height),
                Some(bmp.grid_columns),
                Some(bmp.grid_rows),
                bmp.char_widths,
                Some(bmp.first_char),
                Some(pfr.parsed.clone()),
                Some(pfr.raw_data.clone()),
            );
        }

        if FontInfo::looks_like_real_font_data(&specific_bytes) {
            let info = chunk
                .specific_data
                .font_info()
                .map(|fi| fi.clone().with_default_name(default_name))
                .unwrap_or_else(|| FontInfo::minimal(default_name));

            return (info, None, None, None, None, None, None, None, None, None);
        }

        // fallback
        (FontInfo::minimal(default_name), None, None, None, None, None, None, None, None, None)
    }

    pub fn get_script_id(&self) -> Option<u32> {
        match &self.member_type {
            CastMemberType::Bitmap(bitmap) => {
                if bitmap.script_id > 0 {
                    Some(bitmap.script_id)
                } else {
                    None
                }
            }
            CastMemberType::Button(button) => {
                if button.script_id > 0 {
                    Some(button.script_id)
                } else {
                    None
                }
            }
            CastMemberType::Shape(shape) => {
                if shape.script_id > 0 {
                    Some(shape.script_id)
                } else {
                    None
                }
            }
            CastMemberType::Field(field) => {
                if field.script_id > 0 {
                    Some(field.script_id)
                } else {
                    None
                }
            }
            CastMemberType::Text(text) => {
                if text.script_id > 0 {
                    Some(text.script_id)
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    pub fn get_member_script_ref(&self) -> Option<&CastMemberRef> {
        match &self.member_type {
            CastMemberType::Bitmap(bitmap) => bitmap.member_script_ref.as_ref(),
            CastMemberType::Button(button) => button.member_script_ref.as_ref(),
            CastMemberType::Shape(shape) => shape.member_script_ref.as_ref(),
            CastMemberType::Field(field) => field.member_script_ref.as_ref(),
            CastMemberType::Text(text) => text.member_script_ref.as_ref(),
            _ => None,
        }
    }

    pub fn set_member_script_ref(&mut self, script_ref: CastMemberRef) {
        match &mut self.member_type {
            CastMemberType::Bitmap(bitmap) => {
                bitmap.member_script_ref = Some(script_ref);
            }
            CastMemberType::Button(button) => {
                button.member_script_ref = Some(script_ref);
            }
            CastMemberType::Shape(shape) => {
                shape.member_script_ref = Some(script_ref);
            }
            CastMemberType::Field(field) => {
                field.member_script_ref = Some(script_ref);
            }
            CastMemberType::Text(text) => {
                text.member_script_ref = Some(script_ref);
            }
            _ => {}
        }
    }

    pub fn from(
        cast_lib: u32,
        number: u32,
        member_def: &CastMemberDef,
        lctx: &Option<ScriptContext>,
        bitmap_manager: &mut BitmapManager,
        dir_version: u16,
        palette_id_offset: i16,
        font_table: &HashMap<u16, String>,
    ) -> CastMember {
        let chunk = &member_def.chunk;

        let member_type = match chunk.member_type {
            MemberType::Text => {
                let text_chunk = member_def.children.iter()
                    .find_map(|c| c.as_ref().and_then(|ch| ch.as_text()))
                    .expect("No text chunk found for text member");
                let raw = chunk.specific_data_raw.as_slice();
                let field_info = FieldInfo::from(raw);
                debug!(
                    "[FIELD_INFO] rect=({},{},{},{}) text_height={} max_height={} border={} margin={} box_shadow={} box_type={} scroll={} flags=0x{:02X} raw_len={}",
                    field_info.rect_left, field_info.rect_top, field_info.rect_right, field_info.rect_bottom,
                    field_info.text_height,
                    field_info.max_height,
                    field_info.border,
                    field_info.margin,
                    field_info.box_drop_shadow,
                    field_info.box_type,
                    field_info.scroll,
                    field_info.flags,
                    raw.len(),
                );
                let mut field_member = FieldMember::from_field_info(&field_info);
                field_member.text = text_chunk.text.clone();

                // Parse STXT formatting data to extract actual fontId, fontSize, and style
                let formatting_runs = text_chunk.parse_formatting_runs();
                // Keep the FULL run list on the field so per-char prop access
                // (`the textStyle of char N of member`, `member.char[N].fontStyle`)
                // and per-run rendering (underline links, mixed bold spans)
                // can read it. Without this, fields with rich STXT formatting
                // (Fugue No.4's "Narrative" text-link field, etc.) would
                // collapse to a single uniform style and the script's
                // link-detection logic never fires.
                field_member.formatting_runs = formatting_runs.clone();
                // Pick the DOMINANT font_size — the size used by the most
                // characters — as the member-wide default. Director's
                // rendering effectively uses this size for the bulk of
                // the field; the first run's size (e.g. David's Notes
                // header at 18) is correct for that range but the body
                // (12) is what dominates the rendered area. Picking
                // dominant matches Shockwave's visual output for
                // Spanish/Portuguese/David's Notes alike.
                //
                // Algorithm:
                //   1. For each run, compute its char coverage as
                //      (next_run.start_position - run.start_position),
                //      or text_len - run.start_position for the last
                //      run.
                //   2. Sum coverage per font_size (skipping bogus sizes
                //      <6 from marker runs).
                //   3. Pick the size with the highest total coverage.
                //
                // Other member-wide defaults (font, fixed_line_space,
                // fore_color) still come from the FIRST run with that
                // dominant size, so any consistent per-run formatting
                // tied to the body comes through correctly.
                let text_byte_len = text_chunk.text.len() as u32;
                let mut coverage_by_size: std::collections::HashMap<u16, u32> =
                    std::collections::HashMap::new();
                for (i, r) in formatting_runs.iter().enumerate() {
                    if r.font_size < 6 { continue; }
                    let next_pos = if i + 1 < formatting_runs.len() {
                        formatting_runs[i + 1].start_position
                    } else {
                        text_byte_len
                    };
                    let coverage = next_pos.saturating_sub(r.start_position);
                    *coverage_by_size.entry(r.font_size).or_insert(0) += coverage;
                }
                let dominant_size: Option<u16> = coverage_by_size
                    .iter()
                    .max_by_key(|&(_, c)| *c)
                    .map(|(s, _)| *s);
                // Among runs at the dominant size, prefer one whose
                // font_id resolves to a NON-styled (no "Bold"/"Italic")
                // variant. The renderer loads one atlas per field and
                // applies bold via double-strike / italic via shear on
                // that atlas — if the atlas itself is "Arial Bold" or
                // "Arial Italic", stacking another transformation on
                // top produces bold-italic or extra-bold glyphs that
                // don't match Shockwave's render. Fugue No. 4
                // Narrative's 12pt body has its dominant run pointed
                // at "Arial Bold" in the Fmap; without this preference
                // the whole body atlas comes out heavy.
                let resolve_name = |fid: u16| -> Option<String> {
                    font_table.get(&fid).cloned()
                };
                let is_neutral_name = |name: &str| -> bool {
                    let lc = name.to_ascii_lowercase();
                    !lc.contains("bold") && !lc.contains("italic")
                };
                let primary_run = dominant_size
                    .and_then(|sz| {
                        formatting_runs.iter()
                            .find(|r| r.font_size == sz
                                && resolve_name(r.font_id)
                                    .as_deref()
                                    .map(is_neutral_name)
                                    .unwrap_or(false))
                            .or_else(|| formatting_runs.iter().find(|r| r.font_size == sz))
                    })
                    .or_else(|| formatting_runs.iter()
                        .find(|r| r.font_size >= 6
                            && resolve_name(r.font_id)
                                .as_deref()
                                .map(is_neutral_name)
                                .unwrap_or(false)))
                    .or_else(|| formatting_runs.iter().find(|r| r.font_size >= 6))
                    .or_else(|| formatting_runs.first());
                if let Some(first_run) = primary_run {
                    // Extract foreground color from STXT formatting run
                    let fg_r = (first_run.color_r >> 8) as u8;
                    let fg_g = (first_run.color_g >> 8) as u8;
                    let fg_b = (first_run.color_b >> 8) as u8;
                    field_member.fore_color = Some(ColorRef::Rgb(fg_r, fg_g, fg_b));

                    field_member.font_id = Some(first_run.font_id);
                    // Resolve STXT font_id to font name via Fmap font table
                    if let Some(font_name) = font_table.get(&first_run.font_id) {
                        field_member.font = font_name.clone();
                    }
                    debug!(
                        "[field.font] STXT font_id={} -> Fmap='{}' (table has {} entries)",
                        first_run.font_id,
                        if field_member.font.is_empty() { "<NOT FOUND>" } else { &field_member.font },
                        font_table.len(),
                    );
                    if first_run.font_size > 0 {
                        field_member.font_size = first_run.font_size;
                    }
                    // Use STXT run's height as line spacing — this is Director's
                    // computed line height (ascent + descent + leading) for the run.
                    if first_run.height > 0 {
                        field_member.fixed_line_space = first_run.height;
                    }
                    if first_run.style != 0 {
                        let mut styles = Vec::new();
                        if (first_run.style & 0x01) != 0 {
                            styles.push("bold");
                        }
                        if (first_run.style & 0x02) != 0 {
                            styles.push("italic");
                        }
                        if (first_run.style & 0x04) != 0 {
                            styles.push("underline");
                        }
                        if styles.is_empty() {
                            field_member.font_style = "plain".to_string();
                        } else {
                            field_member.font_style = styles.join(" ");
                        }
                    }
                }

                // Cast-member-attached "BehaviorScript" — Director ships
                // some buttons as Field members with a member script holding
                // mouseDown/mouseUp/mouseUpOutSide. Pulled out of the cast
                // info header the same way ButtonMember does.
                let field_script_id = chunk
                    .member_info
                    .as_ref()
                    .map(|info| info.header.script_id)
                    .unwrap_or(0);
                if field_script_id > 0 {
                    field_member.script_id = field_script_id;
                    field_member.member_script_ref = Some(CastMemberRef {
                        cast_lib: cast_lib as i32,
                        cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
                    });
                }

                debug!(
                    "FieldMember text='{}' alignment='{}' word_wrap={} font='{}' \
                     font_style='{}' font_size={} font_id={:?} fixed_line_space={} \
                     top_spacing={} box_type='{}' anti_alias={} width={} \
                     auto_tab={} editable={} border={} fore_color={:?} back_color={:?} formatting_runs={} script_id={}",
                    field_member.text, field_member.alignment, field_member.word_wrap,
                    field_member.font, field_member.font_style, field_member.font_size,
                    field_member.font_id, field_member.fixed_line_space,
                    field_member.top_spacing, field_member.box_type, field_member.anti_alias,
                    field_member.width, field_member.auto_tab, field_member.editable,
                    field_member.border, field_member.fore_color, field_member.back_color,
                    formatting_runs.len(), field_member.script_id,
                );

                CastMemberType::Field(field_member)
            }
            MemberType::Script => {
                let member_info = chunk.member_info.as_ref().unwrap();
                let mut script_id = member_info.header.script_id;
                let script_type = chunk.specific_data.script_type().unwrap();
                let has_script = lctx.as_ref()
                    .map(|ctx| ctx.scripts.contains_key(&script_id))
                    .unwrap_or(false);

                // Note: script_id == 0 means the script was recycled/deleted.
                // Do NOT fall back to using the member number — the Lscr chunk at that
                // index may contain stale bytecode from before the script was recycled.

                let has_script = lctx.as_ref()
                    .map(|ctx| ctx.scripts.contains_key(&script_id))
                    .unwrap_or(false);

                if has_script {
                    CastMemberType::Script(ScriptMember {
                        script_id,
                        script_type,
                        name: member_info.name.clone(),
                    })
                } else {
                    warn!("Script member {}: script_id {} not found in Lctx, skipping", number, script_id);
                    CastMemberType::Unknown
                }
            }
            MemberType::Flash => {
                use crate::director::enums::ShapeType;
                debug!("Flash member {}: checking for shape_info", number);
                debug!("  specific_data has shape_info: {}", chunk.specific_data.shape_info().is_some());

                if let Some(shape_info) = chunk.specific_data.shape_info() {
                    let script_id = chunk.member_info.as_ref()
                        .map(|info| info.header.script_id)
                        .unwrap_or(0);
                    let member_script_ref = if script_id > 0 {
                        Some(CastMemberRef { cast_lib: cast_lib as i32, cast_member: number as i32 })
                    } else { None };
                    debug!("Flash member {} is a Shape (via shape_info), script_id={}", number, script_id);
                    return CastMember {
                        number,
                        name: chunk
                            .member_info
                            .as_ref()
                            .map(|x| x.name.to_owned())
                            .unwrap_or_default(),
                        comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                        member_type: CastMemberType::Shape(ShapeMember {
                            shape_info: shape_info.clone(),
                            script_id,
                            member_script_ref,
                        }),
                        color: ColorRef::PaletteIndex(255),
                        bg_color: ColorRef::PaletteIndex(0),
                        reg_point: (0, 0),
                    }
                }

                // Director MX 2004 can store shapes as Flash members
                // Try to parse the specific_data_raw as ShapeInfo
                if !chunk.specific_data_raw.is_empty() {
                    debug!("  specific_data_raw length: {}", chunk.specific_data_raw.len());

                    // Try parsing as ShapeInfo
                    let shape_info = ShapeInfo::from(chunk.specific_data_raw.as_slice());
                    debug!("  Parsed shape_type: {:?}", shape_info.shape_type);

                    // If it looks like valid shape data, treat it as a shape
                    if matches!(shape_info.shape_type, ShapeType::Rect | ShapeType::Oval | ShapeType::OvalRect | ShapeType::Line) {
                        let script_id = chunk.member_info.as_ref()
                            .map(|info| info.header.script_id)
                            .unwrap_or(0);
                        let member_script_ref = if script_id > 0 {
                            Some(CastMemberRef { cast_lib: cast_lib as i32, cast_member: number as i32 })
                        } else { None };
                        debug!("Flash member {} is actually a Shape! script_id={}", number, script_id);
                        return CastMember {
                            number,
                            name: chunk
                                .member_info
                                .as_ref()
                                .map(|x| x.name.to_owned())
                                .unwrap_or_default(),
                            comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                            member_type: CastMemberType::Shape(ShapeMember {
                                shape_info,
                                script_id,
                                member_script_ref,
                            }),
                            color: ColorRef::PaletteIndex(255),
                            bg_color: ColorRef::PaletteIndex(0),
                            reg_point: (0, 0),
                        }
                    }
                }

                // Search ALL children for SWF data (not just child 0)
                for child_opt in &member_def.children {
                    if let Some(child) = child_opt {
                        if let Some(bytes) = child.as_bytes() {
                            if let Some(cm) = Self::try_parse_swf(bytes.to_vec(), number, chunk) {
                                return cm;
                            }
                        }
                    }
                }
                // Also scan XMedia children
                if let Some(cm) = Self::scan_children_for_ole(member_def, number, chunk, bitmap_manager, cast_lib) {
                    return cm;
                }
                // Fallback: use first child bytes if available. Hoist the
                // bytes lookup BEFORE reg_point so the centered branch can
                // read true SWF dimensions for centering (see the OLE
                // make_swf_member site for the same rationale —
                // FlashInfo.reg_point can be stale; parse_swf_dimensions
                // reads the SWF FrameSize header directly).
                // Mirror make_swf_member: the FLSH payload is sometimes in the
                // parsed specific_data and sometimes only in specific_data_raw.
                // Without the raw fallback, native Flash members got flash_info
                // = None → reg_point defaulted to (0,0) (bogey_nights' arm read
                // regPoint point(0,0) instead of Director's point(109,63)).
                let flash_info = chunk
                    .specific_data
                    .flash_info()
                    .cloned()
                    .or_else(|| crate::director::enums::FlashInfo::from(&chunk.specific_data_raw));
                let bytes_opt = Self::get_first_child_bytes(member_def);
                let reg_point = Self::flash_reg_point(
                    flash_info.as_ref(),
                    bytes_opt.as_deref().unwrap_or(&[]),
                );
                let flash_member_type = if let Some(bytes) = bytes_opt {
                    CastMemberType::Flash(FlashMember { data: bytes, reg_point, flash_info })
                } else {
                    warn!("Flash cast member has no data chunk or it is invalid.");
                    CastMemberType::Flash(FlashMember { data: vec![], reg_point, flash_info })
                };
                // Early-return a full CastMember so the computed reg point lands
                // on CastMember.reg_point too — `member.regPoint` reads that
                // (CastMember-level) value, not the FlashMember's. Matches the
                // make_swf_member (OLE) path.
                return CastMember {
                    number,
                    name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                    comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                    member_type: flash_member_type,
                    color: ColorRef::PaletteIndex(255),
                    bg_color: ColorRef::PaletteIndex(0),
                    reg_point: (reg_point.0 as i32, reg_point.1 as i32),
                };
            }
            MemberType::Ole => {
                Self::log_ole_start(number, cast_lib, chunk);

                // Check if this OLE member is a Shockwave3D member.
                // Format: 4-byte string length + "shockwave3d" + 3DPR data
                if Self::is_shockwave3d_ole(&chunk.specific_data_raw) {
                    let info = Shockwave3dInfo::from(&chunk.specific_data_raw)
                        .unwrap_or(Shockwave3dInfo { loops: false, duration: 0, direct_to_stage: false, animation_enabled: false, preload: false, reg_point: (0, 0), default_rect: (0, 0, 0, 0), camera_position: None, camera_rotation: None, bg_color: None, ambient_color: None });
                    let w3d_data = member_def.children.iter()
                        .filter_map(|c| c.as_ref())
                        .find_map(|c| match c {
                            Chunk::XMedia(xm) => Some(xm.raw_data.clone()),
                            Chunk::Raw(raw) => {
                                // Some Director versions store W3D data as Raw chunks
                                if raw.len() > 4 {
                                    Some(raw.clone())
                                } else {
                                    None
                                }
                            }
                            _ => None,
                        })
                        .unwrap_or_default();
                    // Dump specific_data_raw and first bytes of w3d for debugging
                    let specific_hex: Vec<String> = chunk.specific_data_raw
                        .iter().map(|b| format!("{:02X}", b)).collect();
                    // Try to decode extra 3DPR fields (camera, colors)
                    let raw = &chunk.specific_data_raw;
                    let str_len = u32::from_be_bytes([raw[0], raw[1], raw[2], raw[3]]) as usize;
                    let o = 4 + str_len + 12;
                    let mut extra_info = String::new();
                    if raw.len() >= o + 0x80 {
                        // Scan for camera position/rotation floats after the known fields
                        // Try reading floats starting from o+0x57+4 onwards
                        let scan_start = o + 0x57;
                        for scan_off in (scan_start..raw.len().saturating_sub(12)).step_by(4) {
                            let f1 = f32::from_bits(u32::from_be_bytes([raw[scan_off], raw[scan_off+1], raw[scan_off+2], raw[scan_off+3]]));
                            let f2 = f32::from_bits(u32::from_be_bytes([raw[scan_off+4], raw[scan_off+5], raw[scan_off+6], raw[scan_off+7]]));
                            let f3 = f32::from_bits(u32::from_be_bytes([raw[scan_off+8], raw[scan_off+9], raw[scan_off+10], raw[scan_off+11]]));
                            // Look for plausible camera-like values
                            if f1.abs() > 0.01 && f1.abs() < 10000.0 && f2.abs() > 0.01 && f2.abs() < 10000.0 && f3.abs() > 0.01 && f3.abs() < 10000.0 {
                                extra_info.push_str(&format!("\n  @o+0x{:X}: floats ({:.4}, {:.4}, {:.4})", scan_off - o, f1, f2, f3));
                            }
                        }
                    }

                    debug!(
                        "Ole member #{} Shockwave3D: w3d={} bytes, rect=({},{},{},{})\n  specific_data_raw[{}]: {}\n  3DPR content offset=0x{:X}{}",
                        number, w3d_data.len(),
                        info.default_rect.0, info.default_rect.1, info.default_rect.2, info.default_rect.3,
                        chunk.specific_data_raw.len(), specific_hex.join(" "),
                        o, extra_info
                    );

                    // Dump the IFX view node block data if found
                    if let Some(ifx_start) = crate::director::chunks::w3d::find_ifx_start_offset(&w3d_data) {
                        let ifx = &w3d_data[ifx_start..];
                        let first256: Vec<String> = ifx[..ifx.len().min(256)].iter().map(|b| format!("{:02X}", b)).collect();
                        debug!(
                            "  IFX data at offset {}, first 256 bytes:\n  {}",
                            ifx_start, first256.join(" ")
                        );
                    }
                    let parsed_scene = if !w3d_data.is_empty() {
                        match crate::director::chunks::w3d::parse_w3d(&w3d_data) {
                            Ok(scene) => {
                                debug!("W3D parsed: {} materials, {} nodes, {} meshes, {} motions",
                                    scene.materials.len(), scene.nodes.len(), scene.clod_meshes.len(), scene.motions.len());
                                Some(std::rc::Rc::new(scene))
                            }
                            Err(e) => {
                                web_sys::console::error_1(&format!("W3D parse error: {}", e).into());
                                Some(std::rc::Rc::new(Self::create_empty_w3d_scene()))
                            }
                        }
                    } else {
                        // Empty W3D data — create empty scene for Lingo-created content
                        Some(std::rc::Rc::new(Self::create_empty_w3d_scene()))
                    };
                    let runtime_state = Shockwave3dRuntimeState::from_info(&info, parsed_scene.as_deref());
                    return CastMember {
                        number,
                        name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                        member_type: CastMemberType::Shockwave3d(Shockwave3dMember {
                        // Capture the load-time scene (even when it's the empty scene
                        // for Lingo-built content like Pacman's "BlankScene") so
                        // resetWorld() can restore it. Without this, resetWorld was a
                        // no-op for these members and runtime models (the whole maze,
                        // ghosts, etc.) leaked across a game-over restart.
                        source_scene: parsed_scene.clone(),
                        parsed_scene,
                        runtime_state,
                        info: info.clone(),
                        w3d_data,
                        converted_from_text: false,
                        text3d_state: None,
                        text3d_source: None,
                    }),
                        color: ColorRef::PaletteIndex(255),
                        bg_color: ColorRef::PaletteIndex(0),
                        reg_point: info.reg_point,
                    };
                }

                // Check if this OLE member is a Havok Physics member
                if Self::is_havok_member_any(&chunk.specific_data_raw, &chunk.member_info) {
                    let hke_data = member_def.children.iter()
                        .filter_map(|c| c.as_ref())
                        .find_map(|c| match c {
                            Chunk::XMedia(xm) => Some(xm.raw_data.clone()),
                            Chunk::Raw(raw) if raw.len() > 4 => Some(raw.clone()),
                            _ => None,
                        })
                        .unwrap_or_default();
                    debug!(
                        "Havok Physics member #{} detected, HKE data={} bytes",
                        number, hke_data.len()
                    );
                    return CastMember {
                        number,
                        name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                        member_type: CastMemberType::HavokPhysics(HavokPhysicsMember::new(hke_data)),
                        color: ColorRef::PaletteIndex(255),
                        bg_color: ColorRef::PaletteIndex(0),
                        reg_point: (0, 0),
                    };
                }

                // Check if this OLE member is a PhysX (AGEIA) Physics member.
                // PhysX members have no authored binary state — the wrapper is
                // empty until Lingo `init()` / `createRigidBody` calls populate it.
                if Self::is_physx_member_any(&chunk.specific_data_raw, &chunk.member_info) {
                    debug!("PhysX (AGEIA) Physics member #{} detected", number);
                    return CastMember {
                        number,
                        name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                        member_type: CastMemberType::PhysXPhysics(PhysXPhysicsMember::new()),
                        color: ColorRef::PaletteIndex(255),
                        bg_color: ColorRef::PaletteIndex(0),
                        reg_point: (0, 0),
                    };
                }

                // Check if this OLE member is a vectorShape by examining specific_data_raw.
                // Format: 4-byte string length + "vectorShape" + FLSH data block
                if let Some(cm) = Self::try_parse_vector_shape(&chunk.specific_data_raw, number, chunk) {
                    return cm;
                }

                // Try direct OLE data
                if let Some(bytes) = Self::get_first_child_bytes(member_def) {
                    if let Some(cm) = Self::try_parse_swf(bytes, number, chunk) {
                        return cm;
                    }
                }

                // Try all XMedia children for SWF or fonts
                if let Some(cm) = Self::scan_children_for_ole(member_def, number, chunk, bitmap_manager, cast_lib) {
                    return cm;
                }

                // An EMPTY Flash container. The Flash Asset Xtra declares
                // itself with the length-prefixed OLE type string "flash" (the
                // same mechanism `vectorShape` uses above), and a member can
                // legitimately carry no SWF at all — the movie points it at one
                // at runtime:
                //
                //   on advertContainer me, sNum, id, w, h
                //     sprite(sNum).member.fileName = …advertLoader…
                //     sprite(sNum).member.cdpCheckMode = #useMediaPolicy
                //     preload(sprite(sNum).member)
                //
                // Both SWF scans above find nothing for such a member, and
                // falling through to Unknown made every Flash property raise —
                // Miniclip's gameloader dies on the `.fileName` write. Typing it
                // as an empty Flash member (exactly as the MemberType::Flash arm
                // does when its data chunk is missing) lets the runtime load
                // proceed.
                if Self::ole_type_string(&chunk.specific_data_raw).as_deref() == Some("flash") {
                    let flash_info = chunk
                        .specific_data
                        .flash_info()
                        .cloned()
                        .or_else(|| crate::director::enums::FlashInfo::from(&chunk.specific_data_raw));
                    let reg_point = Self::flash_reg_point(flash_info.as_ref(), &[]);
                    debug!("Empty Flash (OLE) member #{} — awaiting a runtime .fileName", number);
                    return CastMember {
                        number,
                        name: chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
                        member_type: CastMemberType::Flash(FlashMember {
                            data: vec![],
                            reg_point,
                            flash_info,
                        }),
                        color: ColorRef::PaletteIndex(255),
                        bg_color: ColorRef::PaletteIndex(0),
                        reg_point: (reg_point.0 as i32, reg_point.1 as i32),
                    };
                }

                // Fallback
                Self::log_unknown_ole(number, chunk);
                CastMemberType::Unknown
            }
            MemberType::Picture => {
                // Director picture cast members carry QuickDraw PICT data in a
                // raw child chunk. Their score location anchors the top-left.
                let pict = member_def.children.iter().find_map(|child| {
                    match child.as_ref() {
                        Some(Chunk::Raw(data)) if data.get(10..14) == Some(&[0, 0x11, 2, 0xff]) => Some(data),
                        _ => None,
                    }
                });
                let decoded = pict.ok_or_else(|| "No PICT v2 child chunk".to_string())
                    .and_then(|data| super::bitmap::pict::decode_pict(data));
                match decoded {
                    Ok(bitmap) => {
                        let info = BitmapInfo {
                            width: bitmap.width, height: bitmap.height,
                            reg_x: 0, reg_y: 0, bit_depth: 32,
                            palette_id: -1, clut_cast_lib: -1, pitch: 0,
                            use_alpha: false, trim_white_space: false, center_reg_point: false,
                        };
                        let script_id = chunk.member_info.as_ref().map(|info| info.header.script_id).unwrap_or(0);
                        let member_script_ref = if script_id > 0 {
                            Some(CastMemberRef {cast_lib: cast_lib as i32, cast_member: number as i32})
                        } else { None };
                        CastMemberType::Bitmap(BitmapMember {
                            image_ref: bitmap_manager.add_bitmap(bitmap), reg_point: (0, 0),
                            script_id, member_script_ref, info,
                        })
                    }
                    Err(error) => {
                        warn!("Cannot decode PICT member {}: {}", number, error);
                        CastMemberType::Unknown
                    }
                }
            }
            MemberType::Bitmap => {
                let mut bitmap_info = chunk.specific_data.bitmap_info().unwrap().clone();

                // Adjust palette_id if offset is non-zero (Config vs MCsL numbering mismatch).
                if bitmap_info.palette_id > 0 && palette_id_offset != 0 {
                    bitmap_info.palette_id -= palette_id_offset;
                }

                let script_id = chunk
                    .member_info
                    .as_ref()
                    .map(|info| info.header.script_id)
                    .unwrap_or(0);
                
                let behavior_script_ref = if script_id > 0 {
                    let script_chunk = &lctx.as_ref().unwrap().scripts[&script_id];

                    // Create the behavior script reference
                    Some(CastMemberRef {
                        cast_lib: cast_lib as i32,
                        cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
                    })
                } else {
                    None
                };

                // First, check if there's a Media (ediM) chunk with JPEG data
                let media_chunk = member_def.children.iter().find_map(|c| {
                    c.as_ref().and_then(|chunk| match chunk {
                        Chunk::Media(m) => Some(m),
                        _ => None,
                    })
                });

                let new_bitmap_ref = if let Some(media) = media_chunk {
                    // Check if the media chunk contains JPEG data
                    let is_jpeg = if media.audio_data.len() >= 4 {
                        let header = u32::from_be_bytes([
                            media.audio_data[0],
                            media.audio_data[1],
                            media.audio_data[2],
                            media.audio_data[3],
                        ]);
                        // JPEG magic numbers: FFD8FFE0, FFD8FFE1, FFD8FFE2, FFD8FFDB
                        (header & 0xFFFFFF00) == 0xFFD8FF00
                    } else {
                        false
                    };

                    if is_jpeg && !media.audio_data.is_empty() {
                        // Look for ALFA chunk in children (Raw data from parsed ALFA chunk)
                        let alfa_data: Option<&Vec<u8>> = member_def.children.iter().find_map(|c| {
                            c.as_ref().and_then(|chunk| match chunk {
                                Chunk::Raw(data) => Some(data),
                                _ => None,
                            })
                        });

                        match decode_jpeg_bitmap(&media.audio_data, &bitmap_info, alfa_data) {
                            Ok(new_bitmap) => {
                                debug!(
                                    "Successfully decoded JPEG: {}x{}, bit_depth: {}",
                                    new_bitmap.width, new_bitmap.height, new_bitmap.bit_depth
                                );
                                bitmap_manager.add_bitmap(new_bitmap)
                            }
                            Err(e) => {
                                warn!(
                                    "Failed to decode JPEG bitmap {}: {:?}. Using empty image.",
                                    number, e
                                );
                                bitmap_manager.add_bitmap(Bitmap::new(
                                    1,
                                    1,
                                    8,
                                    8,
                                    0,
                                    PaletteRef::BuiltIn(BuiltInPalette::GrayScale),
                                ))
                            }
                        }
                    } else {
                        // Media chunk exists but doesn't contain JPEG, fall back to BITD
                        Self::decode_bitmap_from_bitd(
                            member_def,
                            &bitmap_info,
                            cast_lib,
                            number,
                            bitmap_manager,
                        )
                    }
                } else {
                    // No Media chunk, use BITD
                    Self::decode_bitmap_from_bitd(
                        member_def,
                        &bitmap_info,
                        cast_lib,
                        number,
                        bitmap_manager,
                    )
                };

                debug!(
                        "BitmapMember created â†’ name: {} palette_id {} useAlpha {} trimWhiteSpace {}",
                        chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        bitmap_info.palette_id,
                        bitmap_info.use_alpha,
                        bitmap_info.trim_white_space
                    );

                CastMemberType::Bitmap(BitmapMember {
                    image_ref: new_bitmap_ref,
                    reg_point: (bitmap_info.reg_x, bitmap_info.reg_y),
                    script_id,
                    member_script_ref: behavior_script_ref,
                    info: bitmap_info.clone(),
                })
            }
            MemberType::Palette => {
                let palette_chunk = member_def.children.iter()
                    .find_map(|c| c.as_ref().and_then(|ch| ch.as_palette()))
                    .expect("No palette chunk found for palette member");

                CastMemberType::Palette(PaletteMember {
                    colors: palette_chunk.colors.clone(),
                })
            }
            MemberType::Shape => {
                let script_id = chunk
                    .member_info
                    .as_ref()
                    .map(|info| info.header.script_id)
                    .unwrap_or(0);

                let member_script_ref = if script_id > 0 {
                    Some(CastMemberRef {
                        cast_lib: cast_lib as i32,
                        cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
                    })
                } else {
                    None
                };

                debug!("Shape member {} script_id={}", number, script_id);

                CastMemberType::Shape(ShapeMember {
                    shape_info: chunk.specific_data.shape_info().unwrap().clone(),
                    script_id,
                    member_script_ref,
                })
            }
            MemberType::FilmLoop => {
                let score_chunk_opt = member_def.children.get(0)
                    .and_then(|c| c.as_ref())
                    .and_then(|c| c.as_score());
                let film_loop_info = chunk.specific_data.film_loop_info().unwrap();

                if let Some(score_chunk) = score_chunk_opt {
                    let mut score = Score::empty();
                    score.load_from_score_chunk(score_chunk, dir_version);

                    // Compute initial_rect by finding the bounding box of all sprites
                    let initial_rect = Self::compute_filmloop_initial_rect(
                        &score_chunk.frame_data.frame_channel_data,
                        film_loop_info.reg_point,
                    );

                    debug!(
                        "FilmLoop {} initial_rect: ({}, {}, {}, {}), info size: {}x{}, reg_point: ({}, {})",
                        number,
                        initial_rect.left, initial_rect.top, initial_rect.right, initial_rect.bottom,
                        film_loop_info.width, film_loop_info.height,
                        film_loop_info.reg_point.0, film_loop_info.reg_point.1
                    );

                    // Log sprite_spans info
                    debug!(
                        "FilmLoop {} has {} sprite_spans, {} frame_intervals, {} frame_channel_data entries",
                        number,
                        score.sprite_spans.len(),
                        score_chunk.frame_intervals.len(),
                        score_chunk.frame_data.frame_channel_data.len()
                    );

                    let total_frames = {
                        let init_max = score.channel_initialization_data.iter()
                            .map(|(f, _, _)| *f + 1).max().unwrap_or(1);
                        let span_max = score.sprite_spans.iter()
                            .map(|s| s.end_frame).max().unwrap_or(1);
                        let kf_max = score.keyframes_cache.values()
                            .filter_map(|kf| kf.path.as_ref())
                            .flat_map(|p| p.keyframes.iter())
                            .map(|kf| kf.frame).max().unwrap_or(1);
                        init_max.max(span_max).max(kf_max)
                    };
                    CastMemberType::FilmLoop(FilmLoopMember {
                        info: film_loop_info.clone(),
                        score_chunk: score_chunk.clone(),
                        score,
                        current_frame: 1, // Start at frame 1
                        initial_rect,
                        cached_total_frames: Some(total_frames),
                    })
                } else {
                    warn!("FilmLoop {} has no valid score chunk, creating empty film loop", number);
                    let empty_score_chunk = ScoreChunk {
                        header: ScoreChunkHeader {
                            total_length: 0, unk1: 0, unk2: 0,
                            entry_count: 0, unk3: 0, entry_size_sum: 0,
                        },
                        entries: vec![],
                        frame_intervals: vec![],
                        frame_data: ScoreFrameData::default(),
                        sprite_details: std::collections::HashMap::new(),
                    };
                    CastMemberType::FilmLoop(FilmLoopMember {
                        info: film_loop_info.clone(),
                        score_chunk: empty_score_chunk,
                        score: Score::empty(),
                        current_frame: 1,
                        initial_rect: super::geometry::IntRect { left: 0, top: 0, right: 0, bottom: 0 },
                        cached_total_frames: None,
                    })
                }
            }
            MemberType::Movie => {
                // Linked Movie (`#movie`) member. The linked .dir/.dcr path is
                // stored in the member info's file_name; content is fetched at
                // play time (linked, not embedded), so `bytes` stay None until
                // the fileName setter / activation loads them. Playback flags
                // share the FilmLoop specific-data layout (reg_point + a flags
                // byte: center=bit0, crop=1-bit1, sound=bit3, loop=1-bit5);
                // scriptsEnabled is a Movie-only extra flag (bit TBD, mapped via
                // the hex dump below).
                let mut mv = MovieMember::new();
                if let Some(info) = chunk.member_info.as_ref() {
                    mv.file_name = info.file_name.clone();
                }
                // Specific-data layout (big-endian), fully verified by toggling
                // each property in Director MX 2004 and diffing the flags byte:
                //   [0..8]  QuickDraw rect: top, left, bottom, right (u16 each)
                //   [8..11] reserved (0)
                //   [11]    flags byte:
                //             bit0 (0x01) center
                //             bit1 (0x02) crop        (inverted: crop = !bit1)
                //             bit3 (0x08) sound
                //             bit4 (0x10) scriptsEnabled
                //             bit5 (0x20) loop        (inverted: loop = !bit5)
                //           (bit2 0x04 is an always-set flag, ignored)
                //   [12..14] reserved (0)
                // place_holder.dcr: rect(200,150,300,250) -> 100x100, regPoint
                // center (50,50); flags 0x0E -> center=F crop=F sound=T
                // scriptsEnabled=F loop=T (and 0x3E -> scriptsEnabled=T loop=F).
                let sd = chunk.specific_data_raw.as_slice();
                let be16 = |i: usize| -> u16 {
                    if i + 1 < sd.len() { u16::from_be_bytes([sd[i], sd[i + 1]]) } else { 0 }
                };
                let (top, left, bottom, right) = (be16(0), be16(2), be16(4), be16(6));
                let flags = sd.get(11).copied().unwrap_or(0);
                mv.width = right.saturating_sub(left);
                mv.height = bottom.saturating_sub(top);
                mv.reg_point = ((mv.width / 2) as i16, (mv.height / 2) as i16);
                mv.center = (flags & 0x01) != 0;
                mv.crop = (flags & 0x02) == 0;
                mv.sound = (flags & 0x08) != 0;
                mv.scripts_enabled = (flags & 0x10) != 0;
                mv.loops = (flags & 0x20) == 0;
                CastMemberType::Movie(mv)
            }
            MemberType::Sound => {
                // Log children
                if !member_def.children.is_empty() {
                    debug!(
                        "CastMember {} has {} children:",
                        number,
                        member_def.children.len()
                    );

                    for (i, c_opt) in member_def.children.iter().enumerate() {
                        match c_opt {
                            Some(c) => debug!("child[{}] = {}", i, Self::chunk_type_name(c)),
                            None => debug!("child[{}] = None", i),
                        }
                    }
                }

                // Pluck the cue-points child chunk (`cupt`), if present. Director
                // stores these alongside the sound payload on the cast member; the
                // movie's `on cuePassed` handler is driven by the playhead crossing
                // these times.
                let (cue_point_times, cue_point_names) = member_def.children.iter()
                    .filter_map(|c| c.as_ref())
                    .find_map(|c| match c {
                        Chunk::CuePoints(cp) => Some((cp.times_ms.clone(), cp.names.clone())),
                        _ => None,
                    })
                    .unwrap_or_else(|| (Vec::new(), Vec::new()));

                // Try to find a sound chunk - check multiple formats:
                // 1. "snd " chunk (Mac snd resource)
                // 2. "ediM" chunk (MediaChunk)
                // 3. "sndH" + "sndS" chunks (Director 6+ split format)
                let sound_chunk_opt = member_def.children.iter()
                .filter_map(|c_opt| c_opt.as_ref())
                .find_map(|chunk| match chunk {
                    Chunk::Sound(s) => {
                    debug!("Found Sound chunk with {} bytes", s.data().len());
                    Some(s.clone())
                    },
                    Chunk::Media(m) => {
                    debug!("Found Media chunk: sample_rate={}, data_size_field={}, audio_data.len()={}, is_compressed={}",
                        m.sample_rate, m.data_size_field, m.audio_data.len(), m.is_compressed
                    );

                    // Check if the Media chunk has any sound data
                    // Don't just check is_empty - also check data_size_field
                    if !m.audio_data.is_empty() || m.data_size_field > 0 {
                        let sound = SoundChunk::from_media(&m);
                        debug!(
                        "Created SoundChunk from Media: {} bytes, rate={}",
                        sound.data().len(),
                        sound.sample_rate()
                        );
                        Some(sound)
                    } else {
                        debug!("Media chunk has no audio data");
                        None
                    }
                    },
                    _ => None,
                });

                // If no sound found yet, try sndH + sndS combination
                let sound_chunk_opt = if sound_chunk_opt.is_some() {
                    sound_chunk_opt
                } else {
                    // Look for sndH (header) and sndS (samples) children
                    let snd_header = member_def.children.iter()
                        .filter_map(|c| c.as_ref())
                        .find_map(|c| match c {
                            Chunk::SndHeader(h) => Some(h),
                            _ => None,
                        });
                    let snd_samples = member_def.children.iter()
                        .filter_map(|c| c.as_ref())
                        .find_map(|c| match c {
                            Chunk::SndSamples(data) => Some(data),
                            _ => None,
                        });

                    if let (Some(header), Some(samples)) = (snd_header, snd_samples) {
                        debug!(
                            "Found sndH + sndS: rate={}, bits={}, channels={}, numFrames={}, samples_len={}",
                            header.frame_rate, header.bits_per_sample, header.num_channels, header.num_frames, samples.len()
                        );
                        Some(SoundChunk::from_snd_header_and_samples(header, samples))
                    } else if let Some(_header) = snd_header {
                        debug!("Found sndH but no sndS data");
                        None
                    } else {
                        None
                    }
                };

                let found_sound = sound_chunk_opt.is_some();
                debug!(
                    "CastMember {}: {} children, found sound chunk = {}",
                    number,
                    member_def.children.len(),
                    found_sound
                );

                // Construct SoundMember
                if let Some(sound_chunk) = sound_chunk_opt {
                    let info = SoundInfo {
                        sample_rate: sound_chunk.sample_rate(),
                        sample_size: sound_chunk.bits_per_sample(),
                        channels: sound_chunk.channels(),
                        sample_count: sound_chunk.sample_count(),
                        duration: if sound_chunk.sample_rate() > 0 {
                            (sound_chunk.sample_count() as f32 / sound_chunk.sample_rate() as f32
                                * 1000.0)
                                .round() as u32
                        } else {
                            0
                        },
                        loop_enabled: chunk
                            .member_info
                            .as_ref()
                            .map_or(false, |info| (info.header.flags & 0x10) == 0),
                    };

                    debug!(
                        "SoundMember created â†’ name: {}, version: {}, sample_rate: {}, sample_size: {}, channels: {}, sample_count: {}, duration: {:.3}ms",
                        chunk.member_info.as_ref().map(|x| x.name.to_owned()).unwrap_or_default(),
                        sound_chunk.version,
                        info.sample_rate,
                        info.sample_size,
                        info.channels,
                        info.sample_count,
                        info.duration
                    );

                    CastMemberType::Sound(SoundMember {
                        info,
                        sound: sound_chunk,
                        cue_point_times,
                        cue_point_names,
                    })
                } else {
                    warn!("No sound chunk found for member {}", number);
                    CastMemberType::Sound(SoundMember {
                        info: SoundInfo::default(),
                        sound: SoundChunk::default(),
                        cue_point_times,
                        cue_point_names,
                    })
                }
            }
            MemberType::Button => {
                // Button members are parsed identically to Text (FieldInfo + STXT child),
                // with an extra u16 at bytes 28-29 for button type.
                let text_chunk = member_def.children.iter()
                    .find_map(|c| c.as_ref().and_then(|ch| ch.as_text()));
                let raw = chunk.specific_data_raw.as_slice();
                let field_info = FieldInfo::from(raw);
                let mut field_member = FieldMember::from_field_info(&field_info);

                // Button dimensions come from the rect, not text_height
                field_member.width = field_info.width();
                field_member.height = field_info.height();

                // Read button type from bytes 28-29 (u16 BE, value is 1-indexed per ScummVM)
                let button_type_raw = if raw.len() >= 30 {
                    ((raw[28] as u16) << 8) | (raw[29] as u16)
                } else {
                    1 // default to pushButton (1-indexed)
                };
                let button_type = ButtonType::from_raw(button_type_raw.wrapping_sub(1));

                if let Some(text_chunk) = text_chunk {
                    field_member.text = text_chunk.text.clone();

                    let formatting_runs = text_chunk.parse_formatting_runs();
                    if let Some(first_run) = formatting_runs.first() {
                        let fg_r = (first_run.color_r >> 8) as u8;
                        let fg_g = (first_run.color_g >> 8) as u8;
                        let fg_b = (first_run.color_b >> 8) as u8;
                        field_member.fore_color = Some(ColorRef::Rgb(fg_r, fg_g, fg_b));

                        field_member.font_id = Some(first_run.font_id);
                        if let Some(font_name) = font_table.get(&first_run.font_id) {
                            field_member.font = font_name.clone();
                        }
                        if first_run.font_size > 0 {
                            field_member.font_size = first_run.font_size;
                        }
                        if first_run.height > 0 {
                            field_member.fixed_line_space = first_run.height;
                        }
                        if first_run.style != 0 {
                            let mut styles = Vec::new();
                            if (first_run.style & 0x01) != 0 { styles.push(BuiltInSymbol::Bold); }
                            if (first_run.style & 0x02) != 0 { styles.push(BuiltInSymbol::Italic); }
                            if (first_run.style & 0x04) != 0 { styles.push(BuiltInSymbol::Underline); }
                            if styles.is_empty() {
                                field_member.font_style = BuiltInSymbol::Plain.to_string();
                            } else {
                                field_member.font_style = styles.iter().map(|x| x.as_str()).collect_vec().join(" ");
                            }
                        }
                    }
                }

                let script_id = chunk
                    .member_info
                    .as_ref()
                    .map(|info| info.header.script_id)
                    .unwrap_or(0);

                let behavior_script_ref = if script_id > 0 {
                    let _script_chunk = &lctx.as_ref().unwrap().scripts[&script_id];
                    Some(CastMemberRef {
                        cast_lib: cast_lib as i32,
                        cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
                    })
                } else {
                    None
                };

                debug!(
                    "ButtonMember text='{}' button_type={:?} font='{}' font_size={} width={} height={} script_id={}",
                    field_member.text, button_type, field_member.font, field_member.font_size,
                    field_member.width, field_member.height, script_id,
                );

                CastMemberType::Button(ButtonMember {
                    field: field_member,
                    button_type,
                    hilite: false,
                    script_id,
                    member_script_ref: behavior_script_ref,
                })
            }
            MemberType::RTE => {
                // Rich Text Editor cast member (Director type 12). Children:
                // RTE0 = style runs (commonly empty), RTE1 = plain text,
                // RTE2 = a pre-rendered anti-aliased bitmap. Director displays
                // the RTE2 bitmap, so we decode it and surface the member as a
                // Bitmap — that gives the exact authored visual (anti-aliased,
                // correctly colored) AND reuses Bitmap members' existing
                // cast-member-attached script support (header.script_id), so an
                // `on mouseUp` navigation handler fires just like Field/Bitmap
                // buttons. These scripts are not stored as separate Script cast
                // members. Previously RTE fell through to `_` and became
                // CastMemberType::Unknown, so the labels were invisible and the
                // buttons dead (SpongeBob JellyFishin' "next"/"play"/
                // "instructions").

                let script_id = chunk
                    .member_info
                    .as_ref()
                    .map(|info| info.header.script_id)
                    .unwrap_or(0);
                let member_script_ref = if script_id > 0 {
                    Some(CastMemberRef {
                        cast_lib: cast_lib as i32,
                        cast_member: number as i32, // member's own slot; attached script registered at scripts[number]
                    })
                } else {
                    None
                };

                // Foreground color from cast info specific_data. Layout (34
                // bytes): rect(0..8), pageRect(8..16), misc(16..25), then an
                // RGB triple. RTE0 style runs are empty so this is the only
                // color source. Default to white (visible) if absent.
                let raw = chunk.specific_data_raw.as_slice();
                let fg = if raw.len() >= 28 {
                    (raw[25], raw[26], raw[27])
                } else {
                    (255, 255, 255)
                };

                let rte2 = member_def
                    .children
                    .iter()
                    .find_map(|c| c.as_ref().and_then(|ch| ch.as_rte_bitmap()));

                if let Some((w, h, rgba)) = rte2.and_then(|d| decode_rte2_bitmap(d, fg)) {
                    let bitmap = Bitmap {
                        width: w,
                        height: h,
                        bit_depth: 32,
                        original_bit_depth: 32,
                        data: rgba,
                        palette_ref: PaletteRef::Default,
                        matte: None,
                        use_alpha: true,
                        trim_white_space: false,
                        was_trimmed: false,
                        version: 0,
                    };
                    let image_ref = bitmap_manager.add_bitmap(bitmap);
                    let info = crate::director::enums::BitmapInfo {
                        width: w,
                        height: h,
                        // RTE members register top-left like text (reg point 0,0),
                        // not bitmap-center, so the score sprite lands correctly.
                        reg_x: 0,
                        reg_y: 0,
                        bit_depth: 32,
                        use_alpha: true,
                        ..Default::default()
                    };
                    debug!(
                        "RTE member #{} name='{}' -> Bitmap {}x{} fg={:?} script_id={}",
                        number,
                        chunk.member_info.as_ref().map(|x| x.name.as_str()).unwrap_or(""),
                        w, h, fg, script_id,
                    );
                    CastMemberType::Bitmap(BitmapMember {
                        image_ref,
                        reg_point: (0, 0),
                        script_id,
                        member_script_ref,
                        info,
                    })
                } else {
                    // No decodable RTE2 — fall back to a TextMember from RTE1
                    // so text/clicks still work.
                    let rte_text = member_def
                        .children
                        .iter()
                        .find_map(|c| c.as_ref().and_then(|ch| ch.as_rte_text()))
                        .unwrap_or_default()
                        .to_string();
                    let mut text_member = TextMember::new();
                    text_member.text = rte_text;
                    if raw.len() >= 8 {
                        let be = |i: usize| ((raw[i] as u16) << 8) | (raw[i + 1] as u16);
                        let w = be(6).saturating_sub(be(2));
                        let h = be(4).saturating_sub(be(0));
                        if w > 0 { text_member.width = w; }
                        if h > 0 { text_member.height = h; }
                    }
                    text_member.script_id = script_id;
                    text_member.member_script_ref = member_script_ref;
                    debug!(
                        "RTE member #{} name='{}' (no RTE2) -> TextMember text='{}' script_id={}",
                        number,
                        chunk.member_info.as_ref().map(|x| x.name.as_str()).unwrap_or(""),
                        text_member.text, script_id,
                    );
                    CastMemberType::Text(text_member)
                }
            }
            MemberType::Xtra if TransitionInfo::from_member_bytes(&chunk.specific_data_raw).is_some() => {
                // Director stores built-in score/puppet transitions as raw member-type
                // 14 (dirplayer's `Xtra`) with a 6-byte record; detect them by shape so
                // real Xtra members aren't misread. The transition/effect channel
                // references these by number (see Score::get_frame_transition).
                let info = TransitionInfo::from_member_bytes(&chunk.specific_data_raw).unwrap();
                CastMemberType::Transition(TransitionMember { info })
            }
            _ => {
                // Assuming `chunk.member_type` is an enum backed by a numeric ID
                // If it's not Copy, clone or cast as needed.
                let member_type_id = chunk.member_type as u16; // or u32 depending on your enum base type

                debug!(
                    "[CastMember::from] Unknown member type for member #{} (cast_lib={}): {:?} (id={})",
                    number,
                    cast_lib,
                    chunk.member_type, // this prints name, e.g. Button
                    member_type_id      // this prints numeric id, e.g. 15
                );

                if let Some(info) = &chunk.member_info {
                    debug!(
                        " name='{}', script_id={}, flags={:?}",
                        info.name, info.header.script_id, info.header.flags
                    );
                } else {
                    debug!(" No member_info available");
                }

                // Log all child chunks
                if member_def.children.is_empty() {
                    debug!(" No children found.");
                } else {
                    debug!(" {} children:", member_def.children.len());

                    for (i, c_opt) in member_def.children.iter().enumerate() {
                        match c_opt {
                            Some(c) => debug!("    child[{}] = {}", i, Self::chunk_type_name(c)),
                            None => debug!("    child[{}] = None", i),
                        }
                    }
                }

                // Check if this unknown member is Havok by name or file_name
                if Self::is_havok_member_any(&chunk.specific_data_raw, &chunk.member_info) {
                    let hke_data = member_def.children.iter()
                        .filter_map(|c| c.as_ref())
                        .find_map(|c| match c {
                            Chunk::XMedia(xm) => Some(xm.raw_data.clone()),
                            Chunk::Raw(raw) if raw.len() > 4 => Some(raw.clone()),
                            _ => None,
                        })
                        .unwrap_or_else(|| chunk.specific_data_raw.clone());
                    debug!(
                        "Havok Physics member #{} detected in default branch (type={:?}), HKE data={} bytes",
                        number, chunk.member_type, hke_data.len()
                    );
                    CastMemberType::HavokPhysics(HavokPhysicsMember::new(hke_data))
                } else if Self::is_physx_member_any(&chunk.specific_data_raw, &chunk.member_info) {
                    debug!(
                        "PhysX Physics member #{} detected in default branch (type={:?})",
                        number, chunk.member_type
                    );
                    CastMemberType::PhysXPhysics(PhysXPhysicsMember::new())
                } else {
                    CastMemberType::Unknown
                }
            }
        };

        // Post-processing: if the member wasn't detected as Havok / PhysX by type-specific paths,
        // but its name IS exactly "havok"/"physx" (or file_name contains it), override it.
        // Only override non-Script members to avoid catching scripts like "havokManager".
        let member_type = if !matches!(member_type, CastMemberType::HavokPhysics(_) | CastMemberType::PhysXPhysics(_) | CastMemberType::Script(_)) {
            let name_is_havok = chunk.member_info.as_ref()
                .map(|i| i.name.eq_ignore_ascii_case("havok") || i.file_name.to_lowercase().contains("havok"))
                .unwrap_or(false);
            if name_is_havok {
                let hke_data = member_def.children.iter()
                    .filter_map(|c| c.as_ref())
                    .find_map(|c| match c {
                        Chunk::XMedia(xm) => Some(xm.raw_data.clone()),
                        Chunk::Raw(raw) if raw.len() > 4 => Some(raw.clone()),
                        _ => None,
                    })
                    .unwrap_or_else(|| chunk.specific_data_raw.clone());
                debug!(
                    "Havok Physics member #{} detected by name override (was {:?}), HKE={} bytes",
                    number, member_type, hke_data.len()
                );
                CastMemberType::HavokPhysics(HavokPhysicsMember::new(hke_data))
            } else {
                // Same override path for PhysX members.
                let name_is_physx = chunk.member_info.as_ref()
                    .map(|i| i.name.eq_ignore_ascii_case("physx")
                        || i.name.eq_ignore_ascii_case("physics")
                        || i.file_name.to_lowercase().contains("physx")
                        || i.file_name.to_lowercase().contains("dynamiks"))
                    .unwrap_or(false);
                if name_is_physx {
                    debug!(
                        "PhysX Physics member #{} detected by name override (was {:?})",
                        number, member_type
                    );
                    CastMemberType::PhysXPhysics(PhysXPhysicsMember::new())
                } else {
                    member_type
                }
            }
        } else {
            member_type
        };

        let reg_point = match &member_type {
            CastMemberType::Bitmap(bm) => (bm.reg_point.0 as i32, bm.reg_point.1 as i32),
            _ => (0, 0),
        };
        // Director surfaces field/button background color through `member.bgColor`.
        // Without propagating field.back_color up to the outer CastMember, the
        // generic getter at cast_member_ref.rs returns the default
        // PaletteIndex(0) for every field — which is also why Coke Studios'
        // `nav_vego_search_field` rendered without a white fill (the field had
        // bgpal RGB white in its STXT, but the renderer's `effective_bg`
        // fallback chain still ended up at the sprite's PaletteIndex(0) on
        // some paths). Mirror Director by surfacing the parsed back_color here.
        let initial_bg_color = match &member_type {
            CastMemberType::Field(fm) => fm
                .back_color
                .clone()
                .unwrap_or(ColorRef::PaletteIndex(0)),
            _ => ColorRef::PaletteIndex(0),
        };
        CastMember {
            number,
            name: chunk
                .member_info
                .as_ref()
                .map(|x| x.name.to_owned())
                .unwrap_or_default(),
            comments: chunk.member_info.as_ref().map(|x| x.comments.to_owned()).unwrap_or_default(),
            member_type: member_type,
            color: ColorRef::PaletteIndex(255),
            bg_color: initial_bg_color,
            reg_point,
        }
    }
}
