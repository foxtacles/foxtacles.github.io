use binary_reader::BinaryReader;

use crate::io::list_readers::{read_pascal_string, read_string};
use crate::io::encoding::decode_text_auto_macroman;

use super::list::BasicListChunk;

#[allow(dead_code)]
pub struct CastMemberInfoChunkHeader {
    data_offset: usize,
    unk1: u32,
    unk2: u32,
    pub flags: u32,
    pub script_id: u32,
}

pub struct CastMemberInfoChunk {
    pub header: CastMemberInfoChunkHeader,
    pub script_src_text: String,
    pub name: String,
    /// Linked file directory (castInfo strings index 2) - for OLE/Xtra linked media
    pub directory: String,
    /// Linked file name (castInfo strings index 3) - for OLE/Xtra linked media
    pub file_name: String,
    pub comments: String,
}

impl CastMemberInfoChunk {
    pub fn read(
        reader: &mut BinaryReader,
        dir_version: u16,
        platform: u16,
    ) -> Result<CastMemberInfoChunk, String> {
        let header = Self::read_header(reader, dir_version).unwrap();
        let offset_table =
            BasicListChunk::read_offset_table(reader, dir_version, header.data_offset).unwrap();
        let item_bufs =
            BasicListChunk::read_items(reader, dir_version, header.data_offset, &offset_table)
                .unwrap();

        let script_src_text = read_string(&item_bufs, 0);
        let name = read_metadata_name(&item_bufs, 1, reader.endian, platform);
        let directory = read_metadata_name(&item_bufs, 2, reader.endian, platform);
        let file_name = read_metadata_name(&item_bufs, 3, reader.endian, platform);
        let comments = read_string(&item_bufs, 20);

        return Ok(CastMemberInfoChunk {
            header,
            script_src_text,
            name,
            directory,
            file_name,
            comments,
        });
    }

    #[allow(unused_variables)]
    fn read_header(
        reader: &mut BinaryReader,
        dir_version: u16,
    ) -> Result<CastMemberInfoChunkHeader, String> {
        return Ok(CastMemberInfoChunkHeader {
            data_offset: reader.read_u32().unwrap() as usize,
            unk1: reader.read_u32().unwrap(),
            unk2: reader.read_u32().unwrap(),
            flags: reader.read_u32().unwrap(),
            script_id: reader.read_u32().unwrap(),
        });
    }
}

/// Member identifiers and linked paths use the authoring platform's encoding.
/// D7 Macintosh movies carry e.g. gr<9A>n3 in both CASt and Lscr. Decoding only
/// the literal as Mac Roman made it impossible to find that cast member.
fn read_metadata_name(items: &Vec<Vec<u8>>, index: usize, endian: binary_reader::Endian, platform: u16) -> String {
    if platform != 1 {
        return read_pascal_string(items, index, endian);
    }
    let Some(item) = items.get(index) else { return String::new(); };
    let Some(&length) = item.first() else { return String::new(); };
    let end = (length as usize + 1).min(item.len());
    decode_text_auto_macroman(&item[1..end])
}

#[cfg(test)]
mod macintosh_member_name_tests {
    use super::read_metadata_name;
    use binary_reader::Endian;

    #[test]
    fn authored_platform_preserves_literal_to_member_name_identity() {
        // Original DAG13 CASt-213 and Lscr-582 both spell gr<9A>n3.
        let mac = vec![vec![5, b'g', b'r', 0x9A, b'n', b'3']];
        let windows = vec![vec![5, b'g', b'r', 0xF6, b'n', b'3']];
        assert_eq!(read_metadata_name(&mac, 0, Endian::Big, 1), "grön3");
        assert_eq!(read_metadata_name(&windows, 0, Endian::Big, 2), "grön3");
        assert_eq!(read_metadata_name(&mac, 0, Endian::Big, 2), "gršn3");
    }

    #[test]
    fn modern_utf8_and_empty_metadata_remain_readable() {
        let utf8 = vec![vec![6, b'g', b'r', 0xC3, 0xB6, b'n', b'3']];
        for platform in [1, 2] {
            assert_eq!(read_metadata_name(&utf8, 0, Endian::Big, platform), "grön3");
            assert_eq!(read_metadata_name(&vec![vec![]], 0, Endian::Big, platform), "");
            assert_eq!(read_metadata_name(&vec![], 0, Endian::Big, platform), "");
        }
    }
}
