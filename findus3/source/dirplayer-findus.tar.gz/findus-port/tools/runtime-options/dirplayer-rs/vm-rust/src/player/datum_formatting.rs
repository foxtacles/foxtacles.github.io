use crate::{
    director::lingo::datum::Datum,
    player::{allocator::ScriptInstanceAllocatorTrait, sprite::ColorRef, bitmap::bitmap::PaletteRef},
};

use super::{DatumRef, DirPlayer};

pub fn format_concrete_datum(datum: &Datum, player: &DirPlayer) -> String {
    return format_concrete_datum_with_depth(datum, player, 0, usize::MAX);
}

pub fn format_concrete_datum_with_depth(datum: &Datum, player: &DirPlayer, depth: usize, max_depth: usize) -> String {
    match datum {
        Datum::String(s) => format!("\"{s}\""),
        Datum::Int(i) => i.to_string(),
        Datum::Float(f) => format_float_with_precision(*f, player),
        Datum::List(_, items, _) => {
            let formatted_items: Vec<String> =
                items.iter().map(|x| format_datum_with_depth(x, player, depth + 1, max_depth)).collect();
            format!("[{}]", formatted_items.join(", "))
        }
        Datum::VarRef(_) => "VarRef".to_string(),
        Datum::Void => "Void".to_string(),
        Datum::Symbol(s) => format!("#{s}"),
        Datum::CastLib(n) => format!("castLib({n})"),
        Datum::Stage => "the stage".to_string(),
        Datum::PropList(entries, ..) => {
            if entries.is_empty() {
                return "[:]".to_string();
            }
            let formatted_entries: Vec<String> = entries
                .iter()
                .map(|(k, v)| format!("{}: {}", format_datum_with_depth(k, player, depth + 1, max_depth), format_datum_with_depth(v, player, depth + 1, max_depth)))
                .collect();
            format!("[{}]", formatted_entries.join(", "))
        }
        Datum::StringChunk(..) => format!(
            "\"{}\"",
            datum.string_value().unwrap_or("!!!ERR!!!".to_string())
        ),
        Datum::ScriptRef(member_ref) => {
            let script = player
                .movie
                .cast_manager
                .get_script_by_ref(&member_ref)
                .unwrap();
            format!("(script {})", script.name)
        }
        Datum::ScriptInstanceRef(instance_ref) => {
            let instance = player.allocator.get_script_instance(instance_ref);
            if let Some(script) = player
                .movie
                .cast_manager
                .get_script_by_ref(&instance.script)
            {
                format!("<offspring {} {} _>", script.name, instance_ref)
            } else {
                format!("<offspring {} {} _>", "(stale)", instance_ref)
            }
        }
        Datum::CastMember(member_ref) => {
            format!(
                "(member {} of castLib {})",
                member_ref.cast_member, member_ref.cast_lib
            )
        }
        Datum::SpriteRef(sprite_ref) => {
            format!("(sprite {})", sprite_ref)
        }
        Datum::Rect(vals, flags) => {
            let x1 = Datum::inline_component_to_datum(vals[0], Datum::inline_is_float(*flags, 0));
            let y1 = Datum::inline_component_to_datum(vals[1], Datum::inline_is_float(*flags, 1));
            let x2 = Datum::inline_component_to_datum(vals[2], Datum::inline_is_float(*flags, 2));
            let y2 = Datum::inline_component_to_datum(vals[3], Datum::inline_is_float(*flags, 3));
            format!(
                "rect({}, {}, {}, {})",
                format_numeric_value(&x1, player),
                format_numeric_value(&y1, player),
                format_numeric_value(&x2, player),
                format_numeric_value(&y2, player)
            )
        }
        Datum::Point(vals, flags) => {
            let x = Datum::inline_component_to_datum(vals[0], Datum::inline_is_float(*flags, 0));
            let y = Datum::inline_component_to_datum(vals[1], Datum::inline_is_float(*flags, 1));
            format!(
                "point({}, {})",
                format_numeric_value(&x, player),
                format_numeric_value(&y, player)
            )
        }
        Datum::SoundChannel(_) => {
            format!("<soundChannel>")
        }
        Datum::CursorRef(_) => {
            format!("<cursor>")
        }
        Datum::TimeoutRef(name) => {
            format!("timeout(\"{name}\")")
        }
        Datum::TimeoutFactory => {
            format!("<timeoutFactory>")
        }
        Datum::TimeoutInstance(ti) => {
            format!("timeoutInstance(\"{0}\")", ti.name)
        }
        Datum::ColorRef(color_ref) => match color_ref {
            ColorRef::PaletteIndex(i) => {
                format!("color({})", i)
            }
            ColorRef::Rgb(r, g, b) => {
                format!("rgb({}, {}, {})", r, g, b)
            }
        },
        Datum::BitmapRef(bitmap) => {
            let bitmap = player.bitmap_manager.get_bitmap(*bitmap).unwrap();
            format!(
                "<bitmap {}x{}x{}>",
                bitmap.width, bitmap.height, bitmap.bit_depth
            )
        }
        Datum::PaletteRef(palette_ref) => match palette_ref {
            PaletteRef::BuiltIn(builtin) => {
                format!("{:?}", builtin).to_lowercase()
            }
            PaletteRef::Member(member_ref) => {
                format!(
                    "(member {} of castLib {})",
                    member_ref.cast_member,
                    member_ref.cast_lib
                )
            }
            PaletteRef::Default => "#default".to_string(),
        },
        Datum::Xtra(name) => {
            format!("<Xtra \"{}\" _ _______>", name)
        }
        Datum::XtraInstance(name, instance_id) => {
            // "<Xtra child \"Multiuser\" _ _______>";
            format!("<Xtra child \"{}\" #{}>", name, instance_id)
        }
        Datum::Matte(..) => {
            format!("<mask:0000000>")
        }
        Datum::Null => {
            format!("<Null>")
        }
        Datum::PlayerRef => {
            format!("<_player>")
        }
        Datum::MovieRef => {
            format!("<_movie>")
        }
        Datum::MouseRef => {
            format!("<_mouse>")
        }
        Datum::XmlRef(id) => {
            format!("<xml:{}>", id)
        }
        Datum::JsObjectRef(_) => {
            // Matches what Director's JS syntax prints for a plain object.
            format!("[object Object]")
        }
        Datum::MathRef(_) => {
            format!("<math>")
        }
        Datum::Vector(v) => {
            format!(
                "vector({}, {}, {})", 
                format_float_with_precision(v[0], player),
                format_float_with_precision(v[1], player),
                format_float_with_precision(v[2], player),
            )
        }
        Datum::SoundRef(_) => {
            format!("<_sound>")
        }
        Datum::DateRef(id) => {
            // Director 11.5 Scripting Dictionary, `date() (System)`: "_system.date()
            // returns the current date in the system clock", and its own example
            // indexes the result as text (`_system.date().char[1..4] = "1/1/"`), so a
            // date must render as a DATE STRING, not a type placeholder. AreaZero's
            // startup log printed "Movie started at @ 18:02:17<date>." because we
            // emitted the placeholder into the concatenation.
            //
            // The dictionary notes the format follows the machine's date settings, so
            // defer to the host locale rather than hardcoding a layout.
            // Measured in Director: `put _system.date()` -> "03.08.2026" — no
            // leading space. The space that separates time from date in a
            // concatenation belongs to _system.time() (Windows short-time keeps an
            // empty AM/PM slot in 24-hour locales); see TypeHandlers::time.
            player.date_objects.get(id)
                .map(|d| js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(d.timestamp_ms as f64))
                    .to_locale_date_string("default", &date_opts())
                    .as_string()
                    .unwrap_or_default())
                .unwrap_or_else(|| "<date>".to_string())
        }
        Datum::Media(_) => {
            format!("<media>")
        }
        Datum::JavaScript(data) => {
            format!("<javascript {} bytes>", data.len())
        }
        Datum::FlashObjectRef(fr) => {
            format!("<Flash object: {}>", fr.path)
        }
        Datum::Shockwave3dObjectRef(sr) => {
            format!("{}(\"{}\")", sr.object_type, sr.name)
        }
        Datum::Transform3d(m) => {
            format!("transform({:.2},{:.2},{:.2},{:.2}, {:.2},{:.2},{:.2},{:.2}, {:.2},{:.2},{:.2},{:.2}, {:.2},{:.2},{:.2},{:.2})",
                m[0],m[1],m[2],m[3], m[4],m[5],m[6],m[7], m[8],m[9],m[10],m[11], m[12],m[13],m[14],m[15])
        }
        Datum::HavokObjectRef(hr) => {
            format!("{}(\"{}\")", hr.object_type, hr.name)
        }
        Datum::PhysXObjectRef(pr) => {
            format!("{}(\"{}\")", pr.object_type, pr.name)
        }
        Datum::VectorVertexRef(member_ref, index) => {
            format!("vertex[{}] of member({}, {})", index + 1, member_ref.cast_member, member_ref.cast_lib)
        }
    }
}

pub fn datum_to_string_for_concat(datum: &Datum, player: &DirPlayer) -> String {
    match datum {
        Datum::String(s) => s.clone(),
        
        Datum::Symbol(s) => s.as_str().to_string(),
        
        // Void/Null become empty string in concatenation
        Datum::Void | Datum::Null => String::new(),
        
        Datum::ColorRef(cr) => match cr {
            ColorRef::PaletteIndex(i) => format!("color({})", i),
            ColorRef::Rgb(r, g, b) => format!("rgb({}, {}, {})", r, g, b),
        },
        
        // Lists/proplists: defer to format_concrete_datum so inner strings stay
        // quoted ([#name: "London I"], not [#name:London I]). Matches Director's
        // behavior and is required for round-trips through value() — without the
        // quotes, value() can't re-parse strings that contain spaces.
        Datum::List(..) | Datum::PropList(..) => format_concrete_datum(datum, player),
        
        Datum::StringChunk(..) => {
            datum.string_value().unwrap_or(String::new())
        },
        
        // For other complex types, use the standard formatter
        _ => format_concrete_datum(datum, player),
    }
}

pub fn format_datum(datum_ref: &DatumRef, player: &DirPlayer) -> String {
    let datum = player.get_datum(datum_ref);
    format_concrete_datum_with_depth(datum, player, 0, usize::MAX)
}

pub fn format_datum_with_depth(datum_ref: &DatumRef, player: &DirPlayer, depth: usize, max_depth: usize) -> String {
    if depth >= max_depth {
        return format!("<{}>", datum_ref);
    }
    let datum = player.get_datum(datum_ref);
    format_concrete_datum_with_depth(datum, player, depth, max_depth)
}

// Helper function to format a numeric value according to floatPrecision
pub fn format_float_with_precision(val: f64, player: &DirPlayer) -> String {
    // Normalize negative zero to positive zero
    let val = if val == 0.0 { 0.0 } else { val };

    let fp = player.float_precision as i32;
    
    // Calculate how many characters the decimal notation would take
    let integer_digits = if val.abs() < 1.0 {
        1 // Just "0"
    } else {
        (val.abs().log10().floor() as i32 + 1).max(1)
    };
    
    let decimal_places = if fp > 0 { fp } else { 0 };
    let total_chars = integer_digits + 1 + decimal_places; // digits + '.' + decimals
    
    // Director switches to scientific notation when formatted string >= 18 chars
    if total_chars >= 18 {
        return format!("{:.14e}", val);
    }
    
    // Normal formatting based on floatPrecision
    if fp > 0 {
        let p = fp.min(15) as usize;
        format!("{:.*}", p, val)
    } else if fp == 0 {
        format!("{}", val.round() as i32)
    } else {
        let p = (-fp).min(15);
        let pow = 10f64.powi(p);
        let rounded = (val * pow).round() / pow;
        let s = format!("{:.*}", p as usize, rounded);
        s.trim_end_matches('0')
            .trim_end_matches('.')
            .to_string()
    }
}

pub fn format_numeric_value(datum: &Datum, player: &DirPlayer) -> String {
    match datum {
        Datum::Int(i) => i.to_string(),
        Datum::Float(f) => format_float_with_precision(*f, player),
        _ => format_concrete_datum(datum, player),
    }
}

/// Options for Director's system SHORT date: zero-padded day and month with a
/// full year. Measured against Director on this machine: `03.08.2026`, where a
/// bare toLocaleDateString gave `3.8.2026`. The locale still chooses the field
/// ORDER and separator — only the padding is pinned, matching the dictionary's
/// note that the date format "varies, depending on how the date is formatted on
/// the computer".
fn date_opts() -> js_sys::Object {
    let o = js_sys::Object::new();
    let _ = js_sys::Reflect::set(&o, &"day".into(), &"2-digit".into());
    let _ = js_sys::Reflect::set(&o, &"month".into(), &"2-digit".into());
    let _ = js_sys::Reflect::set(&o, &"year".into(), &"numeric".into());
    o
}
