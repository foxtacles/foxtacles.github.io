use crate::{
    director::lingo::datum::Datum,
    player::{DatumRef, DirPlayer, ScriptError, reserve_player_mut, symbols::{builtin::BuiltInSymbol, symbol::Symbol}},
};
use chrono::{Datelike, TimeZone, Timelike};

pub struct DateObject {
    pub id: u32,
    pub timestamp_ms: i64, // milliseconds since epoch
}

impl DateObject {
    pub fn new(id: u32) -> Self {
        // Current time in milliseconds
        let now_ms = chrono::Utc::now().timestamp_millis();
        DateObject {
            id,
            timestamp_ms: now_ms,
        }
    }

    pub fn from_timestamp(id: u32, timestamp_ms: i64) -> Self {
        DateObject { id, timestamp_ms }
    }

    /// Host-controlled reference date without rewriting the original calendar
    /// bytecode. Empty/absent uses local wall-clock time; explicit invalid dates
    /// are errors rather than silently changing the user's requested policy.
    pub fn for_calendar(id: u32, override_date: Option<&str>) -> Result<Self, ScriptError> {
        let Some(value) = override_date.filter(|s| !s.is_empty()) else {
            return Ok(Self::new(id));
        };
        let date = chrono::NaiveDate::parse_from_str(value, "%Y-%m-%d")
            .map_err(|_| ScriptError::new(format!("Invalid findusDate: {value}; expected YYYY-MM-DD")))?;
        if date.format("%Y-%m-%d").to_string() != value {
            return Err(ScriptError::new(format!("Invalid findusDate: {value}; expected YYYY-MM-DD")));
        }
        // Noon keeps the requested local calendar day away from DST changes.
        let local = chrono::Local.from_local_datetime(&date.and_hms_opt(12, 0, 0).unwrap())
            .single().ok_or_else(|| ScriptError::new(format!("Invalid local calendar date: {value}")))?;
        Ok(Self::from_timestamp(id, local.timestamp_millis()))
    }

    fn local_time(&self) -> Result<chrono::DateTime<chrono::Local>, ScriptError> {
        chrono::DateTime::from_timestamp_millis(self.timestamp_ms)
            .map(|date| date.with_timezone(&chrono::Local))
            .ok_or_else(|| ScriptError::new("Date is outside the supported range".to_string()))
    }
}

pub struct DateDatumHandlers;

#[cfg(all(test, not(target_arch = "wasm32")))]
mod findus_calendar_tests {
    use super::*;

    #[test]
    fn original_calendar_reads_local_one_based_month_and_day() {
        let _harness = crate::player::testing::TestPlayer::new();
        for (date, month, day) in [
            ("2026-08-31", 8, 31), ("2026-09-01", 9, 1),
            ("2026-11-30", 11, 30), ("2026-12-01", 12, 1),
            ("2026-12-16", 12, 16), ("2026-12-24", 12, 24),
            ("2026-12-25", 12, 25), ("2027-01-01", 1, 1),
            ("2028-02-29", 2, 29),
        ] {
            reserve_player_mut(|player| {
                player.external_params.insert("findusDate".to_string(), date.to_string());
                let system_date = player.get_movie_prop(Symbol::builtin(BuiltInSymbol::SystemDate)).unwrap();
                let m = DateDatumHandlers::get_prop(player, &system_date, Symbol::builtin(BuiltInSymbol::Month)).unwrap();
                let d = DateDatumHandlers::get_prop(player, &system_date, Symbol::builtin(BuiltInSymbol::Day)).unwrap();
                assert_eq!(player.get_datum(&m).int_value().unwrap(), month, "{date}");
                assert_eq!(player.get_datum(&d).int_value().unwrap(), day, "{date}");
            });
        }
    }

    #[test]
    fn absent_override_uses_now_and_invalid_dates_fail() {
        let before = chrono::Utc::now().timestamp_millis();
        let date = DateObject::for_calendar(1, None).unwrap();
        let after = chrono::Utc::now().timestamp_millis();
        assert!((before..=after).contains(&date.timestamp_ms));
        for value in ["2026-02-29", "2026-12-32", "2026-9-1", "tomorrow"] {
            assert!(DateObject::for_calendar(1, Some(value)).is_err(), "{value}");
        }
    }
}

impl DateDatumHandlers {
    pub fn call(
        datum: &DatumRef,
        handler_name: Symbol,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let date_id = player.get_datum(datum).to_date_ref()?;
            let date_obj = player
                .date_objects
                .get(&date_id)
                .ok_or_else(|| ScriptError::new(format!("Date object {} not found", date_id)))?;

            let js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                date_obj.timestamp_ms as f64,
            ));

            match handler_name.into_builtin() {
                Some(BuiltInSymbol::GetTime) => {
                    // Return as Float — current epoch ms (~1.7e12) overflows i32.
                    // f64 holds integer ms exactly up to 2^53, well past the year 285,000.
                    Ok(player.alloc_datum(Datum::Float(date_obj.timestamp_ms as f64)))
                }
                Some(BuiltInSymbol::SetTime) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setTime requires a time argument".to_string(),
                        ));
                    }
                    // Accept Float (from getTime + offset arithmetic) or Int.
                    let time = player.get_datum(&args[0]).float_value()? as i64;
                    let date_obj = player.date_objects.get_mut(&date_id).ok_or_else(|| {
                        ScriptError::new(format!("Date object {} not found", date_id))
                    })?;
                    date_obj.timestamp_ms = time;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::GetFullYear) => {
                    let year = js_date.get_full_year() as i32;
                    Ok(player.alloc_datum(Datum::Int(year)))
                }
                Some(BuiltInSymbol::GetYear) => {
                    // Legacy AS/JS Date.getYear() returns year - 1900.
                    let year = js_date.get_full_year() as i32 - 1900;
                    Ok(player.alloc_datum(Datum::Int(year)))
                }
                Some(BuiltInSymbol::GetMonth) => {
                    let month = js_date.get_month() as i32;
                    Ok(player.alloc_datum(Datum::Int(month)))
                }
                Some(BuiltInSymbol::GetDate) => {
                    let date = js_date.get_date() as i32;
                    Ok(player.alloc_datum(Datum::Int(date)))
                }
                Some(BuiltInSymbol::GetHours) => {
                    let hours = js_date.get_hours() as i32;
                    Ok(player.alloc_datum(Datum::Int(hours)))
                }
                Some(BuiltInSymbol::GetMinutes) => {
                    let minutes = js_date.get_minutes() as i32;
                    Ok(player.alloc_datum(Datum::Int(minutes)))
                }
                Some(BuiltInSymbol::GetSeconds) => {
                    let seconds = js_date.get_seconds() as i32;
                    Ok(player.alloc_datum(Datum::Int(seconds)))
                }
                Some(BuiltInSymbol::SetFullYear) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setFullYear requires a year argument".to_string(),
                        ));
                    }
                    let year = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_full_year(year as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::SetYear) => {
                    // Legacy AS/JS Date.setYear(): arg is offset from 1900.
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setYear requires a year argument".to_string(),
                        ));
                    }
                    let year_offset = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_full_year((year_offset + 1900) as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::SetMonth) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setMonth requires a month argument".to_string(),
                        ));
                    }
                    let month = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_month(month as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::SetDate) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setDate requires a date argument".to_string(),
                        ));
                    }
                    let date = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_date(date as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::SetHours) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setHours requires an hours argument".to_string(),
                        ));
                    }
                    let hours = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_hours(hours as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::SetMinutes) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setMinutes requires a minutes argument".to_string(),
                        ));
                    }
                    let minutes = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_minutes(minutes as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                Some(BuiltInSymbol::SetSeconds) => {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "setSeconds requires a seconds argument".to_string(),
                        ));
                    }
                    let seconds = player.get_datum(&args[0]).int_value()?;
                    let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
                        date_obj.timestamp_ms as f64,
                    ));
                    js_date.set_seconds(seconds as u32);

                    let date_obj = player.date_objects.get_mut(&date_id).unwrap();
                    date_obj.timestamp_ms = js_date.get_time() as i64;
                    Ok(DatumRef::Void)
                }
                _ => Err(ScriptError::new(format!(
                    "No handler {} for date",
                    handler_name
                ))),
            }
        })
    }

    pub fn get_prop(
        player: &mut DirPlayer,
        datum: &DatumRef,
        prop: Symbol,
    ) -> Result<DatumRef, ScriptError> {
        if prop == BuiltInSymbol::Ilk {
            return Ok(player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Date))));
        }

        let date_id = player.get_datum(datum).to_date_ref()?;
        let date_obj = player
            .date_objects
            .get(&date_id)
            .ok_or_else(|| ScriptError::new(format!("Date object {} not found", date_id)))?;
        let date = date_obj.local_time()?;

        // Lingo Date object properties — `#year`, `#month`, `#day`. We also
        // expose the common time-of-day properties so the JavaScript-style
        // members (`hour`, `minute`, `seconds`) work alongside the existing
        // method accessors (`getHours`, …).
        match prop.into_builtin() {
            Some(BuiltInSymbol::Day) => Ok(player.alloc_datum(Datum::Int(date.day() as i32))),
            Some(BuiltInSymbol::Month) => Ok(player.alloc_datum(Datum::Int(date.month() as i32))),
            Some(BuiltInSymbol::Year) => Ok(player.alloc_datum(Datum::Int(date.year()))),
            Some(BuiltInSymbol::Hour | BuiltInSymbol::Hours) => Ok(player.alloc_datum(Datum::Int(date.hour() as i32))),
            Some(BuiltInSymbol::Minute | BuiltInSymbol::Minutes) => Ok(player.alloc_datum(Datum::Int(date.minute() as i32))),
            Some(BuiltInSymbol::Second | BuiltInSymbol::Seconds) => Ok(player.alloc_datum(Datum::Int(date.second() as i32))),
            Some(BuiltInSymbol::MilliSeconds) => Ok(player.alloc_datum(Datum::Int(date.timestamp_subsec_millis() as i32))),
            Some(BuiltInSymbol::WeekDay) => {
                // Lingo's `the weekday of date()` is 1=Sunday … 7=Saturday.
                Ok(player.alloc_datum(Datum::Int(date.weekday().number_from_sunday() as i32)))
            },
            Some(BuiltInSymbol::Time) => Ok(player.alloc_datum(Datum::Float(date_obj.timestamp_ms as f64))),
            _ => Err(ScriptError::new(format!(
                "Cannot get date property {}",
                prop
            ))),
        }
    }

    pub fn set_prop(
        player: &mut DirPlayer,
        datum: &DatumRef,
        prop: Symbol,
        value: &DatumRef,
    ) -> Result<(), ScriptError> {
        let date_id = player.get_datum(datum).to_date_ref()?;
        let date_obj = player
            .date_objects
            .get(&date_id)
            .ok_or_else(|| ScriptError::new(format!("Date object {} not found", date_id)))?;
        let mut js_date = js_sys::Date::new(&wasm_bindgen::JsValue::from_f64(
            date_obj.timestamp_ms as f64,
        ));
        let value_datum = player.get_datum(value);

        match prop.into_builtin() {
            Some(BuiltInSymbol::Day) => { js_date.set_date(value_datum.int_value()? as u32); }
            // Lingo months are 1-based; JS months are 0-based.
            Some(BuiltInSymbol::Month) => { js_date.set_month((value_datum.int_value()? - 1).max(0) as u32); }
            Some(BuiltInSymbol::Year) => { js_date.set_full_year(value_datum.int_value()? as u32); }
            Some(BuiltInSymbol::Hour | BuiltInSymbol::Hours) => { js_date.set_hours(value_datum.int_value()? as u32); }
            Some(BuiltInSymbol::Minute | BuiltInSymbol::Minutes) => { js_date.set_minutes(value_datum.int_value()? as u32); }
            Some(BuiltInSymbol::Second | BuiltInSymbol::Seconds) => { js_date.set_seconds(value_datum.int_value()? as u32); }
            Some(BuiltInSymbol::MilliSeconds) => { js_date.set_milliseconds(value_datum.int_value()? as u32); }
            Some(BuiltInSymbol::Time) => {
                let new_ms = value_datum.float_value()? as i64;
                let obj = player.date_objects.get_mut(&date_id).unwrap();
                obj.timestamp_ms = new_ms;
                return Ok(());
            }
            _ => return Err(ScriptError::new(format!(
                "Cannot set date property {}",
                prop
            ))),
        };

        let obj = player.date_objects.get_mut(&date_id).unwrap();
        obj.timestamp_ms = js_date.get_time() as i64;
        Ok(())
    }
}
