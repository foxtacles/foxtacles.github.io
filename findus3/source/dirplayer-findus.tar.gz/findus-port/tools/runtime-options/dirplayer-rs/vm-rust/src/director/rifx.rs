pub struct RIFXReaderContext {
    pub after_burned: bool,
    pub ils_body_offset: usize,
    pub dir_version: u16,
    /// Authoring platform from DRCF: 1 Macintosh, 2 Windows.
    pub platform: u16,
    pub lctx_capital_x: bool,
}
