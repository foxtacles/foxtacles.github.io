use std::collections::VecDeque;

use log::debug;

use super::cast_member::{
    bitmap::BitmapMemberHandlers, button::ButtonMemberHandlers, field::FieldMemberHandlers,
    film_loop::FilmLoopMemberHandlers, font::FontMemberHandlers,
    havok::HavokPhysicsMemberHandlers,
    physx::PhysXPhysicsMemberHandlers,
    shockwave3d::Shockwave3dMemberHandlers,
    sound::SoundMemberHandlers, text::TextMemberHandlers, palette::PaletteMemberHandlers,
    vector_shape::VectorShapeMemberHandlers,
};

use crate::{
    director::{
        enums::{ScriptType, ShapeType},
        lingo::datum::{Datum, DatumType, datum_bool},
    },
    js_api::JsApi,
    player::{
        DatumRef, DirPlayer, ScriptError, bitmap::bitmap::{Bitmap, resolve_color_ref}, cast_lib::CastMemberRef, cast_member::{BitmapMember, CastMember, CastMemberType, CastMemberTypeId, TextMember}, handlers::types::TypeUtils, reserve_player_mut, reserve_player_ref, sprite::ColorRef, symbols::{builtin::BuiltInSymbol, symbol::Symbol}
    },
};

pub struct CastMemberRefHandlers {}

fn is_3d_member(datum: &DatumRef) -> Result<bool, ScriptError> {
    reserve_player_mut(|player| {
        let r = match player.get_datum(datum) {
            Datum::CastMember(r) => r.to_owned(),
            _ => return Ok(false),
        };
        Ok(player.movie.cast_manager.find_member_by_ref(&r)
            .map_or(false, |m| m.member_type.as_shockwave3d().is_some()))
    })
}

fn is_havok_member(datum: &DatumRef) -> Result<bool, ScriptError> {
    reserve_player_mut(|player| {
        let r = match player.get_datum(datum) {
            Datum::CastMember(r) => r.to_owned(),
            _ => return Ok(false),
        };
        Ok(player.movie.cast_manager.find_member_by_ref(&r)
            .map_or(false, |m| matches!(m.member_type, CastMemberType::HavokPhysics(_))))
    })
}

fn is_physx_member(datum: &DatumRef) -> Result<bool, ScriptError> {
    reserve_player_mut(|player| {
        let r = match player.get_datum(datum) {
            Datum::CastMember(r) => r.to_owned(),
            _ => return Ok(false),
        };
        Ok(player.movie.cast_manager.find_member_by_ref(&r)
            .map_or(false, |m| matches!(m.member_type, CastMemberType::PhysXPhysics(_))))
    })
}

pub fn borrow_member_mut<T1, F1, T2, F2>(member_ref: &CastMemberRef, player_f: F2, f: F1) -> T1
where
    F1: FnOnce(&mut CastMember, T2) -> T1,
    F2: FnOnce(&mut DirPlayer) -> T2,
{
    reserve_player_mut(|player| {
        let arg = player_f(player);
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(&member_ref)
            .expect("cast member ref should be valid in borrow_member_mut");
        f(member, arg)
    })
}

fn get_text_member_line_height(text_data: &TextMember) -> u16 {
    return text_data.font_size + 3; // TODO: Implement text line height
}

impl CastMemberRefHandlers {
    /// Encode `(cast_lib, member)` as Director's single-integer member number —
    /// "a unique identifier for the cast member that is a single integer
    /// describing its location in and position in the cast library"
    /// (Director 11.5 Scripting Dictionary, `number (Member)`).
    ///
    /// The cast index is encoded ZERO-based, so members of the first cast
    /// library encode to their bare position. That is what Director reports for
    /// a single-cast movie, and it is what keeps `member(x).number` comparable
    /// with `the memberNum of sprite N` — `memberNum` is the member's "position
    /// in its cast library" (spec) and so is always bare. Movies compare the two
    /// directly: snowcraft gates its whole snowball pool on
    ///
    ///   if the memberNum of sprite n = the number of member "nothing" then
    ///
    /// With a one-based encoding the internal cast contributed 0x10000, so 67
    /// was compared against 65603, the pool never reported a free slot, and
    /// throwing a snowball did nothing — the thrower stuck on "R cock" forever.
    ///
    /// Multi-cast movies still get distinct values (cast 2 -> 0x10000 + n).
    pub fn get_cast_slot_number(cast_lib: u32, cast_member: u32) -> u32 {
        cast_lib.saturating_sub(1) << 16 | (cast_member & 0xFFFF)
    }

    pub fn member_ref_from_slot_number(slot_number: u32) -> CastMemberRef {
        let cast_lib = (slot_number >> 16) as i32 + 1;
        let cast_member = (slot_number & 0xFFFF) as i32;
        // Zero-based cast encoding makes a bare member number (high 16 bits
        // zero — `the castNum of sprite = 10` in a Director-4 movie, or
        // `member N` with no cast lib) decode to cast 1 by construction, which
        // is the default/internal cast those forms mean. slot 0 stays the null
        // ref [0, 0].
        if slot_number == 0 {
            return CastMemberRef { cast_lib: 0, cast_member: 0 };
        }
        CastMemberRef { cast_lib, cast_member }
    }

    /// Check if a cast member handler needs async dispatch.
    /// Havok `step` runs physics with per-substep Lingo callbacks; bitmap
    /// `importFileInto` needs to await the network fetch.
    pub fn has_async_handler(datum: &DatumRef, handler_name: Symbol) -> bool {
        if handler_name == BuiltInSymbol::ImportFileInto {
            return true;
        }
        // 3D `member.loadFile(w3dFile …)` fetches the W3D over the net.
        if handler_name == BuiltInSymbol::LoadFile {
            return true;
        }
        if handler_name != BuiltInSymbol::Step { return false; }
        // Check if this is a Havok member
        reserve_player_ref(|player| {
            let r = match player.get_datum(datum) {
                Datum::CastMember(r) => r.to_owned(),
                _ => return false,
            };
            player.movie.cast_manager.find_member_by_ref(&r)
                .map_or(false, |m| matches!(m.member_type, CastMemberType::HavokPhysics(_)))
        })
    }

    /// Async handler for Havok step — runs physics with per-substep callback invocation.
    /// From the original engine (x86 sub_100175C0):
    ///   for each substep:
    ///     1. Integrate forces → velocity (Euler)
    ///     2. Apply actions (springs, dashpots, drag)
    ///     3. Step collision (Rapier)
    ///     4. Read back positions
    ///     5. Invoke step callbacks ← this is where Lingo handlers run
    ///   After all substeps:
    ///     6. Invoke collision interest callbacks
    ///     7. Sync to W3D models, clear forces
    pub fn call_async<'a>(
        datum: &'a DatumRef,
        _handler_name: Symbol,
        args: &'a Vec<DatumRef>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<DatumRef, ScriptError>> + 'a>> {
        Box::pin(async move {
            if _handler_name == BuiltInSymbol::ImportFileInto {
                // Method form `member.importFileInto(url, props)` forwards
                // to the global verb in BuiltInHandlerManager which holds
                // the canonical implementation — prepend `self` so its
                // args[0] = member, matching the old-Lingo verb form.
                let mut forwarded = Vec::with_capacity(args.len() + 1);
                forwarded.push(datum.clone());
                forwarded.extend(args.iter().cloned());
                return crate::player::handlers::manager::BuiltInHandlerManager::call_async_handler(
                    BuiltInSymbol::ImportFileInto.into(), &forwarded,
                ).await;
            }
            if _handler_name.eq_ignore_ascii_case("loadFile") {
                let member_ref = reserve_player_ref(|player| match player.get_datum(datum) {
                    Datum::CastMember(r) => Some(r.to_owned()),
                    _ => None,
                });
                let member_ref = match member_ref {
                    Some(r) => r,
                    None => return Err(ScriptError::new(
                        "loadFile: receiver must be a cast member".to_string(),
                    )),
                };
                return crate::player::handlers::datum_handlers::cast_member::shockwave3d::
                    Shockwave3dMemberHandlers::load_file(&member_ref, args).await;
            }
            // Run the full physics step via the monolithic sync path.
            // This does: Euler integrate (full_dt) + Rapier substeps + readback + W3D sync + clear forces.
            let (step_result, step_cbs, collision_cbs) = HavokPhysicsMemberHandlers::step_with_callbacks(datum, args)?;

            // After the step, invoke step callbacks (async, post-step). A step
            // callback may apply per-sub-step forces (age-of-speed applies gravity
            // this way); mark that context so applyForce routes to the full-strength
            // `step_force` accumulator rather than the force_scale-attenuated one.
            // The gravity callback runs synchronously (a plain applyForce loop), so
            // the flag can't leak across an await.
            //
            // NB the Xtra actually fires these per SUB-STEP (Havok Xtra Lingo
            // Reference: "called at each sub step"), so post-step invocation leaves
            // the applied force one frame stale. Moving it BEFORE the step was
            // tried: it did NOT fix Age of Speed's loop and it REGRESSED
            // SuperSonic (supersonic.rs:231). Don't repeat it without also
            // reworking how `step_force` is accumulated.
            use super::cast_member::havok_physics::IN_STEP_CALLBACK;
            for (cb_handler, cb_instance, dt_value) in &step_cbs {
                let dt_ref = reserve_player_mut(|player| {
                    player.alloc_datum(Datum::Float(*dt_value))
                });
                IN_STEP_CALLBACK.with(|c| c.set(true));
                let _ = super::player_call_datum_handler(cb_instance, *cb_handler, &vec![dt_ref]).await;
                IN_STEP_CALLBACK.with(|c| c.set(false));
            }

            // Invoke collision interest callbacks (async, post-step).
            for (cb_handler, cb_instance, collision_info_ref) in &collision_cbs {
                let _ = super::player_call_datum_handler(cb_instance, *cb_handler, &vec![collision_info_ref.clone()]).await;
            }

            Ok(step_result)
        })
    }

    pub fn call(
        datum: &DatumRef,
        handler_name: Symbol,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let handler_name_str = handler_name.as_str();
        match handler_name.into_builtin() {
            // `member(x).char[a..b] = v` compiles to an object call
            // setProp(member, #char, a, b, v). Director writes just that range
            // of the member's text and leaves the rest; without this the call
            // errored and the member kept whatever the author had typed.
            Some(BuiltInSymbol::SetProp) => {
                crate::player::handlers::manager::BuiltInHandlerManager::set_member_chunk(datum, args)
            }
            Some(BuiltInSymbol::Duplicate) => Self::duplicate(datum, args),
            Some(BuiltInSymbol::Erase) => Self::erase(datum, args),
            Some(BuiltInSymbol::Move) => Self::move_member(datum, args),
            Some(BuiltInSymbol::GetPixel) | Some(BuiltInSymbol::SetPixel) => {
                // Director lets image methods be called directly on a bitmap MEMBER
                // (`member.getPixel(x,y)`), proxying to the member's image object.
                // unicraft's terrainPreview samples a heightmap this way.
                use crate::player::handlers::datum_handlers::bitmap::BitmapDatumHandlers;
                let image_datum = reserve_player_mut(|player| {
                    let member_ref = match player.get_datum(datum) {
                        Datum::CastMember(r) => r.to_owned(),
                        _ => return Err(ScriptError::new(format!("{}: not a cast member", handler_name))),
                    };
                    let member = player.movie.cast_manager.find_member_by_ref(&member_ref)
                        .ok_or_else(|| ScriptError::new(format!("{}: member not found", handler_name)))?;
                    match &member.member_type {
                        CastMemberType::Bitmap(b) => Ok(player.alloc_datum(Datum::BitmapRef(b.image_ref))),
                        other => Err(ScriptError::new(format!(
                            "{}: member type {:?} has no image", handler_name, other.member_type_id()))),
                    }
                })?;
                if handler_name == BuiltInSymbol::GetPixel {
                    BitmapDatumHandlers::get_pixel(&image_datum, args)
                } else {
                    BitmapDatumHandlers::set_pixel(&image_datum, args)
                }
            }
            Some(BuiltInSymbol::CharPosToLoc) => {
                let member_arg = datum.clone();
                let mut delegated_args: Vec<DatumRef> = Vec::with_capacity(args.len() + 1);
                delegated_args.push(member_arg);
                delegated_args.extend(args.iter().cloned());
                crate::player::handlers::manager::BuiltInHandlerManager::call_handler(
                    Symbol::from_str("charpostoloc"),
                    &delegated_args,
                )
            }
            Some(BuiltInSymbol::GetProp) => {
                // Chunk-typed property + range args (e.g.
                // `member.char[y..y+8]`, `member.line[3..5]`) compiles to
                // `getProp(member, #char, y, y+8)`. Route those to the
                // chunk-aware getPropRef path so the slice is taken as a
                // StringChunk (with vm_range_to_host clamping) instead of
                // being passed through a list getter that indexes a single
                // element and ignores the end arg. Without this branch,
                // Narrative_Buttons#upCount reads `member(nar).char[y..y+8]`
                // and OOBs when locToCharPos returns a position past
                // text.length.
                let prop_name = reserve_player_mut(|player| {
                    Ok::<String, ScriptError>(player.get_datum(&args[0]).string_value().unwrap_or_default())
                })?;
                let is_chunk_typed = matches!(
                    prop_name.to_ascii_lowercase().as_str(),
                    "char" | "chars" | "word" | "words" | "line" | "lines" | "item" | "items"
                );
                if is_chunk_typed && args.len() >= 2 {
                    // Delegate to the member-type getPropRef which builds a
                    // StringChunk via field.rs / text.rs.
                    return Self::call_member_type(datum, "getPropRef", args);
                }

                let result_ref = reserve_player_mut(|player| {
                    let cast_member_ref = match player.get_datum(datum) {
                        Datum::CastMember(cast_member_ref) => cast_member_ref.to_owned(),
                        _ => {
                            return Err(ScriptError::new(
                                "Cannot call getProp on non-cast-member".to_string(),
                            ))
                        }
                    };
                    let prop = player.get_datum(&args[0]).symbol_value()?;
                    let result = Self::get_prop(player, &cast_member_ref, prop)?;
                    Ok(player.alloc_datum(result))
                })?;
                if args.len() > 1 {
                    reserve_player_mut(|player| {
                        TypeUtils::get_sub_prop(&result_ref, &args[1], player)
                    })
                } else {
                    Ok(result_ref)
                }
            }
            Some(BuiltInSymbol::GetPropRef) => {
                if is_havok_member(datum)? {
                    HavokPhysicsMemberHandlers::call(datum, handler_name_str, args)
                } else if is_physx_member(datum)? {
                    PhysXPhysicsMemberHandlers::call(datum, handler_name, args)
                } else if is_3d_member(datum)? {
                    Shockwave3dMemberHandlers::call(datum, handler_name, args)
                } else {
                    Self::call_member_type(datum, handler_name_str, args)
                        .or_else(|_| reserve_player_mut(|player| Ok(player.alloc_datum(Datum::Void))))
                }
            }
            Some(BuiltInSymbol::Count) => {
                if is_havok_member(datum)? {
                    HavokPhysicsMemberHandlers::call(datum, handler_name_str, args)
                } else if is_physx_member(datum)? {
                    PhysXPhysicsMemberHandlers::call(datum, handler_name, args)
                } else if is_3d_member(datum)? {
                    Shockwave3dMemberHandlers::call(datum, handler_name, args)
                } else {
                    reserve_player_mut(|player| {
                        let cast_member_ref = match player.get_datum(datum) {
                            Datum::CastMember(cast_member_ref) => cast_member_ref.to_owned(),
                            _ => {
                                return Err(ScriptError::new(
                                    "Cannot call count on non-cast-member".to_string(),
                                ))
                            }
                        };
                        if args.is_empty() {
                            return Err(ScriptError::new("count requires 1 argument".to_string()));
                        }
                        // Try to get the member's text
                        // First try "text" property, then fallback to "previewText" for Font members
                        let text = match Self::get_prop(player, &cast_member_ref, Symbol::builtin(BuiltInSymbol::Text)) {
                            Ok(datum) => datum.string_value()?,
                            Err(_) => {
                                // Try previewText for Font members
                                match Self::get_prop(player, &cast_member_ref, Symbol::builtin(BuiltInSymbol::PreviewText)) {
                                    Ok(datum) => datum.string_value()?,
                                    Err(_) => {
                                        return Err(ScriptError::new(format!(
                                            "Member type does not support count operation"),
                                        ));
                                    }
                                }
                            }
                        };

                        let count_of = player.get_datum(&args[0]).symbol_value()?;

                        let delimiter = player.movie.item_delimiter;
                        let chunk_type = std::panic::catch_unwind(|| crate::director::lingo::datum::StringChunkType::from(count_of))
                            .map_err(|_| ScriptError::new(format!("Invalid string chunk type: {}", count_of.as_str())))?;
                        let count = crate::player::handlers::datum_handlers::string_chunk::StringChunkUtils::resolve_chunk_count(
                            &text,
                            chunk_type,
                            delimiter,
                        )?;
                        Ok(player.alloc_datum(Datum::Int(count as i32)))
                    })
                }
            }
            // Shockwave 3D member handlers — delegated to Shockwave3dMemberHandlers::call()
            Some(
                BuiltInSymbol::Model | BuiltInSymbol::ModelResource | BuiltInSymbol::Shader | BuiltInSymbol::Texture
                | BuiltInSymbol::Light | BuiltInSymbol::Camera | BuiltInSymbol::Group | BuiltInSymbol::Motion
                | BuiltInSymbol::ResetWorld | BuiltInSymbol::RevertToWorldDefaults
                | BuiltInSymbol::NewTexture | BuiltInSymbol::NewShader | BuiltInSymbol::NewModel | BuiltInSymbol::NewModelResource
                | BuiltInSymbol::NewLight | BuiltInSymbol::NewCamera | BuiltInSymbol::NewGroup | BuiltInSymbol::NewMotion | BuiltInSymbol::NewMesh
                | BuiltInSymbol::DeleteTexture | BuiltInSymbol::DeleteShader | BuiltInSymbol::DeleteModel | BuiltInSymbol::DeleteModelResource
                | BuiltInSymbol::DeleteLight | BuiltInSymbol::DeleteCamera | BuiltInSymbol::DeleteGroup | BuiltInSymbol::DeleteMotion
                | BuiltInSymbol::CloneModelFromCastmember | BuiltInSymbol::CloneMotionFromCastmember | BuiltInSymbol::CloneDeep
                | BuiltInSymbol::LoadFile | BuiltInSymbol::Extrude3d | BuiltInSymbol::GetPref | BuiltInSymbol::SetPref
                | BuiltInSymbol::RegisterForEvent | BuiltInSymbol::RegisterScript | BuiltInSymbol::UnregisterAllEvents
                | BuiltInSymbol::Image
                | BuiltInSymbol::ModelsUnderRay | BuiltInSymbol::ModelsUnderLoc | BuiltInSymbol::ModelUnderLoc,
            ) => {
                Shockwave3dMemberHandlers::call(datum, handler_name, args)
            }
            // Havok + PhysX (AGEIA) Physics member handlers — overlapping
            // handler names are routed by member type below. Director Lingo
            // is fully case-insensitive on handler names, so we use
            // `match_ci!` to recognize every casing the script may use
            // (`EnableCollisionCallback`, `enablecollisioncallback`, etc.).
            _ if match_ci!(handler_name_str, {
                // Havok handlers
                "initialize" | "shutdown" | "step" | "reset"
                    | "rigidBody" | "spring"
                    | "linearDashpot" | "angularDashpot"
                    | "makeMovableRigidBody" | "makeFixedRigidBody"
                    | "makeSpring" | "makeLinearDashpot" | "makeAngularDashpot"
                    | "deleteRigidBody" | "deleteSpring"
                    | "deleteLinearDashpot" | "deleteAngularDashpot"
                    | "registerInterest" | "removeInterest"
                    | "registerStepCallback" | "removeStepCallback"
                    | "enableCollision" | "disableCollision"
                    | "enableAllCollisions" | "disableAllCollisions"
                // PhysX additions (Director chapter 15)
                    | "init" | "destroy" | "pauseSimulation" | "resumeSimulation"
                    | "simulate" | "getSimulationTime"
                    | "createRigidBody" | "createRigidBodyFromProxy"
                    | "getRigidBody" | "getRigidBodies" | "getSleepingBodies"
                    | "createProxyTemplate" | "addProxyTemplate" | "loadProxyTemplate"
                    | "createSpring" | "createLinearJoint" | "createAngularJoint" | "createD6Joint"
                    | "deleteConstraint" | "deleteRigidBodyConstraints"
                    | "getSpring" | "getConstraint" | "getAllSprings" | "getAllConstraints"
                    | "createCloth" | "deleteCloth" | "getCloth" | "getCloths" | "createClothResource"
                    | "createController" | "deleteController" | "getController" | "getControllers"
                    | "createTerrain" | "createTerrainDesc" | "deleteTerrain" | "getTerrain" | "getTerrains"
                    | "enableCollisionCallback" | "disableCollisionCallback"
                    | "enableCollisionGroupFlag" | "getCollisionDisabledPairs"
                    | "getCollisionCallbackDisabledPairs"
                    | "notifyCollisions" | "registerForCollisions" | "removeCallback"
                    | "registerCollisionCallback" | "removeCollisionCallback"
                    | "getRayCastClosestShape" | "getRayCastAllShapes"
                    | "rayCastClosest" | "rayCastAll"
                    | "getBoundingBox" | "getBoundingSphere"
                    => true,
                _ => false,
            }) => {
                if is_havok_member(datum)? {
                    HavokPhysicsMemberHandlers::call(datum, handler_name_str, args)
                } else if is_physx_member(datum)? {
                    PhysXPhysicsMemberHandlers::call(datum, handler_name, args)
                } else {
                    Self::call_member_type(datum, handler_name_str, args)
                }
            }
            // Mixer Xtra (chapter 15:8702) — minimum-viable stub. The full
            // Mixer API has its own audio engine (createSoundObject, sound
            // playback, filter chains, callbacks) which is out of scope; we
            // stub the init-time surface so movies that reset the mixer
            // state on startup don't crash. Music won't actually play.
            _ if match_ci!(handler_name_str, {
                "getSoundObjectList" | "getSoundObject" | "createSoundObject"
                    | "deleteSoundObject" | "deleteAllSoundObjects" => true,
                _ => false,
            }) => {
                reserve_player_mut(|player| {
                    if handler_name_str.eq_ignore_ascii_case("getSoundObjectList") {
                        // Empty list — no sound objects exist.
                        Ok(player.alloc_datum(Datum::List(
                            DatumType::List, std::collections::VecDeque::new(), false,
                        )))
                    } else {
                        // getSoundObject / createSoundObject / deleteSoundObject /
                        // deleteAllSoundObjects all return void in the stub.
                        // Real Director returns the SoundObject ref for create
                        // / get; scripts that subsequently mutate that ref will
                        // hit their own VOID errors which is the correct
                        // signal that audio is unimplemented.
                        Ok(DatumRef::Void)
                    }
                })
            }
            _ => Self::call_member_type(datum, handler_name_str, args),
        }
    }

    fn call_member_type(
        datum: &DatumRef,
        handler_name: &str,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let member_ref = match player.get_datum(datum) {
                Datum::CastMember(cast_member_ref) => cast_member_ref.to_owned(),
                _ => {
                    return Err(ScriptError::new(
                        "Cannot call_member_type on non-cast-member".to_string(),
                    ))
                }
            };
            let cast_member = match player
                .movie
                .cast_manager
                .find_member_by_ref(&member_ref)
            {
                Some(m) => m,
                None => {
                    // preload/unload on non-existent members are no-ops in Director.
                    // Compare case-INSENSITIVELY: Lingo handler names are not
                    // case-sensitive, and movies write the camelCase spellings
                    // (`member(x).unLoad()`). The lowercase-only compare here let
                    // `unLoad`/`preLoad` fall through to the error below —
                    // "Cannot call unLoad on non-existent member (-1, -1)" when a
                    // movie unloads an empty member ref (Habbo v31 catalogue).
                    // The no-op `matches!` further down already lists both
                    // spellings; this guard was the odd one out.
                    if handler_name.eq_ignore_ascii_case("preload")
                        || handler_name.eq_ignore_ascii_case("unload")
                    {
                        return Ok(DatumRef::Void);
                    }
                    return Err(ScriptError::new(format!(
                        "Cannot call {} on non-existent member ({}, {})",
                        handler_name, member_ref.cast_lib, member_ref.cast_member
                    )));
                }
            };
            // preload/unload/stop/play/pause/rewind are no-ops for all member types in a web player.
            // preLoadBuffer is a SWA (Shockwave Audio) member method that preloads the audio
            // buffer; we decode on demand so it's a no-op too.
            if matches!(
                handler_name,
                "preload" | "preLoad"
                    | "preloadBuffer" | "preLoadBuffer"
                    | "unload" | "unLoad"
                    | "stop" | "play" | "pause" | "rewind"
            ) {
                return Ok(DatumRef::Void);
            }
            match &cast_member.member_type {
                CastMemberType::Field(_) => {
                    FieldMemberHandlers::call(player, datum, handler_name, args)
                }
                CastMemberType::Text(_) => {
                    TextMemberHandlers::call(player, datum, handler_name, args)
                }
                CastMemberType::Button(_) => {
                    ButtonMemberHandlers::call(player, datum, Symbol::from_str(handler_name), args)
                }
                CastMemberType::HavokPhysics(_) => {
                    HavokPhysicsMemberHandlers::call(datum, handler_name, args)
                }
                // Defensive route for the physics + 3D member types: the
                // outer dispatcher in `call()` lists known handler names
                // explicitly and forwards them to the right per-member
                // dispatcher, but it's easy to miss a name (e.g.
                // unregisterAllEvents until recently). Catching them here
                // lets the per-member handler decide whether to implement
                // or log+stub, instead of throwing a generic "No handler"
                // that hides the real member type.
                CastMemberType::Shockwave3d(_) => {
                    Shockwave3dMemberHandlers::call(datum, Symbol::from_str(handler_name), args)
                }
                CastMemberType::PhysXPhysics(_) => {
                    PhysXPhysicsMemberHandlers::call(datum, Symbol::from_str(handler_name), args)
                }
                CastMemberType::VectorShape(_) => {
                    VectorShapeMemberHandlers::call(player, datum, handler_name, args)
                }
                _ => Err(ScriptError::new(format!(
                    "No handler {} for member type {:?}",
                    handler_name, cast_member.member_type.member_type_id()
                ))),
            }
        })
    }

    fn erase(datum: &DatumRef, _: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let cast_member_ref = match player.get_datum(datum) {
                Datum::CastMember(cast_member_ref) => cast_member_ref.to_owned(),
                _ => return Err(ScriptError::new("Cannot erase non-cast-member".to_string())),
            };
            // Silently ignore invalid cast lib or non-existent members, matching Director behavior
            let _ = player
                .movie
                .cast_manager
                .remove_member_with_ref(&cast_member_ref);
            Ok(DatumRef::Void)
        })
    }

    /// `member.move({intPosn, castLibName})` — Director 11.5 Scripting
    /// Dictionary, Member method:
    ///
    /// > moves a specified cast member to either the first empty location in
    /// > its containing cast, or to a specified location in a given cast.
    ///
    /// Both parameters are optional and no return value is documented, so this
    /// answers VOID. The dictionary's own example passes a MEMBER REFERENCE
    /// rather than the documented `intPosn, castLibName` pair —
    /// `member("shrine").move(member(20, "Bitmaps"))` — and that is the form
    /// real movies use (Agent Free Ride's Miniclip wrapper does
    /// `move(hsController, member(1, 2))`), so all four shapes are accepted:
    ///
    ///   move()                      first free slot in the member's own cast
    ///   move(member(N, lib))        that exact slot
    ///   move(intPosn)               that slot in the member's own cast
    ///   move(intPosn, castLibName)  that slot in the named cast
    ///
    /// Note the dictionary's caveat that this is an AUTHORING operation ("the
    /// move is typically saved with the file") — at runtime a member's slot
    /// rarely matters, and Director itself points scripts at `sprite.member`
    /// for display changes. It still has to work, because a wrapper script that
    /// calls it dies at that line otherwise.
    fn move_member(datum: &DatumRef, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let src_ref = match player.get_datum(datum) {
                Datum::CastMember(r) => r.to_owned(),
                _ => return Err(ScriptError::new("Cannot move non-cast-member".to_string())),
            };

            let dest_arg = args.get(0).map(|x| player.get_datum(x).clone());
            let lib_arg = args.get(1).map(|x| player.get_datum(x).clone());

            let dest_ref = match &dest_arg {
                // move(member(N, lib)) — an explicit destination member ref.
                Some(Datum::CastMember(r)) => r.clone(),
                // move(intPosn {, castLibName}).
                Some(d) => {
                    let posn = d.int_value().map_err(|_| {
                        ScriptError::new(
                            "move: expected a member ref or a position number".to_string(),
                        )
                    })?;
                    let cast_lib = match &lib_arg {
                        Some(lib) => {
                            let name = lib.string_value()?;
                            match player.movie.cast_manager.get_cast_by_name(&name) {
                                Some(c) => c.number as i32,
                                // Director does not raise for an unknown cast
                                // name here; there is simply nowhere to move to.
                                None => return Ok(DatumRef::Void),
                            }
                        }
                        None => src_ref.cast_lib,
                    };
                    CastMemberRef { cast_lib, cast_member: posn }
                }
                // move() — first empty location in the member's own cast.
                None => {
                    let cast = player.movie.cast_manager.get_cast_mut(src_ref.cast_lib as u32);
                    let free = cast.first_free_member_id();
                    if free == 0 {
                        // Cast is full; nothing to do.
                        return Ok(DatumRef::Void);
                    }
                    CastMemberRef { cast_lib: src_ref.cast_lib, cast_member: free as i32 }
                }
            };

            // Moving onto itself is a no-op, not a delete-then-reinsert.
            if dest_ref == src_ref {
                return Ok(DatumRef::Void);
            }

            let member = match player.movie.cast_manager.find_member_by_ref(&src_ref) {
                Some(m) => m.clone(),
                // Director silently ignores a move of a member that isn't there.
                None => return Ok(DatumRef::Void),
            };

            // Remove first, then insert: the two refs can name the same cast,
            // and removing afterwards would delete what we just wrote when the
            // destination happens to be the source slot in another guise.
            let _ = player.movie.cast_manager.remove_member_with_ref(&src_ref);

            let mut moved = member;
            moved.number = dest_ref.cast_member as u32;
            let dest_cast = player
                .movie
                .cast_manager
                .get_cast_mut(dest_ref.cast_lib as u32);
            dest_cast.insert_member(dest_ref.cast_member as u32, moved);
            player.movie.cast_manager.invalidate_member_name_cache();
            player
                .movie
                .cast_manager
                .queue_texture_invalidation(dest_ref.clone());

            Ok(DatumRef::Void)
        })
    }

    fn duplicate(datum: &DatumRef, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let cast_member_ref = match player.get_datum(datum) {
                Datum::CastMember(cast_member_ref) => cast_member_ref.to_owned(),
                _ => {
                    return Err(ScriptError::new(
                        "Cannot duplicate non-cast-member".to_string(),
                    ))
                }
            };
            let dest_arg = args.get(0).map(|x| player.get_datum(x).clone());
            let dest_ref = match &dest_arg {
                Some(Datum::CastMember(r)) => r.clone(),
                Some(d) => {
                    let slot = d.int_value().map_err(|_| ScriptError::new(
                        "Cannot duplicate: expected member ref or slot number".to_string(),
                    ))?;
                    Self::member_ref_from_slot_number(slot as u32)
                }
                None => {
                    return Err(ScriptError::new(
                        "Cannot duplicate cast member without destination".to_string(),
                    ));
                }
            };

            let mut new_member = {
                let src_member = player
                    .movie
                    .cast_manager
                    .find_member_by_ref(&cast_member_ref);
                match src_member {
                    Some(m) => m.clone(),
                    None => {
                        return Err(ScriptError::new(format!(
                            "Cannot duplicate cast member: source member not found (castLib {}, member {})",
                            cast_member_ref.cast_lib, cast_member_ref.cast_member
                        )));
                    }
                }
            };
            new_member.number = dest_ref.cast_member as u32;

            // Deep-copy the backing bitmap so the duplicate is independent.
            // `BitmapMember.image_ref` is only a SLOT ID into bitmap_manager, so
            // a plain member clone leaves the duplicate ALIASING the source's
            // pixels. Director's `member.duplicate()` clones the image — without
            // this, `member("3dBallTemplate").duplicate(N)` made every generated
            // ball share one bitmap, and create3DBallOne's copyPixels writes all
            // landed in that single slot (last color wins → every ball rendered
            // yellow, the last colour generated).
            if let CastMemberType::Bitmap(bm) = &new_member.member_type {
                let cloned = player.bitmap_manager.get_bitmap(bm.image_ref).cloned();
                if let Some(cloned) = cloned {
                    let new_ref = player.bitmap_manager.add_bitmap(cloned);
                    if let CastMemberType::Bitmap(bm) = &mut new_member.member_type {
                        bm.image_ref = new_ref;
                    }
                }
            }

            let dest_cast = player
                .movie
                .cast_manager
                .get_cast_mut(dest_ref.cast_lib as u32);
            dest_cast.insert_member(dest_ref.cast_member as u32, new_member);
            player.movie.cast_manager.invalidate_member_name_cache();
            player
                .movie
                .cast_manager
                .queue_texture_invalidation(dest_ref.clone());

            Ok(player.alloc_datum(Datum::CastMember(dest_ref)))
        })
    }

    fn get_invalid_member_prop(
        player: &mut DirPlayer,
        member_ref: &CastMemberRef,
        prop: Symbol,
    ) -> Result<Datum, ScriptError> {
        match prop.into_builtin() {
            Some(BuiltInSymbol::Name) => Ok(Datum::String("".to_string())),
            // Director: `.number` returns 0 for the empty/NULL member ref
            // (i.e. `sprite(N).member.number` when sprite N has no member),
            // and the negative slot for `member(-1)`-style invalid refs.
            // Scripts use `sprite(chan).member.number = 0` as the
            // empty-channel exit test in tile-composition loops; returning
            // -1 unconditionally made that test never fire and dragged the
            // loop through unrelated UI sprites further down the score
            // (verified in Trick or Treat Beat's `buildTileAnims`).
            Some(BuiltInSymbol::Number) => Ok(Datum::Int(
                if member_ref.cast_lib == 0 && member_ref.cast_member == 0 {
                    0
                } else {
                    member_ref.cast_member.min(-1)
                },
            )),
                        // A valid member's `.type` returns a Symbol (see get_prop's "type"
            // arm), so the invalid/empty member must too — Director's `#empty`.
            // Returning a String made `member("x").type = #empty` FALSE (String
            // vs Symbol), so the common lazy-create idiom
            //   `if member(name).type = #empty then member = new(#bitmap) ...`
            // took the else branch and used the invalid (-1,-1) ref instead of
            // creating the member (g349 cave-door `drawframes`).
            Some(BuiltInSymbol::Type) => Ok(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Empty))),
            Some(BuiltInSymbol::CastLibNum) => Ok(Datum::Int(-1)),
            Some(BuiltInSymbol::MemberNum) => Ok(Datum::Int(-1)),
            Some(BuiltInSymbol::Text | BuiltInSymbol::Comments) => Ok(Datum::String("".to_string())),
            Some(BuiltInSymbol::Loaded | BuiltInSymbol::MediaReady) => Ok(Datum::Int(1)),
            Some(BuiltInSymbol::Width | BuiltInSymbol::Height | BuiltInSymbol::Rect | BuiltInSymbol::Duration) => Ok(Datum::Void),
            Some(BuiltInSymbol::Image) => Ok(Datum::Void),
            Some(BuiltInSymbol::RegPoint) => Ok(Datum::Point([0.0, 0.0], 0)),
            _ => Err(ScriptError::new(format!(
                "Cannot get prop {} of invalid cast member ({}, {})",
                prop, member_ref.cast_lib, member_ref.cast_member
            ))),
        }
    }

    fn get_member_type_prop(
        player: &mut DirPlayer,
        cast_member_ref: &CastMemberRef,
        member_type: &CastMemberTypeId,
        prop: Symbol,
    ) -> Result<Datum, ScriptError> {
        let prop_str = prop.as_str();
        debug!("Getting prop '{}' for member type {:?}", prop_str, member_type);
        if prop == BuiltInSymbol::RegPoint {
            // Text members with centerRegPoint use the CURRENT (measured) size for
            // the reg point, not the stored TextInfo.reg_x/reg_y which are authored
            // defaults that don't track wrapped-text expansion.
            if *member_type == CastMemberTypeId::Text {
                use crate::player::font::{measure_text, measure_text_wrapped};
                let member = player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                    .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;
                if let CastMemberType::Text(tm) = &member.member_type {
                    let is_center = tm.info.as_ref().map_or(false, |i| i.center_reg_point);
                    if is_center {
                        let authored_w = if tm.width > 0 {
                            tm.width
                        } else if let Some(ref info) = tm.info {
                            info.width as u16
                        } else { 0 };
                        // Measure current height (same logic as member.height getter).
                        let tm = tm.clone();
                        let cache_key = crate::player::font::FontManager::cache_key(&tm.font);
                        let font = player.font_manager.font_cache.get(&cache_key).cloned()
                            .or_else(|| player.font_manager.get_system_font());
                        let measured_h = font.as_ref().map(|f| {
                            if tm.word_wrap && authored_w > 0 {
                                measure_text_wrapped(
                                    &tm.text, f, authored_w, true,
                                    tm.fixed_line_space, tm.top_spacing, tm.bottom_spacing,
                                    tm.char_spacing,
                                ).1
                            } else {
                                measure_text(
                                    &tm.text, f, None,
                                    tm.fixed_line_space, tm.top_spacing, tm.bottom_spacing,
                                ).1
                            }
                        }).unwrap_or(tm.height);
                        let w = if authored_w > 0 { authored_w } else { tm.width };
                        let h = if measured_h > 0 { measured_h } else { tm.height };
                        return Ok(Datum::Point([(w as i32 / 2) as f64, (h as i32 / 2) as f64], 0));
                    }
                }
            }
            let member = player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;
            let rp = member.reg_point;
            return Ok(Datum::Point([rp.0 as f64, rp.1 as f64], 0));
        }
        // `the scriptText of member` is valid on ANY member type (it's the
        // member's Lingo source, empty if none). Handle it commonly so it
        // doesn't fall through to a type handler that rejects it (e.g. sound,
        // which is how freeT's checkForWin read `the scriptText of cast(9)`).
        if prop == "scriptText" {
            return Ok(Datum::String(
                player.script_text_overrides.get(cast_member_ref).cloned().unwrap_or_default(),
            ));
        }
        match &member_type {
            CastMemberTypeId::Bitmap => {
                BitmapMemberHandlers::get_prop(player, cast_member_ref, prop)
            }
            CastMemberTypeId::Field => FieldMemberHandlers::get_prop(player, cast_member_ref, prop_str),
            CastMemberTypeId::Text => {
                TextMemberHandlers::get_prop(player, cast_member_ref, prop_str)
                    .or_else(|_| {
                        // Forward to 3D handler if text member has embedded 3D world
                        if player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                            .and_then(|m| m.member_type.as_shockwave3d()).is_some()
                        {
                            Shockwave3dMemberHandlers::get_prop(player, cast_member_ref, prop)
                        } else {
                            Err(ScriptError::new(format!(
                                "Cannot get castMember property {} for text", prop_str
                            )))
                        }
                    })
            },
            CastMemberTypeId::Button => ButtonMemberHandlers::get_prop(player, cast_member_ref, prop),
            CastMemberTypeId::FilmLoop => {
                FilmLoopMemberHandlers::get_prop(player, cast_member_ref, prop_str)
            }
            CastMemberTypeId::Sound => SoundMemberHandlers::get_prop(player, cast_member_ref, prop),
            CastMemberTypeId::Font => FontMemberHandlers::get_prop(player, cast_member_ref, prop),
            CastMemberTypeId::Palette => PaletteMemberHandlers::get_prop(player, cast_member_ref, prop),
            CastMemberTypeId::Shockwave3d => Shockwave3dMemberHandlers::get_prop(player, cast_member_ref, prop),
            CastMemberTypeId::HavokPhysics => HavokPhysicsMemberHandlers::get_prop(player, cast_member_ref, prop_str),
            CastMemberTypeId::PhysXPhysics => PhysXPhysicsMemberHandlers::get_prop(player, cast_member_ref, prop),
            CastMemberTypeId::Script => {
                let cast_member = player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                    .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;
                let script_data = match &cast_member.member_type {
                    CastMemberType::Script(s) => s,
                    _ => return Err(ScriptError::new("Cast member is not a script".to_string())),
                };
                match prop.into_builtin() {
                    Some(BuiltInSymbol::Text) => Ok(Datum::String("".to_string())),
                    Some(BuiltInSymbol::Script) => Ok(Datum::ScriptRef(cast_member_ref.clone())),
                    Some(BuiltInSymbol::ScriptText) => Ok(Datum::String("".to_string())),
                    Some(BuiltInSymbol::ScriptType) => {
                        let symbol = match script_data.script_type {
                            ScriptType::Movie => "movie",
                            ScriptType::Parent => "parent",
                            ScriptType::Score => "score",
                            ScriptType::Member => "member",
                            _ => "unknown",
                        };
                        Ok(Datum::Symbol(Symbol::from_str(symbol)))
                    }
                    Some(BuiltInSymbol::Ilk) => Ok(Datum::Symbol(Symbol::from_str("script"))),
                    _ => Err(ScriptError::new(format!("Script members don't support property {}", prop))),
                }
            }
            CastMemberTypeId::Shape => {
                let cast_member = player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                    .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;

                if let CastMemberType::Shape(shape_member) = &cast_member.member_type {
                    let info = &shape_member.shape_info;
                    match prop.into_builtin() {
                        Some(BuiltInSymbol::Rect) => {
                            let width = info.width() as f64;
                            let height = info.height() as f64;
                            Ok(Datum::Rect([0.0, 0.0, width, height], 0))
                        }
                        Some(BuiltInSymbol::Width) => Ok(Datum::Int(info.width() as i32)),
                        Some(BuiltInSymbol::Height) => Ok(Datum::Int(info.height() as i32)),
                        Some(BuiltInSymbol::ShapeType) => {
                            let symbol = match info.shape_type {
                                ShapeType::Rect => "rect",
                                ShapeType::OvalRect => "roundRect",
                                ShapeType::Oval => "oval",
                                ShapeType::Line => "line",
                                ShapeType::Unknown => "rect",
                            };
                            Ok(Datum::Symbol(Symbol::from_str(symbol)))
                        }
                        Some(BuiltInSymbol::Filled) => Ok(datum_bool(info.fill_type != 0)),
                        // Director stores line thickness 1-based: 1 = no
                        // border ("hairline" / invisible), 2 = 1px, 3 = 2px,
                        // …, 6 = 5px (max). The Lingo `lineSize of member`
                        // getter returns the 0-based form (file value − 1),
                        // so file=1 → Lingo=0 (matches Director on a
                        // sprite-4 shape with no border).
                        Some(BuiltInSymbol::LineSize) => {
                            let raw = info.line_thickness as i32;
                            Ok(Datum::Int((raw - 1).max(0)))
                        }
                        Some(BuiltInSymbol::Pattern) => Ok(Datum::Int(info.pattern as i32)),
                        Some(BuiltInSymbol::ForeColor) => Ok(Datum::Int(info.fore_color as i32)),
                        Some(BuiltInSymbol::BackColor) => Ok(Datum::Int(info.back_color as i32)),
                        Some(BuiltInSymbol::Image) => {
                            // Director rasterizes shape members on demand for
                            // `the image of member`. Snapshot the small
                            // ShapeInfo so we can release the cast_manager
                            // borrow before mutating bitmap_manager below.
                            let info_owned = info.clone();
                            let width = info_owned.width().max(1) as u16;
                            let height = info_owned.height().max(1) as u16;
                            let palettes_rc = player.movie.cast_manager.palettes();
                            let palettes: &_ = &*palettes_rc;
                            let frame_palette = player
                                .movie
                                .score
                                .get_frame_palette(player.movie.current_frame);
                            let fg_rgb = resolve_color_ref(
                                palettes,
                                &ColorRef::PaletteIndex(info_owned.fore_color),
                                &frame_palette,
                                8,
                            );
                            let bg_rgb = resolve_color_ref(
                                palettes,
                                &ColorRef::PaletteIndex(info_owned.back_color),
                                &frame_palette,
                                8,
                            );

                            let mut bitmap =
                                Bitmap::new(width, height, 32, 32, 8, frame_palette.clone());
                            let w = width as i32;
                            let h = height as i32;
                            bitmap.fill_rect(0, 0, w, h, bg_rgb, palettes, 1.0);

                            let filled = info_owned.fill_type != 0;
                            // Same 1-based thickness convention as the on-stage
                            // renderer: filled shapes draw their outline at the
                            // raw thickness; outlined shapes subtract 1 so 1 ==
                            // hairline/invisible.
                            let thickness = if filled {
                                info_owned.line_thickness as i32
                            } else {
                                (info_owned.line_thickness as i32) - 1
                            };

                            match info_owned.shape_type {
                                ShapeType::Rect => {
                                    if filled {
                                        bitmap.fill_rect(0, 0, w, h, fg_rgb, palettes, 1.0);
                                    }
                                    if thickness > 0 {
                                        for t in 0..thickness {
                                            bitmap.stroke_rect(
                                                t,
                                                t,
                                                w - t,
                                                h - t,
                                                fg_rgb,
                                                palettes,
                                                1.0,
                                            );
                                        }
                                    }
                                }
                                ShapeType::OvalRect => {
                                    let radius = 12;
                                    if filled {
                                        bitmap.fill_round_rect(
                                            0, 0, w, h, radius, fg_rgb, palettes, 1.0,
                                        );
                                    }
                                    if thickness > 0 {
                                        bitmap.stroke_round_rect(
                                            0, 0, w, h, radius, fg_rgb, palettes, 1.0, thickness,
                                        );
                                    }
                                }
                                ShapeType::Oval => {
                                    if filled {
                                        bitmap.fill_ellipse(0, 0, w, h, fg_rgb, palettes, 1.0);
                                    }
                                    if thickness > 0 {
                                        bitmap.stroke_ellipse(
                                            0, 0, w, h, fg_rgb, palettes, 1.0, thickness,
                                        );
                                    }
                                }
                                ShapeType::Line => {
                                    let t = (info_owned.line_thickness as i32).max(1);
                                    if info_owned.line_direction == 6 {
                                        bitmap.draw_line_thick(
                                            0,
                                            h - 1,
                                            w - 1,
                                            0,
                                            fg_rgb,
                                            palettes,
                                            1.0,
                                            t,
                                        );
                                    } else {
                                        bitmap.draw_line_thick(
                                            0,
                                            0,
                                            w - 1,
                                            h - 1,
                                            fg_rgb,
                                            palettes,
                                            1.0,
                                            t,
                                        );
                                    }
                                }
                                ShapeType::Unknown => {
                                    bitmap.fill_rect(0, 0, w, h, fg_rgb, palettes, 1.0);
                                }
                            }

                            let bitmap_ref =
                                player.bitmap_manager.add_ephemeral_bitmap(bitmap);
                            Ok(Datum::BitmapRef(bitmap_ref))
                        }
                        _ => Err(ScriptError::new(format!(
                            "Shape members don't support property {}", prop
                        ))),
                    }
                } else {
                    Err(ScriptError::new("Expected shape member".to_string()))
                }
            }
            CastMemberTypeId::VectorShape => {
                return VectorShapeMemberHandlers::get_prop(player, cast_member_ref, prop);
            }
            CastMemberTypeId::Flash => {
                let cast_member = player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                    .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;
                if let CastMemberType::Flash(flash) = &cast_member.member_type {
                    let (l, t, r, b) = flash.effective_rect();
                    match prop.into_builtin() {
                        Some(BuiltInSymbol::Width) => Ok(Datum::Int((r - l) as i32)),
                        Some(BuiltInSymbol::Height) => Ok(Datum::Int((b - t) as i32)),
                        Some(BuiltInSymbol::Rect) => Ok(Datum::Rect([l as f64, t as f64, r as f64, b as f64], 0)),
                        Some(BuiltInSymbol::RegPoint) => {
                            let rp = flash.reg_point;
                            Ok(Datum::Point([rp.0 as f64, rp.1 as f64], 0))
                        }
                        // Flash cast-member frameCount (spec :60880, read-only):
                        // the SWF root timeline's total frame count. Parse it
                        // from the SWF header bytes — authoritative and correct
                        // even while the Ruffle instance is still (re)loading
                        // (asking Ruffle returns 0 during that window, which
                        // makes bogey_nights' #hiding `sprite.frame =
                        // member.frameCount` pin the SWF root at frame 0 and
                        // stall the grab state machine into a stuck #retreat).
                        Some(BuiltInSymbol::FrameCount) => Ok(Datum::Int(
                            crate::player::cast_member::CastMember::parse_swf_frame_count(&flash.data)
                                .map(|n| n as i32)
                                .unwrap_or(0),
                        )),
                        // `member.size` — "size in memory, in bytes, of a cast
                        // member. Read-only" (Director 11.5 Scripting Dictionary).
                        // For a Flash member this is its SWF byte count. Neopets'
                        // DGS `showPreLoader` gates on `member(x).size < 1000` to
                        // detect a missing/empty preloader after linking it via
                        // `x.fileName = <url>`, so this must reflect the bytes the
                        // fileName setter loaded from the preload cache.
                        Some(BuiltInSymbol::Size) => Ok(Datum::Int(flash.data.len() as i32)),
                        _ => Ok(Datum::Void),
                    }
                } else {
                    Ok(Datum::Void)
                }
            }
            CastMemberTypeId::Movie => {
                // Linked Movie member props (Director 11.5 Scripting Dictionary).
                let cast_member = player.movie.cast_manager.find_member_by_ref(cast_member_ref)
                    .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;
                if let CastMemberType::Movie(mv) = &cast_member.member_type {
                    match prop.as_lower_str() {
                        "filename" | "pathname" => Ok(Datum::String(mv.file_name.clone())),
                        "scriptsenabled" => Ok(Datum::Int(mv.scripts_enabled as i32)),
                        "crop" => Ok(Datum::Int(mv.crop as i32)),
                        "center" => Ok(Datum::Int(mv.center as i32)),
                        "sound" => Ok(Datum::Int(mv.sound as i32)),
                        "loop" => Ok(Datum::Int(mv.loops as i32)),
                        "width" => Ok(Datum::Int(mv.width as i32)),
                        "height" => Ok(Datum::Int(mv.height as i32)),
                        "rect" => Ok(Datum::Rect(
                            [0.0, 0.0, mv.width as f64, mv.height as f64],
                            0,
                        )),
                        "linked" => Ok(Datum::Int(1)),
                        "regpoint" => Ok(Datum::Point(
                            [mv.reg_point.0 as f64, mv.reg_point.1 as f64],
                            0,
                        )),
                        _ => Ok(Datum::Void),
                    }
                } else {
                    Ok(Datum::Void)
                }
            }
            _ => {
                // SWA/streaming media properties — return sensible defaults
                match prop.into_builtin() {
                    Some(BuiltInSymbol::SoundChannel) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::PreloadTime) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::Volume) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::Url) => Ok(Datum::String(String::new())),
                    Some(BuiltInSymbol::State) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::CurrentTime) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::Duration) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::PercentPlayed) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::PercentStreamed) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::Loop) => Ok(Datum::Int(0)),
                    Some(BuiltInSymbol::PausedAtStart) => Ok(Datum::Int(0)),
                    // Mixer Xtra status (chapter 15:8702). Real Director
                    // returns #playing / #stopped / #paused / #error; our
                    // mixer stub never plays anything, so #stopped is the
                    // honest default. Scripts compare against #playing to
                    // gate audio-driven branches — those branches stay off.
                    Some(BuiltInSymbol::Status) => Ok(Datum::Symbol(Symbol::from_str("stopped"))),
                    Some(BuiltInSymbol::NumBuffersToPreload | BuiltInSymbol::PlaybackQuality | BuiltInSymbol::AudioContextLatency) => Ok(Datum::Int(0)),
                    // `cdpCheckMode` is Get/Set with a documented default of
                    // `useSwPolicy` (see the setter). Answer the stored value,
                    // or that default when the movie never set one.
                    _ if prop.eq_ignore_ascii_case("cdpCheckMode") => {
                        let mode = reserve_player_ref(|player| {
                            Ok::<_, ScriptError>(
                                player
                                    .cdp_check_modes
                                    .get(cast_member_ref)
                                    .cloned()
                                    .unwrap_or_else(|| "useSwPolicy".to_string()),
                            )
                        })?;
                        Ok(Datum::Symbol(Symbol::from_str(&mode)))
                    }
                    _ => Err(ScriptError::new(format!(
                        "Cannot get castMember prop {} for member of type {:?}",
                        prop, member_type
                    ))),
                }
            }
        }
    }

    fn set_member_type_prop(
        member_ref: &CastMemberRef,
        prop: Symbol,
        value: Datum,
    ) -> Result<(), ScriptError> {
        let member_type = reserve_player_ref(|player| {
            let cast_member = player.movie.cast_manager.find_member_by_ref(member_ref);
            match cast_member {
                Some(cast_member) => Ok(Some(cast_member.member_type.member_type_id())),
                None => {
                    // Silently ignore setting props on erased members (Director
                    // does the same). debug!, not console::warn_1 — the latter
                    // always prints to the browser console and floods it (with
                    // retained entries) for movies that poke a null member each
                    // frame.
                    debug!(
                        "Ignoring set prop {} on erased member {} of castLib {}",
                        prop, member_ref.cast_member, member_ref.cast_lib
                    );
                    Ok(None)
                }
            }
        })?;

        let member_type = match member_type {
            Some(t) => t,
            None => return Ok(()), // Member was erased, silently ignore
        };

        let prop_str = prop.as_str();
        // `the scriptText of member` is settable on ANY member type. We don't
        // compile Lingo, but movies (freeT) use it as scratch storage, so
        // round-trip the string keyed by member ref (read back by the getter).
        if prop.eq_ignore_ascii_case("scriptText") {
            return reserve_player_mut(|player| {
                player
                    .script_text_overrides
                    .insert(member_ref.clone(), value.string_value()?);
                Ok(())
            });
        }

        if prop == BuiltInSymbol::RegPoint {
            return reserve_player_mut(|player| {
                let (vals, _flags) = value.to_point_inline()?;
                let x = vals[0] as i32;
                let y = vals[1] as i32;
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Cast member not found".to_string()))?;
                member.reg_point = (x, y);
                // Explicitly setting regPoint turns off centerRegPoint — the
                // user is saying "no, use THIS point, not the auto-center".
                // Without this, the renderer's center-reg-point branch in
                // get_concrete_sprite_rect overrides the explicit value with
                // bitmap-center, which broke spineworld_dcr's pDropList box:
                // the script does `pMember.image = timg; pMember.regPoint =
                // point(0, 0)`, but the image setter auto-centers AND leaves
                // centerRegPoint enabled, so the dropdown rendered with its
                // top-left shifted by (-bitmap_w/2, -bitmap_h/2) and the box
                // ended up at top-left of the stage instead of (280, 216).
                if let CastMemberType::Bitmap(ref mut bm) = member.member_type {
                    bm.reg_point = (x as i16, y as i16);
                    bm.info.center_reg_point = false;
                }
                Ok(())
            });
        }

        // Handle Script-specific props before the main match so unrecognized
        // props fall through to the wildcard arm (e.g. implicit bitmap conversion).
        if member_type == CastMemberTypeId::Script {
            match prop.into_builtin() {
                Some(BuiltInSymbol::ScriptText) => return Ok(()), // No-op: no lingo compiler
                Some(BuiltInSymbol::ScriptType) => {
                    let type_str = value.string_value()?;
                    let script_type = match type_str.to_lowercase().as_str() {
                        "movie" => ScriptType::Movie,
                        "parent" => ScriptType::Parent,
                        "score" => ScriptType::Score,
                        "member" => ScriptType::Member,
                        _ => return Err(ScriptError::new(format!("Unknown scriptType: {}", type_str))),
                    };
                    return borrow_member_mut(
                        member_ref,
                        |_| {},
                        |cast_member, _| {
                            if let CastMemberType::Script(ref mut s) = cast_member.member_type {
                                s.script_type = script_type;
                            }
                            Ok(())
                        },
                    );
                }
                _ => {} // Fall through to main match
            }
        }

        match member_type {
            CastMemberTypeId::Field => FieldMemberHandlers::set_prop(member_ref, prop_str, value),
            CastMemberTypeId::Text => {
                let text_result = TextMemberHandlers::set_prop(member_ref, prop_str, value.clone());
                if text_result.is_err() {
                    // Forward to 3D handler if text member has embedded 3D world
                    let has_w3d = reserve_player_ref(|player| {
                        player.movie.cast_manager.find_member_by_ref(member_ref)
                            .and_then(|m| m.member_type.as_shockwave3d()).is_some()
                    });
                    if has_w3d {
                        reserve_player_mut(|player| {
                            Shockwave3dMemberHandlers::set_prop(player, member_ref, prop_str, &value)
                        })
                    } else {
                        text_result
                    }
                } else {
                    text_result
                }
            },
            CastMemberTypeId::Button => ButtonMemberHandlers::set_prop(member_ref, prop, value),
            CastMemberTypeId::Font => reserve_player_mut(|player| {
                FontMemberHandlers::set_prop(player, member_ref, prop, value)
            }),
            CastMemberTypeId::Bitmap => BitmapMemberHandlers::set_prop(member_ref, prop, value),
            CastMemberTypeId::Sound => SoundMemberHandlers::set_prop(member_ref, prop, value),
            CastMemberTypeId::Palette => reserve_player_mut(|player| {
                PaletteMemberHandlers::set_prop(player, member_ref, prop, value)
            }),
            CastMemberTypeId::VectorShape => reserve_player_mut(|player| {
                VectorShapeMemberHandlers::set_prop(player, member_ref, prop, value)
            }),
            CastMemberTypeId::Flash => {
                // `member.fileName = <path/url>` — "refers to the name of the file
                // assigned to a linked cast member. Read/write ... also accepts
                // URLs ... to minimize download time, use preloadNetThing() ...
                // then set the fileName property" (Director 11.5 Scripting
                // Dictionary). Neopets' DGS `showPreLoader` does exactly that:
                // `preloadNetThing(url)` then `x.fileName = url`, then checks
                // `member(x).size`. So resolve the URL against the completed net
                // task the loader already primed and copy its SWF bytes into the
                // member; `effective_rect()` re-parses dimensions from the SWF
                // header (flash_info left None). If the URL wasn't preloaded we
                // leave the member empty (size stays 0) rather than block on a
                // synchronous fetch — matching Director's "used next time" note.
                if prop.eq_ignore_ascii_case("filename") || prop.eq_ignore_ascii_case("pathname") {
                    let url = value.string_value()?;
                    return reserve_player_mut(|player| {
                        let bytes = player
                            .net_manager
                            .find_task_by_url(&url)
                            .and_then(|id| player.net_manager.get_task_result(Some(id)))
                            .and_then(|r| r.ok());
                        if let Some(bytes) = bytes {
                            if !bytes.is_empty() {
                                if let Some(cm) =
                                    player.movie.cast_manager.find_member_by_ref_mut(member_ref)
                                {
                                    if let CastMemberType::Flash(flash) = &mut cm.member_type {
                                        flash.data = bytes;
                                        flash.flash_info = None;
                                    }
                                }
                            }
                        }
                        Ok(())
                    });
                }
                // Other Flash props (directToStage, quality, scaleMode, etc.)
                // are accepted silently.
                Ok(())
            }
            CastMemberTypeId::Movie => {
                // Linked Movie member props (Director 11.5 Scripting Dictionary).
                if prop.eq_ignore_ascii_case("filename") || prop.eq_ignore_ascii_case("pathname") {
                    // `member.fileName = <url>` links the external .dir/.dcr.
                    // Like the Flash member, grab the bytes from the net task the
                    // caller already preloadNetThing'd (Director's preload-then-set
                    // pattern) and stash them on the member; the live nested Movie
                    // is parsed/built from them at activation. Left unlinked (bytes
                    // None) if the URL wasn't preloaded.
                    let url = value.string_value()?;
                    return reserve_player_mut(|player| {
                        let captured: Option<(std::rc::Rc<Vec<u8>>, String)> =
                            player.net_manager.find_task_by_url(&url).and_then(|id| {
                                let bytes = player
                                    .net_manager
                                    .get_task_result(Some(id))
                                    .and_then(|r| r.ok())?;
                                if bytes.is_empty() {
                                    return None;
                                }
                                let base_url = player
                                    .net_manager
                                    .get_task(id)
                                    .map(|task| crate::utils::get_base_url(&task.resolved_url).to_string())
                                    .unwrap_or_default();
                                Some((std::rc::Rc::new(bytes), base_url))
                            });
                        if let Some(cm) = player.movie.cast_manager.find_member_by_ref_mut(member_ref) {
                            if let CastMemberType::Movie(mv) = &mut cm.member_type {
                                mv.file_name = url.clone();
                                if let Some((bytes, base_url)) = captured {
                                    mv.bytes = Some(bytes);
                                    mv.base_url = base_url;
                                }
                            }
                        }
                        Ok(())
                    });
                }
                return reserve_player_mut(|player| {
                    if let Some(cm) = player.movie.cast_manager.find_member_by_ref_mut(member_ref) {
                        if let CastMemberType::Movie(mv) = &mut cm.member_type {
                            let truthy = value.to_bool().unwrap_or(false);
                            match prop.to_lowercase().as_str() {
                                "scriptsenabled" => mv.scripts_enabled = truthy,
                                "crop" => mv.crop = truthy,
                                "center" => mv.center = truthy,
                                "regpoint" => {
                                    if let Datum::Point(pt, _) = &value {
                                        mv.reg_point = (pt[0] as i16, pt[1] as i16);
                                    }
                                }
                                _ => {} // other linked-movie props accepted silently
                            }
                        }
                    }
                    Ok(())
                });
            }
            CastMemberTypeId::Shockwave3d => reserve_player_mut(|player| {
                Shockwave3dMemberHandlers::set_prop(player, member_ref, prop_str, &value)
            }),
            CastMemberTypeId::HavokPhysics => {
                HavokPhysicsMemberHandlers::set_prop(member_ref, prop_str, value)
            }
            CastMemberTypeId::PhysXPhysics => {
                PhysXPhysicsMemberHandlers::set_prop(member_ref, prop_str, value)
            }
            _ => {
                // SWA/streaming media properties — accept silently as no-ops
                if matches!(prop.into_builtin(), Some(
                    BuiltInSymbol::SoundChannel | BuiltInSymbol::PreloadTime | BuiltInSymbol::Volume
                    | BuiltInSymbol::Url | BuiltInSymbol::State | BuiltInSymbol::CurrentTime
                    | BuiltInSymbol::Duration | BuiltInSymbol::PercentPlayed
                    | BuiltInSymbol::PercentStreamed | BuiltInSymbol::Loop | BuiltInSymbol::PausedAtStart
                )) {
                    return Ok(());
                }
                // Check if this is a bitmap-specific property being set on a non-bitmap
                if matches!(prop.into_builtin(), Some(
                    BuiltInSymbol::Image | BuiltInSymbol::RegPoint
                    | BuiltInSymbol::PaletteRef | BuiltInSymbol::Palette
                )) {
                    // Director allows setting bitmap properties on non-bitmap members
                    // by implicitly converting them to bitmap members
                    reserve_player_mut(|player| {
                        let cast_member = player
                            .movie
                            .cast_manager
                            .find_mut_member_by_ref(member_ref)
                            .expect("cast member ref should be valid in set_member_type_prop");

                        // If not already a bitmap, convert it
                        if cast_member.member_type.as_bitmap().is_none() {
                            // Create a new empty/default bitmap member
                            let new_bitmap = BitmapMember::default();

                            // Replace the member type
                            cast_member.member_type = CastMemberType::Bitmap(new_bitmap);
                        }

                        Ok(())
                    })?;
                    // Now try setting the property again
                    BitmapMemberHandlers::set_prop(member_ref, prop, value)
                } else if matches!(prop.into_builtin(), Some(BuiltInSymbol::Pattern) | Some(BuiltInSymbol::Filled) | Some(BuiltInSymbol::LineSize))
                    && member_type == CastMemberTypeId::Shape
                {
                    // Shape cast-member properties. Director 11.5 Scripting
                    // Dictionary, `pattern`: "Cast member property; determines the
                    // pattern associated with the specified shape … This property
                    // can be tested and set." `filled`, `lineSize` and `shapeType`
                    // are the sibling shape properties. dkbarrel's
                    // `Generic Help Dialog box.HelpInit` does
                    //   member(sprite(HelpScrollBgChan).member).pattern = 10
                    // to tile its scrollbar track.
                    reserve_player_mut(|player| {
                        let n = value.int_value()?;
                        let member = player
                            .movie
                            .cast_manager
                            .find_mut_member_by_ref(member_ref)
                            .ok_or_else(|| ScriptError::new("Invalid member ref".to_string()))?;
                        if let CastMemberType::Shape(shape) = &mut member.member_type {
                            match prop.into_builtin() {
                                Some(BuiltInSymbol::Pattern) => shape.shape_info.pattern = n as u16,
                                Some(BuiltInSymbol::Filled) => shape.shape_info.fill_type = if n != 0 { 1 } else { 0 },
                                _ => shape.shape_info.line_thickness = n as u8,
                            }
                        }
                        Ok(())
                    })
                } else if prop == "rect" {
                    // `member.rect` on a graphic member. The 11.5 dictionary entry
                    // for `rect (Member)` says "Read-only for all cast members,
                    // read/write for field cast members only", but its own example
                    // immediately after is headed "This statement sets the
                    // coordinates of bitmap cast member Banner" — and Director does
                    // accept the write for graphic members. dkbarrel's
                    // `Generic Help Dialog box.HelpInit` sizes its scrollbar track
                    // this way:
                    //   member(sprite(HelpScrollBgChan).member).rect =
                    //       rect(0, 0, brectangle[3], …)
                    // on a Shape member, which previously raised.
                    reserve_player_mut(|player| {
                        let (l, t, r, b) = match value {
                            Datum::Rect(vals, _) => {
                                (vals[0] as i16, vals[1] as i16, vals[2] as i16, vals[3] as i16)
                            }
                            _ => return Err(ScriptError::new(
                                "member.rect requires a rect".to_string(),
                            )),
                        };
                        let member = player
                            .movie
                            .cast_manager
                            .find_mut_member_by_ref(member_ref)
                            .ok_or_else(|| ScriptError::new("Invalid member ref".to_string()))?;
                        match &mut member.member_type {
                            CastMemberType::Shape(shape) => {
                                shape.shape_info.rect_left = l;
                                shape.shape_info.rect_top = t;
                                shape.shape_info.rect_right = r;
                                shape.shape_info.rect_bottom = b;
                                Ok(())
                            }
                            // Other graphic types don't carry a resizable rect of
                            // their own; accept the write rather than raising, as
                            // Director does for read-only-ish members.
                            _ => Ok(()),
                        }
                    })
                } else if prop.eq_ignore_ascii_case("cdpCheckMode") {
                    // `member(whichFlashMember).cdpCheckMode` — Director 11.5
                    // reference: Access Get/Set, default `useSwPolicy`. Set to
                    // `#useMediaPolicy` to use the Flash player's cross-domain
                    // checks, or `#useSWPolicy` to use Shockwave's.
                    //
                    // dirplayer runs in a browser, where the cross-origin
                    // decision is made by CORS on the actual fetch — neither
                    // policy path exists for us, so this is stored rather than
                    // enforced. Storing (not discarding) keeps the documented
                    // Get/Set round-trip honest for a script that reads it back.
                    //
                    // It must not RAISE: Miniclip's gameloader sets it right
                    // before `preloadNetThing(gameUrl)` ("Miniclip Game Loader"
                    // behavior, plus three sites in `MiniclipServices script`),
                    // so an error here aborts the loader and the game never
                    // starts.
                    reserve_player_mut(|player| {
                        let mode = value.string_value().unwrap_or_default();
                        player.cdp_check_modes.insert(member_ref.clone(), mode);
                        Ok(())
                    })
                } else {
                    Err(ScriptError::new(format!(
                        "Cannot set castMember prop {} for member of type {:?}",
                        prop, member_type
                    )))
                }
            }
        }
    }

    pub fn get_prop(
        player: &mut DirPlayer,
        cast_member_ref: &CastMemberRef,
        prop: Symbol,
    ) -> Result<Datum, ScriptError> {
        let is_invalid = cast_member_ref.cast_lib < 0 || cast_member_ref.cast_member < 0;
        if is_invalid {
            return Self::get_invalid_member_prop(player, cast_member_ref, prop);
        }
        let cast_member = player
            .movie
            .cast_manager
            .find_member_by_ref(cast_member_ref);
        let (name, comments, slot_number, member_type, color, bg_color, member_num) = match cast_member {
            Some(cast_member) => {
                let name = cast_member.name.to_owned();
                let comments = cast_member.comments.to_owned();
                let slot_number = Self::get_cast_slot_number(
                    cast_member_ref.cast_lib as u32,
                    cast_member_ref.cast_member as u32,
                ) as i32;
                let member_type = cast_member.member_type.member_type_id();
                let member_num = cast_member.number;
                let color = cast_member.color.to_owned();
                let bg_color = cast_member.bg_color.to_owned();
                (name, comments, slot_number, member_type, color, bg_color, member_num)
            }
            None => {
                // Ref (0,0) is Director's "no member" sentinel (an empty sprite
                // channel); querying its props is normal and handled by
                // get_invalid_member_prop. Keep at debug so a per-frame poll
                // doesn't flood the browser console (which retains every entry).
                debug!(
                    "Getting prop {} of non-existent castMember reference {}, {}",
                    prop, cast_member_ref.cast_lib, cast_member_ref.cast_member
                );
                return Self::get_invalid_member_prop(player, cast_member_ref, prop);
            }
        };

        match prop.into_builtin() {
            Some(BuiltInSymbol::Name) => Ok(Datum::String(name)),
            Some(BuiltInSymbol::MemberNum) => Ok(Datum::Int(member_num as i32)),
            Some(BuiltInSymbol::Number) => {
                if player.movie.dir_version >= 600 {
                    Ok(Datum::Int(slot_number))
                } else {
                    Ok(Datum::Int(member_num as i32))
                }
            }
            Some(BuiltInSymbol::Type) => Ok(Datum::Symbol(Symbol::from_str(member_type.symbol_string()?))),
            Some(BuiltInSymbol::CastLibNum) => Ok(Datum::Int(cast_member_ref.cast_lib as i32)),
            Some(BuiltInSymbol::Color) => Ok(Datum::ColorRef(color)),
            Some(BuiltInSymbol::BgColor) => Ok(Datum::ColorRef(bg_color)),
            Some(BuiltInSymbol::Loaded) => Ok(Datum::Int(1)),
            Some(BuiltInSymbol::MediaReady) => Ok(Datum::Int(1)),
            Some(BuiltInSymbol::Comments) => Ok(Datum::String(comments)),
            Some(BuiltInSymbol::Ilk) => Ok(Datum::Symbol(Symbol::from_str("member"))),
            Some(BuiltInSymbol::Member) => Ok(Datum::CastMember(cast_member_ref.clone())),
            _ => Self::get_member_type_prop(player, cast_member_ref, &member_type, prop),
        }
    }

    pub fn set_prop(
        cast_member_ref: &CastMemberRef,
        prop: Symbol,
        value: Datum,
    ) -> Result<(), ScriptError> {
        let is_invalid = cast_member_ref.cast_lib < 0 || cast_member_ref.cast_member < 0;
        if is_invalid {
            // Silently ignore setting props on an invalid (negative) reference,
            // e.g. a VOID/unset member ref a script still writes through.
            // Returning early also keeps the negative indices away from the
            // `as u32` casts below. debug!, not console::warn_1 — the latter
            // always floods the browser console.
            debug!(
                "Ignoring set prop {} on invalid castMember reference (member {} of castLib {})",
                prop, cast_member_ref.cast_member, cast_member_ref.cast_lib
            );
            return Ok(());
        }
        let exists = reserve_player_ref(|player| {
            player
                .movie
                .cast_manager
                .find_member_by_ref(cast_member_ref)
                .is_some()
        });
        let result = if exists {
            match prop.into_builtin() {
                Some(BuiltInSymbol::Name) => borrow_member_mut(
                    cast_member_ref,
                    |_player| value.string_value(),
                    |cast_member, value| {
                        cast_member.name = value?;
                        Ok(())
                    },
                ),
                Some(BuiltInSymbol::Comments) => borrow_member_mut(
                    cast_member_ref,
                    |_player| value.string_value(),
                    |cast_member, value| {
                        cast_member.comments = value?;
                        Ok(())
                    },
                ),
                Some(BuiltInSymbol::Color) => borrow_member_mut(
                    cast_member_ref,
                    |_| {},
                    |cast_member, _| {
                        cast_member.color = value.to_color_ref()?.to_owned();
                        // Director's `the color of member` recolors the WHOLE
                        // text member, overriding per-run/span colors. Clear the
                        // styled spans' explicit colors so `.image` (and the
                        // renderer) fall back to the new member color. Without
                        // this, spectral-wizard's LOADING dialog —
                        // putTextImageWithShadow sets member.color to the shadow
                        // then white between two `.image` reads — kept the spans'
                        // authored black and rendered the text black both times.
                        // Mirrors the text.rs member-prop setter. Per-line
                        // `member.line[i].color` setters run afterward and
                        // re-apply concrete colors where the script wants them.
                        if let Some(text) = cast_member.member_type.as_text_mut() {
                            for span in &mut text.html_styled_spans {
                                span.style.color = None;
                            }
                        }
                        Ok(())
                    },
                ),
                Some(BuiltInSymbol::BgColor) => borrow_member_mut(
                    cast_member_ref,
                    |_| {},
                    |cast_member, _| {
                        cast_member.bg_color = value.to_color_ref()?.to_owned();
                        Ok(())
                    },
                ),
                // Mixer Xtra setter stubs — same scope rationale as the
                // call() arm above. Music init scripts touch these on the
                // mixer cast member; we accept the writes but discard them.
                _ if match prop.into_builtin() {
                    Some(BuiltInSymbol::NumBuffersToPreload) | Some(BuiltInSymbol::PreloadTime) | Some(BuiltInSymbol::PlaybackQuality)
                        | Some(BuiltInSymbol::AudioContext) | Some(BuiltInSymbol::AudioContextLatency)
                        => true,
                    _ => false,
                } => Ok(()),
                _ => Self::set_member_type_prop(cast_member_ref, prop, value),
            }
        } else {
            // Silently ignore setting props on non-existent members.
            // This can happen when a script erases a member but still holds a
            // reference; Director silently ignores this case. debug!, not
            // console::warn_1 — the latter always floods the browser console.
            debug!(
                "Ignoring set prop {} on erased member {} of castLib {}",
                prop, cast_member_ref.cast_member, cast_member_ref.cast_lib
            );
            Ok(())
        };
        if result.is_ok() {
            if prop == BuiltInSymbol::Name {
                reserve_player_mut(|player| {
                    player.movie.cast_manager.invalidate_member_name_cache();
                });
                JsApi::on_cast_member_name_changed(Self::get_cast_slot_number(
                    cast_member_ref.cast_lib as u32,
                    cast_member_ref.cast_member as u32,
                ));
            }
            JsApi::dispatch_cast_member_changed(cast_member_ref.to_owned());
        }
        result
    }
}
