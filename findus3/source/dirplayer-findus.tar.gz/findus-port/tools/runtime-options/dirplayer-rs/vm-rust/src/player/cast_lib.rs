use std::{cell::RefCell, collections::HashMap, rc::Rc};

use fxhash::FxHashMap;
use url::Url;

use crate::{
    director::{
        cast::CastDef, chunks::sound::SoundChunk, enums::{ScriptType, BitmapInfo, SoundInfo},
        file::{read_director_file_bytes, DirectorFile},
        lingo::{datum::Datum, script::ScriptContext},
    }, js_api::JsApi, player::{cast_member::ScriptMember, ci_string::CiString, symbols::{builtin::BuiltInSymbol, symbol::Symbol}}, utils::{get_base_url, get_basename_no_extension, log_i}
};

use super::{
    allocator::DatumAllocator,
    bitmap::{
        bitmap::{Bitmap, BuiltInPalette, PaletteRef},
        manager::BitmapManager,
    },
    cast_member::{
        BitmapMember, CastMember, CastMemberType, FieldMember, FlashMember, MovieMember,
        PaletteMember, SoundMember, TextMember, VectorShapeMember,
    },
    datum_ref::DatumRef,
    handlers::datum_handlers::cast_member_ref::CastMemberRefHandlers,
    net_manager::NetManager,
    net_task::NetResult,
    reserve_player_mut,
    script::Script,
    ScriptError, PLAYER_OPT,
};

pub type CastLibNumber = u32;
pub type CastMemberNumber = u32;
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CastLibState {
    None,
    Loading,
    Loaded,
}

pub struct CastLib {
    pub name: String,
    pub file_name: String,
    pub number: u32,
    pub is_external: bool,
    pub state: CastLibState,
    pub lctx: Option<ScriptContext>,
    pub members: FxHashMap<u32, CastMember>,
    pub scripts: FxHashMap<u32, Rc<Script>>,
    pub name_symbols: Vec<Symbol>,
    pub preload_mode: u16,
    pub capital_x: bool,
    pub dir_version: u16,
    /// Offset to adjust bitmap clutId from Config-based to MCsL-based member numbering.
    pub palette_id_offset: i16,
    /// Lazy lowercased-name → lowest member number index for `find_member_by_name`.
    /// Built on first lookup and reused until a member is inserted/removed/renamed
    /// (see `invalidate_name_index`). Replaces an O(members) linear scan per call —
    /// the Habbo preloader's `FindCastNumber` hammers name lookups in tight loops.
    pub name_index: RefCell<Option<FxHashMap<String, u32>>>,
    /// Director Fmap/VWFM font-table snapshot: font_id → font name (e.g.
    /// "Arial", "Arial Bold", "Arial Italic"). Kept on the cast lib so
    /// per-run `font_id`s from STXT can be resolved to actual names at
    /// runtime — `.font` and `.fontStyle` chunk getters need this to
    /// distinguish bold variants from italic variants. Bit-flag heuristics
    /// (e.g. `font_id & 0x8000 = bold`) don't generalise — different movies
    /// pack the table differently and the only authoritative mapping is
    /// the file's own font table.
    pub font_table: HashMap<u16, String>,
}

impl CastLib {
    pub fn max_member_id(&self) -> u32 {
        *self.members.keys().max().unwrap_or(&0)
    }

    /// Lowest unused member number in this cast lib — the slot Director's
    /// `new(type, castLib(n))` allocates. Member numbers are 1-based.
    ///
    /// Returns 0 ONLY when the cast is genuinely full; callers must treat that
    /// as an error rather than creating a member at slot 0 (see `TypeHandlers::new`).
    ///
    /// This used to scan a hardcoded `1..5000` window and return 0 the moment
    /// every slot in it was taken. Habbo v31's dynamic-download bin cast holds
    /// 4999 members, so it exhausted that window exactly: `new()` then created
    /// each member AT slot 0, whose `.number` encodes to `(castLib-1) << 16`
    /// (131072 for the bin at cast 3) with a zero member index. Habbo's
    /// Resource Manager keys its name -> number map on `member.number`, so
    /// every downloaded furni member registered the SAME 131072 and clobbered
    /// slot 0 in turn; `member(getmemnum(name))` then resolved to whichever
    /// member landed there last — a field — surfacing as "Cannot set castMember
    /// prop paletteRef for field" and leaving the catalogue product strip stuck
    /// on loading placeholders.
    ///
    /// The 5000 ceiling was arbitrary (its own comment asked where it came
    /// from). Director's documented limit is 32,000 members per cast library;
    /// the hard bound here is the 16 bits `get_cast_slot_number` has for the
    /// member index, so scan the whole encodable range.
    pub fn first_free_member_id(&self) -> u32 {
        for i in 1..=0xFFFFu32 {
            if !self.members.contains_key(&i) {
                return i;
            }
        }
        0
    }

    pub fn remove_member(&mut self, number: u32) {
        // TODO remove from movie script cache
        self.members.remove(&number);
        self.scripts.remove(&number);
        self.invalidate_name_index();
        JsApi::on_cast_member_name_changed(CastMemberRefHandlers::get_cast_slot_number(
            self.number,
            number,
        ));
        JsApi::dispatch_cast_member_list_changed(self.number);
    }

    pub async fn preload(
        &mut self,
        net_manager: &mut NetManager,
        bitmap_manager: &mut BitmapManager,
        dir_cache: &mut HashMap<Box<str>, DirectorFile>,
    ) {
        let file_name = self.file_name.clone();
        if file_name.is_empty() {
            return;
        } else if let Some(cached_file) = dir_cache.get(&*file_name) {
            self.load_from_dir_file(cached_file, &file_name, bitmap_manager);
        } else {
            log::debug!("Loading cast {} into castLib {} ('{}')", self.file_name, self.number, self.name);
            self.state = CastLibState::Loading;
            let task_id = net_manager.preload_net_thing(self.file_name.clone());
            if !net_manager.is_task_done(Some(task_id)) {
                net_manager.await_task(task_id).await;
            }
            let task = net_manager.get_task(task_id).unwrap();
            let result = net_manager.get_task_result(Some(task_id)).unwrap();
            self.on_cast_preload_result(&result, &task.resolved_url, bitmap_manager, dir_cache);
        }
    }

    fn on_cast_preload_result(
        &mut self,
        result: &NetResult,
        resolved_url: &Url,
        bitmap_manager: &mut BitmapManager,
        dir_cache: &mut HashMap<Box<str>, DirectorFile>,
    ) {
        let load_file_name = resolved_url.as_str();
        if let Ok(cast_bytes) = result {
            let cast_file = read_director_file_bytes(
                cast_bytes,
                &resolved_url.to_string(),
                &get_base_url(resolved_url).to_string(),
            );
            if let Ok(cast_file) = cast_file {
                dir_cache.insert(load_file_name.into(), cast_file);
                let cast_file = dir_cache.get(load_file_name).unwrap();
                self.load_from_dir_file(&cast_file, load_file_name, bitmap_manager);
                // We return here because the function `load_from_dir_file()`
                // has changed our `state` to `Loaded` and we want to keep this.
                return;
            } else {
                log::debug!("Could not parse {load_file_name}");
            }
        } else {
            // ~650 null.cst pool slots fail to fetch during resetCastLibs;
            // keep this off the console (log::debug) to avoid flooding DevTools.
            log::debug!("Fetching {load_file_name} failed");
        }
        self.state = CastLibState::None;
    }

    pub fn find_member_by_number(&self, number: u32) -> Option<&CastMember> {
        self.members.get(&number)
    }

    pub fn find_mut_member_by_number(&mut self, number: u32) -> Option<&mut CastMember> {
        self.members.get_mut(&number)
    }

    /// Drop the lazily-built name index. Called whenever the member set or a
    /// member name changes, so the next `find_member_by_name` rebuilds it.
    pub fn invalidate_name_index(&self) {
        self.name_index.replace(None);
    }

    pub fn find_member_by_name(&self, name: &str) -> Option<&CastMember> {
        // An UNNAMED member cannot be addressed by name. Director identifies members
        // by name or by number, and a member with no name is reachable only by number,
        // so an empty query must never match — and unnamed members must never enter
        // the name index, or they become the match for `member("")`.
        //
        // AreaZero's Sound Manager does `member(tSoundName)` where tSoundName comes
        // straight from data that carries 39 `#sound: ""` entries; its own guard only
        // rejects VOID, not EMPTY. Indexing unnamed members made `member("")` resolve
        // to the lowest-numbered unnamed member — a SCRIPT — which then failed with
        // "Script members don't support property duration" and flooded the audio path
        // with non-sound members ("Failed to create source AudioBuffer").
        if name.is_empty() {
            return None;
        }
        // Director returns the lowest-numbered member when duplicates exist in the
        // same cast. Build (once) a lowercased-name → lowest-number index so repeated
        // lookups are O(1) instead of an O(members) scan per call.
        if self.name_index.borrow().is_none() {
            let mut index: FxHashMap<String, u32> = FxHashMap::default();
            for member in self.members.values() {
                if member.name.is_empty() {
                    continue;
                }
                let key = member.name.to_ascii_lowercase();
                index
                    .entry(key)
                    .and_modify(|n| {
                        if member.number < *n {
                            *n = member.number;
                        }
                    })
                    .or_insert(member.number);
            }
            self.name_index.replace(Some(index));
        }

        let number = {
            let idx_ref = self.name_index.borrow();
            let idx = idx_ref.as_ref().unwrap();
            // Avoid allocating a lowercased key on every lookup: most callers
            // (Habbo's normalizeCastName output) already pass a lowercase name,
            // so probe the index directly with `&str` and only allocate when the
            // name actually contains uppercase ASCII.
            if name.bytes().any(|b| b.is_ascii_uppercase()) {
                let lookup = name.to_ascii_lowercase();
                idx.get(lookup.as_str()).copied()
            } else {
                idx.get(name).copied()
            }
        };
        number.and_then(|n| self.members.get(&n))
    }


    fn clear(&mut self) {
        // Clear regardless of state. The previous early-return-when-not-Loaded
        // guard left stale members in place when a swap-in-place reload went
        // through the network path of `preload`: that path sets
        // `state = Loading` *before* awaiting the fetch, and by the time
        // `load_from_dir_file` calls `clear()` the guard short-circuited so
        // the OLD cast's members survived. `apply_cast_def` then merged the
        // new cast on top, leaving any slot the new cast didn't redefine
        // pinned to the previous cast's content (e.g. Coke Studios' first-time
        // swap from one public studio to another bled walls/floor/decor from
        // the previously visited studio).
        if self.members.is_empty()
            && self.scripts.is_empty()
            && self.lctx.is_none()
            && self.state == CastLibState::None
        {
            return;
        }
        self.members.clear();
        self.scripts.clear();
        self.lctx = None;
        self.state = CastLibState::None;
        self.invalidate_name_index();

        JsApi::dispatch_cast_member_list_changed(self.number);
    }

    fn set_name(&mut self, name: String) {
        if name != self.name {
            self.name = name;
            JsApi::dispatch_cast_name_changed(self.number);
        }
    }

    pub fn set_prop(
        &mut self,
        prop: Symbol,
        value: Datum,
        datums: &DatumAllocator,
    ) -> Result<(), ScriptError> {
        // TODO
        match prop.into_builtin() {
            Some(BuiltInSymbol::PreloadMode) => {
                self.preload_mode = value.int_value()? as u16;
            }
            Some(BuiltInSymbol::Name) => {
                self.set_name(value.string_value()?);
            }
            Some(BuiltInSymbol::FileName) => {
                self.file_name = value.string_value()?;
            }
            _ => {
                return Err(ScriptError::new(format!(
                    "Cannot set castLib property {}",
                    prop
                )));
            }
        };
        Ok(())
    }

    pub fn get_prop(&self, prop: Symbol) -> Result<Datum, ScriptError> {
        match prop.into_builtin() {
            Some(BuiltInSymbol::PreloadMode) => Ok(Datum::Int(self.preload_mode as i32)),
            Some(BuiltInSymbol::FileName) => {
                // Only return the fileName if the cast is actually loaded.
                // External casts with preloadMode=0 ("When Needed") have file_name set
                // in the movie structure but aren't loaded yet. Scripts like PreloadCast
                // compare castLib.fileName to decide whether to download — returning the
                // configured name for an unloaded cast would skip the download.
                if self.is_external && self.state == CastLibState::None {
                    Ok(Datum::String(String::new()))
                } else {
                    Ok(Datum::String(self.file_name.clone()))
                }
            }
            Some(BuiltInSymbol::Number) => Ok(Datum::Int(self.number as i32)),
            Some(BuiltInSymbol::Name) => Ok(Datum::String(self.name.clone())),
            Some(BuiltInSymbol::NumberOfCastMembers | BuiltInSymbol::NumberOfMembers) => {
                // Director semantics: the highest member slot number in use,
                // not the population count. Casts routinely have gaps, and
                // Lingo code like `repeat with i = 1 to the number of
                // castMembers of castLib "X"` relies on this to reach every
                // populated slot (including dynamically created members at
                // high numbers) — otherwise cleanup loops silently skip them.
                Ok(Datum::Int(self.max_member_id() as i32))
            }
            _ => Err(ScriptError::new(format!(
                "Cannot get castLib property {}",
                prop
            ))),
        }
    }

    fn load_from_dir_file(
        &mut self,
        file: &DirectorFile,
        load_file_name: &str,
        bitmap_manager: &mut BitmapManager,
    ) {
        self.clear();
        // TODO file.parseScripts

        self.file_name = load_file_name.to_owned();
        self.state = CastLibState::Loaded;
        if self.name.is_empty() {
            self.set_name(get_basename_no_extension(load_file_name));
        }
        if let Some(cast_def) = file.casts.first() {
            log::debug!(
                "Applying cast def to castLib {} ('{}'): {} members",
                self.number,
                self.name,
                cast_def.members.len()
            );
            self.apply_cast_def(file, cast_def, bitmap_manager, &file.font_table);
        } else {
            log_i(
                format_args!(
                    "No cast def found in file {} for castLib {} ('{}')",
                    load_file_name,
                    self.number,
                    self.name
                )
                .to_string()
                .as_str(),
            );
        }
    }

    pub fn apply_cast_def(
        &mut self,
        _: &DirectorFile,
        cast_def: &CastDef,
        bitmap_manager: &mut BitmapManager,
        font_table: &HashMap<u16, String>,
    ) {
        self.lctx = cast_def.lctx.clone();
        // AUTHORITATIVE: a cast's own name table claims the global display
        // spelling for its names, overriding a builtin that interned the same
        // name in different casing at startup. Director has no builtin spelling
        // table seeded before the movie, so there the movie is always the first
        // writer; `init_builtin_symbols()` makes us the first writer instead.
        // Habbo v31: the XML builtin `nodeName` claimed the spelling, so the
        // movie's `#nodename` reported as "nodeName" and the catalogue's
        // `tdata.getaProp("nodename")` missed ("Malformed node data nodeName").
        self.name_symbols = self.lctx.as_ref()
            .map(|lctx| lctx.names.iter().map(|n| Symbol::from_str_authoritative(n)).collect())
            .unwrap_or_default();
        self.capital_x = cast_def.capital_x;
        self.dir_version = cast_def.dir_version;
        self.palette_id_offset = cast_def.palette_id_offset;
        self.font_table = font_table.clone();
        self.state = CastLibState::Loaded;
        for (id, member_def) in &cast_def.members {
            self.insert_member(
                *id,
                CastMember::from(self.number, *id, member_def, &self.lctx, bitmap_manager, self.dir_version, self.palette_id_offset, font_table),
            );
            JsApi::on_cast_member_name_changed(CastMemberRefHandlers::get_cast_slot_number(
                self.number,
                *id,
            ));
        }
        JsApi::dispatch_cast_member_list_changed(self.number);
        unsafe {
            let player_mut = &mut crate::player::player_mut();

            player_mut.movie.cast_manager.clear_movie_script_cache();
            player_mut.movie.cast_manager.invalidate_member_name_cache();
            player_mut.movie.cast_manager.load_fonts_into_manager(&mut player_mut.font_manager);
        };
    }

    pub fn insert_member(&mut self, number: u32, member: CastMember) {
        // Which lctx script should we register under this member's slot, and as
        // what type? A `Script` cast member registers its own script. A non-Script
        // member (Field, Text, Bitmap, Button, Shape) may carry an ATTACHED script
        // via `member_info.header.script_id` — Director lets `script("name")` and
        // `new(script(...))` resolve to that attached script, and a movie can store
        // a parent script AS a Field cast member (SpongeBob "JellyFishin'" stores
        // its "hero parent" parent script as a Field). Register it at the member
        // slot so `get_script_for_member(number)` finds it. (Member BEHAVIOR scripts
        // for mouse events are dispatched separately via get_behavior_script_from_lctx.)
        let registration: Option<(u32, ScriptType)> = match &member.member_type {
            CastMemberType::Script(s) => Some((s.script_id, s.script_type)),
            _ => member.get_script_id().map(|sid| (sid, ScriptType::Parent)),
        };

        if let Some((reg_script_id, reg_script_type)) = registration {
            let script_def = self
                .lctx
                .as_ref()
                .and_then(|lctx| lctx.scripts.get(&reg_script_id));

            if let Some(script_def) = script_def {
                let mut handler_names = Vec::new();
                let mut handler_names_raw = Vec::new();
                let mut handler_name_map = FxHashMap::default();
                let names = &self.lctx.as_ref().unwrap().names;
                for (idx, handler) in script_def.handlers.iter().enumerate() {
                    // name_id 0xFFFF (and any out-of-range id) marks an
                    // anonymous handler slot — Director leaves these in the
                    // handler vector (netjack D4 has one). It must still occupy
                    // its position: `LocalCall` / `get_own_handler_ref_at`
                    // index handler_names BY POSITION, so skipping would
                    // misalign every later handler. Give it a unique synthetic
                    // name (registered in the map too) so it stays callable by
                    // index without indexing past the names table.
                    let handler_name = match names.get(handler.name_id as usize) {
                        Some(n) => n.clone(),
                        None => format!("__anon_handler_{}", idx),
                    };
                    let handler_name_symbol = Symbol::from_str(&handler_name);
                    handler_name_map.insert(handler_name_symbol, Rc::new(handler.clone()));
                    handler_names.push(handler_name_symbol);
                    handler_names_raw.push(handler_name);
                }

                let property_names = script_def
                    .property_name_ids
                    .iter()
                    .filter_map(|id| names.get(*id as usize).map(|n| Symbol::from_str(n)));
                let mut properties = FxHashMap::default();
                for name in property_names {
                    properties.insert(name, DatumRef::Void);
                }

                let script = Script {
                    member_ref: cast_member_ref(self.number as i32, number as i32),
                    name: (&member.name).to_owned(),
                    chunk: script_def.clone(),
                    script_type: reg_script_type,
                    handlers: handler_name_map,
                    handler_names,
                    handler_names_raw,
                    properties: RefCell::new(properties),
                };
                // JS Lingo diagnostic: decode and disassemble each XDR-wrapped JSScript
                // in the literal data area. Phase 1 — read-only; translator hook lands later.
                crate::player::js_lingo_loader::diagnose_js_script(&script);
                self.scripts.insert(number, Rc::new(script));
            }
        } else if let CastMemberType::Palette(_) = &member.member_type {
            reserve_player_mut(|player| {
                player.movie.cast_manager.invalidate_palette_cache();
            });
        }

        self.members.insert(number, member);
        self.invalidate_name_index();
    }

    pub fn create_member_at(
        &mut self,
        number: u32,
        member_type: &str,
        bitmap_manager: &mut BitmapManager,
    ) -> Result<CastMemberRef, ScriptError> {
        // Director symbols are case-insensitive (`new(#vectorShape)` ==
        // `new(#vectorshape)`), so match member-type names through `match_ci!`.
        let member = match_ci!(member_type, {
            "field" => Ok(CastMember::new(
                number,
                CastMemberType::Field(FieldMember::new()),
            )),
            "text" => Ok(CastMember::new(
                number,
                CastMemberType::Text(TextMember::new()),
            )),
            "bitmap" => {
                let bitmap = Bitmap::new(
                    0,
                    0,
                    32,
                    32,
                    0,
                    PaletteRef::BuiltIn(BuiltInPalette::GrayScale),
                );
                let bitmap_ref = bitmap_manager.add_bitmap(bitmap);
                Ok(CastMember::new(
                    number,
                    CastMemberType::Bitmap(BitmapMember {
                        image_ref: bitmap_ref,
                        reg_point: (0, 0),
                        script_id: 0,
                        member_script_ref: None,
                        info: BitmapInfo::default(),
                    }),
                ))
            },
            "palette" => Ok(CastMember::new(
                number,
                CastMemberType::Palette(PaletteMember::new()),
            )),
            // `new(#vectorShape)` creates an empty vector shape; the script
            // populates vertices via `addVertex` and sets fill/stroke/gradient
            // props (Director 11.5 Scripting Dictionary). spectral-wizard's
            // parent_grad builds gradient backgrounds this way at runtime.
            "vectorshape" => Ok(CastMember::new(
                number,
                CastMemberType::VectorShape(VectorShapeMember::new()),
            )),
            // `new(#sound, castLib)` creates an empty sound member; its media is
            // populated later, typically via `importFileInto` (Director 11.5
            // Scripting Dictionary, `new()` / `importFileInto()`). Habbo's
            // Download Manager relies on this for streamed trax samples.
            "sound" => Ok(CastMember::new(
                number,
                CastMemberType::Sound(SoundMember {
                    info: SoundInfo::default(),
                    sound: SoundChunk::default(),
                    cue_point_times: Vec::new(),
                    cue_point_names: Vec::new(),
                }),
            )),
            "script" => Ok(CastMember::new(
                number,
                CastMemberType::Script(ScriptMember {
                    script_id: 0,
                    script_type: ScriptType::Movie,
                    name: String::new(),
                }),
            )),
            // `new(#flash)` creates an empty Flash cast member; the script then
            // points it at a SWF, typically by setting `.linked = TRUE` and
            // `.pathName = "http://…/foo.swf"`, or by assigning preloaded bytes
            // (Director 11.5 Scripting Dictionary — `new()`, `#flash` member).
            // Neopets' DGS loader (`mainClass.showPreLoader`) uses this to host
            // the downloaded preloader SWF. Empty until its source is assigned.
            "flash" => Ok(CastMember::new(
                number,
                CastMemberType::Flash(FlashMember {
                    data: Vec::new(),
                    reg_point: (0, 0),
                    flash_info: None,
                }),
            )),
            // `new(#movie)` creates an empty Linked Movie member; the script
            // links it to an external .dir/.dcr via `member.fileName = <url>`
            // and plays it by assigning the member to a sprite (Director 11.5
            // Scripting Dictionary "Linked Movie"). Neopets' DGS loader
            // (`showAndStartShockwaveGame`) uses this to run the downloaded game.
            "movie" => Ok(CastMember::new(
                number,
                CastMemberType::Movie(MovieMember::new()),
            )),
            // `new(#physics)` creates an empty Physics cast member. `#physics` is
            // a documented member type (Director 11.5 Scripting Dictionary,
            // `type (Member)` — the value list includes `#physics`), supplied by
            // the AGEIA Physics Xtra that ships with 11.5. The script then calls
            // `member.init(...)` / `createRigidBody(...)` on it, exactly as the
            // authored Physics members in Agent Free Ride are used. AreaZero's
            // `[M] Member.createMember` builds its "MenuCharacter_Physics" member
            // this way instead of authoring it in the cast.
            "physics" => Ok(CastMember::new(
                number,
                CastMemberType::PhysXPhysics(crate::player::cast_member::PhysXPhysicsMember {
                    state: crate::player::cast_member::PhysXPhysicsState::default(),
                }),
            )),
            _ => Err(ScriptError::new(format!(
                "Cannot create member of type {}",
                member_type
            ))),
        })?;
        self.insert_member(number, member);
        JsApi::dispatch_cast_member_list_changed(self.number);
        Ok(cast_member_ref(self.number as i32, number as i32))
    }

    pub fn get_script_for_member(&self, number: u32) -> Option<&Rc<Script>> {
        // A cast-member slot and an Lctx script ID are separate namespaces.
        // insert_member registers both standalone and attached scripts at the
        // owning member's slot. Treating a missing slot as an Lctx ID can run an
        // unrelated live script: Findus DAG01's dead member 22 aliased member 27
        // (Lctx ID 22), starting the rooster narration from the racing screen.
        // Explicit Lctx lookups use get_behavior_script_from_lctx instead.
        self.scripts.get(&number)
    }

    pub fn get_behavior_script_from_lctx(&mut self, script_id: u32) -> Option<Rc<Script>> {
        // Use an offset to avoid collision with cast member numbers
        // Behavior scripts are stored at script_id + 1000000
        let cache_key = script_id + 1000000;
        
        // Check if already cached
        if let Some(cached) = self.scripts.get(&cache_key) {
            return Some(cached.clone());
        }
        
        // Get script chunk from lctx.scripts
        let script_chunk = self.lctx.as_ref()?.scripts.get(&script_id)?;
        
        // Build handler map
        let mut handler_names = Vec::new();
        let mut handler_names_raw = Vec::new();
        let mut handler_name_map = FxHashMap::default();
        let names = &self.lctx.as_ref().unwrap().names;
        for (idx, handler) in script_chunk.handlers.iter().enumerate() {
            // Anonymous handler slots (name_id 0xFFFF / out of range) must keep
            // their position — LocalCall indexes handler_names by position.
            // Give them a unique synthetic name instead of skipping.
            let handler_name = match names.get(handler.name_id as usize) {
                Some(n) => n.clone(),
                None => format!("__anon_handler_{}", idx),
            };
            let handler_name_symbol = Symbol::from_str(&handler_name);
                    handler_name_map.insert(handler_name_symbol, Rc::new(handler.clone()));
            handler_names.push(handler_name_symbol);
                    handler_names_raw.push(handler_name);
        }

        // Build properties
        let property_names = script_chunk
            .property_name_ids
            .iter()
            .filter_map(|id| names.get(*id as usize).map(|n| Symbol::from_str(n)));
        let mut properties = FxHashMap::default();
        for name in property_names {
            properties.insert(name, DatumRef::Void);
        }

        let script = Rc::new(Script {
            member_ref: cast_member_ref(self.number as i32, cache_key as i32),
            name: format!("BehaviorScript_{}", script_id),
            chunk: script_chunk.clone(),
            script_type: ScriptType::Member,
            handlers: handler_name_map,
            handler_names,
            handler_names_raw,
            properties: RefCell::new(properties),
        });
        
        // Cache it with the offset key
        self.scripts.insert(cache_key, script.clone());
        
        Some(script)
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash, Copy)]
pub struct CastMemberRef {
    pub cast_lib: i32,
    pub cast_member: i32,
}

pub const INVALID_CAST_MEMBER_REF: CastMemberRef = CastMemberRef {
    cast_lib: -1,
    cast_member: -1,
};
pub const NULL_CAST_MEMBER_REF: CastMemberRef = CastMemberRef {
    cast_lib: 0,
    cast_member: 0,
};

pub fn cast_member_ref(cast_lib: i32, cast_member: i32) -> CastMemberRef {
    CastMemberRef {
        cast_lib,
        cast_member,
    }
}

impl CastMemberRef {
    pub fn is_valid(&self) -> bool {
        // The NULL ref (0, 0) is "no member" — it is what an EMPTY sprite
        // channel reports and what `member(0, 0)` builds — so it is not a valid
        // member any more than the INVALID (-1, -1) sentinel is. Without this,
        // a channel cleared with `sprite.member = member(0, 0)` still counted
        // as occupied: it kept hit-testing, so an invisible cleared overlay
        // swallowed clicks meant for the sprite beneath it (LEGO Supersonic's
        // menu stopped responding).
        if self.cast_lib == NULL_CAST_MEMBER_REF.cast_lib
            && self.cast_member == NULL_CAST_MEMBER_REF.cast_member
        {
            return false;
        }
        self.cast_lib != INVALID_CAST_MEMBER_REF.cast_lib
            && self.cast_member != INVALID_CAST_MEMBER_REF.cast_member
    }
}

pub async fn player_cast_lib_set_prop(
    cast_lib: u32,
    prop_name: Symbol,
    value: Datum,
) -> Result<(), ScriptError> {
    let player = unsafe { crate::player::player_mut() };
    let builtin_prop_name = prop_name.into_builtin_or_error()?;

    let cast_manager = &mut player.movie.cast_manager;
    let cast_lib_obj = cast_manager.get_cast_mut(cast_lib as u32);

    if builtin_prop_name == BuiltInSymbol::FileName {
        // log::debug (not console) — the cast pool sets fileName on ~650 empty
        // slots during resetCastLibs; a per-set console.log floods DevTools and
        // dominates load time when the console is open.
        log::debug!(
            "Setting fileName of castLib {} ('{}') to '{}'",
            cast_lib,
            cast_lib_obj.name,
            value.string_value().unwrap_or_default()
        );
    }

    cast_lib_obj.set_prop(prop_name, value, &player.allocator)?;
    if builtin_prop_name == BuiltInSymbol::FileName {
        cast_lib_obj
            .preload(
                &mut player.net_manager,
                &mut player.bitmap_manager,
                &mut player.dir_cache,
            )
            .await;
        // The external cast was reloaded in place — any Flash member it holds
        // now has new SWF bytes behind the same member ref. Tear down the stale
        // Ruffle instances so the renderer re-creates them from the new bytes
        // (Storyscramble swaps `castLib("story").fileName` to load the next
        // story; member 2:1's SWF changes but the tile sprites keep pointing at
        // it). `cast_lib_obj`'s borrow ends here (NLL), freeing `player`.
        player.invalidate_flash_for_cast_lib(cast_lib as i32);
    }
    // TODO handle preload error
    Ok(())
}

#[cfg(test)]
mod name_index_tests {
    use super::*;
    use crate::player::cast_member::FieldMember;

    fn empty_cast() -> CastLib {
        // Constructing cast members can format BuiltInSymbols, which read the
        // global symbol table; make sure it's initialized (idempotent).
        crate::player::symbols::symbol_table::init_symbol_table();
        CastLib {
            name: String::new(),
            file_name: String::new(),
            number: 1,
            is_external: false,
            state: CastLibState::Loaded,
            lctx: None,
            members: FxHashMap::default(),
            scripts: FxHashMap::default(),
            name_symbols: Vec::new(),
            preload_mode: 0,
            capital_x: false,
            dir_version: 0,
            palette_id_offset: 0,
            name_index: RefCell::new(None),
            font_table: HashMap::new(),
        }
    }

    fn field_member(number: u32, name: &str) -> CastMember {
        // Field members take the simple insert path (no JsApi / script wiring).
        let mut m = CastMember::new(number, CastMemberType::Field(FieldMember::new()));
        m.name = name.to_string();
        m
    }

    #[test]
    fn find_by_name_is_case_insensitive_and_lowest_number_wins() {
        let mut cast = empty_cast();
        cast.insert_member(5, field_member(5, "Window"));
        cast.insert_member(2, field_member(2, "window")); // duplicate name, lower number
        cast.insert_member(9, field_member(9, "Frame"));

        // Lowest-numbered match wins; lookup is case-insensitive.
        assert_eq!(cast.find_member_by_name("WINDOW").map(|m| m.number), Some(2));
        assert_eq!(cast.find_member_by_name("window").map(|m| m.number), Some(2));
        assert_eq!(cast.find_member_by_name("frame").map(|m| m.number), Some(9));
        assert!(cast.find_member_by_name("missing").is_none());
        // Second lookup hits the cached index and returns the same result.
        assert_eq!(cast.find_member_by_name("window").map(|m| m.number), Some(2));
    }

    #[test]
    fn index_invalidates_on_rename_and_remove() {
        let mut cast = empty_cast();
        cast.insert_member(3, field_member(3, "Alpha"));
        assert_eq!(cast.find_member_by_name("alpha").map(|m| m.number), Some(3)); // builds index

        // Rename: mutate the member then invalidate (mirrors the name-setter,
        // which routes through invalidate_member_name_cache -> invalidate_name_index).
        cast.members.get_mut(&3).unwrap().name = "Beta".to_string();
        cast.invalidate_name_index();
        assert!(cast.find_member_by_name("alpha").is_none());
        assert_eq!(cast.find_member_by_name("beta").map(|m| m.number), Some(3));

        // Remove via the map + invalidate (avoid remove_member's JsApi calls in tests).
        cast.members.remove(&3);
        cast.invalidate_name_index();
        assert!(cast.find_member_by_name("beta").is_none());
    }
}
