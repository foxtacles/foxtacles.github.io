use std::collections::HashMap;

use indexmap::IndexMap;

use async_std::channel::Receiver;
use chrono::Local;
use log::{warn, debug};
use manual_future::ManualFuture;
use url::Url;

use crate::{
    console_warn,
    director::lingo::datum::{Datum, TimeoutRef},
    js_api::JsApi,
    player::{PLAYER_OPT, symbols::{builtin::BuiltInSymbol, symbol::Symbol}},
    utils::ToHexString,
};

use super::{
    allocator::ScriptInstanceAllocatorTrait,
    cast_lib::CastMemberRef,
    cast_member::CastMemberType,
    datum_ref::DatumRef,
    events::{
        player_dispatch_callback_event, player_dispatch_event_to_sprite,
        player_dispatch_movie_callback, player_wait_available,
        player_dispatch_event_to_sprite_targeted, player_invoke_frame_and_movie_scripts,
    },
    font::player_load_system_font,
    keyboard_events::{player_key_down, player_key_up},
    handlers::datum_handlers::player_call_datum_handler,
    player_alloc_datum, player_call_script_handler, player_dispatch_global_event,
    player_is_playing, reserve_player_mut, reserve_player_ref,
    score::{
        concrete_sprite_hit_test, get_concrete_sprite_rect, get_sprite_at, get_sprites_at,
        sprite_has_handler,
    },
    script_ref::ScriptInstanceRef,
    PlayerVMExecutionItem, ScriptError, ScriptReceiver, PLAYER_TX,
};

#[allow(dead_code)]
pub enum PlayerVMCommand {
    LoadMovieFromFile(String, bool),
    SetExternalParams(IndexMap<String, String>),
    SetBasePath(String),
    SetStartupDo(String),
    SetStartupDoBefore(String),
    SetStartupGo(u32),
    SetMoviePathOverride(String),
    SetMoviePathLabel(String),
    SetSystemFontPath(String),
    SetStageSize(u32, u32),
    TimeoutTriggered(TimeoutRef),
    PrintMemberBitmapHex(CastMemberRef),
    /// Dev UI sound preview: play a sound member through channel 1 (the real
    /// puppetSound path) so it exercises the same decode/playback code a movie
    /// would. Triggered by a user gesture so the AudioContext can resume.
    PlayMemberSound(CastMemberRef),
    MouseDown((i32, i32)),
    MouseUp((i32, i32)),
    MouseMove((i32, i32), bool),
    RightMouseDown((i32, i32)),
    RightMouseUp((i32, i32)),
    KeyDown(String, u16),
    KeyUp(String, u16),
    TriggerAlertHook,
    // Flash-to-Lingo callback mechanism
    TriggerFlashCallback {
        sprite_num: i32,
        handler_name: Symbol,
        args: Vec<DatumRef>,
    },
    TriggerLingoCallbackOnScript {
        cast_lib: i32,
        cast_member: i32,
        handler_name: Symbol,
        args: Vec<DatumRef>,
    },
    /// Flash `LocalConnection.send` → the Lingo handler registered via
    /// `setCallback` on a Director-created LocalConnection, dispatched to the
    /// EXACT target instance (so `me` in `on myOnStatus me, ...` is correct).
    TriggerLocalConnectionCallback {
        target: ScriptInstanceRef,
        handler_name: String,
        args: Vec<DatumRef>,
    },
    SetLingoScriptProperty {
        cast_lib: i32,
        cast_member: i32,
        prop_name: Symbol,
        value: DatumRef,
    },
    /// Dispatch a Flash `getURL("event: …")` body into Director's event chain.
    /// Mirrors the Flash Asset Xtra: `send <handler> [args...]` becomes a global
    /// event invocation that walks active sprite behaviors → frame script → movie
    /// scripts, so any `on <handler>` in scope picks it up.
    DispatchFlashEvent {
        cast_lib: i32,
        cast_member: i32,
        handler_name: Symbol,
        args: Vec<DatumRef>,
    },
}

pub fn _format_player_cmd(command: &PlayerVMCommand) -> String {
    match command {
        PlayerVMCommand::LoadMovieFromFile(path, autoplay) => format!("LoadMovieFromFile({}, {})", path, autoplay),
        PlayerVMCommand::SetExternalParams(params) => {
            format!("SetExternalParams({:?})", params.keys().collect::<Vec<_>>())
        }
        PlayerVMCommand::SetBasePath(path) => format!("SetBasePath({})", path),
        PlayerVMCommand::SetStartupDo(code) => format!("SetStartupDo({})", code),
        PlayerVMCommand::SetStartupDoBefore(code) => format!("SetStartupDoBefore({})", code),
        PlayerVMCommand::SetStartupGo(frame) => format!("SetStartupGo({})", frame),
        PlayerVMCommand::SetMoviePathOverride(path) => format!("SetMoviePathOverride({})", path),
        PlayerVMCommand::SetMoviePathLabel(path) => format!("SetMoviePathLabel({})", path),
        PlayerVMCommand::SetSystemFontPath(path) => format!("SetSystemFontPath({})", path),
        PlayerVMCommand::SetStageSize(width, height) => {
            format!("SetStageSize({}, {})", width, height)
        }
        PlayerVMCommand::TimeoutTriggered(timeout_ref) => {
            format!("TimeoutTriggered({})", timeout_ref)
        }
        PlayerVMCommand::PrintMemberBitmapHex(..) => "PrintMemberBitmapHex(..)".to_string(),
        PlayerVMCommand::PlayMemberSound(..) => "PlayMemberSound(..)".to_string(),
        PlayerVMCommand::MouseDown((x, y)) => format!("MouseDown({}, {})", x, y),
        PlayerVMCommand::MouseUp((x, y)) => format!("MouseUp({}, {})", x, y),
        PlayerVMCommand::MouseMove((x, y), _) => format!("MouseMove({}, {})", x, y),
        PlayerVMCommand::RightMouseDown((x, y)) => format!("RightMouseDown({}, {})", x, y),
        PlayerVMCommand::RightMouseUp((x, y)) => format!("RightMouseUp({}, {})", x, y),
        PlayerVMCommand::KeyDown(key, ..) => format!("KeyDown({})", key),
        PlayerVMCommand::KeyUp(key, ..) => format!("KeyUp({})", key),
        PlayerVMCommand::TriggerAlertHook => "TriggerAlertHook".to_string(),
        PlayerVMCommand::TriggerFlashCallback { sprite_num, handler_name, .. } => {
            format!("TriggerFlashCallback(sprite: {}, handler: {})", sprite_num, handler_name)
        }
        PlayerVMCommand::TriggerLingoCallbackOnScript { cast_lib, cast_member, handler_name, .. } => {
            format!("TriggerLingoCallbackOnScript(cast_lib: {}, cast_member: {}, handler: {})", cast_lib, cast_member, handler_name)
        }
        PlayerVMCommand::TriggerLocalConnectionCallback { handler_name, .. } => {
            format!("TriggerLocalConnectionCallback(handler: {})", handler_name)
        }
        PlayerVMCommand::SetLingoScriptProperty { cast_lib, cast_member, prop_name, .. } => {
            format!("SetLingoScriptProperty(cast_lib: {}, cast_member: {}, prop: {})", cast_lib, cast_member, prop_name)
        }
        PlayerVMCommand::DispatchFlashEvent { cast_lib, cast_member, handler_name, .. } => {
            format!("DispatchFlashEvent(cast_lib: {}, cast_member: {}, handler: {})", cast_lib, cast_member, handler_name)
        }
    }
}

/// Handle a mouse-down that landed on a `#scroll` field's scrollbar.
///
/// Returns true when the click was consumed. Director's field scrollbar is
/// chrome owned by the player, not the movie: it scrolls the field and the click
/// does not reach the sprite's behaviours or move the caret.
///
/// Click zones follow the standard scrollbar contract — the arrow boxes step by
/// one line, the trough above/below the lift pages by the visible height
/// (Director's `pageHeight`), and pressing the lift starts a drag. `scrollTop`
/// is in pixels per the 11.5 Scripting Dictionary ("the distance, in pixels,
/// from the top of a field cast member to the top of the field that is currently
/// visible in the scrolling box"), so all three move it in pixels.
fn handle_field_scrollbar_mouse_down(
    player: &mut crate::player::DirPlayer,
    x: i32,
    y: i32,
) -> bool {
    use crate::player::score::{find_field_scrollbar_at, get_concrete_sprite_rect};

    let Some((sprite_number, sb)) = find_field_scrollbar_at(player, x, y) else {
        return false;
    };
    let Some(sprite) = player.movie.score.get_sprite(sprite_number) else {
        return false;
    };
    let rect = get_concrete_sprite_rect(player, sprite);
    let ly = y - rect.top;

    let member_ref = sprite.member.clone();
    let scroll_top = member_ref
        .as_ref()
        .and_then(|r| player.movie.cast_manager.find_member_by_ref(r))
        .and_then(|m| match &m.member_type {
            CastMemberType::Field(f) => Some(f.scroll_top as i32),
            _ => None,
        })
        .unwrap_or(0);

    // One "line" for the arrow steps. Use the font size rather than a fixed
    // constant so a large-text field steps by a visible amount.
    let line_h = member_ref
        .as_ref()
        .and_then(|r| player.movie.cast_manager.find_member_by_ref(r))
        .and_then(|m| match &m.member_type {
            CastMemberType::Field(f) => Some(if f.font_size > 0 { f.font_size as i32 } else { 12 }),
            _ => None,
        })
        .unwrap_or(12);

    let thumb = sb.thumb(scroll_top);
    let new_scroll = if ly < sb.y0 + sb.arrow_h {
        scroll_top - line_h
    } else if ly >= sb.y1 - sb.arrow_h {
        scroll_top + line_h
    } else if let Some((ty0, ty1)) = thumb {
        if ly < ty0 {
            scroll_top - sb.page_height
        } else if ly >= ty1 {
            scroll_top + sb.page_height
        } else {
            // On the lift: start a drag, remembering where it was grabbed so it
            // doesn't jump under the pointer.
            player.field_scroll_drag = Some((sprite_number, ly - ty0));
            scroll_top
        }
    } else {
        scroll_top
    };

    set_field_scroll_top(player, sprite_number, new_scroll.clamp(0, sb.max_scroll));
    true
}

/// Write a field's `scrollTop` and invalidate so the next frame re-rasterizes.
fn set_field_scroll_top(player: &mut crate::player::DirPlayer, sprite_number: i16, scroll_top: i32) {
    let member_ref = player
        .movie
        .score
        .get_sprite(sprite_number)
        .and_then(|s| s.member.clone());
    let Some(member_ref) = member_ref else { return };
    if let Some(member) = player.movie.cast_manager.find_mut_member_by_ref(&member_ref) {
        if let CastMemberType::Field(field) = &mut member.member_type {
            let new = scroll_top.max(0) as u16;
            if field.scroll_top != new {
                field.scroll_top = new;
                player.movie.score.invalidate_render_channel_cache();
            }
        }
    }
}

/// Continue an in-progress lift drag. Called from the mouse-move path.
pub fn update_field_scrollbar_drag(player: &mut crate::player::DirPlayer, y: i32) {
    use crate::player::score::{get_concrete_sprite_rect, get_field_scrollbar};

    let Some((sprite_number, grab_offset)) = player.field_scroll_drag else {
        return;
    };
    let Some(sprite) = player.movie.score.get_sprite(sprite_number) else {
        player.field_scroll_drag = None;
        return;
    };
    let Some(sb) = get_field_scrollbar(player, sprite) else {
        player.field_scroll_drag = None;
        return;
    };
    let rect = get_concrete_sprite_rect(player, sprite);
    let ly = y - rect.top;
    let scroll = sb.scroll_for_thumb_top(ly - grab_offset);
    set_field_scroll_top(player, sprite_number, scroll.clamp(0, sb.max_scroll));
}

/// Check if a movie callback script (mouseDownScript, mouseUpScript, etc.)
/// contains actual executable content. Comments like "--nothing" are stored
/// but don't block event propagation in Director.
fn has_executable_callback(callback: &Option<ScriptReceiver>) -> bool {
    match callback {
        Some(ScriptReceiver::ScriptText(text)) => {
            let trimmed = text.trim();
            !trimmed.is_empty() && !trimmed.starts_with("--")
        }
        Some(_) => true, // ScriptInstance or Script refs are always executable
        None => false,
    }
}

pub async fn run_command_loop(rx: Receiver<PlayerVMExecutionItem>) {
    warn!("Starting command loop");

    // Snapshot the player generation this loop belongs to. If the generation
    // changes (another test reset the player), this loop is stale and must
    // exit so it can't mutate the new player's state.
    let generation = unsafe { crate::player::PLAYER_GENERATION };

    while !rx.is_closed() {
        if unsafe { crate::player::PLAYER_GENERATION } != generation {
            warn!("Command loop stopped (generation changed)");
            return;
        }
        let item = match rx.recv().await {
            Ok(item) => item,
            Err(_) => break, // Channel closed (sender dropped)
        };
        if unsafe { crate::player::PLAYER_GENERATION } != generation {
            warn!("Command loop stopped after recv (generation changed)");
            return;
        }
        let consumed_by_navigation = if let Some(origin) = item.mouse_input_origin {
            crate::player::wait_for_handler_gap().await;
            mouse_input_origin_is_stale(origin)
        } else {
            false
        };
        // Physical mouse state was set synchronously by the host. A polling
        // frame handler can consume the click and go() before this queued event
        // gets its turn. Replaying it would target the next screen (DAG01's
        // rooster loop and menu Play both handled the same release).
        let result = if consumed_by_navigation {
            Ok(DatumRef::Void)
        } else {
            run_queued_player_command(item.command).await
        };
        match result {
            Ok(result) => {
                if let Some(completer) = item.completer {
                    completer.complete(Ok(result)).await;
                }
            }
            Err(err) => {
                if err.code == super::ScriptErrorCode::Abort {
                    // abort is a normal control flow mechanism, not an error
                    if let Some(completer) = item.completer {
                        completer.complete(Ok(DatumRef::Void)).await;
                    }
                } else {
                    // TODO ignore error if it's a CancelledException
                    // TODO print stack trace
                    reserve_player_mut(|player| player.on_script_error(&err));
                    if let Some(completer) = item.completer {
                        completer.complete(Err(err)).await;
                    }
                }
            }
        }
    }
    warn!("Command loop stopped!")
}

pub fn player_dispatch(command: PlayerVMCommand) {
    // Route to the ACTIVE player's own command channel (not the global
    // PLAYER_TX) so a nested `#movie` sub-player's commands land in its own
    // queue, processed by its own command loop with its own active-player id.
    // For the main player this is identical (main.queue_tx == the PLAYER_TX
    // channel). Fall back to PLAYER_TX before any player exists (early boot).
    apply_live_mouse_button_state(&command);
    let tx = reserve_player_ref(|p| p.queue_tx.clone());
    let mouse_input_origin = capture_mouse_input_origin(&command);
    if let Err(e) = tx.try_send(PlayerVMExecutionItem {
        command,
        completer: None,
        mouse_input_origin,
    }) {
        // The channel is closed or full
        eprintln!("Failed to send command to player: {:?}", e);
    }
}

#[allow(dead_code)]
pub async fn player_dispatch_async(command: PlayerVMCommand) -> Result<DatumRef, ScriptError> {
    apply_live_mouse_button_state(&command);
    let tx = unsafe { PLAYER_TX.clone() }.unwrap();
    let (future, completer) = ManualFuture::new();
    let mouse_input_origin = capture_mouse_input_origin(&command);
    let item = PlayerVMExecutionItem {
        command,
        completer: Some(completer),
        mouse_input_origin,
    };
    tx.send(item).await.unwrap();
    future.await
}

fn capture_mouse_input_origin(command: &PlayerVMCommand) -> Option<(u64, u32)> {
    if !matches!(command, PlayerVMCommand::MouseDown(_) | PlayerVMCommand::MouseUp(_)) {
        return None;
    }
    reserve_player_ref(|p| {
        (p.handler_stack_depth > 0 || !p.is_yield_safe())
            .then_some((p.movie_mount_generation, p.movie.current_frame))
    })
}

fn mouse_input_origin_is_stale(origin: (u64, u32)) -> bool {
    reserve_player_ref(|p| origin != (p.movie_mount_generation, p.movie.current_frame))
}

#[cfg(test)]
mod polled_mouse_input_tests {
    use super::*;
    use crate::player::testing::{run_test, TestPlayer};

    #[test]
    fn only_mouse_events_queued_during_lingo_follow_their_original_frame() {
        run_test(async {
            let _p = TestPlayer::new();
            let mouse = PlayerVMCommand::MouseUp((410, 452));
            assert!(capture_mouse_input_origin(&mouse).is_none());
            reserve_player_mut(|p| {p.handler_stack_depth = 1;p.movie.current_frame = 4;});
            let origin = capture_mouse_input_origin(&mouse).unwrap();
            assert!(!mouse_input_origin_is_stale(origin));
            assert!(capture_mouse_input_origin(&PlayerVMCommand::KeyUp("x".into(), 7)).is_none());
            reserve_player_mut(|p| p.movie.current_frame = 15);
            assert!(mouse_input_origin_is_stale(origin));
            reserve_player_mut(|p| {p.movie.current_frame = 4;p.movie_mount_generation += 1;});
            assert!(mouse_input_origin_is_stale(origin));
        });
    }

    #[test]
    fn delayed_mouse_dispatch_does_not_replay_superseded_button_state() {
        run_test(async {
            let _p = TestPlayer::new();
            reserve_player_mut(|p| p.is_playing = true);
            let press = PlayerVMCommand::MouseDown((210, 445));
            let release = PlayerVMCommand::MouseUp((210, 445));
            // Both physical events arrive while narration is busy. The queued
            // press handler must see UP, or repeat-while-mouseDown deadlocks
            // the release command queued behind that handler (Findus KONSTR02).
            apply_live_mouse_button_state(&press);
            apply_live_mouse_button_state(&release);
            run_queued_player_command(press).await.unwrap();
            assert!(!reserve_player_ref(|p| p.movie.mouse_down));

            // Likewise, a delayed release must not release a newer press.
            apply_live_mouse_button_state(&PlayerVMCommand::MouseDown((220, 450)));
            run_queued_player_command(release).await.unwrap();
            assert!(reserve_player_ref(|p| p.movie.mouse_down));
        });
    }
}

/// Direct callers (including native input tests) deliver physical state now.
/// Queued commands have already delivered it when enqueued and must not replay it.
pub async fn run_player_command(command: PlayerVMCommand) -> Result<DatumRef, ScriptError> {
    apply_live_mouse_button_state(&command);
    run_queued_player_command(command).await
}

fn apply_live_mouse_button_state(command: &PlayerVMCommand) {
    let down = match command {
        PlayerVMCommand::MouseDown(_) => true,
        PlayerVMCommand::MouseUp(_) => false,
        _ => return,
    };
    reserve_player_mut(|p| p.movie.mouse_down = down);
}

async fn run_queued_player_command(command: PlayerVMCommand) -> Result<DatumRef, ScriptError> {
    // Snapshot the generation this command belongs to. `player_wait_available`
    // yields, and during that yield a new test can reset the player (bumping
    // PLAYER_GENERATION). If that happens, this command is stale — executing
    // it would mutate the new player's state (unbalancing scope push/pop,
    // leaking timeouts, etc.). Bail with Abort so the outer command loop
    // treats it as a normal cancellation.
    let generation_at_entry = unsafe { crate::player::PLAYER_GENERATION };
    player_wait_available().await;
    if unsafe { crate::player::PLAYER_GENERATION } != generation_at_entry {
        return Err(crate::player::ScriptError::new_code(
            crate::player::ScriptErrorCode::Abort,
            "Command cancelled: player generation changed (test reset)".to_string(),
        ));
    }
    match command {
        PlayerVMCommand::SetExternalParams(params) => {
            reserve_player_mut(|player| {
                player.external_params = params;
                crate::player::stage::apply_stage_draw_rect(player);
                let (w, h) = crate::player::stage::stage_canvas_dims(player);
                crate::js_api::JsApi::dispatch_stage_size_changed(w, h, player.center_stage);
            });
        }
        PlayerVMCommand::SetBasePath(path) => {
            reserve_player_mut(|player| {
                player.net_manager.set_base_path(Url::parse(&path)
                    .expect(&format!("Invalid base path URL: '{}'", path)));
            });
        }
        PlayerVMCommand::SetStartupDo(code) => {
            reserve_player_mut(|player| {
                player.startup_do = if code.is_empty() { None } else { Some(code) };
            });
        }
        PlayerVMCommand::SetStartupDoBefore(code) => {
            reserve_player_mut(|player| {
                player.startup_do_before = if code.is_empty() { None } else { Some(code) };
            });
        }
        PlayerVMCommand::SetStartupGo(frame) => {
            reserve_player_mut(|player| {
                player.startup_go = if frame == 0 { None } else { Some(frame) };
            });
        }
        PlayerVMCommand::SetMoviePathOverride(path) => {
            reserve_player_mut(|player| {
                player.movie_path_override = if path.is_empty() { None } else { Some(path) };
            });
        }
        PlayerVMCommand::SetMoviePathLabel(path) => {
            reserve_player_mut(|player| {
                player.movie_path_label = if path.is_empty() { None } else { Some(path) };
            });
        }
        PlayerVMCommand::SetSystemFontPath(path) => {
            console_warn!("Loading system font: {}", path);
            player_load_system_font(&path).await;
        }
        PlayerVMCommand::LoadMovieFromFile(file_path, autoplay) => {
            // `--doBefore` runs "in the scope of the game being curated BEFORE
            // it has been loaded" (SPR README), so it goes here rather than in
            // `run_movie_init_sequence` where `--do` lives.
            crate::player::run_startup_do_before().await;
            let player = unsafe { crate::player::player_mut() };
            match player.load_movie_from_file(&file_path).await {
                Ok(()) => {
                    if autoplay {
                        player.play();
                    }
                }
                Err(err) => {
                    JsApi::dispatch_movie_load_failed(&file_path, &err);
                }
            }
        }
        PlayerVMCommand::SetStageSize(width, height) => {
            reserve_player_mut(|player| {
                player.stage_size = (width, height);
                crate::player::stage::apply_stage_draw_rect(player);
                let (w, h) = crate::player::stage::stage_canvas_dims(player);
                crate::js_api::JsApi::dispatch_stage_size_changed(w, h, player.center_stage);
            });
        }
        PlayerVMCommand::TimeoutTriggered(timeout_ref) => {
            let (is_found, is_playing, is_script_paused, target_ref, handler_name, timeout_name) =
                reserve_player_mut(|player| {
                    if let Some(timeout) = player.timeout_manager.get_timeout(&timeout_ref) {
                        let is_playing = player.is_playing;
                        let is_script_paused = player.is_script_paused;
                        (
                            true,
                            is_playing,
                            is_script_paused,
                            timeout.target_ref.clone(),
                            timeout.handler.to_owned(),
                            timeout.name.to_owned(),
                        )
                    } else {
                        (
                            false,
                            false,
                            false,
                            DatumRef::Void,
                            Symbol::builtin(BuiltInSymbol::EmptyString),
                            "".to_string(),
                        )
                    }
                });
            if !is_found {
                warn!("Timeout triggered but not found: {}", timeout_ref);
                return Ok(DatumRef::Void);
            }
            if !is_playing || is_script_paused {
                // TODO how to handle is_script_paused?
                warn!("Timeout triggered but not playing");
                return Ok(DatumRef::Void);
            }
            let timeout_name_for_args = timeout_name.clone();
            let ref_datum = player_alloc_datum(Datum::TimeoutRef(timeout_name));
            let args = vec![ref_datum];
            // Director 11.5 Scripting Dictionary, `new()` (Timeout): the
            // targetObject "indicates which CHILD OBJECT's handler should be
            // called ... If you omit this parameter, Director looks for the
            // specified handler in the movie script."
            //
            // A target that is NOT an object can't receive a method call, so
            // Director falls back to the movie script and passes the target
            // through as the first argument. AreaZero's Event Manager relies on
            // this: it creates
            //     timeout().new(tName, pDelay, #DelayEventTimeOut, pevent)
            // with pevent a STRING, and its handler is declared
            //     on DelayEventTimeOut tEvent, tTimeOut
            // i.e. (target, timeoutObject). Dispatching the handler ON the
            // string raised "No handler DelayEventTimeOut for string datum".
            let target_is_object = reserve_player_ref(|player| {
                matches!(
                    player.get_datum(&target_ref),
                    Datum::ScriptInstanceRef(_)
                )
            });
            if target_is_object {
                player_dispatch_callback_event(target_ref, handler_name, &args);
            } else if target_ref != DatumRef::Void {
                let mut args = vec![target_ref];
                args.extend(
                    [player_alloc_datum(Datum::TimeoutRef(timeout_name_for_args))]
                );
                player_dispatch_global_event(handler_name, &args);
            } else {
                player_dispatch_global_event(handler_name, &args);
            }
        }
        PlayerVMCommand::PrintMemberBitmapHex(member_ref) => {
            reserve_player_ref(|player| {
                let member = player
                    .movie
                    .cast_manager
                    .find_member_by_ref(&member_ref)
                    .unwrap();
                let bitmap = member.member_type.as_bitmap().unwrap();
                let bitmap = player.bitmap_manager.get_bitmap(bitmap.image_ref).unwrap();
                let bitmap = &bitmap.data;
                warn!("Bitmap hex: {}", bitmap.to_hex_string());
            });
        }
        PlayerVMCommand::PlayMemberSound(member_ref) => {
            use crate::player::handlers::datum_handlers::sound_channel::SoundChannelDatumHandlers;
            let (cl, cm) = (member_ref.cast_lib, member_ref.cast_member);
            reserve_player_mut(|player| {
                let is_sound = player
                    .movie
                    .cast_manager
                    .find_member_by_ref(&member_ref)
                    .map(|m| matches!(m.member_type, CastMemberType::Sound(_)))
                    .unwrap_or(false);
                if !is_sound {
                    console_warn!("[sound-preview] member {}:{} is not a sound member", cl, cm);
                    return;
                }
                let member_datum = player.alloc_datum(Datum::CastMember(member_ref));
                // Preview on channel 1 (Director's default puppetSound channel).
                // Always play ONCE here, ignoring the member's loop flag, so a
                // looping member doesn't run forever from the dev-UI preview.
                let channel = match player.get_sound_channel(1) {
                    Ok(ch) => ch,
                    Err(e) => {
                        console_warn!("[sound-preview] no channel for {}:{}: {}", cl, cm, e.message);
                        return;
                    }
                };
                if let Err(e) =
                    SoundChannelDatumHandlers::handle_play_file(player, &channel, &member_datum, 1)
                {
                    console_warn!("[sound-preview] play failed for {}:{}: {}", cl, cm, e.message);
                }
            });
        }
        PlayerVMCommand::MouseDown((x, y)) => {
            crate::player::wait_for_handler_gap().await;
            crate::player::hold_draw_for_input_handler();
            if !player_is_playing().await {
                return Ok(DatumRef::Void);
            }
            // In Director, mouseDownScript intercepts BEFORE sprites get the event.
            // Only block when it contains executable content (not just a comment).
            // Comments like "--nothing" are stored but don't block propagation.
            let mouse_down_script_active = reserve_player_ref(|player| {
                has_executable_callback(&player.movie.mouse_down_script)
            });
            // Capture click timestamp BEFORE the stepFrame flush below. The flush is
            // async and variable in length (CS rooms have 50+ FurnitureItems in
            // actorList, plus IsoScene.processRoomRollover doing pixel hit-tests),
            // so reading `now` after it would add the flush duration to the
            // inter-click delta and a fast double-click could be misclassified as
            // two single clicks. CS's ACTION_TIMED_ANIMATION (and similar) reads
            // `the doubleClick` to gate `toggleState()`, so a wrong flag silently
            // breaks every animation-toggling action.
            let click_now = chrono::Utc::now().timestamp_millis().abs();
            // Flush actorList stepFrame so cached rollover state (e.g. oMouseSquare)
            // is fresh before the mouseDown handler reads it. On mobile/touch there's
            // no prior mouse_move, so stepFrame hasn't run at the tap position yet.
            // mouse_loc is already set synchronously by the JS-side mouse_down() call.
            {
                let actor_snapshot = reserve_player_ref(|player| {
                    player.actor_list_stepframe_snapshot()
                });
                for (_idx, actor_ref) in actor_snapshot.0.iter().enumerate() {
                    if actor_snapshot.1.contains(&actor_ref.unwrap()) {
                        let _ = player_call_datum_handler(
                            actor_ref, Symbol::builtin(BuiltInSymbol::StepFrame), &vec![],
                        ).await;
                    }
                }
            }

            // `the mouseDownScript` (if set) runs at the END of the
            // mouseDown pipeline, alongside sprite/cast/frame dispatch.
            // We deliberately do NOT short-circuit the sprite dispatch
            // when this script is set — Director's docs say mouseDownScript
            // suppresses sprite handlers unless the script calls pass(),
            // but real movies (e.g. ClubMarian's `checkMouse` global
            // observer that early-returns on most frames) rely on sprite
            // handlers firing regardless. See the post-sprite-dispatch
            // callback at the end of this branch.
            let _ = mouse_down_script_active;

            // A click inside a #scroll field's scrollbar drives the scrollbar and
            // goes no further — Director's field chrome consumes it rather than
            // passing it to the sprite's scripts or moving the caret. Tested
            // BEFORE the normal sprite lookup because that lookup applies
            // `is_click_transparent_sprite`, which makes a non-editable field
            // click-through; the scrollbar must stay live regardless.
            let scrollbar_consumed = reserve_player_mut(|player| {
                player.mouse_loc = (x, y);
                player.movie.click_loc = (x, y);
                handle_field_scrollbar_mouse_down(player, x, y)
            });
            if scrollbar_consumed {
                return Ok(DatumRef::Void);
            }

            // Use scripted=true so only sprites with scripts (behavior or cast member)
            // are detected. Non-scripted sprites (decorations, overlays) are skipped,
            // matching Director behavior.
            reserve_player_mut(|player| {
                let is_double_click = (click_now - player.last_mouse_down_time) < 500;
                player.mouse_loc = (x, y);
                player.movie.click_loc = (x, y);
                player.is_double_click = is_double_click;
                player.last_mouse_down_time = click_now;

                // Director's clickOn records the highest ACTIVE sprite, not
                // arbitrary decoration. Otherwise a script-drawn brush cursor
                // (Findus DAG22 sprite31) masks every paint pot it hovers over.
                // Moveable sprites count as active even without behaviors.
                let any_sprite = get_sprite_at(player, x, y, true);
                if let Some(sprite_number) = any_sprite {
                    player.click_on_sprite = sprite_number as i16;
                    // Capture drag offset for moveable sprites (so sprite doesn't jump to cursor)
                    if let Some(sprite) = player.movie.score.get_sprite(sprite_number as i16) {
                        if sprite.moveable {
                            player.drag_offset = (sprite.loc_h - x, sprite.loc_v - y);
                        }
                    }
                    let sprite = player.movie.score.get_sprite(sprite_number as i16);
                    let sprite_member = sprite
                        .and_then(|x| x.member.as_ref())
                        .and_then(|x| player.movie.cast_manager.find_member_by_ref(&x));
                    if let Some(sprite_member) = sprite_member {
                        // Four cases where a clicked sprite should become the
                        // keyboardFocusSprite (so subsequent keyDown events route
                        // through it):
                        //   - `field.editable` / `text.info.editable` from the file
                        //   - `the editable of sprite` set at runtime
                        //   - The sprite has a behaviour with a `keyDown` handler
                        //     (fake-input pattern: a non-editable text member with
                        //     a sprite behaviour that traps keyDown and renders its
                        //     own buffer into `myMember.text`, e.g. spineworld_dcr's
                        //     `formscript` on the password fields).
                        let member_editable = match &sprite_member.member_type {
                            CastMemberType::Field(f) => f.editable,
                            CastMemberType::Text(t) => t.info.as_ref().map_or(false, |i| i.editable),
                            _ => false,
                        };
                        let sprite_editable = sprite
                            .map(|s| s.editable)
                            .unwrap_or(false);
                        let has_keydown = sprite
                            .map(|s| crate::player::score::sprite_has_handler(player, s, &["keyDown", "keyUp"]))
                            .unwrap_or(false);
                        if sprite_editable || member_editable || has_keydown {
                            player.keyboard_focus_sprite = sprite_number as i16;
                        }
                    }

                    // Toggle hilite for button members on mouseDown
                    if let Some(sprite) = player.movie.score.get_sprite(sprite_number as i16) {
                        if let Some(member_ref) = sprite.member.clone() {
                            if let Some(member) = player.movie.cast_manager.find_mut_member_by_ref(&member_ref) {
                                match &mut member.member_type {
                                    CastMemberType::Button(button) => {
                                        match button.button_type {
                                            crate::player::cast_member::ButtonType::PushButton => {
                                                button.hilite = true;
                                            }
                                            crate::player::cast_member::ButtonType::CheckBox => {
                                                button.hilite = !button.hilite;
                                            }
                                            crate::player::cast_member::ButtonType::RadioButton => {
                                                button.hilite = true;
                                            }
                                        }
                                    }
                                    _ => {}
                                }
                            }
                        }
                    }
                } else {
                    player.click_on_sprite = 0;
                }

                // For event dispatch targeting, use scripted lookup —
                // only sprites with behaviors or cast member scripts receive mouseDown.
                let scripted_sprite = crate::player::score::get_mouse_sprite_at(player, x, y);
                if let Some(sprite_number) = scripted_sprite {
                    player.mouse_down_sprite = sprite_number as i16;
                } else {
                    player.mouse_down_sprite = -1;
                }
                debug!(
                    "[mouseDown] mouse_down_sprite={} (scripted lookup at {},{})",
                    player.mouse_down_sprite, x, y
                );
            });

            // If the click landed on a Flash sprite, forward the press into
            // the SWF so its own AS1 `on (press)` / button handlers run.
            // Director normally delivers these by passing the event straight
            // through to the embedded Flash player; in our setup Ruffle's
            // canvas is offscreen so the click never reaches it organically.
            // Use unscripted lookup here — Flash members don't always carry
            // a Director-side behaviour, but their internal buttons still
            // need the event.
            let (flash_forward, debug_info) = reserve_player_ref(|player| {
                let any_sprite = get_sprite_at(player, x, y, false);
                if any_sprite.is_none() {
                    return (None, format!("no sprite at ({},{})", x, y));
                }
                let any_sprite = any_sprite.unwrap();
                let sprite = match player.movie.score.get_sprite(any_sprite as i16) {
                    Some(s) => s,
                    None => return (None, format!("sprite#{} not found", any_sprite)),
                };
                let member_ref = match sprite.member.as_ref() {
                    Some(m) => m,
                    None => return (None, format!("sprite#{} has no member", any_sprite)),
                };
                let member = match player.movie.cast_manager.find_member_by_ref(member_ref) {
                    Some(m) => m,
                    None => return (None, format!("member {:?} not resolvable", member_ref)),
                };
                let type_str = member.member_type.type_string();
                if !matches!(member.member_type, CastMemberType::Flash(_)) {
                    return (None, format!("sprite#{} member type='{}' (not Flash)", any_sprite, type_str));
                }
                let rect = super::score::get_concrete_sprite_rect(player, sprite);
                (
                    Some((any_sprite as i32, x - rect.left, y - rect.top, rect.right - rect.left, rect.bottom - rect.top)),
                    format!("Flash sprite#{} member={}:{} rect=({},{})-({},{})",
                        any_sprite, member_ref.cast_lib, member_ref.cast_member,
                        rect.left, rect.top, rect.right, rect.bottom),
                )
            });
            debug!("[Flash mouseDown] click@({},{}) → {}", x, y, debug_info);

            // Diagnostic: dump the script names attached to the clicked sprite
            // so we can see what behaviours (if any) have a chance to handle
            // mouseUp. If the list is empty / has no on mouseUp, clicking is a
            // no-op regardless of Flash forwarding.
            let sprite_scripts_dump = reserve_player_ref(|player| {
                let any_sprite = match get_sprite_at(player, x, y, false) {
                    Some(s) => s,
                    None => return "none".to_string(),
                };
                let sprite = match player.movie.score.get_sprite(any_sprite as i16) {
                    Some(s) => s,
                    None => return format!("sprite#{} missing", any_sprite),
                };
                let names: Vec<String> = sprite
                    .script_instance_list
                    .iter()
                    .map(|inst_ref| {
                        let inst = player.allocator.get_script_instance(inst_ref);
                        let script = player.movie.cast_manager.get_script_by_ref(&inst.script);
                        let script_name = script.map(|s| s.name.clone()).unwrap_or_else(|| "?".to_string());
                        let handlers = script
                            .map(|s| {
                                s.handlers
                                    .iter()
                                    .map(|(name, _def)| name.to_string())
                                    .collect::<Vec<_>>()
                                    .join(",")
                            })
                            .unwrap_or_default();
                        format!("{}({}/{}: handlers=[{}])",
                            script_name,
                            inst.script.cast_lib, inst.script.cast_member,
                            handlers)
                    })
                    .collect();
                if names.is_empty() {
                    format!("sprite#{} has 0 behaviours", any_sprite)
                } else {
                    format!("sprite#{} behaviours: {}", any_sprite, names.join(" | "))
                }
            });
            debug!("[click sprite scripts] {}", sprite_scripts_dump);
            if let Some((sn, lx, ly, sw, sh)) = flash_forward {
                // AVM1 button hit-testing reads the stage-mouse position
                // that's last updated by MouseMove. A real browser always
                // emits pointermove before pointerdown, so the position is
                // current. Our injected MouseDown alone leaves the stage
                // mouse at its previous location (often 0,0 if no organic
                // input ever reached the SWF), and Ruffle's button test
                // misses the click. Send a MouseMove first to seed it.
                let _ = super::handlers::datum_handlers::flash_object::ruffle_dispatch_mouse_event_global(
                    sn, "move", lx, ly, sw, sh,
                );
                let _ = super::handlers::datum_handlers::flash_object::ruffle_dispatch_mouse_event_global(
                    sn, "down", lx, ly, sw, sh,
                );
            }

            // Temporarily clear ALL is_yield_safe() flags so that updateStage()
            // called from within mouseDown handlers will render (but not yield).
            // MouseDown commands can be processed at any .await point in the frame
            // loop, where multiple flags may be true simultaneously (e.g.
            // is_in_frame_update AND in_enter_frame during enterFrame dispatch).
            // Set in_mouse_command so the frame loop skips frame updates/advancement
            // and updateStage renders without sleeping (preventing re-entrant event
            // dispatch and timing issues with mouseUp processing).
            let saved_yield_flags = reserve_player_mut(|player| {
                let saved = (
                    player.is_in_frame_update,
                    player.in_frame_script,
                    player.in_enter_frame,
                    player.in_prepare_frame,
                    player.in_event_dispatch,
                    player.in_mouse_command,
                );
                player.is_in_frame_update = false;
                player.in_frame_script = false;
                player.in_enter_frame = false;
                player.in_prepare_frame = false;
                player.in_event_dispatch = false;
                player.in_mouse_command = true;
                saved
            });

            // Dispatch to sprite behaviors if the sprite has any, otherwise
            // fall through to frame/movie scripts per Director's propagation chain.
            let sprite_with_behaviors = reserve_player_ref(|player| {
                if player.mouse_down_sprite > 0 {
                    let sprite = player.movie.score.get_sprite(player.mouse_down_sprite);
                    let has_behaviors = sprite.map_or(false, |s| {
                        player.sprite_has_script_instance_ids(
                            player.mouse_down_sprite,
                            s.script_instance_list.as_slice(),
                        )
                    });
                    if has_behaviors {
                        return Some(player.mouse_down_sprite as u16);
                    }
                }
                None
            });

            // A behavior that calls stopEvent() also blocks the cast member
            // script — the message hierarchy stops there (Director 11.5
            // Scripting Dictionary, `stopEvent()`).
            let mut event_stopped = false;
            if let Some(sprite_num) = sprite_with_behaviors {
                event_stopped = player_dispatch_event_to_sprite_targeted(
                    Symbol::builtin(BuiltInSymbol::MouseDown),
                    &vec![],
                    sprite_num,
                ).await;
            } else {
                player_invoke_frame_and_movie_scripts(
                    Symbol::builtin(BuiltInSymbol::MouseDown),
                    &vec![]
                ).await?;
            }

            // Execute cast member script if it exists
            let cast_member_script_call = reserve_player_mut(|player| {
                if event_stopped || player.mouse_down_sprite <= 0 {
                    return None;
                }

                let sprite = player.movie.score.get_sprite(player.mouse_down_sprite)?;
                let member_ref = sprite.member.as_ref()?;
                let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;

                // First check for member behavior script (stored in member_script_ref)
                if let Some(script_ref) = member.get_member_script_ref() {
                    debug!(
                        "Cast member '{}' has behavior script (cast_lib={}, member={}), executing mouseDown",
                        member.name, script_ref.cast_lib, script_ref.cast_member
                    );

                    if let Some(script) = player.movie.cast_manager.get_script_by_ref(script_ref) {
                        if let Some(handler) = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::MouseDown)) {
                            return Some((None, handler, vec![]));
                        }
                    }
                }

                // Fallback: check for script_id and get directly from lctx.scripts
                let script_id = member.get_script_id()?;

                debug!(
                    "Cast member '{}' has script {}, getting from lctx.scripts for mouseDown",
                    member.name, script_id
                );

                let script = {
                    let cast_lib = player.movie.cast_manager.get_cast_mut(member_ref.cast_lib as u32);
                    cast_lib.get_behavior_script_from_lctx(script_id)
                };

                let script = match script {
                    Some(s) => {
                       debug!("Behavior script {} found for mouseDown", script_id);
                        s
                    }
                    None => {
                        debug!("Behavior script {} NOT FOUND in lctx.scripts for mouseDown", script_id);
                        return None;
                    }
                };

                let handler = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::MouseDown))?;

                Some((None, handler, vec![]))
            });

            let mut handler_err: Option<ScriptError> = None;
            if let Some((receiver, handler, args)) = cast_member_script_call {
                if let Err(e) = player_call_script_handler(receiver, handler, &args).await {
                    handler_err = Some(e);
                }
            }

            // Dispatch mouseDownScript last as well (for cases where it was set
            // during sprite handler execution, e.g. not set at start of event)
            if handler_err.is_none() {
                if let Err(e) = player_dispatch_movie_callback(BuiltInSymbol::MouseDown).await {
                    handler_err = Some(e);
                }
            }

            // Restore all is_yield_safe() flags and in_mouse_command
            // MUST happen even on error to prevent skip_frame getting stuck
            reserve_player_mut(|player| {
                player.is_in_frame_update = saved_yield_flags.0;
                player.in_frame_script = saved_yield_flags.1;
                player.in_enter_frame = saved_yield_flags.2;
                player.in_prepare_frame = saved_yield_flags.3;
                player.in_event_dispatch = saved_yield_flags.4;
                player.in_mouse_command = saved_yield_flags.5;
            });

            if let Some(e) = handler_err {
                return Err(e);
            }
            return Ok(DatumRef::Void);
        }
        PlayerVMCommand::MouseUp((x, y)) => {
            crate::player::wait_for_handler_gap().await;
            crate::player::hold_draw_for_input_handler();
            if !player_is_playing().await {
                return Ok(DatumRef::Void);
            }
            // `the mouseUpScript` (if set) is dispatched at the END of the
            // mouseUp pipeline (post-sprite/cast/frame), via the existing
            // player_dispatch_movie_callback call further below. We
            // deliberately do NOT short-circuit sprite dispatch here even
            // when mouseUpScript is set — Director's docs say the script
            // suppresses sprite handlers unless it explicitly calls pass(),
            // but real movies (e.g. ClubMarian's `checkMouse` global
            // observer that early-returns on most frames) rely on sprite
            // mouseUp behaviors firing regardless. Without this, every
            // button in such movies is silent.

            // A lift drag ends on release and swallows the mouseUp, matching the
            // mouseDown that started it (the scrollbar is player chrome, not
            // something the movie's scripts see).
            let was_scroll_drag = reserve_player_mut(|player| {
                if player.field_scroll_drag.take().is_some() {
                    true
                } else {
                    false
                }
            });
            if was_scroll_drag {
                return Ok(DatumRef::Void);
            }

            // Update mouse state and determine which sprite to notify
            let result = reserve_player_mut(|player| {
                player.mouse_loc = (x, y);
                let sprite_num_to_notify = player.mouse_down_sprite;

                // Reset hilite for push buttons on mouseUp
                if player.mouse_down_sprite > 0 {
                    if let Some(sprite) = player.movie.score.get_sprite(player.mouse_down_sprite) {
                        if let Some(member_ref) = sprite.member.clone() {
                            if let Some(member) = player.movie.cast_manager.find_mut_member_by_ref(&member_ref) {
                                if let CastMemberType::Button(button) = &mut member.member_type {
                                    if button.button_type == crate::player::cast_member::ButtonType::PushButton {
                                        button.hilite = false;
                                    }
                                }
                            }
                        }
                    }
                }

                let sprite = if player.mouse_down_sprite > 0 {
                    player.movie.score.get_sprite(player.mouse_down_sprite)
                } else {
                    None
                };
                player.mouse_down_sprite = -1;
                if let Some(sprite) = sprite {
                    let is_inside = concrete_sprite_hit_test(player, sprite, x, y);
                    Some((sprite.script_instance_list.clone(), is_inside, sprite_num_to_notify))
                } else {
                    None
                }
            });
            let is_inside = result.as_ref().map(|x| x.1).unwrap_or(true);
            let event_name = if is_inside {
                "mouseUp"
            } else {
                "mouseUpOutSide"
            };

            // Temporarily clear ALL is_yield_safe() flags so that updateStage()
            // called from within mouseUp handlers will render (but not yield).
            // Same rationale as mouseDown: multiple flags may be true when
            // the mouseUp command is processed at a frame loop .await point.
            // Set in_mouse_command to prevent re-entrant frame updates and
            // make updateStage synchronous (render-only, no sleep).
            let saved_yield_flags = reserve_player_mut(|player| {
                let saved = (
                    player.is_in_frame_update,
                    player.in_frame_script,
                    player.in_enter_frame,
                    player.in_prepare_frame,
                    player.in_event_dispatch,
                    player.in_mouse_command,
                );
                player.is_in_frame_update = false;
                player.in_frame_script = false;
                player.in_enter_frame = false;
                player.in_prepare_frame = false;
                player.in_event_dispatch = false;
                player.in_mouse_command = true;
                saved
            });

            // Mirror the mouseDown forwarding: if the cursor is currently
            // over a Flash sprite, hand the release into Ruffle so the SWF's
            // own AS1 button handlers (`on (release)`) can fire. Uses the
            // current cursor position — AS1 buttons need press+release on the
            // same Flash member to register a click, so resolving by cursor
            // position handles the common click-and-release-in-place case.
            // (releaseOutside semantics for drag-off-the-button can be added
            // later by tracking the press sprite separately.)
            let flash_forward_up = reserve_player_ref(|player| {
                let any_sprite = get_sprite_at(player, x, y, false)?;
                let sprite = player.movie.score.get_sprite(any_sprite as i16)?;
                let member_ref = sprite.member.as_ref()?;
                let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;
                if !matches!(member.member_type, CastMemberType::Flash(_)) {
                    return None;
                }
                let rect = super::score::get_concrete_sprite_rect(player, sprite);
                Some((any_sprite as i32, x - rect.left, y - rect.top, rect.right - rect.left, rect.bottom - rect.top))
            });
            if let Some((sn, lx, ly, sw, sh)) = flash_forward_up {
                // Same MouseMove-before-MouseUp seeding as the down handler.
                let _ = super::handlers::datum_handlers::flash_object::ruffle_dispatch_mouse_event_global(
                    sn, "move", lx, ly, sw, sh,
                );
                let _ = super::handlers::datum_handlers::flash_object::ruffle_dispatch_mouse_event_global(
                    sn, "up", lx, ly, sw, sh,
                );
            }

            // Dispatch to the sprite that originally received mouseDown,
            // or fall through to frame/movie scripts if no sprite was involved.
            let mut event_stopped = false;
            let dispatched_to_sprite = if let Some((_, _, sprite_num)) = result.as_ref() {
                debug!("[mouseUp] dispatching to sprite#{} (event={})", sprite_num, event_name);
                if *sprite_num > 0 {
                    event_stopped = player_dispatch_event_to_sprite_targeted(
                        Symbol::from_str(event_name),
                        &vec![],
                        *sprite_num as u16,
                    ).await;
                    true
                } else {
                    false
                }
            } else {
                debug!("[mouseUp] no sprite to dispatch to (result was None)");
                false
            };

            if !dispatched_to_sprite {
                player_invoke_frame_and_movie_scripts(
                    Symbol::builtin(BuiltInSymbol::MouseUp),
                    &vec![]
                ).await;
            }

            // Execute cast member script using the ORIGINAL sprite that had mouseDown,
            // consistent with Director behavior
            let cast_member_script_call = reserve_player_mut(|player| {
                let sprite_num_to_notify = result.as_ref().map(|r| r.2).unwrap_or(-1);
                // stopEvent() in a behavior halts the hierarchy here too.
                if event_stopped || sprite_num_to_notify <= 0 {
                    return None;
                }

                let sprite = player.movie.score.get_sprite(sprite_num_to_notify)?;
                let member_ref = sprite.member.as_ref()?;
                let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;

                let handler_name = if is_inside { "mouseUp" } else { "mouseUpOutSide" };

                // First check for member behavior script (stored in member_script_ref)
                if let Some(script_ref) = member.get_member_script_ref() {
                    if let Some(script) = player.movie.cast_manager.get_script_by_ref(script_ref) {
                        if let Some(handler) = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::MouseUp)) {
                            return Some((None, handler, vec![]));
                        }
                    }
                }

                // Fallback: check for script_id and get directly from lctx.scripts
                let script_id = member.get_script_id()?;

                let script = {
                    let cast_lib = player.movie.cast_manager.get_cast_mut(member_ref.cast_lib as u32);
                    cast_lib.get_behavior_script_from_lctx(script_id)
                };

                let script = script?;
                let handler = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::MouseUp))?;

                // Try to get the handler
                let handler = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::MouseUp));
                
                // ADD THIS CHECK:
                if handler.is_none() {
                    debug!("⚠️  Handler '{}' NOT FOUND in script {}", handler_name, script_id);
                    return None;
                }
                
                debug!("✓ Handler '{}' found!", handler_name);
                
                Some((None, handler.unwrap(), vec![]))
            });

            let mut handler_err: Option<ScriptError> = None;
            if let Some((receiver, handler, args)) = cast_member_script_call {
                if let Err(e) = player_call_script_handler(receiver, handler, &args).await {
                    handler_err = Some(e);
                }
            }

            if handler_err.is_none() {
                if let Err(e) = player_dispatch_movie_callback(BuiltInSymbol::MouseUp).await {
                    handler_err = Some(e);
                }
            }

            // Restore all is_yield_safe() flags and command_handler_yielding
            // MUST happen even on error to prevent skip_frame getting stuck
            reserve_player_mut(|player| {
                player.is_in_frame_update = saved_yield_flags.0;
                player.in_frame_script = saved_yield_flags.1;
                player.in_enter_frame = saved_yield_flags.2;
                player.in_prepare_frame = saved_yield_flags.3;
                player.in_event_dispatch = saved_yield_flags.4;
                player.in_mouse_command = saved_yield_flags.5;
                player.is_double_click = false;
            });

            if let Some(e) = handler_err {
                return Err(e);
            }
            return Ok(DatumRef::Void);
        }
        PlayerVMCommand::MouseMove((x, y), mouse_was_down) => {
            if !player_is_playing().await {
                return Ok(DatumRef::Void);
            }
            reserve_player_mut(|player| {
                player.mouse_loc = (x, y);

                // Continue a field lift drag before anything else — it owns the
                // pointer until release.
                if player.field_scroll_drag.is_some() {
                    update_field_scrollbar_drag(player, y);
                }

                // A hover queued before mouseDown must not turn into a drag merely
                // because the host has already updated the live button state.
                // Drag moveable sprites (use click_on_sprite, not mouse_down_sprite,
                // since moveable sprites don't need scripts to be draggable)
                if mouse_was_down && player.click_on_sprite > 0 {
                    let drag_sprite_num = player.click_on_sprite;
                    let (off_x, off_y) = player.drag_offset;
                    let sprite = player.movie.score.get_sprite_mut(drag_sprite_num);
                    if sprite.moveable {
                        let mut new_h = x + off_x;
                        let mut new_v = y + off_y;

                        // Constraint bounds only apply to Shockwave3D members.
                        // Regular 2D sprites can be dragged freely; bounds-clamping
                        // them caused puzzle pieces to lock to a small area.
                        let is_3d_member = sprite.member.as_ref()
                            .and_then(|mref| player.movie.cast_manager.find_member_by_ref(mref))
                            .map_or(false, |m| matches!(
                                m.member_type,
                                CastMemberType::Shockwave3d(_)
                            ));
                        if is_3d_member {
                            let sprite = player.movie.score.get_sprite(drag_sprite_num).unwrap();
                            let constraint_num = sprite.constraint;
                            if constraint_num > 0 {
                                // Constrain to the bounding rect of the constraint sprite
                                if let Some(constraint_sprite) = player.movie.score.get_sprite(constraint_num as i16) {
                                    let bounds = get_concrete_sprite_rect(player, constraint_sprite);
                                    new_h = new_h.max(bounds.left).min(bounds.right);
                                    new_v = new_v.max(bounds.top).min(bounds.bottom);
                                }
                            } else {
                                // Constrain to stage
                                let stage = &player.movie.rect;
                                new_h = new_h.max(stage.left).min(stage.right);
                                new_v = new_v.max(stage.top).min(stage.bottom);
                            }
                        }

                        let sprite = player.movie.score.get_sprite_mut(drag_sprite_num);
                        sprite.loc_h = new_h;
                        sprite.loc_v = new_v;
                    }
                }

            });
            // The pointer moved, so re-evaluate which sprites it is inside.
            // (The same pass also runs once per frame — mouseWithin is sent
            // every frame the pointer stays inside, not only when it moves.)
            crate::player::events::dispatch_rollover_events();
        }
        PlayerVMCommand::RightMouseDown((x, y)) => {
            if !player_is_playing().await {
                return Ok(DatumRef::Void);
            }
            // Update mouse_loc + flag is already done in lib.rs
            // (right_mouse_down). Here we dispatch the `rightMouseDown`
            // event to the topmost active sprite (so behaviors with
            // `on rightMouseDown me` fire), then to the global event
            // handler in frame/movie scripts. We don't toggle button
            // hilite or set mouse_down_sprite — those are left-button
            // concerns.
            let scripted_sprite = reserve_player_ref(|player| {
                crate::player::score::get_mouse_sprite_at(player, x, y)
            });
            if let Some(sprite_number) = scripted_sprite {
                player_dispatch_event_to_sprite_targeted(
                    Symbol::builtin(BuiltInSymbol::RightMouseDown),
                    &vec![],
                    sprite_number as u16,
                ).await;
            } else {
                player_invoke_frame_and_movie_scripts(
                    Symbol::builtin(BuiltInSymbol::RightMouseDown),
                    &vec![],
                ).await;
            }
        }
        PlayerVMCommand::RightMouseUp((x, y)) => {
            if !player_is_playing().await {
                return Ok(DatumRef::Void);
            }
            let scripted_sprite = reserve_player_ref(|player| {
                crate::player::score::get_mouse_sprite_at(player, x, y)
            });
            if let Some(sprite_number) = scripted_sprite {
                player_dispatch_event_to_sprite_targeted(
                    Symbol::builtin(BuiltInSymbol::RightMouseUp),
                    &vec![],
                    sprite_number as u16,
                ).await;
            } else {
                player_invoke_frame_and_movie_scripts(
                    Symbol::builtin(BuiltInSymbol::RightMouseUp),
                    &vec![],
                ).await;
            }
        }
        PlayerVMCommand::KeyDown(key, code) => {
            crate::player::wait_for_handler_gap().await;
            crate::player::hold_draw_for_input_handler();
            // Set command_handler_yielding so that:
            // 1. updateStage() always yields (bypasses is_yield_safe check),
            //    letting the browser process keyUp events during repeat-while-
            //    keyPressed loops (like the Hook script's movement).
            // 2. The frame loop skips frame updates and advancement to avoid
            //    running frame scripts that would corrupt the shared scope stack.
            reserve_player_mut(|player| {
                player.command_handler_yielding = true;
            });

            let result = player_key_down(key, code).await;

            reserve_player_mut(|player| {
                player.command_handler_yielding = false;
            });

            return result;
        }
        PlayerVMCommand::KeyUp(key, code) => {
            crate::player::wait_for_handler_gap().await;
            crate::player::hold_draw_for_input_handler();
            return player_key_up(key, code).await;
        }
        PlayerVMCommand::TriggerAlertHook => {
            let call_params = reserve_player_mut(|player| {
                let arg_list = vec![
                    player.alloc_datum(Datum::String("Script Error".to_string())),
                    player
                        .alloc_datum(Datum::String("An error occurred in the script".to_string())),
                ];
                if let Some(alert_hook) = &player.movie.alert_hook {
                    match alert_hook {
                        ScriptReceiver::ScriptInstance(instance_ref) => {
                            let script_instance =
                                player.allocator.get_script_instance(&instance_ref);
                            let script = player
                                .movie
                                .cast_manager
                                .get_script_by_ref(&script_instance.script)
                                .unwrap();
                            let handler = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::AlertHook));
                            if let Some(handler) = handler {
                                Some((Some(instance_ref.clone()), handler, arg_list))
                            } else {
                                None
                            }
                        }
                        ScriptReceiver::Script(script_ref) => {
                            let script = player
                                .movie
                                .cast_manager
                                .get_script_by_ref(&script_ref)
                                .unwrap();
                            let handler = script.get_own_handler_ref(Symbol::builtin(BuiltInSymbol::AlertHook));
                            if let Some(handler) = handler {
                                Some((None, handler, arg_list))
                            } else {
                                None
                            }
                        }
                        ScriptReceiver::ScriptText(text) => {
                            // For mouseDownScript, you'd compile and execute the text
                            // But for alertHook specifically, you'd look for an alertHook handler
                            // in the compiled script
                            
                            // Option 1: Compile the script text on-the-fly
                            // This requires your Lingo compiler to be accessible
                            
                            // Option 2: For simple cases like "--nothing", just ignore it
                            if text.trim().starts_with("--") || text.trim().is_empty() {
                                // It's a comment or empty, do nothing
                                None
                            } else {
                                // TODO: Compile and execute the script text
                                // You'll need to:
                                // 1. Parse the text as Lingo code
                                // 2. Compile it to bytecode
                                // 3. Execute it with the given arguments
                                
                                // For now, log a warning and skip
                                warn!("Warning: Script text execution not yet implemented for alertHook: {}", text);
                                None
                            }
                        }
                    }
                } else {
                    None
                }
            });
            if let Some((receiver, handler, args)) = call_params {
                player_call_script_handler(receiver, handler, &args).await?;
            }
        }
        PlayerVMCommand::TriggerFlashCallback { sprite_num, handler_name, args } => {
            // Find the sprite and its script instances, call the matching handler
            let call_params = reserve_player_mut(|player| {
                if let Some(sprite) = player.movie.score.get_sprite(sprite_num as i16) {
                    for script_instance_ref in &sprite.script_instance_list {
                        let script_instance = player.allocator.get_script_instance(script_instance_ref);
                        if let Some(script) = player.movie.cast_manager.get_script_by_ref(&script_instance.script) {
                            if let Some(handler_ref) = script.get_own_handler_ref(handler_name) {
                                return Some((
                                    Some(script_instance_ref.clone()),
                                    handler_ref,
                                    args.clone(),
                                ));
                            }
                        }
                    }
                }
                None
            });

            if let Some((receiver, handler, args)) = call_params {
                player_call_script_handler(receiver, handler, &args).await?;
            }
        }
        PlayerVMCommand::TriggerLingoCallbackOnScript { cast_lib, cast_member, handler_name, args } => {
            use super::handlers::datum_handlers::script_instance::ScriptInstanceDatumHandlers;

            let call_params = reserve_player_mut(|player| {
                for (script_instance_id, script_instance_entry) in player.allocator.script_instances.iter() {
                    let script_instance = &script_instance_entry.script_instance;

                    if script_instance.script.cast_lib == cast_lib &&
                       script_instance.script.cast_member == cast_member
                    {
                        if let Some(script) = player.movie.cast_manager.get_script_by_ref(&script_instance.script) {
                            if let Some(handler_ref) = script.get_own_handler_ref(handler_name) {
                                let script_instance_ref = ScriptInstanceRef::from_id(
                                    script_instance_id as u32,
                                    script_instance_entry.ref_count.get()
                                );
                                return Some((
                                    script_instance_ref,
                                    handler_ref,
                                    args.clone(),
                                ));
                            }
                        }
                    }
                }
                None
            });

            if let Some((receiver, handler, args)) = call_params {
                let receiver_datum = player_alloc_datum(Datum::ScriptInstanceRef(receiver));
                let _ = ScriptInstanceDatumHandlers::call_async(
                    &receiver_datum,
                    handler.1,
                    &args
                ).await;
            }
        }
        PlayerVMCommand::TriggerLocalConnectionCallback { target, handler_name, args } => {
            use super::handlers::datum_handlers::script_instance::ScriptInstanceDatumHandlers;
            // Dispatch to the EXACT registered instance so `me` is right.
            let handler_ref = reserve_player_ref(|player| {
                let si = player.allocator.get_script_instance_opt(&target)?;
                let script = player.movie.cast_manager.get_script_by_ref(&si.script)?;
                script.get_own_handler_ref(Symbol::from_str(&handler_name))
            });
            if let Some(handler) = handler_ref {
                let receiver_datum = player_alloc_datum(Datum::ScriptInstanceRef(target));
                let _ = ScriptInstanceDatumHandlers::call_async(
                    &receiver_datum,
                    *&handler.1,
                    &args,
                ).await;
            }
        }
        PlayerVMCommand::SetLingoScriptProperty { cast_lib, cast_member, prop_name, value } => {
            use super::script::script_set_prop;

            reserve_player_mut(|player| {
                let mut matching_instances = Vec::new();

                for (instance_id, instance_entry) in player.allocator.script_instances.iter() {
                    let instance = &instance_entry.script_instance;
                    if instance.script.cast_lib == cast_lib && instance.script.cast_member == cast_member {
                        matching_instances.push(ScriptInstanceRef::from_id(
                            instance_id as u32,
                            instance_entry.ref_count.get()
                        ));
                    }
                }

                for instance_ref in matching_instances {
                    let _ = script_set_prop(player, &instance_ref, prop_name, &value, false);
                }
            });
        }
        PlayerVMCommand::DispatchFlashEvent { cast_lib, cast_member, handler_name, args } => {
            // Director's Flash Asset Xtra targets the SPRITE that owns the
            // Flash member — semantically `sendSprite(flashSpriteNum, …)`,
            // NOT a global broadcast. Going global made `on send` fire once
            // per sprite that defined it (e.g. storyscramble's
            // BehaviorScript 24 attached to multiple sprites).
            //
            // Resolve the host sprite by member match. In typical Director
            // movies there's one sprite per Flash member at any frame; if
            // multiple sprites share the same member we dispatch to each
            // (each behaves independently, mirroring the Xtra's behaviour
            // when the same SWF is on stage twice).
            let sprite_nums: Vec<u16> = reserve_player_ref(|player| {
                player
                    .movie
                    .score
                    .channels
                    .iter()
                    .filter_map(|channel| {
                        let m = channel.sprite.member.as_ref()?;
                        if m.cast_lib == cast_lib && m.cast_member == cast_member {
                            Some(channel.number as u16)
                        } else {
                            None
                        }
                    })
                    .collect()
            });

            if sprite_nums.is_empty() {
                // Member exists but isn't on stage right now — fall back to
                // the global path so movie / frame scripts still get a chance
                // (matches Director's behaviour of dispatching even when the
                // Flash sprite has just been removed from the score).
                use super::events::player_invoke_global_event;
                let _ = player_invoke_global_event(handler_name, &args).await;
            } else {
                use super::events::player_dispatch_event_to_sprite_targeted;
                for sprite_num in sprite_nums {
                    player_dispatch_event_to_sprite_targeted(
                        handler_name,
                        &args,
                        sprite_num,
                    )
                    .await;
                }
            }
        }
    }
    Ok(DatumRef::Void)
}

#[cfg(test)]
mod queued_mouse_move_tests {
    use super::*;
    use crate::player::testing::{run_test, TestPlayer};
    #[test]
    fn hover_queued_before_press_does_not_drag_previous_piece() {
        crate::player::symbols::symbol_table::init_symbol_table();
        run_test(async {
            let _harness = TestPlayer::new();
            reserve_player_mut(|p| {
                p.is_playing = true;
                p.movie.mouse_down = true;
                p.click_on_sprite = 1;
                p.drag_offset = (2, 3);
                p.movie.score.channels = (0..2).map(crate::player::score::SpriteChannel::new).collect();
                let sprite = p.movie.score.get_sprite_mut(1);
                sprite.moveable = true;
                sprite.loc_h = 10;
                sprite.loc_v = 20;
            });
            run_player_command(PlayerVMCommand::MouseMove((100, 200), false)).await.unwrap();
            reserve_player_ref(|p| {
                let sprite = p.movie.score.get_sprite(1).unwrap();
                assert_eq!((sprite.loc_h, sprite.loc_v), (10, 20));
            });
            run_player_command(PlayerVMCommand::MouseMove((100, 200), true)).await.unwrap();
            reserve_player_ref(|p| {
                let sprite = p.movie.score.get_sprite(1).unwrap();
                assert_eq!((sprite.loc_h, sprite.loc_v), (102, 203));
            });
            // The host reports physical release synchronously, before queued
            // pre-release motion is processed. That motion must still apply.
            reserve_player_mut(|p| p.movie.mouse_down = false);
            run_player_command(PlayerVMCommand::MouseMove((200, 300), true)).await.unwrap();
            reserve_player_ref(|p| {
                let sprite = p.movie.score.get_sprite(1).unwrap();
                assert_eq!((sprite.loc_h, sprite.loc_v), (202, 303));
            });
        });
    }
}
