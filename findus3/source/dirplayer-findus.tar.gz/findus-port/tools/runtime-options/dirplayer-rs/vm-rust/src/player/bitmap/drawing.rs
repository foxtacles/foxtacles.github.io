use std::collections::HashMap;

use rgb565::Rgb565;

use crate::{
    director::{
        enums::{ShapeInfo, ShapeType},
        lingo::datum::Datum,
    },
    player::{
        Score, Sprite, bitmap::bitmap::{PaletteRef, BuiltInPalette, get_system_default_palette}, font::{BitmapFont, bitmap_font_copy_char}, geometry::IntRect, reserve_player_mut, sprite::{ColorRef, is_skew_flip}, symbols::builtin::BuiltInSymbol
    },
};

use super::{
    bitmap::{resolve_color_ref, resolve_palette_quantizer, resolve_palette_table, Bitmap, PaletteQuantizer},
    mask::BitmapMask,
    palette_map::PaletteMap,
};

pub struct CopyPixelsParams<'a> {
    pub blend: i32,
    pub ink: u32,
    pub color: ColorRef,
    pub bg_color: ColorRef,
    /// True when `#bgColor` was explicitly supplied in the copyPixels param
    /// list (acts like a non-sprite `has_back_color` for colorize routing —
    /// Director tints source-white pixels with bg_color on copy ink in this
    /// case, which Coke Studios' chat-bubble background tinting relies on).
    pub bg_color_explicit: bool,
    /// True when `#color` was explicitly supplied in the copyPixels param list.
    pub fore_color_explicit: bool,
    pub mask_image: Option<&'a BitmapMask>,
    pub mask_offset: (i32, i32),
    pub is_text_rendering: bool,
    pub rotation: f64,
    pub skew: f64,
    pub sprite: Option<&'a Sprite>,
    pub original_dst_rect: Option<IntRect>,
    /// For ink 9 (Mask): the next cast member's bitmap used as grayscale alpha mask.
    /// Black=opaque, white=transparent, grays=partial transparency.
    pub ink9_mask_bitmap: Option<&'a Bitmap>,
    /// For ink 9: offset added to (sx, sy) when sampling the mask bitmap, so
    /// the mask aligns to the source by their registration points
    /// (mask_reg - src_reg). Director allows mask bitmaps to be larger or
    /// smaller than the source — alignment is by registration point.
    pub ink9_mask_offset: (i32, i32),
    /// Sample a shrunk source at floor(d * src / dst), as Director does for
    /// an authored bitmap (measured on klods.dcr's ruler). Off for text, field
    /// and shape blits, which keep the pixel-centre rule; see the shader's
    /// u_floor_rule.
    pub floor_rule: bool,
}

impl CopyPixelsParams<'_> {
    pub const fn default(bitmap: &Bitmap) -> CopyPixelsParams<'static> {
        CopyPixelsParams {
            blend: 100,
            ink: 0,
            color: bitmap.get_fg_color_ref(),
            bg_color: bitmap.get_bg_color_ref(),
            bg_color_explicit: false,
            fore_color_explicit: false,
            mask_image: None,
            mask_offset: (0, 0),
            is_text_rendering: false,
            rotation: 0.0,
            skew: 0.0,
            sprite: None,
            original_dst_rect: None,
            ink9_mask_bitmap: None,
            ink9_mask_offset: (0, 0),
            floor_rule: false,
        }
    }
}

fn blend_alpha(dst: u8, src: u8, alpha: f32) -> u8 {
    (src as f32 * alpha + dst as f32 * (1.0 - alpha)) as u8
}

fn blend_color_alpha(dst: (u8, u8, u8), src: (u8, u8, u8), alpha: f32) -> (u8, u8, u8) {
    if alpha == 0.0 {
        return dst;
    } else if alpha == 1.0 {
        return src;
    }
    let r = blend_alpha(dst.0, src.0, alpha);
    let g = blend_alpha(dst.1, src.1, alpha);
    let b = blend_alpha(dst.2, src.2, alpha);
    (r, g, b)
}

pub fn should_matte_sprite(ink: u32) -> bool {
    ink == 2 || ink == 36 || ink == 33 || ink == 37 || ink == 39 || ink == 41 || ink == 8 || ink == 7
}

/// Only ink 8 (Matte) uses pixel-level hit testing for mouse clicks.
/// Other inks use bounding box detection even if they use alpha for rendering.
pub fn should_matte_hit_test(ink: u32) -> bool {
    ink == 8
}

fn director_blend_ink0(
    dst: (u8, u8, u8),
    src: (u8, u8, u8),
    src_alpha: f32,
    blend: f32,
) -> (u8, u8, u8) {
    // Straight-alpha source-over compositing: the source pixel's own alpha and
    // the #blend parameter combine into ONE effective coverage, and the
    // destination's complementary weight must use that SAME coverage.
    //
    // The previous formula weighted dst by (1 - blend) while only premultiplying
    // src by src_alpha — so a partial-alpha (anti-aliased) edge at e.g.
    // src_alpha=0.5, blend=1.0 produced `src*0.5` with ZERO destination
    // contribution, i.e. the edge darkened toward black (a halo) instead of
    // blending with what's behind it. spectral-wizard's splashName title
    // fade-in (`copyPixels(..., [#blend: theBlendItems])`, blend ramping 0→100)
    // showed that black fringe against the scrolling menu background.
    let eff = (src_alpha * blend).clamp(0.0, 1.0);
    let inv = 1.0 - eff;
    (
        (dst.0 as f32 * inv + src.0 as f32 * eff).round().clamp(0.0, 255.0) as u8,
        (dst.1 as f32 * inv + src.1 as f32 * eff).round().clamp(0.0, 255.0) as u8,
        (dst.2 as f32 * inv + src.2 as f32 * eff).round().clamp(0.0, 255.0) as u8,
    )
}

fn blend_pixel(
    dst: (u8, u8, u8),
    src: (u8, u8, u8),
    ink: u32,
    bg_color: (u8, u8, u8),
    fg_color: (u8, u8, u8),
    src_indexed: bool, // an indexed (1 to 8 bit) source keeps its colours under Lighten
    blend_alpha: f32, // This is params.blend / 100.0
    src_alpha: f32,   // Alpha from the source pixel (0.0 to 1.0)
) -> (u8, u8, u8) {
    // Calculate the effective alpha: combination of native source alpha and blend parameter
    let effective_alpha = src_alpha * blend_alpha;

    match ink {
        // 0 = Copy (Director semantics: copy source over destination)
        // If fully opaque/effective_alpha==1 => hard copy, otherwise alpha-blend.
        0 => {
            if blend_alpha >= 0.999 {
                // Normal copy, still respecting source alpha
                if src_alpha >= 0.999 {
                    src
                } else {
                    blend_color_alpha(dst, src, src_alpha)
                }
            } else {
                director_blend_ink0(dst, src, src_alpha, blend_alpha)
            }
        }
        // ... (other ink modes use effective_alpha too, just like 'Copy')
        // 7 = Not Ghost
        // Approximation: similar to copy but skip bg_color (like ink 36),
        // many implementations treat this as a matte-related/alpha-preserving ink.
        // We'll behave like "if src == bg_color -> dst, else blend normally".
        7 => {
            blend_color_alpha(dst, src, effective_alpha)
        }
        // 8 = Matte
        // Transparency is decided BEFORE blending.
        // At this point, the pixel is opaque (or partially via src_alpha).
        8 => {
            if src_alpha <= 0.001 {
                dst
            } else if effective_alpha >= 0.999 {
                src
            } else {
                blend_color_alpha(dst, src, effective_alpha)
            }
        }
        // 9 = Mask
        // Mask typically means use mask to determine copy. Here we assume mask was applied earlier,
        // so treat it as a hard copy when present (i.e. if we've reached here, copy).
        9 => {
            if src_alpha <= 0.001 {
                dst
            } else {
                // If blend < 1, respect it.
                if effective_alpha >= 0.999 {
                    src
                } else {
                    blend_color_alpha(dst, src, effective_alpha)
                }
            }
        }
        // 33 = Add Pin (Director-style additive, pinned to 255)
        // bg_color pixels are transparent
        // Standard additive: add source RGB to destination
        33 => {
            if src == bg_color {
                dst
            } else {
                // Standard additive: add source to destination
                let r = ((dst.0 as u32 + src.0 as u32).min(255)) as u8;
                let g = ((dst.1 as u32 + src.1 as u32).min(255)) as u8;
                let b = ((dst.2 as u32 + src.2 as u32).min(255)) as u8;

                // Apply blend factor
                if blend_alpha >= 0.999 {
                    (r, g, b)
                } else {
                    blend_color_alpha(dst, (r, g, b), blend_alpha)
                }
            }
        }
        // 35 = Sub Pin (Director-style subtractive, pinned to 0)
        // bg_color pixels are transparent
        // Subtractive: subtract source RGB from destination
        35 => {
            if src == bg_color {
                dst
            } else {
                // Subtractive: subtract source from destination
                let r = (dst.0 as i32 - src.0 as i32).max(0) as u8;
                let g = (dst.1 as i32 - src.1 as i32).max(0) as u8;
                let b = (dst.2 as i32 - src.2 as i32).max(0) as u8;

                // Apply blend factor
                if blend_alpha >= 0.999 {
                    (r, g, b)
                } else {
                    blend_color_alpha(dst, (r, g, b), blend_alpha)
                }
            }
        }
        // 36 = Background Transparent
        // If the source equals the bg_color, skip; otherwise blend normally.
        36 => {
            blend_color_alpha(dst, src, effective_alpha)
        }
        // 37 = Lightest
        // Compares the *whole* RGB pixels in src and dst by luminance and
        // returns the brighter pixel intact — NOT a per-channel max (that
        // would invent a colour neither source had, e.g. (200,0,0) vs
        // (0,0,200) becoming (200,0,200) magenta). bg_color in src is
        // transparent (skipped).
        37 => {
            if src == bg_color {
                dst
            } else {
                let src_luma = (src.0 as u32) * 299
                    + (src.1 as u32) * 587
                    + (src.2 as u32) * 114; // 0..255_000
                let dst_luma = (dst.0 as u32) * 299
                    + (dst.1 as u32) * 587
                    + (dst.2 as u32) * 114;
                let chosen = if src_luma >= dst_luma { src } else { dst };
                if blend_alpha >= 0.999 {
                    chosen
                } else {
                    blend_color_alpha(dst, chosen, blend_alpha)
                }
            }
        }
        // 39 = Darkest
        // Compares the *whole* RGB pixels in src and dst by luminance and
        // returns the darker pixel intact. Per-channel min would drive
        // pixels toward black even when neither source was that dark
        // (CS RemoteControlCamera CRT showed this — colour came out
        // muddy/near-black). bg_color in src is transparent (skipped).
        39 => {
            if src == bg_color {
                dst
            } else {
                let src_luma = (src.0 as u32) * 299
                    + (src.1 as u32) * 587
                    + (src.2 as u32) * 114;
                let dst_luma = (dst.0 as u32) * 299
                    + (dst.1 as u32) * 587
                    + (dst.2 as u32) * 114;
                let chosen = if src_luma <= dst_luma { src } else { dst };
                if blend_alpha >= 0.999 {
                    chosen
                } else {
                    blend_color_alpha(dst, chosen, blend_alpha)
                }
            }
        }
        // 40 = Lighten: the sprite's foreColor is added to the image
        // (Using Director, "Using sprite inks"). A sprite on the default
        // black foreColor is unchanged, which is what the earlier
        // pass-through measured.
        40 => {
            if src == bg_color {
                dst
            } else if src_indexed {
                blend_color_alpha(dst, src, effective_alpha)
            } else {
                let lit = (
                    src.0.saturating_add(fg_color.0),
                    src.1.saturating_add(fg_color.1),
                    src.2.saturating_add(fg_color.2),
                );
                blend_color_alpha(dst, lit, effective_alpha)
            }
        }
        // 41 = Darken: a foreColor/bgColor remap per channel, black to
        // foreColor and white to bgColor, the same mix the WebGL2 shader
        // draws. The defaults (black, white) leave the image unchanged.
        41 => {
            let mix = |s: u8, fg: u8, bg: u8| {
                let t = s as f32 / 255.0;
                (fg as f32 * (1.0 - t) + bg as f32 * t).round().clamp(0.0, 255.0) as u8
            };
            let color = (
                mix(src.0, fg_color.0, bg_color.0),
                mix(src.1, fg_color.1, bg_color.1),
                mix(src.2, fg_color.2, bg_color.2),
            );
            blend_color_alpha(dst, color, effective_alpha)
        }
        _ => blend_color_alpha(dst, src, effective_alpha),
    }
}

/// One visual line produced by `wrap_lines_with_spans`. `start..end` is the byte
/// range in the original text that this line covers (exclusive of the trailing
/// space that caused a soft wrap, and exclusive of any \r/\n terminator).
#[derive(Clone, Debug)]
pub struct LineSpan {
    pub start: usize,
    pub end: usize,
    pub text: String,
}

impl Bitmap {
    pub fn get_pixel_color_with_alpha(
        &self,
        palettes: &PaletteMap,
        x: u16,
        y: u16,
    ) -> (u8, u8, u8, u8) {
        let color_ref = self.get_pixel_color_ref(x, y);
        let (r, g, b) = resolve_color_ref(
            palettes,
            &color_ref,
            &self.palette_ref,
            self.original_bit_depth,
        );

        if self.bit_depth == 32 {
            let x_usize = x as usize;
            let y_usize = y as usize;
            if x_usize < self.width as usize && y_usize < self.height as usize {
                let index = (y_usize * self.width as usize + x_usize) * 4;
                // The alpha component is the 4th byte for 32-bit data (R, G, B, A)
                let a = self.data[index + 3];
                return (r, g, b, a);
            }
        }
        // Default to fully opaque
        (r, g, b, 0xFF)
    }

    /// Like `get_pixel_color_with_alpha`, but uses a pre-resolved palette table.
    #[inline]
    pub fn get_pixel_color_with_alpha_fast(
        &self,
        palette_cache: &[(u8, u8, u8)],
        x: u16,
        y: u16,
    ) -> (u8, u8, u8, u8) {
        let color_ref = self.get_pixel_color_ref(x, y);
        let (r, g, b) = match &color_ref {
            ColorRef::PaletteIndex(i) => palette_cache[*i as usize],
            ColorRef::Rgb(r, g, b) => (*r, *g, *b),
        };

        if self.bit_depth == 32 {
            let x_usize = x as usize;
            let y_usize = y as usize;
            if x_usize < self.width as usize && y_usize < self.height as usize {
                let index = (y_usize * self.width as usize + x_usize) * 4;
                let a = self.data[index + 3];
                return (r, g, b, a);
            }
        }
        (r, g, b, 0xFF)
    }

    pub fn set_pixel(&mut self, x: i32, y: i32, color: (u8, u8, u8), palettes: &PaletteMap) {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return;
        }
        self.matte = None; // TODO draw on matte instead
        let (r, g, b) = color;
        let x = x as usize;
        let y = y as usize;
        if x < self.width as usize && y < self.height as usize {
            let bytes_per_pixel = self.bit_depth as usize / 8;
            let index = (y * self.width as usize + x) * bytes_per_pixel;
            match self.bit_depth {
                1 => {
                    let bit_index = y * self.width as usize + x;
                    let byte_index = bit_index / 8;
                    let bit_offset = bit_index % 8;
                    let value = self.data[byte_index];
                    let mask = 1 << (7 - bit_offset);
                    let value = if r > 127 || g > 127 || b > 127 {
                        value | mask
                    } else {
                        value & !mask
                    };
                    self.data[byte_index] = value;
                }
                4 => {
                    let own_palette = &self.palette_ref;
                    let mut result_index: u8 = 0;
                    let mut result_distance = i32::MAX;

                    for palette_idx in 0..16u8 {
                        let palette_color = resolve_color_ref(
                            palettes,
                            &ColorRef::PaletteIndex(palette_idx),
                            &own_palette,
                            self.original_bit_depth,
                        );
                        let distance = (r as i32 - palette_color.0 as i32).abs()
                            + (g as i32 - palette_color.1 as i32).abs()
                            + (b as i32 - palette_color.2 as i32).abs();
                        if distance < result_distance {
                            result_index = palette_idx;
                            result_distance = distance;
                        }
                    }
                    self.data[index] = result_index;
                }
                8 => {
                    let own_palette = &self.palette_ref;
                    let mut result_index = 0;
                    let mut result_distance = i32::MAX;

                    for idx in 0..=255 {
                        let palette_color = resolve_color_ref(
                            palettes,
                            &ColorRef::PaletteIndex(idx as u8),
                            &own_palette,
                            self.original_bit_depth,
                        );
                        let distance = (r as i32 - palette_color.0 as i32).abs()
                            + (g as i32 - palette_color.1 as i32).abs()
                            + (b as i32 - palette_color.2 as i32).abs();
                        if distance < result_distance {
                            result_index = idx;
                            result_distance = distance;
                        }
                    }
                    self.data[index] = result_index;
                }
                16 => {
                    let r = r as f32 * 31.0 / 255.0;
                    let g = g as f32 * 63.0 / 255.0;
                    let b = b as f32 * 31.0 / 255.0;
                    let value = Rgb565::pack_565((r as u8, g as u8, b as u8));
                    let bytes = value.to_le_bytes();
                    self.data[index] = bytes[0];
                    self.data[index + 1] = bytes[1];
                }
                32 => {
                    self.data[index] = r;
                    self.data[index + 1] = g;
                    self.data[index + 2] = b;
                    self.data[index + 3] = 0xFF;
                }
                _ => {
                    // TODO: Should this be logged?
                    println!("Unsupported bit depth for set_pixel: {}", self.bit_depth);
                }
            }
        }
    }

    /// Write a raw palette index at (x, y) for indexed (<=8-bit) bitmaps, with
    /// NO RGB round-trip. The copyPixels fast path uses this for same-depth,
    /// same-palette indexed copies so index i stays index i — the general
    /// per-pixel path resolves each index to RGB and re-quantizes on write,
    /// which collapses distinct indices that fall in the same brightness bucket
    /// (Tetris' 1-bit `game_plane` row-shift otherwise turned every occupied
    /// cell empty, desyncing collision from the visual board).
    pub fn set_pixel_index(&mut self, x: i32, y: i32, idx: u8) {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return;
        }
        let x = x as usize;
        let y = y as usize;
        let w = self.width as usize;
        match self.bit_depth {
            1 => {
                let bit_index = y * w + x;
                let byte_index = bit_index / 8;
                let mask = 1u8 << (7 - (bit_index % 8));
                if idx & 1 != 0 {
                    self.data[byte_index] |= mask;
                } else {
                    self.data[byte_index] &= !mask;
                }
            }
            2 => {
                let pix = y * w + x;
                let byte_index = pix / 4;
                let shift = 6 - (pix % 4) * 2; // MSB-first: 6,4,2,0
                self.data[byte_index] =
                    (self.data[byte_index] & !(0b11 << shift)) | ((idx & 0b11) << shift);
            }
            4 => {
                let byte_index = (y * w + x) / 2;
                if x % 2 == 0 {
                    self.data[byte_index] = (self.data[byte_index] & 0x0F) | ((idx & 0x0F) << 4);
                } else {
                    self.data[byte_index] = (self.data[byte_index] & 0xF0) | (idx & 0x0F);
                }
            }
            8 => {
                self.data[y * w + x] = idx;
            }
            _ => {}
        }
    }

    /// Like `set_pixel`, but uses a pre-resolved palette table for indexed formats.
    /// For 4-bit/8-bit bitmaps, this avoids calling `resolve_color_ref` 16/256 times per pixel.
    /// The 8-bit nearest-colour search is memoised by `PaletteQuantizer`.
    pub fn set_pixel_fast(&mut self, x: i32, y: i32, color: (u8, u8, u8), palette_cache: &PaletteQuantizer) {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return;
        }
        // NB: clearing `self.matte` is the CALLER's job — see the pixel loop in
        // `copy_pixels_with_params`, the only caller. Doing it here meant an
        // `Option<Arc<BitmapMask>>` assignment (a branch plus a possible
        // refcount decrement) on every single pixel written.
        let (r, g, b) = color;
        let x = x as usize;
        let y = y as usize;
        match self.bit_depth {
            1 => {
                let bit_index = y * self.width as usize + x;
                let byte_index = bit_index / 8;
                let bit_offset = bit_index % 8;
                let value = self.data[byte_index];
                let mask = 1 << (7 - bit_offset);
                let value = if r > 127 || g > 127 || b > 127 {
                    value | mask
                } else {
                    value & !mask
                };
                self.data[byte_index] = value;
            }
            4 => {
                let result_index = palette_cache.nearest(r, g, b, 16);
                let index = (y * self.width as usize + x) / 2;
                if x % 2 == 0 {
                    self.data[index] = (self.data[index] & 0x0F) | (result_index << 4);
                } else {
                    self.data[index] = (self.data[index] & 0xF0) | (result_index & 0x0F);
                }
            }
            8 => {
                let result_index = palette_cache.nearest(r, g, b, palette_cache.table().len());
                let index = y * self.width as usize + x;
                self.data[index] = result_index;
            }
            16 => {
                let r = r as f32 * 31.0 / 255.0;
                let g = g as f32 * 63.0 / 255.0;
                let b = b as f32 * 31.0 / 255.0;
                let value = Rgb565::pack_565((r as u8, g as u8, b as u8));
                let bytes = value.to_le_bytes();
                let index = (y * self.width as usize + x) * 2;
                self.data[index] = bytes[0];
                self.data[index + 1] = bytes[1];
            }
            32 => {
                let index = (y * self.width as usize + x) * 4;
                self.data[index] = r;
                self.data[index + 1] = g;
                self.data[index + 2] = b;
                self.data[index + 3] = 0xFF;
            }
            _ => {}
        }
    }

    pub fn get_pixel_color_ref(&self, x: u16, y: u16) -> ColorRef {
        let x = x as usize;
        let y = y as usize;
        if x >= self.width as usize || y >= self.height as usize {
            return self.get_bg_color_ref();
        }

        match self.bit_depth {
            1 => {
                // 1-bit images pack 8 pixels per byte, MSB first — the same bit
                // order set_pixel writes (`mask = 1 << (7 - bit_offset)`). Return
                // the stored bit as the palette index so a 1-bit image used as an
                // index bitmask round-trips: fill(paletteIndex(N)) / setPixel(N)
                // -> getPixel().paletteIndex == N. Without this arm every 1-bit
                // pixel fell through to `get_bg_color_ref()` (PaletteIndex 0), so
                // Tetris' game board read as fully occupied and every piece
                // reported game-over immediately.
                let bit_index = y * self.width as usize + x;
                let byte_index = bit_index / 8;
                let bit_offset = bit_index % 8;
                let bit = (self.data[byte_index] >> (7 - bit_offset)) & 1;
                ColorRef::PaletteIndex(bit)
            }
            4 => {
                let bit_index = (y * self.width as usize + x) * 4;
                let byte_index = bit_index / 8;
                let value = self.data[byte_index];

                let nibble = if x % 2 == 0 {
                    value >> 4 // High nibble (0-15)
                } else {
                    value & 0x0F // Low nibble (0-15)
                };

                // 4-bit uses 16-color palette, values are 0-15
                ColorRef::PaletteIndex(nibble)
            }
            8 => {
                let index = y * self.width as usize + x;
                ColorRef::PaletteIndex(self.data[index])
            }
            16 => {
                let index = (y * self.width as usize + x) * 2;
                let value = u16::from_le_bytes([self.data[index], self.data[index + 1]]);
                let (red, green, blue) = Rgb565::unpack_565(value);
                let red = (red as f32 / 31.0 * 255.0) as u8;
                let green = (green as f32 / 63.0 * 255.0) as u8;
                let blue = (blue as f32 / 31.0 * 255.0) as u8;
                ColorRef::Rgb(red, green, blue)
            }
            32 => {
                let bytes_per_pixel = 4;
                let index = (y * self.width as usize + x) * bytes_per_pixel as usize;
                ColorRef::Rgb(self.data[index], self.data[index + 1], self.data[index + 2])
            }
            _ => {
                self.get_bg_color_ref()
                // panic!("Unsupported bit depth: {}", self.bit_depth)
            }
        }
    }

    pub fn get_pixel_color(&self, palettes: &PaletteMap, x: u16, y: u16) -> (u8, u8, u8) {
        let color_ref = self.get_pixel_color_ref(x, y);
        resolve_color_ref(
            palettes,
            &color_ref,
            &self.palette_ref,
            self.original_bit_depth,
        )
    }

    /// Like `get_pixel_color`, but uses a pre-resolved palette table for indexed formats.
    #[inline]
    pub fn get_pixel_color_fast(&self, palette_cache: &[(u8, u8, u8)], x: u16, y: u16) -> (u8, u8, u8) {
        let color_ref = self.get_pixel_color_ref(x, y);
        match color_ref {
            ColorRef::PaletteIndex(i) => palette_cache[i as usize],
            ColorRef::Rgb(r, g, b) => (r, g, b),
        }
    }

    pub const fn has_palette(&self) -> bool {
        self.bit_depth != 16 && self.bit_depth != 32
    }

    pub const fn get_bg_color_ref(&self) -> ColorRef {
        if self.has_palette() {
            ColorRef::PaletteIndex(0)
        } else {
            ColorRef::Rgb(255, 255, 255)
        }
    }

    pub const fn get_fg_color_ref(&self) -> ColorRef {
        if self.has_palette() {
            ColorRef::PaletteIndex(255)
        } else {
            ColorRef::Rgb(0, 0, 0)
        }
    }

    pub fn _flipped_hv(&self, palettes: &PaletteMap) -> Bitmap {
        let mut flipped = self.clone();
        for y in 0..self.height as usize {
            for x in 0..self.width as usize {
                let src_x = x;
                let src_y = y;
                let dst_x = self.width as usize - x - 1;
                let dst_y = self.height as usize - y - 1;
                let src_color = self.get_pixel_color(palettes, src_x as u16, src_y as u16);
                flipped.set_pixel(dst_x as i32, dst_y as i32, src_color, palettes);
            }
        }
        flipped
    }

    pub fn _flipped_h(&self, palettes: &PaletteMap) -> Bitmap {
        let mut flipped = self.clone();
        for y in 0..self.height as usize {
            for x in 0..self.width as usize {
                let src_x = x;
                let src_y = y;
                let dst_x = self.width as usize - x - 1;
                let dst_y = y;
                let src_color = self.get_pixel_color(palettes, src_x as u16, src_y as u16);
                flipped.set_pixel(dst_x as i32, dst_y as i32, src_color, palettes);
            }
        }
        flipped
    }

    pub fn _flipped_v(&self, palettes: &PaletteMap) -> Bitmap {
        let mut flipped = self.clone();
        for y in 0..self.height as usize {
            for x in 0..self.width as usize {
                let src_x = x;
                let src_y = y;
                let dst_x = x;
                let dst_y = self.height as usize - y - 1;
                let src_color = self.get_pixel_color(palettes, src_x as u16, src_y as u16);
                flipped.set_pixel(dst_x as i32, dst_y as i32, src_color, palettes);
            }
        }
        flipped
    }

    pub fn stroke_sized_rect(
        &mut self,
        left: i32,
        top: i32,
        width: i32,
        height: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        let left = left.max(0) as i32;
        let top = top.max(0) as i32;
        let right = (left + width) as i32;
        let bottom = (top + height) as i32;
        self.stroke_rect(left, top, right, bottom, color, palettes, alpha);
    }

    pub fn stroke_rect(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        let left = x1;
        let top = y1;
        let right = x2 - 1;
        let bottom = y2 - 1;

        for x in x1..x2 {
            let top_color = self.get_pixel_color(palettes, x as u16, top as u16);
            let bottom_color = self.get_pixel_color(palettes, x as u16, bottom as u16);
            let blended_top = blend_color_alpha(top_color, color, alpha);
            let blended_bottom = blend_color_alpha(bottom_color, color, alpha);
            self.set_pixel(x as i32, top as i32, blended_top, palettes);
            self.set_pixel(x as i32, bottom as i32, blended_bottom, palettes);
        }
        for y in y1..y2 {
            let left_color = self.get_pixel_color(palettes, left as u16, y as u16);
            let right_color = self.get_pixel_color(palettes, right as u16, y as u16);
            let blended_left = blend_color_alpha(left_color, color, alpha);
            let blended_right = blend_color_alpha(right_color, color, alpha);
            self.set_pixel(left as i32, y as i32, blended_left, palettes);
            self.set_pixel(right as i32, y as i32, blended_right, palettes);
        }
    }

    pub fn clear_rect(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
    ) {
        for y in y1..y2 {
            for x in x1..x2 {
                self.set_pixel(x, y, color, palettes);
            }
        }
    }

    /// Clears a rectangular region with fully transparent pixels (alpha = 0).
    /// Used for filmloop rendering where we need transparency instead of a solid background.
    pub fn clear_rect_transparent(&mut self, x1: i32, y1: i32, x2: i32, y2: i32) {
        // Only works for 32-bit bitmaps
        if self.bit_depth != 32 {
            return;
        }
        for y in y1..y2 {
            for x in x1..x2 {
                if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
                    continue;
                }
                let index = (y as usize * self.width as usize + x as usize) * 4;
                // Set RGBA to (0, 0, 0, 0) - fully transparent black
                self.data[index] = 0;
                self.data[index + 1] = 0;
                self.data[index + 2] = 0;
                self.data[index + 3] = 0; // Alpha = 0 (transparent)
            }
        }
    }

    pub fn fill_relative_rect(
        &mut self,
        left: i32,
        top: i32,
        right: i32,
        bottom: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        let left = left.max(0);
        let top = top.max(0);
        let right = right.min(self.width as i32 - 1);
        let bottom = bottom.min(self.height as i32 - 1);

        let x1 = left;
        let y1 = top;
        let x2 = self.width as i32 - right;
        let y2 = self.height as i32 - bottom;

        self.fill_rect(x1, y1, x2, y2, color, palettes, alpha);
    }

    pub fn fill_rect(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        if alpha == 0.0 {
            return;
        }
        for y in y1..y2 {
            for x in x1..x2 {
                let blended_color = if alpha == 1.0 {
                    color
                } else {
                    let dst_color = self.get_pixel_color(palettes, x as u16, y as u16);
                    blend_color_alpha(dst_color, color, alpha)
                };
                self.set_pixel(x as i32, y as i32, blended_color, palettes);
            }
        }
    }

    /// Fill a rect with a Director built-in tile pattern (shape `pattern` 57-64).
    /// The tile stores palette INDICES; they're resolved through `palette_ref`
    /// (the movie's current palette) exactly like an 8-bit bitmap — so the same
    /// indices that look gray in the Mac palette render in the movie's colours
    /// (e.g. thead's magenta background, whose tile uses index 247 = foreColor).
    /// Tiling is aligned to the shape's top-left corner.
    pub fn fill_rect_tiled(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        tile: &crate::player::bitmap::builtin_tiles::BuiltinTile,
        palettes: &PaletteMap,
        palette_ref: &PaletteRef,
        alpha: f32,
    ) {
        if alpha == 0.0 || tile.w == 0 || tile.h == 0 {
            return;
        }
        let cache = resolve_palette_table(palettes, palette_ref, self.original_bit_depth);
        let tw = tile.w as i32;
        let th = tile.h as i32;
        for y in y1..y2 {
            let ty = (y - y1).rem_euclid(th) as usize;
            let row = ty * tile.w as usize;
            for x in x1..x2 {
                let tx = (x - x1).rem_euclid(tw) as usize;
                let idx = tile.px[row + tx] as usize;
                let color = cache[idx];
                let blended = if alpha == 1.0 {
                    color
                } else {
                    let dst = self.get_pixel_color(palettes, x as u16, y as u16);
                    blend_color_alpha(dst, color, alpha)
                };
                self.set_pixel(x, y, blended, palettes);
            }
        }
    }

    /// Fill `dst_rect` by tiling a region (`tile_rect`) of another bitmap (a
    /// VWTL user-defined tile — shape pattern 57-64 with a custom member). Edge
    /// tiles are clipped. Used for movies like employee whose pattern-58
    /// background is a 32x32 slice of a blue/white checker bitmap.
    /// `abs_origin` is the absolute stage coordinate of `dst_rect`'s top-left,
    /// so the tile is phased to the absolute grid (Director aligns tiles to the
    /// stage, not the shape — a half-cell offset here would swap the checker's
    /// blue/white squares). For the CPU path `dst_rect` is already in stage
    /// coords so pass its top-left; for webgl2 (a local texture) pass the
    /// sprite's stage position.
    pub fn fill_rect_custom_tile(
        &mut self,
        palettes: &PaletteMap,
        src: &Bitmap,
        tile_rect: IntRect,
        dst_rect: IntRect,
        abs_origin: (i32, i32),
    ) {
        let tw = tile_rect.right - tile_rect.left;
        let th = tile_rect.bottom - tile_rect.top;
        if tw <= 0 || th <= 0 {
            return;
        }
        let params: std::collections::HashMap<String, Datum> = std::collections::HashMap::new();
        let mut y = dst_rect.top;
        while y < dst_rect.bottom {
            // Source row within the tile for this absolute scanline.
            let abs_y = abs_origin.1 + (y - dst_rect.top);
            let sy = abs_y.rem_euclid(th);
            let cell_h = (th - sy).min(dst_rect.bottom - y);
            let mut x = dst_rect.left;
            while x < dst_rect.right {
                let abs_x = abs_origin.0 + (x - dst_rect.left);
                let sx = abs_x.rem_euclid(tw);
                let cell_w = (tw - sx).min(dst_rect.right - x);
                let dst = IntRect::from(x, y, x + cell_w, y + cell_h);
                let sr = IntRect::from(
                    tile_rect.left + sx,
                    tile_rect.top + sy,
                    tile_rect.left + sx + cell_w,
                    tile_rect.top + sy + cell_h,
                );
                self.copy_pixels(palettes, src, dst, sr, &params, None);
                x += cell_w;
            }
            y += cell_h;
        }
    }

    /// Fill a rect with a Director 1-bit QuickDraw shape pattern (pattern 1-56).
    /// The 8x8 pattern repeats across the rect; a set bit draws `fore`, a clear
    /// bit draws `back`. Recoloured by the shape's fore/back — no palette needed.
    /// Aligned to the shape's top-left corner.
    pub fn fill_rect_pattern_1bit(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        pattern: &[u8; 8],
        fore: (u8, u8, u8),
        back: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        if alpha == 0.0 {
            return;
        }
        for y in y1..y2 {
            let row = pattern[(y - y1).rem_euclid(8) as usize];
            for x in x1..x2 {
                let bit = (row >> (7 - (x - x1).rem_euclid(8))) & 1;
                let color = if bit != 0 { fore } else { back };
                let blended = if alpha == 1.0 {
                    color
                } else {
                    let dst = self.get_pixel_color(palettes, x as u16, y as u16);
                    blend_color_alpha(dst, color, alpha)
                };
                self.set_pixel(x, y, blended, palettes);
            }
        }
    }

    /// Draw a filled ellipse inscribed in the given bounding box.
    /// Uses midpoint ellipse algorithm with horizontal scanline filling.
    pub fn fill_ellipse(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        if alpha == 0.0 { return; }
        let w = (x2 - x1).max(1);
        let h = (y2 - y1).max(1);
        // Center coordinates (doubled to avoid fractions)
        let cx2 = x1 + x2; // 2 * center_x
        let cy2 = y1 + y2; // 2 * center_y
        let a = w; // 2 * semi-axis a
        let b = h; // 2 * semi-axis b
        let a2 = (a as i64) * (a as i64);
        let b2 = (b as i64) * (b as i64);

        // Fill scanlines for each y from top to bottom
        for py in y1..y2 {
            // Map py to doubled coordinates relative to center
            let dy2 = 2 * py - cy2 + 1; // doubled distance from center
            let dy2_sq = (dy2 as i64) * (dy2 as i64);
            // Ellipse equation: (dx/(w/2))^2 + (dy/(h/2))^2 <= 1
            // In doubled coords: (dx2/a)^2 + (dy2/b)^2 <= 1
            // => dx2^2 <= a^2 * (1 - dy2^2/b^2) = a^2 * (b^2 - dy2^2) / b^2
            if b2 == 0 { continue; }
            let dx2_sq_max = a2 * (b2 - dy2_sq) / b2;
            if dx2_sq_max < 0 { continue; }
            let dx2_max = (dx2_sq_max as f64).sqrt() as i32;
            let px_left = (cx2 - dx2_max) / 2;
            let px_right = (cx2 + dx2_max + 1) / 2; // +1 for ceiling
            let left = px_left.max(x1);
            let right = px_right.min(x2);
            for px in left..right {
                if alpha == 1.0 {
                    self.set_pixel(px, py, color, palettes);
                } else {
                    let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                    self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                }
            }
        }
    }

    /// Draw an ellipse outline inscribed in the given bounding box.
    pub fn stroke_ellipse(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
        thickness: i32,
    ) {
        if alpha == 0.0 || thickness <= 0 { return; }
        // Draw by filling outer ellipse minus inner ellipse
        // For thickness=1, just plot boundary pixels
        let w = (x2 - x1).max(1);
        let h = (y2 - y1).max(1);
        let cx2 = x1 + x2;
        let cy2 = y1 + y2;
        let a_outer = w;
        let b_outer = h;
        let a_inner = (w - 2 * thickness).max(0);
        let b_inner = (h - 2 * thickness).max(0);
        let a_outer2 = (a_outer as i64) * (a_outer as i64);
        let b_outer2 = (b_outer as i64) * (b_outer as i64);
        let a_inner2 = (a_inner as i64) * (a_inner as i64);
        let b_inner2 = (b_inner as i64) * (b_inner as i64);

        for py in y1..y2 {
            let dy2 = 2 * py - cy2 + 1;
            let dy2_sq = (dy2 as i64) * (dy2 as i64);

            // Outer ellipse x range
            if b_outer2 == 0 { continue; }
            let dx2_sq_outer = a_outer2 * (b_outer2 - dy2_sq) / b_outer2;
            if dx2_sq_outer < 0 { continue; }
            let dx2_outer = (dx2_sq_outer as f64).sqrt() as i32;
            let outer_left = (cx2 - dx2_outer) / 2;
            let outer_right = (cx2 + dx2_outer + 1) / 2;

            // Inner ellipse x range
            let (inner_left, inner_right) = if b_inner2 > 0 && a_inner2 > 0 {
                let dx2_sq_inner = a_inner2 * (b_inner2 - dy2_sq) / b_inner2;
                if dx2_sq_inner > 0 {
                    let dx2_inner = (dx2_sq_inner as f64).sqrt() as i32;
                    let il = (cx2 - dx2_inner) / 2 + thickness;
                    let ir = (cx2 + dx2_inner + 1) / 2 - thickness;
                    if ir > il { (il, ir) } else { (outer_right, outer_left) } // no inner gap
                } else {
                    (outer_right, outer_left) // no inner gap at this y
                }
            } else {
                (outer_right, outer_left) // fully filled at this y (thin ellipse)
            };

            // Draw left stroke band and right stroke band
            for px in outer_left.max(x1)..inner_left.min(outer_right).min(x2) {
                if alpha == 1.0 {
                    self.set_pixel(px, py, color, palettes);
                } else {
                    let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                    self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                }
            }
            for px in inner_right.max(outer_left).max(x1)..outer_right.min(x2) {
                if alpha == 1.0 {
                    self.set_pixel(px, py, color, palettes);
                } else {
                    let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                    self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                }
            }
        }
    }

    /// Draw a filled rounded rectangle with given corner radius.
    pub fn fill_round_rect(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        radius: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        if alpha == 0.0 { return; }
        let w = x2 - x1;
        let h = y2 - y1;
        let r = radius.min(w / 2).min(h / 2).max(0);

        for py in y1..y2 {
            let dy_top = py - y1;
            let dy_bottom = (y2 - 1) - py;
            let dy = dy_top.min(dy_bottom);

            let (left, right) = if dy < r {
                // In corner region — compute circular inset
                let ry = r - dy;
                let rx = r - ((r * r - ry * ry) as f64).sqrt() as i32;
                (x1 + rx, x2 - rx)
            } else {
                (x1, x2)
            };

            for px in left..right {
                if alpha == 1.0 {
                    self.set_pixel(px, py, color, palettes);
                } else {
                    let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                    self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                }
            }
        }
    }

    /// Draw a rounded rectangle outline with given corner radius and line thickness.
    pub fn stroke_round_rect(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        radius: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
        thickness: i32,
    ) {
        if alpha == 0.0 || thickness <= 0 { return; }
        let w = x2 - x1;
        let h = y2 - y1;
        let r_outer = radius.min(w / 2).min(h / 2).max(0);
        let r_inner = (r_outer - thickness).max(0);

        for py in y1..y2 {
            let dy_top = py - y1;
            let dy_bottom = (y2 - 1) - py;
            let dy = dy_top.min(dy_bottom);

            // Outer edge
            let (outer_left, outer_right) = if dy < r_outer {
                let ry = r_outer - dy;
                let rx = r_outer - ((r_outer * r_outer - ry * ry) as f64).sqrt() as i32;
                (x1 + rx, x2 - rx)
            } else {
                (x1, x2)
            };

            // Inner edge
            let (inner_left, inner_right) = if dy < thickness {
                // Top or bottom edge — fill entire outer span
                (outer_right, outer_left) // signals "no gap"
            } else if dy < r_outer {
                let inner_dy = dy - thickness;
                if inner_dy < r_inner {
                    let ry = r_inner - inner_dy;
                    let rx = r_inner - ((r_inner * r_inner - ry * ry).max(0) as f64).sqrt() as i32;
                    (x1 + thickness + rx, x2 - thickness - rx)
                } else {
                    (x1 + thickness, x2 - thickness)
                }
            } else {
                (x1 + thickness, x2 - thickness)
            };

            // If inner_left >= inner_right, fill the whole outer row
            if inner_left >= inner_right {
                for px in outer_left..outer_right {
                    if alpha == 1.0 {
                        self.set_pixel(px, py, color, palettes);
                    } else {
                        let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                        self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                    }
                }
            } else {
                // Left stroke band
                for px in outer_left..inner_left.min(outer_right) {
                    if alpha == 1.0 {
                        self.set_pixel(px, py, color, palettes);
                    } else {
                        let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                        self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                    }
                }
                // Right stroke band
                for px in inner_right.max(outer_left)..outer_right {
                    if alpha == 1.0 {
                        self.set_pixel(px, py, color, palettes);
                    } else {
                        let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                        self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                    }
                }
            }
        }
    }

    /// Draw a line with given thickness using Bresenham's algorithm.
    pub fn draw_line_thick(
        &mut self,
        x1: i32,
        y1: i32,
        x2: i32,
        y2: i32,
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
        thickness: i32,
    ) {
        if alpha == 0.0 || thickness <= 0 { return; }
        let half = thickness / 2;

        let dx = (x2 - x1).abs();
        let dy = -(y2 - y1).abs();
        let sx: i32 = if x1 < x2 { 1 } else { -1 };
        let sy: i32 = if y1 < y2 { 1 } else { -1 };
        let mut err = dx + dy;
        let mut cx = x1;
        let mut cy = y1;

        loop {
            // Draw a filled circle/square at each point for thickness
            if thickness <= 2 {
                // For thin lines, draw a small square
                for oy in -half..=(thickness - 1 - half) {
                    for ox in -half..=(thickness - 1 - half) {
                        let px = cx + ox;
                        let py = cy + oy;
                        if alpha == 1.0 {
                            self.set_pixel(px, py, color, palettes);
                        } else {
                            let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                            self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                        }
                    }
                }
            } else {
                // For thicker lines, draw perpendicular to line direction
                for oy in -half..=(thickness - 1 - half) {
                    for ox in -half..=(thickness - 1 - half) {
                        let px = cx + ox;
                        let py = cy + oy;
                        if alpha == 1.0 {
                            self.set_pixel(px, py, color, palettes);
                        } else {
                            let dst = self.get_pixel_color(palettes, px as u16, py as u16);
                            self.set_pixel(px, py, blend_color_alpha(dst, color, alpha), palettes);
                        }
                    }
                }
            }

            if cx == x2 && cy == y2 { break; }
            let e2 = 2 * err;
            if e2 >= dy {
                if cx == x2 { break; }
                err += dy;
                cx += sx;
            }
            if e2 <= dx {
                if cy == y2 { break; }
                err += dx;
                cy += sy;
            }
        }
    }

    /// Flatten a cubic bezier curve into line segments using adaptive subdivision.
    /// Returns a list of (x, y) points along the curve.
    /// P0 = start, C1 = first control point, C2 = second control point, P3 = end.
    pub fn flatten_cubic_bezier(
        p0: (f32, f32),
        c1: (f32, f32),
        c2: (f32, f32),
        p3: (f32, f32),
        tolerance: f32,
    ) -> Vec<(f32, f32)> {
        let mut result = vec![p0];
        Self::flatten_bezier_recursive(p0, c1, c2, p3, tolerance, &mut result, 0);
        result
    }

    fn flatten_bezier_recursive(
        p0: (f32, f32),
        c1: (f32, f32),
        c2: (f32, f32),
        p3: (f32, f32),
        tolerance: f32,
        result: &mut Vec<(f32, f32)>,
        depth: u32,
    ) {
        // Check flatness: distance from control points to line P0-P3
        let dx = p3.0 - p0.0;
        let dy = p3.1 - p0.1;
        let len_sq = dx * dx + dy * dy;

        if depth > 10 || len_sq < 0.001 {
            // Max recursion or degenerate segment
            result.push(p3);
            return;
        }

        // Distance from C1 and C2 to line P0-P3
        let d1 = ((c1.0 - p0.0) * dy - (c1.1 - p0.1) * dx).abs();
        let d2 = ((c2.0 - p0.0) * dy - (c2.1 - p0.1) * dx).abs();
        let max_dist = (d1 + d2) / len_sq.sqrt();

        if max_dist <= tolerance {
            result.push(p3);
            return;
        }

        // De Casteljau subdivision at t=0.5
        let m01 = ((p0.0 + c1.0) * 0.5, (p0.1 + c1.1) * 0.5);
        let m12 = ((c1.0 + c2.0) * 0.5, (c1.1 + c2.1) * 0.5);
        let m23 = ((c2.0 + p3.0) * 0.5, (c2.1 + p3.1) * 0.5);
        let m012 = ((m01.0 + m12.0) * 0.5, (m01.1 + m12.1) * 0.5);
        let m123 = ((m12.0 + m23.0) * 0.5, (m12.1 + m23.1) * 0.5);
        let mid = ((m012.0 + m123.0) * 0.5, (m012.1 + m123.1) * 0.5);

        Self::flatten_bezier_recursive(p0, m01, m012, mid, tolerance, result, depth + 1);
        Self::flatten_bezier_recursive(mid, m123, m23, p3, tolerance, result, depth + 1);
    }

    /// Blend a color with alpha onto a 32-bit RGBA pixel in the bitmap data.
    /// Uses premultiplied alpha "over" compositing.
    fn blend_pixel_aa(&mut self, px: i32, py: i32, color: (u8, u8, u8), coverage: f32) {
        if px < 0 || py < 0 || px >= self.width as i32 || py >= self.height as i32 {
            return;
        }
        let idx = (py as usize * self.width as usize + px as usize) * 4;
        if idx + 3 >= self.data.len() { return; }

        let src_a = (coverage * 255.0 + 0.5) as u8;
        if src_a == 0 { return; }

        let dst_r = self.data[idx] as u16;
        let dst_g = self.data[idx + 1] as u16;
        let dst_b = self.data[idx + 2] as u16;
        let dst_a = self.data[idx + 3] as u16;

        let sa = src_a as u16;
        let inv_sa = 255 - sa;

        self.data[idx]     = ((color.0 as u16 * sa + dst_r * inv_sa) / 255) as u8;
        self.data[idx + 1] = ((color.1 as u16 * sa + dst_g * inv_sa) / 255) as u8;
        self.data[idx + 2] = ((color.2 as u16 * sa + dst_b * inv_sa) / 255) as u8;
        self.data[idx + 3] = (dst_a + (sa * (255 - dst_a)) / 255).min(255) as u8;
    }

    /// Draw an anti-aliased thick line segment using signed distance from the line.
    pub(crate) fn draw_line_aa(
        &mut self,
        x1: f32, y1: f32,
        x2: f32, y2: f32,
        half_width: f32,
        color: (u8, u8, u8),
        _palettes: &PaletteMap,
        alpha: f32,
    ) {
        let dx = x2 - x1;
        let dy = y2 - y1;
        let seg_len = (dx * dx + dy * dy).sqrt();
        if seg_len < 0.001 { return; }

        // Bounding box of the thick line
        let expand = half_width + 1.0;
        let px_min = (x1.min(x2) - expand).floor().max(0.0) as i32;
        let py_min = (y1.min(y2) - expand).floor().max(0.0) as i32;
        let px_max = (x1.max(x2) + expand).ceil().min(self.width as f32 - 1.0) as i32;
        let py_max = (y1.max(y2) + expand).ceil().min(self.height as f32 - 1.0) as i32;

        let inv_len_sq = 1.0 / (seg_len * seg_len);
        for py in py_min..=py_max {
            for px in px_min..=px_max {
                let fx = px as f32 + 0.5;
                let fy = py as f32 + 0.5;

                // Project onto line segment
                let t = (((fx - x1) * dx + (fy - y1) * dy) * inv_len_sq).clamp(0.0, 1.0);

                // Distance to closest point on segment
                let cx = x1 + t * dx;
                let cy = y1 + t * dy;
                let dist = ((fx - cx) * (fx - cx) + (fy - cy) * (fy - cy)).sqrt();

                // Coverage with smooth anti-aliased edge
                let coverage = (half_width + 0.5 - dist).clamp(0.0, 1.0) * alpha;
                if coverage > 0.001 {
                    self.blend_pixel_aa(px, py, color, coverage);
                }
            }
        }
    }

    /// Draw an anti-aliased filled circle for round line joins/caps.
    pub(crate) fn draw_circle_aa(
        &mut self,
        cx: f32, cy: f32,
        radius: f32,
        color: (u8, u8, u8),
        _palettes: &PaletteMap,
        alpha: f32,
    ) {
        let expand = radius + 1.0;
        let px_min = (cx - expand).floor().max(0.0) as i32;
        let py_min = (cy - expand).floor().max(0.0) as i32;
        let px_max = (cx + expand).ceil().min(self.width as f32 - 1.0) as i32;
        let py_max = (cy + expand).ceil().min(self.height as f32 - 1.0) as i32;

        for py in py_min..=py_max {
            for px in px_min..=px_max {
                let fx = px as f32 + 0.5;
                let fy = py as f32 + 0.5;
                let dist = ((fx - cx) * (fx - cx) + (fy - cy) * (fy - cy)).sqrt();
                let coverage = (radius + 0.5 - dist).clamp(0.0, 1.0) * alpha;
                if coverage > 0.001 {
                    self.blend_pixel_aa(px, py, color, coverage);
                }
            }
        }
    }

    /// Draw a vectorShape (bezier curves with stroke/fill) onto this bitmap.
    /// Coordinates are mapped from local vertex space to the destination rect.
    pub fn draw_vector_shape(
        &mut self,
        vector_data: &crate::player::cast_member::VectorShapeMember,
        dst_rect: IntRect,
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        if vector_data.vertices.len() < 2 || alpha == 0.0 {
            return;
        }

        let verts = &vector_data.vertices;

        // Compute bounding box from vertices + stroke padding.
        // The stroke extends half its width beyond vertex positions, so we pad
        // the bbox to ensure the full stroke fits within the destination bitmap.
        let mut min_x = f32::MAX;
        let mut min_y = f32::MAX;
        let mut max_x = f32::MIN;
        let mut max_y = f32::MIN;
        for v in verts.iter() {
            min_x = min_x.min(v.x);
            min_y = min_y.min(v.y);
            max_x = max_x.max(v.x);
            max_y = max_y.max(v.y);
        }
        let pad = vector_data.stroke_width / 1.0;
        min_x -= pad;
        min_y -= pad;
        max_x += pad;
        max_y += pad;

        let src_w = max_x - min_x;
        let src_h = max_y - min_y;
        if src_w <= 0.0 || src_h <= 0.0 {
            return;
        }

        let dst_w = (dst_rect.right - dst_rect.left) as f32;
        let dst_h = (dst_rect.bottom - dst_rect.top) as f32;
        let scale_x = dst_w / src_w;
        let scale_y = dst_h / src_h;

        // Map a point from local vertex space to destination pixel coordinates
        let map_point = |x: f32, y: f32| -> (f32, f32) {
            let px = (x - min_x) * scale_x + dst_rect.left as f32;
            let py = (y - min_y) * scale_y + dst_rect.top as f32;
            (px, py)
        };

        // Flatten all bezier segments into polyline points
        let mut all_points: Vec<(f32, f32)> = Vec::new();
        let num_segments = if vector_data.closed {
            verts.len()
        } else {
            verts.len() - 1
        };

        for i in 0..num_segments {
            let j = (i + 1) % verts.len();
            let v0 = &verts[i];
            let v1 = &verts[j];

            // P0 = vertex[i]
            let p0 = map_point(v0.x, v0.y);
            // C1 = vertex[i] + handle1[i] (outgoing control point)
            let c1 = map_point(v0.x + v0.handle1_x, v0.y + v0.handle1_y);
            // C2 = vertex[j] + handle2[j] (incoming control point)
            let c2 = map_point(v1.x + v1.handle2_x, v1.y + v1.handle2_y);
            // P3 = vertex[j]
            let p3 = map_point(v1.x, v1.y);

            let segment_points = Self::flatten_cubic_bezier(p0, c1, c2, p3, 0.5);
            if i == 0 {
                all_points.extend_from_slice(&segment_points);
            } else {
                // Skip first point (duplicate of previous segment's last point)
                all_points.extend_from_slice(&segment_points[1..]);
            }
        }

        // Fill if fillMode != 0 AND the shape is closed.
        // fill_mode 1 = solid, fill_mode 2 = gradient (radial fill from
        // centroid → bbox corner). Only closed paths get a fill — an
        // open Bezier curve (like figure8 member "Intern", a thin
        // brown curve with strokeWidth 6) has fillMode authored as
        // #none in Director, but historically dirplayer parsed
        // fill_mode incorrectly (always 1 due to wrong FLSH offset)
        // AND filled regardless of `closed` — so open curves rendered
        // as filled blobs. With FLSH offsets now corrected (fillMode
        // at 0x84) the fill_mode is right; this `closed` gate keeps
        // open paths un-filled even if a future shape ends up with
        // fill_mode != 0 + closed = false (Director quirk: SVG-style
        // implicit-close fills are NOT applied to open paths).
        // The catalog floor preview's `floor_shape_preview` uses
        // fill_mode 2 with closed=true → still fills correctly.
        if vector_data.fill_mode != 0 && vector_data.closed && all_points.len() >= 3 {
            let is_gradient = vector_data.fill_mode == 2;
            self.scanline_fill_polygon_gradient(
                &all_points,
                vector_data.fill_color,
                vector_data.end_color,
                is_gradient,
                palettes,
                alpha,
            );
        }

        // Anti-aliased stroke
        if vector_data.stroke_width > 0.0 && all_points.len() >= 2 {
            let half_w = vector_data.stroke_width / 2.0;
            let color = vector_data.stroke_color;
            for i in 0..all_points.len() - 1 {
                let (x1, y1) = all_points[i];
                let (x2, y2) = all_points[i + 1];
                self.draw_line_aa(x1, y1, x2, y2, half_w, color, palettes, alpha);
            }
            // Draw round caps at each polyline point for smooth joins
            for &(px, py) in &all_points {
                self.draw_circle_aa(px, py, half_w, color, palettes, alpha);
            }
        }
    }

    /// Draw a vector shape with full ink support, following the same pattern as
    /// draw_shape_with_sprite: ink 0 draws directly, other inks use an intermediate
    /// bitmap + copy_pixels for proper ink compositing.
    pub fn draw_vector_shape_with_sprite(
        &mut self,
        sprite: &crate::player::sprite::Sprite,
        vector_data: &crate::player::cast_member::VectorShapeMember,
        dst_rect: IntRect,
        palettes: &PaletteMap,
    ) {
        let alpha = (sprite.blend as f32 / 100.0).clamp(0.0, 1.0);

        if sprite.ink == 0 {
            // Copy ink: draw directly onto destination bitmap
            self.draw_vector_shape(vector_data, dst_rect, palettes, alpha);
        } else {
            // Non-copy ink: use temp bitmap + copy_pixels for proper ink handling
            let w = dst_rect.width().max(1);
            let h = dst_rect.height().max(1);
            let mut temp = Bitmap::new(
                w as u16, h as u16,
                32, 32, 0,
                super::bitmap::PaletteRef::BuiltIn(get_system_default_palette()),
            );
            // Start fully transparent
            temp.data.fill(0);
            temp.use_alpha = true;

            // Draw vector shape into temp at local (0,0) coordinates
            let local_rect = IntRect::from_tuple((0, 0, w, h));
            temp.draw_vector_shape(vector_data, local_rect, palettes, 1.0);

            let mut params = HashMap::new();
            params.insert("blend".into(), Datum::Int(sprite.blend as i32));
            params.insert("ink".into(), Datum::Int(sprite.ink as i32));
            params.insert("color".into(), Datum::ColorRef(sprite.color.clone()));
            params.insert("bgColor".into(), Datum::ColorRef(sprite.bg_color.clone()));

            self.copy_pixels(
                palettes,
                &temp,
                dst_rect,
                IntRect::from_tuple((0, 0, w, h)),
                &params,
                None,
            );
        }
    }

    /// Scanline fill a polygon defined by a list of points.
    fn scanline_fill_polygon(
        &mut self,
        points: &[(f32, f32)],
        color: (u8, u8, u8),
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        // Solid-fill convenience wrapper.
        self.scanline_fill_polygon_gradient(points, color, color, false, palettes, alpha);
    }

    /// Polygon scanline fill with optional radial gradient. When
    /// `is_gradient` is true, pixels closer to the polygon centroid get
    /// `fill_color` and pixels at the bounding-box corners get `end_color`,
    /// with linear interpolation in between. CS catalog floor preview
    /// (`floor_shape_preview`) needs gradient fill so its trapezoid renders
    /// with the brown start→end ramp instead of a flat colour.
    fn scanline_fill_polygon_gradient(
        &mut self,
        points: &[(f32, f32)],
        fill_color: (u8, u8, u8),
        end_color: (u8, u8, u8),
        is_gradient: bool,
        palettes: &PaletteMap,
        alpha: f32,
    ) {
        if points.len() < 3 || alpha == 0.0 {
            return;
        }

        // Find extent
        let mut min_x = f32::MAX;
        let mut min_y = f32::MAX;
        let mut max_x = f32::MIN;
        let mut max_y = f32::MIN;
        let mut sum_x = 0.0f32;
        let mut sum_y = 0.0f32;
        for p in points.iter() {
            min_x = min_x.min(p.0);
            min_y = min_y.min(p.1);
            max_x = max_x.max(p.0);
            max_y = max_y.max(p.1);
            sum_x += p.0;
            sum_y += p.1;
        }
        let cx = sum_x / points.len() as f32;
        let cy = sum_y / points.len() as f32;
        let max_dist = {
            let dx1 = (max_x - cx).abs();
            let dx2 = (cx - min_x).abs();
            let dy1 = (max_y - cy).abs();
            let dy2 = (cy - min_y).abs();
            (dx1.max(dx2).powi(2) + dy1.max(dy2).powi(2)).sqrt().max(1.0)
        };

        let y_start = min_y.floor() as i32;
        let y_end = max_y.ceil() as i32;

        // For each scanline, find intersection x-coordinates with polygon edges
        for y in y_start..=y_end {
            let yf = y as f32 + 0.5; // sample at scanline center
            let mut intersections: Vec<f32> = Vec::new();

            let n = points.len();
            for i in 0..n {
                let j = (i + 1) % n;
                let (x0, y0) = points[i];
                let (x1, y1) = points[j];

                // Check if scanline crosses this edge
                if (y0 <= yf && y1 > yf) || (y1 <= yf && y0 > yf) {
                    let t = (yf - y0) / (y1 - y0);
                    intersections.push(x0 + t * (x1 - x0));
                }
            }

            intersections.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

            // Fill between pairs of intersections
            let mut i = 0;
            while i + 1 < intersections.len() {
                let x_start = intersections[i].ceil() as i32;
                let x_end = intersections[i + 1].floor() as i32;
                for x in x_start..=x_end {
                    let color = if is_gradient {
                        let dx = x as f32 + 0.5 - cx;
                        let dy = y as f32 + 0.5 - cy;
                        let t = ((dx * dx + dy * dy).sqrt() / max_dist).clamp(0.0, 1.0);
                        (
                            ((1.0 - t) * fill_color.0 as f32 + t * end_color.0 as f32) as u8,
                            ((1.0 - t) * fill_color.1 as f32 + t * end_color.1 as f32) as u8,
                            ((1.0 - t) * fill_color.2 as f32 + t * end_color.2 as f32) as u8,
                        )
                    } else {
                        fill_color
                    };
                    if alpha == 1.0 {
                        self.set_pixel(x, y, color, palettes);
                    } else {
                        let dst = self.get_pixel_color(palettes, x as u16, y as u16);
                        self.set_pixel(x, y, blend_color_alpha(dst, color, alpha), palettes);
                    }
                }
                i += 2;
            }
        }
    }

    pub fn copy_pixels(
        &mut self,
        palettes: &PaletteMap,
        src: &Bitmap,
        dst_rect: IntRect,
        src_rect: IntRect,
        param_list: &HashMap<String, Datum>,
        score: Option<&Score>,
    ) {
        let mut blend = param_list
            .get("blend")
            .map(|x| x.int_value().unwrap())
            .unwrap_or(100);
        let ink = param_list.get("ink");
        let mut ink = if let Some(ink) = ink {
            match ink {
                Datum::Symbol(s) => match s.as_lower_str() {
                    "copy" => 0,
                    "transparent" => 1,
                    "reverse" => 2,
                    "ghost" => 3,
                    "notcopy" => 4,
                    "nottransparent" => 5,
                    "notreverse" => 6,
                    "notghost" => 7,
                    "matte" => 8,
                    "mask" => 9,
                    "blend" => 32,
                    "addpin" => 33,
                    "add" => 34,
                    "subtractpin" => 35,
                    "backgroundtransparent" | "bgtransparent" => 36,
                    "lightest" => 37,
                    "subtract" => 38,
                    "darkest" => 39,
                    _ => ink.int_value().unwrap_or(0) as u32,
                },
                _ => ink.int_value().unwrap_or(0) as u32,
            }
        } else {
            0
        };
        // blendLevel (0-255) overrides blend (0-100) when present — used by
        // copyPixels with [#ink: #blend, #blendLevel: N]
        if let Some(blend_level) = param_list.get("blendLevel") {
            if let Ok(level) = blend_level.int_value() {
                blend = ((level as f64 * 100.0 / 255.0).round() as i32).max(0).min(100);
                if ink == 0 { ink = 32; } // auto-set blend ink when blendLevel is specified
            }
        }
        let bg_color_explicit = param_list.get("bgColor").is_some();
        let bg_color = param_list.get("bgColor");
        let bg_color = if let Some(bg_color) = bg_color {
            match bg_color {
                Datum::ColorRef(c) => c.to_owned(),
                Datum::Int(i) => ColorRef::PaletteIndex(*i as u8),
                _ => ColorRef::PaletteIndex(0),
            }
        } else {
            ColorRef::PaletteIndex(0)
        };
        let fore_color_explicit = param_list.get("color").is_some();
        let color = param_list.get("color");
        let color = if let Some(color) = color {
            match color {
                Datum::ColorRef(c) => c.to_owned(),
                Datum::Int(i) => ColorRef::PaletteIndex(*i as u8),
                _ => ColorRef::PaletteIndex(255),
            }
        } else {
            ColorRef::PaletteIndex(255)
        };

        let mask_image = param_list.get("maskImage");
        let mask_image = mask_image.and_then(|x| x.to_mask_or_none());

        // Extract rotation parameter (defaults to 0.0 if not provided)
        let rotation = param_list
            .get("rotation")
            .and_then(|x| x.float_value().ok())
            .unwrap_or(0.0);

        // Extract skew parameter (defaults to 0.0 if not provided)
        let skew = param_list
            .get("skew")
            .and_then(|x| x.float_value().ok())
            .unwrap_or(0.0);

        // Check if is_text_rendering parameter exists and is true
        // This is typically NOT set from Lingo scripts, only internally
        let is_text_rendering = param_list
            .get("is_text_rendering")
            .and_then(|x| x.to_bool().ok())
            .unwrap_or(false);

        // Get sprite number, then resolve to actual sprite
        let sprite = score.and_then(|score| {
            param_list
                .get("sprite")
                .and_then(|x| x.to_sprite_ref().ok())
                .and_then(|sprite_num| score.get_sprite(sprite_num))
        });

        let original_dst_rect: Option<IntRect> = param_list
            .get("original_dst_rect")
            .and_then(|datum| {
                if let Datum::Rect(vals, _flags) = datum {
                    Some(IntRect::from(vals[0] as i32, vals[1] as i32, vals[2] as i32, vals[3] as i32))
                } else {
                    None
                }
            });

        // Text glyphs ALWAYS use Copy ink
        if is_text_rendering {
            ink = 0;
        }

        // Extract maskOffset parameter
        let mask_offset = param_list
            .get("maskOffset")
            .and_then(|x| {
                if let Datum::Point(vals, _flags) = x {
                    Some((vals[0] as i32, vals[1] as i32))
                } else {
                    None
                }
            })
            .unwrap_or((0, 0));

        let params = CopyPixelsParams {
            blend,
            ink,
            bg_color,
            bg_color_explicit,
            fore_color_explicit,
            mask_image,
            mask_offset,
            color,
            is_text_rendering,
            rotation,
            skew,
            sprite,
            original_dst_rect,
            ink9_mask_bitmap: None,
            ink9_mask_offset: (0, 0),
            floor_rule: false,
        };
        self.copy_pixels_with_params(palettes, src, dst_rect, src_rect, &params);
    }

    /// Director `image.copyPixels(src, [P0, P1, P2, P3], srcRect, params)` —
    /// the 4-point destination form, used for perspective / skewed blits like
    /// HabbHotel's "screen3d" parallelogram-warped scroller. P0..P3 are the
    /// quad corners in TopLeft / TopRight / BottomRight / BottomLeft order
    /// (Director's documented order).
    ///
    /// We sample the source via inverse bilinear interpolation: for each
    /// destination pixel in the quad's bounding box we solve
    ///   P(u,v) = (1-u)(1-v)·P0 + u(1-v)·P1 + uv·P2 + (1-u)v·P3  =  (x,y)
    /// for (u,v) using a few Newton iterations, then sample the source rect
    /// at (src_rect.left + u·src_w, src_rect.top + v·src_h).
    ///
    /// v1 supports `#ink: 0 (copy)` only — that's what the scroller needs.
    /// Other inks fall back to the bounding-box stretched copy via
    /// `copy_pixels` so they keep working as before.
    pub fn copy_pixels_quad(
        &mut self,
        palettes: &PaletteMap,
        src: &Bitmap,
        quad: [(i32, i32); 4],
        src_rect: IntRect,
        param_list: &HashMap<String, Datum>,
    ) {
        // Bounding box of the quad.
        let min_x = quad.iter().map(|p| p.0).min().unwrap_or(0).max(0);
        let max_x = quad.iter().map(|p| p.0).max().unwrap_or(0).min(self.width as i32 - 1);
        let min_y = quad.iter().map(|p| p.1).min().unwrap_or(0).max(0);
        let max_y = quad.iter().map(|p| p.1).max().unwrap_or(0).min(self.height as i32 - 1);
        if min_x > max_x || min_y > max_y { return; }

        // Bilinear parameters: P(u,v) = a + b*u + c*v + d*u*v
        let p0 = (quad[0].0 as f32, quad[0].1 as f32);
        let p1 = (quad[1].0 as f32, quad[1].1 as f32);
        let p2 = (quad[2].0 as f32, quad[2].1 as f32);
        let p3 = (quad[3].0 as f32, quad[3].1 as f32);
        let a = p0;
        let b = (p1.0 - p0.0, p1.1 - p0.1);
        let c = (p3.0 - p0.0, p3.1 - p0.1);
        let d = (p0.0 - p1.0 - p3.0 + p2.0, p0.1 - p1.1 - p3.1 + p2.1);

        let src_w = (src_rect.right - src_rect.left) as f32;
        let src_h = (src_rect.bottom - src_rect.top) as f32;
        if src_w <= 0.0 || src_h <= 0.0 { return; }
        let src_x0 = src_rect.left as f32;
        let src_y0 = src_rect.top as f32;

        // Invalidate any cached matte — destination pixels change.
        self.matte = None;
        self.mark_dirty();

        for y in min_y..=max_y {
            for x in min_x..=max_x {
                // Solve b*u + c*v + d*u*v = (x - a.x, y - a.y) via Newton.
                let px = x as f32 - a.0;
                let py = y as f32 - a.1;
                let mut u = 0.5_f32;
                let mut v = 0.5_f32;
                let mut converged = false;
                for _ in 0..10 {
                    let fx = b.0 * u + c.0 * v + d.0 * u * v - px;
                    let fy = b.1 * u + c.1 * v + d.1 * u * v - py;
                    // Jacobian rows: [∂/∂u, ∂/∂v]
                    let j11 = b.0 + d.0 * v;
                    let j12 = c.0 + d.0 * u;
                    let j21 = b.1 + d.1 * v;
                    let j22 = c.1 + d.1 * u;
                    let det = j11 * j22 - j12 * j21;
                    if det.abs() < 1e-7 { break; }
                    let inv = 1.0 / det;
                    let du = (j22 * fx - j12 * fy) * inv;
                    let dv = (j11 * fy - j21 * fx) * inv;
                    u -= du;
                    v -= dv;
                    if du.abs() < 1e-4 && dv.abs() < 1e-4 {
                        converged = true;
                        break;
                    }
                }
                // Skip pixels outside the quad's actual shape — the iteration
                // walks the *bounding box* of the quad, so without this any
                // pixel above / beside the warped parallelogram would draw
                // with its u/v clamped to the boundary, smearing the edge
                // pixels into the gap. Allow a tiny epsilon so seam-of-the
                // edge pixels are still included.
                if !converged || u < -0.001 || u > 1.001 || v < -0.001 || v > 1.001 {
                    continue;
                }
                if u < 0.0 { u = 0.0; }
                if u > 1.0 { u = 1.0; }
                if v < 0.0 { v = 0.0; }
                if v > 1.0 { v = 1.0; }

                // u/v reach exactly 1.0 on the quad's far edge, where
                // `src_x0 + u * src_w` lands on src_rect.right — one pixel PAST
                // the last source column, because the rect is half-open. The
                // bounds check below then skipped that pixel, so every quad blit
                // silently lost its far row and far column.
                //
                // On a large warped blit that is an invisible one-pixel seam,
                // which is why it went unnoticed. It is destructive when the
                // destination is only a few pixels across: Habbo V31 builds its
                // window frames as a 9-slice whose 1x6 and 6x1 edge strips are
                // produced by MIRRORING a base piece, and Director expresses a
                // mirror as a quad — so for a 1x6 strip the dropped row is 1 of
                // 6, and mirroring puts v == 1.0 on the dark border line that
                // closes the frame. The strips arrived blank or border-less, the
                // composed window had white bands, and ink 36 (Background
                // Transparent) keyed that white out — which read as rounded
                // transparent corners on a frame that should be square.
                //
                // Clamp to the last valid source pixel instead of dropping it.
                let mut sx = (src_x0 + u * src_w) as i32;
                let mut sy = (src_y0 + v * src_h) as i32;
                if sx >= src_rect.right {
                    sx = src_rect.right - 1;
                }
                if sy >= src_rect.bottom {
                    sy = src_rect.bottom - 1;
                }
                // Kept as a backstop for source rects extending past the bitmap.
                if sx < 0 || sx >= src.width as i32 || sy < 0 || sy >= src.height as i32 {
                    continue;
                }
                let (r, g, bl, a) = src.get_pixel_color_with_alpha(palettes, sx as u16, sy as u16);
                // Honor the source's per-pixel alpha for 32-bit useAlpha images,
                // otherwise the rotated/warped blit paints the transparent
                // background as opaque. The player's rope-swing frames
                // (hero1_s1/s2 — 32-bit, useAlpha) are drawn through this quad
                // path; without this their black background showed as a solid
                // box around the hero. Fully transparent → skip; partial →
                // alpha-blend over the destination; opaque → straight copy.
                if src.use_alpha {
                    if a == 0 {
                        continue;
                    } else if a < 255 {
                        let dst = self.get_pixel_color(palettes, x as u16, y as u16);
                        let blended = blend_color_alpha(dst, (r, g, bl), a as f32 / 255.0);
                        self.set_pixel(x, y, blended, palettes);
                        continue;
                    }
                }
                self.set_pixel(x, y, (r, g, bl), palettes);
            }
        }
        let _ = param_list; // ink/blend handling deferred — v1 = copy ink only.
    }

    fn calculate_rotated_bounding_box(
        rect: &IntRect,
        rotation_degrees: f64,
        pivot_x: i32,
        pivot_y: i32,
    ) -> IntRect {
        let theta = rotation_degrees * std::f64::consts::PI / 180.0;
        let cos_theta = theta.cos();
        let sin_theta = theta.sin();
        
        // Registration point in sprite-local coordinates
        let pivot_x = pivot_x as f64;
        let pivot_y = pivot_y as f64;
            
        // Define the 4 corners of the original rectangle
        let corners = [
            (rect.left as f64, rect.top as f64),
            (rect.right as f64, rect.top as f64),
            (rect.right as f64, rect.bottom as f64),
            (rect.left as f64, rect.bottom as f64),
        ];
        
        // Rotate each corner around the pivot point
        let mut rotated_corners = Vec::new();
        for (x, y) in corners.iter() {
            let dx = x - pivot_x as f64;
            let dy = y - pivot_y as f64;
            
            let rotated_x = pivot_x as f64 + (dx * cos_theta - dy * sin_theta);
            let rotated_y = pivot_y as f64 + (dx * sin_theta + dy * cos_theta);
            
            rotated_corners.push((rotated_x, rotated_y));
        }
        
        // Find the bounding box of rotated corners
        let min_x = rotated_corners.iter().map(|(x, _)| *x).fold(f64::INFINITY, f64::min) as i32;
        let max_x = rotated_corners.iter().map(|(x, _)| *x).fold(f64::NEG_INFINITY, f64::max) as i32;
        let min_y = rotated_corners.iter().map(|(_, y)| *y).fold(f64::INFINITY, f64::min) as i32;
        let max_y = rotated_corners.iter().map(|(_, y)| *y).fold(f64::NEG_INFINITY, f64::max) as i32;
        
        IntRect::from(min_x, min_y, max_x, max_y)
    }

    fn apply_forecolor_tint(
        src: (u8, u8, u8),
        fore: (u8, u8, u8),
    ) -> (u8, u8, u8) {
        (
            ((src.0 as u16 * fore.0 as u16) / 255) as u8,
            ((src.1 as u16 * fore.1 as u16) / 255) as u8,
            ((src.2 as u16 * fore.2 as u16) / 255) as u8,
        )
    }

    fn allows_colorize(depth: u8, ink: u32, is_text: bool) -> bool {
        if is_text {
            return true; // text has its own rules
        }

        match (depth, ink) {
            (32, 0) => true,            // grayscale remap
            (32, 8) | (32, 9) => true,  // foreColor only
            (d, 0) if d <= 8 => true,
            (d, 8) | (d, 9) if d <= 8 => true,
            _ => false, // ink 36, 7, 33, 40, etc
        }
    }

    fn uses_back_color(depth: u8, ink: u32) -> bool {
        ink == 0 && (depth == 32 || depth <= 8)
    }

    /// Copy pixels from src to self, respecting scaling, flipping, masks, blending, and rotation
    pub fn copy_pixels_with_params(
        &mut self,
        palettes: &PaletteMap,
        src: &Bitmap,
        dst_rect: IntRect,
        src_rect: IntRect,
        params: &CopyPixelsParams,
    ) {
        // Destination pixels are about to change, so retire anything keyed on the
        // old contents. The WebGL2 texture cache keys on `bitmap.version`
        // (rendering_gpu/webgl2/mod.rs), so a member image mutated IN PLACE by
        // Lingo — `sprite.member.image.copyPixels(digit, …)`, the timer HUD in
        // Heatwave Racing and Age of Speed — kept rendering the texture uploaded
        // when the sprite first appeared: the clock froze at its first value and
        // only the odd character that happened to land on another invalidation
        // ever changed. Marked up front so every early return below is covered.
        self.matte = None;
        self.mark_dirty();

        let ink = params.ink;
        let alpha = params.blend as f32 / 100.0;
        let mask_image = params.mask_image;
        // Sprite foreColor/backColor palette indices are resolved against the bitmap's palette,
        // so they work together correctly (e.g., index 248/255 in a custom 256-color palette).
        let bg_color_resolved = resolve_color_ref(
            palettes,
            &params.bg_color,
            &src.palette_ref,
            src.original_bit_depth,
        );

        let fg_color_resolved = resolve_color_ref(
            palettes,
            &params.color,
            &src.palette_ref,
            src.original_bit_depth,
        );

        let is_indexed = src.original_bit_depth <= 8;

        // Pre-resolve palettes into lookup tables to avoid per-pixel resolve_color_ref calls.
        // Source table: used for reading indexed source pixels without calling resolve_color_ref.
        let src_palette_cache: Option<Vec<(u8, u8, u8)>> = if is_indexed {
            Some(resolve_palette_table(palettes, &src.palette_ref, src.original_bit_depth))
        } else {
            None
        };
        // Destination table: used by set_pixel_fast to avoid resolving the
        // palette per pixel, and to memoise the nearest-colour search that
        // writing an indexed pixel needs.
        let dst_palette_cache = if self.bit_depth <= 8 {
            resolve_palette_quantizer(palettes, &self.palette_ref, self.original_bit_depth)
        } else {
            std::rc::Rc::new(PaletteQuantizer::empty())
        };

        let bg_index = match &params.bg_color {
            ColorRef::PaletteIndex(i) => *i,
            _ => 0, // Director default
        }; 

        let is_matte_bitmap =
            src.trim_white_space
            || params.is_text_rendering;

        let use_grayscale_as_alpha = match src.palette_ref {
            PaletteRef::BuiltIn(palette) => {
                palette.symbol() == BuiltInSymbol::Grayscale
            }
            _ => false, // Any other palette → not grayscale
        };

        // ----------- Setup destination bounds and flip flags -------------
        let min_dst_x = dst_rect.left.min(dst_rect.right);
        let max_dst_x = dst_rect.left.max(dst_rect.right);
        let min_dst_y = dst_rect.top.min(dst_rect.bottom);
        let max_dst_y = dst_rect.top.max(dst_rect.bottom);
        let flip_x = dst_rect.right < dst_rect.left;
        let flip_y = dst_rect.bottom < dst_rect.top;

        // ----------- Scaling factors -------------
        let dst_w = (max_dst_x - min_dst_x) as f64;
        let dst_h = (max_dst_y - min_dst_y) as f64;
        let src_w = src_rect.width() as f64;
        let src_h = src_rect.height() as f64;

        // For rotation: use original rect dimensions for scaling, not expanded bounding box
        let (scale_w, scale_h) = if let Some(orig_rect) = &params.original_dst_rect {
            (
                (orig_rect.right - orig_rect.left) as f64,
                (orig_rect.bottom - orig_rect.top) as f64,
            )
        } else {
            (dst_w, dst_h)
        };

        // Use full ratio (src_size / dst_size)
        let scale_x = src_w / scale_w;
        let scale_y = src_h / scale_h;

        let min_dst_x_f = min_dst_x as f64;
        let min_dst_y_f = min_dst_y as f64;
        let src_left_f = src_rect.left as f64;
        let src_top_f = src_rect.top as f64;

        let mut sprite_num = 0;

        // ----------------------------------------------------------
        // Calculate sprite rotation pivot (registration point)
        // ----------------------------------------------------------
        let (center_x, center_y) = if let Some(sprite) = params.sprite {
            sprite_num = sprite.number;
            // Rotate around the sprite's registration point (locH, locV)
            (sprite.loc_h as f64, sprite.loc_v as f64)
        } else {
            // Fallback: rotate around center of destination rect
            (
                (dst_rect.left + dst_rect.right) as f64 / 2.0,
                (dst_rect.top + dst_rect.bottom) as f64 / 2.0,
            )
        };

        // Precompute rotation values if sprite rotation is needed
        let has_sprite_rotation = params.rotation.abs() > 0.1;
        let (cos_theta, sin_theta) = if has_sprite_rotation {
            let theta = -(params.rotation) * std::f64::consts::PI / 180.0;
            (theta.cos(), theta.sin())
        } else {
            (1.0, 0.0)
        };

        // Check for skew-based flip (skew=±180° combined with rotation produces a mirror)
        let has_skew_flip = is_skew_flip(params.skew);

        // Fast path — copy a 32-bit RGBA source into an 8-bit GRAYSCALE destination
        // for Director's text→alpha-mask→texture HUD pattern
        // (`grayImage.copyPixels(textImage)` then `rgba.setAlpha(grayImage)`): the
        // grayscale value is written as the SOURCE ALPHA (0=transparent..255=opaque).
        // Routing that through the colour path matched the reversed Mac grayscale CLUT
        // (white glyph → index 0), so setAlpha turned the glyphs transparent and left
        // the fill opaque (LEGO SuperSonic HUD digits invisible / white-blocked).
        //
        // This ONLY applies when the source actually carries transparency (a glyph
        // coverage / extractAlpha mask). A fully OPAQUE 32-bit source — e.g. the Habbo
        // camera capturing `(the stage).image` into an 8-bit #grayscale photo — has
        // alpha 255 everywhere, so writing alpha would make the whole image 255 (a
        // blank photo). For an opaque source we fall through to the colour path, which
        // maps each pixel to the nearest grayscale index — what real Director does for
        // an opaque 32→8 grayscale copy (and what makes the camera photo render).
        if ink == 0 && !has_sprite_rotation && !has_skew_flip
            && self.bit_depth == 8
            && matches!(self.palette_ref, PaletteRef::BuiltIn(BuiltInPalette::GrayScale))
            && src.bit_depth == 32
        {
            let dw = self.width as usize;
            // Map a destination pixel back to its source pixel index (respecting flip
            // and scale), or None if it samples outside the source.
            let src_index = |dx: i32, dy: i32| -> Option<usize> {
                let rel_x = if flip_x { (max_dst_x - 1 - dx) - min_dst_x } else { dx - min_dst_x } as f64;
                let rel_y = if flip_y { (max_dst_y - 1 - dy) - min_dst_y } else { dy - min_dst_y } as f64;
                let sx = (src_left_f + rel_x * scale_x).floor() as i32;
                let sy = (src_top_f + rel_y * scale_y).floor() as i32;
                if sx < 0 || sy < 0 || sx >= src.width as i32 || sy >= src.height as i32 { return None; }
                Some(((sy as usize) * src.width as usize + sx as usize) * 4)
            };
            // Only take the alpha-mask fast path if the copied source region is
            // mask-like: it either carries transparency (a glyph coverage image) or
            // is pure grayscale (R==G==B — what `extractAlpha()` returns, alpha 255
            // with the mask in RGB). A COLOUR opaque source — the Habbo camera
            // capturing `(the stage).image` into an 8-bit #grayscale photo — belongs
            // on the colour (nearest-index) path instead.
            let mut src_has_alpha = false;
            let mut src_is_gray = true;
            'scan: for dy in min_dst_y..max_dst_y {
                if dy < 0 || dy >= self.height as i32 { continue; }
                for dx in min_dst_x..max_dst_x {
                    if dx < 0 || dx >= self.width as i32 { continue; }
                    if let Some(si) = src_index(dx, dy) {
                        if si + 3 < src.data.len() {
                            if src.data[si + 3] < 255 {
                                src_has_alpha = true;
                                break 'scan;
                            }
                            if src.data[si] != src.data[si + 1] || src.data[si + 1] != src.data[si + 2] {
                                src_is_gray = false;
                            }
                        }
                    }
                }
            }
            if src_has_alpha || src_is_gray {
                for dy in min_dst_y..max_dst_y {
                    if dy < 0 || dy >= self.height as i32 { continue; }
                    for dx in min_dst_x..max_dst_x {
                        if dx < 0 || dx >= self.width as i32 { continue; }
                        if let Some(si) = src_index(dx, dy) {
                            if si + 3 < src.data.len() {
                                // Transparency-bearing source: its ALPHA is the mask
                                // (LEGO SuperSonic's timer digits copy the text image
                                // itself). Opaque grayscale source: the mask is already
                                // in RGB (`extractAlpha()` output — the "Time remaining"
                                // / "Points" labels), and the reversed Mac #grayscale
                                // CLUT would invert it to an opaque white block.
                                self.data[(dy as usize) * dw + dx as usize] = if src_has_alpha {
                                    src.data[si + 3]
                                } else {
                                    src.data[si]
                                };
                            }
                        }
                    }
                }
                self.matte = None;
                return;
            }
        }

        // ----------------------------------------------------------
        // Director-style draw bounds (allow rotated overflow)
        // ----------------------------------------------------------
        let (draw_min_x, draw_max_x, draw_min_y, draw_max_y) =
            if has_sprite_rotation {
                if let (Some(orig_rect), Some(sprite)) =
                    (&params.original_dst_rect, params.sprite)
                {
                    let expanded = Self::calculate_rotated_bounding_box(
                        orig_rect,
                        params.rotation,
                        sprite.loc_h,
                        sprite.loc_v,
                    );

                    (
                        expanded.left.min(expanded.right),
                        expanded.left.max(expanded.right),
                        expanded.top.min(expanded.bottom),
                        expanded.top.max(expanded.bottom),
                    )
                } else {
                    (min_dst_x, max_dst_x, min_dst_y, max_dst_y)
                }
            } else {
                (min_dst_x, max_dst_x, min_dst_y, max_dst_y)
            };

        let needs_matte_mask =
            !params.is_text_rendering
            && is_matte_bitmap
            && ((ink == 0 && src.original_bit_depth <= 8)
                || (ink == 8 && (src.original_bit_depth <= 8 || (src.original_bit_depth == 32 && !src.use_alpha))));

        let mut matte_mask: Option<Vec<Vec<bool>>> = None;

        // ----------------------------------------------------------
        // 32-bit matte key color:
        // - Ink 0: use bgColor (sprite's background color, typically white)
        // - Other inks (8, etc.): use edge color (pixel 0,0)
        // ----------------------------------------------------------
        let edge_matte_color: Option<(u8, u8, u8)> =
            if src.original_bit_depth == 32 && !src.use_alpha {
                let (r, g, b, _) =
                    src.get_pixel_color_with_alpha(palettes, 0, 0);
                Some((r, g, b))
            } else {
                None
            };

        if needs_matte_mask {
            let width = src.width as usize;
            let height = src.height as usize;

            let mut mask = vec![vec![false; width]; height];
            let mut stack = Vec::<(usize, usize)>::new();

            // Fast pixel color getter using cached palette table
            let get_src_rgb = |x: u16, y: u16| -> (u8, u8, u8) {
                let color_ref = src.get_pixel_color_ref(x, y);
                if let (ColorRef::PaletteIndex(i), Some(cache)) = (&color_ref, &src_palette_cache) {
                    cache[*i as usize]
                } else {
                    resolve_color_ref(palettes, &color_ref, &src.palette_ref, src.original_bit_depth)
                }
            };

            let matte_bg = edge_matte_color.unwrap_or(bg_color_resolved);

            // ---- seed flood fill from edges ----
            for x in 0..width {
                if get_src_rgb(x as u16, 0) == matte_bg {
                    stack.push((x, 0));
                }
                if get_src_rgb(x as u16, (height - 1) as u16) == matte_bg {
                    stack.push((x, height - 1));
                }
            }

            for y in 0..height {
                if get_src_rgb(0, y as u16) == matte_bg {
                    stack.push((0, y));
                }
                if get_src_rgb((width - 1) as u16, y as u16) == matte_bg {
                    stack.push((width - 1, y));
                }
            }

            // ---- flood fill ----
            while let Some((x, y)) = stack.pop() {
                if mask[y][x] {
                    continue;
                }

                if get_src_rgb(x as u16, y as u16) != matte_bg {
                    continue;
                }

                mask[y][x] = true;

                if x > 0 { stack.push((x - 1, y)); }
                if x + 1 < width { stack.push((x + 1, y)); }
                if y > 0 { stack.push((x, y - 1)); }
                if y + 1 < height { stack.push((x, y + 1)); }
            }

            matte_mask = Some(mask);
        }

        // ---------------- Fast path: unscaled, unrotated, same-palette 8-bit blit ----------------
        // The dominant per-frame cost in tile/map compositing (drawmap terrain
        // tiling, water copyPixels) is the O(256) nearest-color search inside
        // set_pixel_fast, run once per destination pixel. When the source and
        // destination are both 8-bit indexed sharing the same palette, index i
        // maps to index i, so we can copy raw index bytes row-by-row and skip
        // both the palette resolve AND the nearest-color search entirely.
        {
            let sprite_bg = params.sprite.map_or(false, |sp| sp.has_back_color);
            let sprite_fg = params.sprite.map_or(false, |sp| sp.has_fore_color);
            let no_colorize = !(sprite_bg
                || sprite_fg
                || params.bg_color_explicit
                || params.fore_color_explicit);
            let dst_span_w = max_dst_x - min_dst_x;
            let dst_span_h = max_dst_y - min_dst_y;
            let unscaled =
                dst_span_w == src_rect.width() && dst_span_h == src_rect.height();
            if self.bit_depth == 8
                && src.bit_depth == 8
                && src.palette_ref == self.palette_ref
                && !has_sprite_rotation
                && !has_skew_flip
                && !flip_x
                && !flip_y
                && unscaled
                && alpha >= 0.999
                && mask_image.is_none()
                && matte_mask.is_none()
                && no_colorize
                && (ink == 0 || ink == 2 || ink == 36)
            {
                // For color-key inks, precompute which source indices resolve to
                // the transparent background color (mirrors the per-pixel
                // `(r,g,b) == bg_color_resolved` skip).
                let transparent: Option<[bool; 256]> = if ink == 2 || ink == 36 {
                    let mut t = [false; 256];
                    if let Some(cache) = &src_palette_cache {
                        for (i, slot) in t.iter_mut().enumerate() {
                            if let Some(&rgb) = cache.get(i) {
                                *slot = rgb == bg_color_resolved;
                            }
                        }
                    }
                    Some(t)
                } else {
                    None
                };

                let dst_w = self.width as i32;
                let dst_h = self.height as i32;
                let sw = src.width as i32;
                let sh = src.height as i32;

                // Horizontal clip is constant across rows (no rotation/flip).
                let dx0 = min_dst_x.max(0);
                let dx1 = max_dst_x.min(dst_w);
                let src_x_start = src_rect.left + (dx0 - min_dst_x);
                let row_len = (dx1 - dx0).max(0) as usize;
                if row_len > 0
                    && src_x_start >= 0
                    && src_x_start + row_len as i32 <= sw
                {
                    self.matte = None;
                    let width = self.width as usize;
                    let s_width = src.width as usize;
                    for dst_y in min_dst_y.max(0)..max_dst_y.min(dst_h) {
                        let src_y = src_rect.top + (dst_y - min_dst_y);
                        if src_y < 0 || src_y >= sh {
                            continue;
                        }
                        let d_row = dst_y as usize * width + dx0 as usize;
                        let s_row = src_y as usize * s_width + src_x_start as usize;
                        match &transparent {
                            None => {
                                // Ink 0 (Copy): fully opaque raw byte copy.
                                self.data[d_row..d_row + row_len]
                                    .copy_from_slice(&src.data[s_row..s_row + row_len]);
                            }
                            Some(t) => {
                                // Ink 2/36: copy non-transparent indices only.
                                for i in 0..row_len {
                                    let idx = src.data[s_row + i];
                                    if !t[idx as usize] {
                                        self.data[d_row + i] = idx;
                                    }
                                }
                            }
                        }
                    }
                    return;
                }
            }
        }

        // -------- Index-preserving fast path: same-depth same-palette 1/4-bit --------
        // A copyPixels between two indexed bitmaps of the SAME low bit depth and
        // palette maps index i -> index i. The general per-pixel path below
        // resolves each index to RGB and re-quantizes on write, collapsing
        // distinct indices that share a brightness bucket (Tetris' 1-bit
        // game_plane row-shift on a line clear turned every occupied cell empty,
        // wiping the collision board). Copy the raw index straight across.
        // (8-bit already handled by the byte-copy path above; 1/4-bit have a real
        // get_pixel_color_ref index arm, 2-bit does not, so it's excluded.)
        {
            let sprite_bg = params.sprite.map_or(false, |sp| sp.has_back_color);
            let sprite_fg = params.sprite.map_or(false, |sp| sp.has_fore_color);
            let no_colorize = !(sprite_bg
                || sprite_fg
                || params.bg_color_explicit
                || params.fore_color_explicit);
            let unscaled = (max_dst_x - min_dst_x) == src_rect.width()
                && (max_dst_y - min_dst_y) == src_rect.height();
            if self.bit_depth == src.bit_depth
                && (self.bit_depth == 1 || self.bit_depth == 4)
                && src.palette_ref == self.palette_ref
                && !has_sprite_rotation
                && !has_skew_flip
                && !flip_x
                && !flip_y
                && unscaled
                && alpha >= 0.999
                && mask_image.is_none()
                && matte_mask.is_none()
                && no_colorize
                && ink == 0
            {
                self.matte = None;
                let dst_w = self.width as i32;
                let dst_h = self.height as i32;
                let sw = src.width as i32;
                let sh = src.height as i32;
                for dst_y in min_dst_y.max(0)..max_dst_y.min(dst_h) {
                    let src_y = src_rect.top + (dst_y - min_dst_y);
                    if src_y < 0 || src_y >= sh {
                        continue;
                    }
                    for dst_x in min_dst_x.max(0)..max_dst_x.min(dst_w) {
                        let src_x = src_rect.left + (dst_x - min_dst_x);
                        if src_x < 0 || src_x >= sw {
                            continue;
                        }
                        if let ColorRef::PaletteIndex(idx) =
                            src.get_pixel_color_ref(src_x as u16, src_y as u16)
                        {
                            self.set_pixel_index(dst_x, dst_y, idx);
                        }
                    }
                }
                return;
            }
        }

        // ---------------- Pixel loop ----------------
        // Invalidate the cached matte ONCE for the whole blit. `set_pixel_fast`
        // used to do this per pixel. (The early-return fast paths above each
        // clear it themselves before returning.)
        self.matte = None;
        for dst_y in draw_min_y..draw_max_y {
            for dst_x in draw_min_x..draw_max_x {
                if dst_x < 0
                    || dst_y < 0
                    || dst_x >= self.width as i32
                    || dst_y >= self.height as i32
                {
                    continue;
                }

                // ----------------------------------------------------------
                // SPRITE ROTATION & SKEW: Apply transforms to destination coordinates
                // ----------------------------------------------------------
                let (rotated_x, rotated_y) = if has_sprite_rotation || has_skew_flip {
                    // Translate to center
                    let dx = dst_x as f64 - center_x as f64;
                    let mut dy = dst_y as f64 - center_y as f64;

                    // Apply skew flip (negate Y before rotation)
                    // When combined with rotation=180, this produces a vertical flip (mirror)
                    // rotation=180 alone: (dx, dy) -> (-dx, -dy) = upside down
                    // rotation=180 + skew=180: (dx, -dy) -> (-dx, dy) = vertical flip
                    if has_skew_flip {
                        dy = -dy;
                    }

                    // Apply inverse rotation matrix
                    let rx = dx * cos_theta - dy * sin_theta;
                    let ry = dx * sin_theta + dy * cos_theta;

                    // Translate back
                    (rx + center_x as f64, ry + center_y as f64)
                } else {
                    (dst_x as f64, dst_y as f64)
                };

                // Calculate indices relative to destination rect
                let dst_x_idx = rotated_x - min_dst_x_f;
                let dst_y_idx = rotated_y - min_dst_y_f;

                // Check if rotated pixel is within destination bounds
                if dst_x_idx < 0.0 || dst_x_idx >= dst_w || dst_y_idx < 0.0 || dst_y_idx >= dst_h {
                    continue;
                }

                // Map destination pixel to source coordinate with scaling.
                // Director samples a stretched bitmap at floor(d * src / dst),
                // the top-left of the destination pixel, not its centre.
                // Measured on klods.dcr's ruler (member 82, 239x46 drawn at
                // 166x32): the floor rule reproduces the projector's pixels
                // 100%, the centre rule 88%, and the difference is the digit
                // rows the centre rule skips. Rotation and skew keep the
                // centre so their resampling stays symmetric.
                // Floor rule (phase 0) only for an authored bitmap scaling down;
                // see the shader.
                let scaling_up = scale_x < 1.0 || scale_y < 1.0;
                let phase = if has_sprite_rotation || has_skew_flip || scaling_up || !params.floor_rule { 0.5 } else { 0.0 };
                let src_f_x = src_left_f + (dst_x_idx + phase) * scale_x;
                let src_f_y = src_top_f + (dst_y_idx + phase) * scale_y;

                // Handle horizontal flip
                let src_mapped_x = if flip_x {
                    let rel = src_f_x - src_left_f;
                    src_left_f + src_w - rel
                } else {
                    src_f_x
                };

                // Handle vertical flip
                let src_mapped_y = if flip_y {
                    let rel = src_f_y - src_top_f;
                    src_top_f + src_h - rel
                } else {
                    src_f_y
                };

                // Convert to integer sample coordinates with flooring and clamping
                let sx = src_mapped_x.floor() as i32;
                let sy = src_mapped_y.floor() as i32;

                let src_max_x = src_rect.right - 1;
                let src_max_y = src_rect.bottom - 1;

                if src_rect.left > src_max_x || src_rect.top > src_max_y {
                    continue;
                }

                let sx = sx.clamp(src_rect.left, src_max_x) as u16;
                let sy = sy.clamp(src_rect.top, src_max_y) as u16;

                // check if its in the boundaries
                if sx >= src.width || sy >= src.height {
                    continue;
                }

                // Indexed bitmap (1-8 bit) ink 0
                if ink == 0 && is_indexed {
                    // Check matte mask for trimWhiteSpace transparency
                    // mask: true = opaque (draw), false = transparent (skip)
                    if let Some(mask) = mask_image {
                        let mx = (sx as i32 - params.mask_offset.0).max(0) as u16;
                        let my = (sy as i32 - params.mask_offset.1).max(0) as u16;
                        if !mask.get_bit(mx, my) {
                            continue; // Edge-connected background pixel - skip
                        }
                    }

                    let color_ref = src.get_pixel_color_ref(sx, sy);
                    let (mut sr, mut sg, mut sb) = if let (ColorRef::PaletteIndex(i), Some(cache)) = (&color_ref, &src_palette_cache) {
                        cache[*i as usize]
                    } else {
                        resolve_color_ref(palettes, &color_ref, &src.palette_ref, src.original_bit_depth)
                    };

                    // Bitmap ink=0 colorization: mirrors the WebGL2 shader logic.
                    // bgColor default is white (255,255,255), foreColor default
                    // is black (0,0,0); explicit `#bgColor` / `#color` in the
                    // copyPixels param list (Lingo direct bitmap op, no sprite)
                    // counts as "set". Coke Studios' chat renderer relies on
                    // this for `bubblename.copyPixels(... [#bgColor: cColor])`,
                    // and the catalog list does the same per separator icon.
                    //
                    // Lerp NEAR-grayscale pixels along the eff_fg→eff_bg ramp.
                    // Coloured detail pixels (e.g. the brown wood-grain baked
                    // into each catalog separator's `_small` icon) keep their
                    // authored RGB so the icon retains its detail while the
                    // white/grey shading picks up the requested tint.
                    //
                    // Strict R=G=B was too narrow — palette-indexed icons often
                    // dither their grey shades into nearly-equal-but-not-quite
                    // values like (200, 198, 199), so only one face of an
                    // isometric box would tint. A small RGB span tolerance
                    // catches those without touching the brown-ish details
                    // (whose channels diverge by 30+).
                    let sprite_bg = params.sprite.map_or(false, |sp| sp.has_back_color);
                    let sprite_fg = params.sprite.map_or(false, |sp| sp.has_fore_color);
                    let apply_bg = sprite_bg || params.bg_color_explicit;
                    let apply_fg = sprite_fg || params.fore_color_explicit;
                    if apply_bg || apply_fg {
                        let max_c = sr.max(sg).max(sb);
                        let min_c = sr.min(sg).min(sb);
                        let near_grayscale = max_c - min_c <= 16;
                        if near_grayscale {
                            let eff_fg = if apply_fg { fg_color_resolved } else { (0u8, 0u8, 0u8) };
                            let eff_bg = if apply_bg { bg_color_resolved } else { (255u8, 255u8, 255u8) };
                            if eff_fg != (0, 0, 0) || eff_bg != (255, 255, 255) {
                                let gray = ((sr as u16 + sg as u16 + sb as u16) / 3) as u8;
                                let t = gray as f32 / 255.0;
                                sr = ((1.0 - t) * eff_fg.0 as f32 + t * eff_bg.0 as f32) as u8;
                                sg = ((1.0 - t) * eff_fg.1 as f32 + t * eff_bg.1 as f32) as u8;
                                sb = ((1.0 - t) * eff_fg.2 as f32 + t * eff_bg.2 as f32) as u8;
                            }
                        }
                    }

                    // Apply #blend (alpha) when < 100. The CS catalog's
                    // WFpreview script overlays the gray studiofloor pattern
                    // on top of the colored floor gradient using
                    // `[#blend: FloorTextureblend, #maskImage: floormatte]`
                    // — no ink, so the default ink:0 path runs, and without
                    // alpha-blending here the gray pattern fully overwrote
                    // the colored gradient. Other indexed inks (2/36) already
                    // do this; ink:0 was a gap.
                    let final_color = if alpha >= 0.999 {
                        (sr, sg, sb)
                    } else {
                        let dst_color = if !dst_palette_cache.is_empty() {
                            self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16)
                        } else {
                            self.get_pixel_color(palettes, dst_x as u16, dst_y as u16)
                        };
                        blend_color_alpha(dst_color, (sr, sg, sb), alpha)
                    };
                    self.set_pixel_fast(dst_x, dst_y, final_color, &dst_palette_cache);
                    continue;
                }

                // Indexed bitmap (1-8 bit) ink 36 color-key transparency
                if (ink == 2 || ink == 36) && is_indexed {
                    let color_ref = src.get_pixel_color_ref(sx, sy);
                    let ColorRef::PaletteIndex(i) = color_ref else {
                        let (sr, sg, sb) = match &color_ref {
                            ColorRef::Rgb(r, g, b) => (*r, *g, *b),
                            _ => continue,
                        };
                        if (sr, sg, sb) == bg_color_resolved {
                            continue;
                        }
                        let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };
                        let blended = if alpha >= 0.999 {
                            (sr, sg, sb)
                        } else {
                            blend_color_alpha(dst_color, (sr, sg, sb), alpha)
                        };
                        self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                        continue;
                    };

                    // For 1-bit bitmaps: use strict index-based transparency only
                    // Index 0 (bit=0) = background → transparent
                    // Index 255 (bit=1) = foreground → render with foreColor
                    // This is important when foreColor and bgColor resolve to the same RGB
                    // (e.g., both white) - we still want foreground pixels to render.
                    if src.original_bit_depth == 1 {
                        if i == 0 {
                            continue; // Background bit → transparent
                        }
                        // Foreground bit → render with foreColor
                        let src_color = fg_color_resolved;
                        let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                        let blended = if alpha >= 0.999 {
                            src_color
                        } else {
                            blend_color_alpha(dst_color, src_color, alpha)
                        };

                        self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                        continue;
                    }

                    let transparent_index = if src.original_bit_depth <= 4 {
                        0 // Director rule for ≤4-bit
                    } else {
                        bg_index // 8-bit
                    };

                    // Resolve color via cached palette table
                    let (r, g, b) = if let Some(cache) = &src_palette_cache {
                        cache[i as usize]
                    } else {
                        resolve_color_ref(palettes, &ColorRef::PaletteIndex(i), &src.palette_ref, src.original_bit_depth)
                    };

                    // Fast path: check index match first
                    if i == transparent_index && (r, g, b) == bg_color_resolved {
                        continue;
                    }

                    if (r, g, b) == bg_color_resolved {
                        continue; // transparent - RGB matches background color
                    }

                    // If alpha channel disabled → fully opaque
                    let src_alpha = 1.0;

                    // For monochrome-style bitmaps (black content on white bg) with ink 36,
                    // the foreground pixels should be tinted with the sprite's foreColor.
                    // This allows white foreColor to make black numbers appear white.
                    // Only apply if foreColor was explicitly set via Lingo/tweening.
                    let has_fg = params.sprite.map_or(false, |s| s.has_fore_color);
                    let src_color = if has_fg && (i == 255 || (r, g, b) == (0, 0, 0)) {
                        fg_color_resolved // Tint foreground with sprite's foreColor
                    } else {
                        (r, g, b) // Keep original color
                    };

                    let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                    let blended = if src_alpha >= 0.999 && alpha >= 0.999 {
                        src_color
                    } else {
                        blend_color_alpha(dst_color, src_color, src_alpha * alpha)
                    };

                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // 16-bit bitmap ink 36 color-key transparency
                // 16-bit is stored as 32-bit RGB, so compare RGB values directly
                if (ink == 2 || ink == 36) && src.original_bit_depth == 16 {
                    let (r, g, b, _) = src.get_pixel_color_with_alpha(palettes, sx, sy);

                    // Skip pixel if it matches the sprite's bgColor (with tolerance
                    // for RGB565 quantization — pixel values may differ by up to ~4 from bgColor)
                    let max_diff = (r as i16 - bg_color_resolved.0 as i16).unsigned_abs()
                        .max((g as i16 - bg_color_resolved.1 as i16).unsigned_abs())
                        .max((b as i16 - bg_color_resolved.2 as i16).unsigned_abs());
                    if max_diff <= 4 {
                        continue; // transparent - RGB matches background color within 16-bit tolerance
                    }

                    let src_color = (r, g, b);
                    let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                    let blended = if alpha >= 0.999 {
                        src_color
                    } else {
                        blend_color_alpha(dst_color, src_color, alpha)
                    };

                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // 32-bit bitmap ink 36 color-key transparency
                // PFR font bitmaps are decoded to 32-bit RGBA; background is white, glyphs are black.
                if (ink == 2 || ink == 36) && src.original_bit_depth == 32 {
                    let (r, g, b, a) = src.get_pixel_color_with_alpha(palettes, sx, sy);

                    // Skip fully transparent pixels (use_alpha bitmaps like text member images)
                    if src.use_alpha && a == 0 {
                        continue;
                    }

                    // Skip pixel if it matches the sprite's bgColor (transparent background)
                    if (r, g, b) == bg_color_resolved {
                        continue;
                    }

                    // Colorize foreground (black/dark) pixels with the sprite's foreColor
                    let src_color = if (r, g, b) == (0, 0, 0) {
                        fg_color_resolved
                    } else {
                        (r, g, b)
                    };

                    // For text rendering to intermediate bitmap: write colorized RGB with
                    // per-pixel alpha directly. set_pixel always writes alpha=255 which
                    // destroys anti-aliasing information needed by WebGL2 compositing.
                    if params.is_text_rendering && src.use_alpha && a < 255 && self.bit_depth == 32 {
                        if dst_x >= 0 && dst_y >= 0 && dst_x < self.width as i32 && dst_y < self.height as i32 {
                            let idx = (dst_y as usize * self.width as usize + dst_x as usize) * 4;
                            if idx + 3 < self.data.len() {
                                let (sr, sg, sb) = src_color;
                                let dest_a = self.data[idx + 3];
                                if dest_a == 0 {
                                    self.data[idx] = sr;
                                    self.data[idx + 1] = sg;
                                    self.data[idx + 2] = sb;
                                    self.data[idx + 3] = a;
                                } else {
                                    // Composite src over dest using "over" operator
                                    let sa = a as f32 / 255.0;
                                    let da = dest_a as f32 / 255.0;
                                    let out_a = sa + da * (1.0 - sa);
                                    if out_a > 0.001 {
                                        let out_r = (sr as f32 * sa + self.data[idx] as f32 * da * (1.0 - sa)) / out_a;
                                        let out_g = (sg as f32 * sa + self.data[idx + 1] as f32 * da * (1.0 - sa)) / out_a;
                                        let out_b = (sb as f32 * sa + self.data[idx + 2] as f32 * da * (1.0 - sa)) / out_a;
                                        self.data[idx] = out_r.round().min(255.0) as u8;
                                        self.data[idx + 1] = out_g.round().min(255.0) as u8;
                                        self.data[idx + 2] = out_b.round().min(255.0) as u8;
                                        self.data[idx + 3] = (out_a * 255.0).round().min(255.0) as u8;
                                    }
                                }
                            }
                        }
                        continue;
                    }

                    let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                    // Honor the per-pixel source alpha for use_alpha bitmaps,
                    // combined with the #blend factor. Without this a soft
                    // (semi-transparent) glow — e.g. the rune/coin shine in
                    // `inventory_goldBall*`, drawn with ink 36 — rendered as a
                    // hard opaque grey halo because only the whole-blit #blend
                    // was applied. Non-alpha 32-bit bitmaps keep src_a = 1.0,
                    // so their color-key behavior is unchanged.
                    let src_a = if src.use_alpha { a as f32 / 255.0 } else { 1.0 };
                    let eff = src_a * alpha;
                    let blended = if eff >= 0.999 {
                        src_color
                    } else {
                        blend_color_alpha(dst_color, src_color, eff)
                    };

                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // Skip mask check for ink 33 - it handles transparency via bgColor check
                if ink != 33 {
                    if let Some(mask) = mask_image {
                        let mx = (sx as i32 - params.mask_offset.0).max(0) as u16;
                        let my = (sy as i32 - params.mask_offset.1).max(0) as u16;
                        if !mask.get_bit(mx, my) {
                            continue;
                        }
                    }
                }

                // 16-bit bitmap ink 0 (copy with matte for trimWhiteSpace)
                // Uses matte mask created from edge-connected white pixels
                if ink == 0 && src.original_bit_depth == 16 {
                    // Matte mask check already done above via mask_image
                    let (r, g, b, _) = src.get_pixel_color_with_alpha(palettes, sx, sy);

                    let src_color = (r, g, b);
                    let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                    let blended = if alpha >= 0.999 {
                        src_color
                    } else {
                        blend_color_alpha(dst_color, src_color, alpha)
                    };

                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // Indexed bitmap (1-8 bit) ink 8
                if ink == 8 && is_indexed {
                    let color_ref = src.get_pixel_color_ref(sx, sy);
                    let (sr, sg, sb) = if let (ColorRef::PaletteIndex(i), Some(cache)) = (&color_ref, &src_palette_cache) {
                        cache[*i as usize]
                    } else {
                        resolve_color_ref(palettes, &color_ref, &src.palette_ref, src.original_bit_depth)
                    };

                    // Check matte mask - only edge-connected bg pixels are transparent
                    if let Some(mask) = &matte_mask {
                        if mask[sy as usize][sx as usize] {
                            continue; // This pixel is transparent
                        }
                    }

                    // If alpha channel disabled → fully opaque
                    let src_alpha = 1.0;

                    let mut src_color = (sr, sg, sb);

                    // foreColor multiply tint (Director ink=8 + #color/sprite.color
                    // semantics): grayscale dirt overlays in the catalog wall
                    // preview need to multiply with the sprite/copyPixels
                    // foreColor so the gray pattern reads as a darker shade of
                    // the wall colour, not as a desaturating gray smear.
                    let sprite_fg = params.sprite.map_or(false, |sp| sp.has_fore_color);
                    let has_fg = sprite_fg || params.fore_color_explicit;
                    if has_fg && fg_color_resolved != (0, 0, 0) {
                        src_color = Self::apply_forecolor_tint(src_color, fg_color_resolved);
                    }

                    let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                    let blended = if src_alpha >= 0.999 && alpha >= 0.999 {
                        src_color
                    } else {
                        blend_color_alpha(dst_color, src_color, src_alpha * alpha)
                    };

                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // Ink 9 (Mask): use next cast member's bitmap as grayscale alpha mask
                // Black=opaque, white=transparent, grays=partial transparency
                if ink == 9 {
                    if let Some(mask_bmp) = params.ink9_mask_bitmap {
                        // Director aligns the mask to the source by their
                        // registration points; ink9_mask_offset =
                        // mask_reg - src_reg. Sample positions that fall
                        // outside the mask (negative or >= mask dim) are
                        // treated as transparent.
                        let mx_signed = sx as i32 + params.ink9_mask_offset.0;
                        let my_signed = sy as i32 + params.ink9_mask_offset.1;
                        if mx_signed < 0
                            || my_signed < 0
                            || mx_signed >= mask_bmp.width as i32
                            || my_signed >= mask_bmp.height as i32
                        {
                            continue; // outside mask coverage → transparent
                        }
                        let mx = mx_signed as u16;
                        let my = my_signed as u16;
                        let (mr, mg, mb) = mask_bmp.get_pixel_color(palettes, mx, my);
                        // Invert grayscale: black(0)→opaque(1.0), white(255)→transparent(0.0)
                        let gray = (mr as u16 + mg as u16 + mb as u16) / 3;
                        let mask_alpha = (255 - gray as u8) as f32 / 255.0;

                        if mask_alpha < 0.004 {
                            continue; // Fully transparent
                        }

                        let (sr, sg, sb) = if let Some(cache) = &src_palette_cache {
                            let color_ref = src.get_pixel_color_ref(sx, sy);
                            if let ColorRef::PaletteIndex(i) = color_ref {
                                cache[i as usize]
                            } else {
                                src.get_pixel_color(palettes, sx, sy)
                            }
                        } else {
                            src.get_pixel_color(palettes, sx, sy)
                        };

                        let sa_f = mask_alpha * alpha;

                        // For 32-bit alpha-aware destinations (filmloop
                        // bitmaps), write src RGB unchanged with proper alpha
                        // so the eventual stage composite produces the right
                        // translucent fade. Going through set_pixel_fast
                        // would lerp src toward transparent dst (darkening
                        // bright src pixels) and then force dst alpha=0xFF —
                        // turning a soft flame into an opaque dark blob.
                        if self.bit_depth == 32 && self.use_alpha {
                            if sa_f < 0.001 {
                                continue;
                            }
                            let idx = (dst_y as usize * self.width as usize + dst_x as usize) * 4;
                            if idx + 3 < self.data.len() {
                                let dr = self.data[idx] as f32;
                                let dg = self.data[idx + 1] as f32;
                                let db = self.data[idx + 2] as f32;
                                let da = self.data[idx + 3] as f32 / 255.0;
                                let one_minus_sa = 1.0 - sa_f;
                                let out_a = sa_f + da * one_minus_sa;
                                if out_a < 0.001 {
                                    self.data[idx + 3] = 0;
                                } else {
                                    let inv = 1.0 / out_a;
                                    self.data[idx]     = ((sr as f32 * sa_f + dr * da * one_minus_sa) * inv).clamp(0.0, 255.0) as u8;
                                    self.data[idx + 1] = ((sg as f32 * sa_f + dg * da * one_minus_sa) * inv).clamp(0.0, 255.0) as u8;
                                    self.data[idx + 2] = ((sb as f32 * sa_f + db * da * one_minus_sa) * inv).clamp(0.0, 255.0) as u8;
                                    self.data[idx + 3] = (out_a * 255.0).round().clamp(0.0, 255.0) as u8;
                                }
                            }
                            continue;
                        }

                        let dst_color = if !dst_palette_cache.is_empty() {
                            self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16)
                        } else {
                            self.get_pixel_color(palettes, dst_x as u16, dst_y as u16)
                        };

                        let blended = blend_color_alpha(dst_color, (sr, sg, sb), sa_f);
                        self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                        continue;
                    }
                }

                // Sample source pixel
                let (sr, sg, sb, mut sa) = if let Some(cache) = &src_palette_cache {
                    src.get_pixel_color_with_alpha_fast(cache, sx, sy)
                } else {
                    src.get_pixel_color_with_alpha(palettes, sx, sy)
                };

                // Skip fully transparent pixels from RGBA bitmaps when the
                // destination CAN'T hold alpha (would end up as opaque black).
                // When the destination DOES hold alpha (use_alpha=true), don't
                // skip — fall through so the ink 0 path below writes the
                // transparent pixel verbatim, which erases stale content
                // (required for chat buffer scrolling with shifted-slice blits).
                if src.original_bit_depth == 32 && src.use_alpha && sa == 0
                    && !(self.bit_depth == 32 && self.use_alpha && ink == 0 && !params.is_text_rendering)
                {
                    continue;
                }

                // When copying a non-alpha source (e.g., text member image) onto a 32-bit
                // use_alpha destination (e.g., image created with setAlpha(0)), skip white
                // background pixels so the destination's transparency is preserved.
                // This matches Director behavior where copyPixels ink 0 to an alpha-enabled
                // destination preserves transparency for the source's background color.
                if ink == 0
                    && !src.use_alpha
                    && self.bit_depth == 32
                    && self.use_alpha
                    && (sr, sg, sb) == (255, 255, 255)
                {
                    continue;
                }

                let mut src_color = (sr, sg, sb);

                // ----------------------------------------------------------
                // DIRECTOR COLORIZE (foreColor / backColor tweening)
                // ----------------------------------------------------------
                // `has_bg`/`has_fg` fires when a sprite's has_back/fore_color
                // flag is set, OR when the copyPixels param list explicitly
                // carried `#bgColor`/`#color` (Lingo direct bitmap op). Coke
                // Studios' chat renderer does the latter to tint `cc.bubble.left`
                // with the avatar chest color via
                //   bubblename.copyPixels(sourceimg, ..., [#bgColor: cColor])
                let sprite_fg = params.sprite.map_or(false, |sp| sp.has_fore_color);
                let sprite_bg = params.sprite.map_or(false, |sp| sp.has_back_color);
                let has_fg = sprite_fg || params.fore_color_explicit;
                let has_bg = sprite_bg || params.bg_color_explicit;
                if (has_fg || has_bg)
                    && Self::allows_colorize(src.original_bit_depth, ink, params.is_text_rendering)
                {
                    match src.original_bit_depth {
                        // ---------- 32-BIT ----------
                        32 => {
                            // Treat source as grayscale intensity; remap along
                            // the fg→bg ramp. When only one of fg/bg is
                            // explicit, use black/white as the implicit
                            // counterpart so anti-aliased edge pixels get
                            // tinted proportionally (not just pure white).
                            // Coke Studios' chat bubble passes `#bgColor: cColor`
                            // alone and expects `cc.bubble.left`'s white
                            // interior AND its rounded-corner gradient to all
                            // take on the chest colour.
                            if (has_fg || has_bg) && Self::uses_back_color(32, ink) {
                                let gray = ((sr as u16 + sg as u16 + sb as u16) / 3) as u8;
                                let eff_fg = if has_fg { fg_color_resolved } else { (0u8, 0u8, 0u8) };
                                let eff_bg = if has_bg { bg_color_resolved } else { (255u8, 255u8, 255u8) };
                                let t = gray as f32 / 255.0;
                                src_color = (
                                    ((1.0 - t) * eff_fg.0 as f32 + t * eff_bg.0 as f32) as u8,
                                    ((1.0 - t) * eff_fg.1 as f32 + t * eff_bg.1 as f32) as u8,
                                    ((1.0 - t) * eff_fg.2 as f32 + t * eff_bg.2 as f32) as u8,
                                );
                            } else if has_fg {
                                let gray = ((sr as u16 + sg as u16 + sb as u16) / 3) as u8;
                                if gray <= 1 {
                                    src_color = fg_color_resolved;
                                }
                            }
                        }

                        // ---------- INDEXED (≤8-bit) ----------
                        _ => {
                            // Palette index based semantics
                            let color_ref = src.get_pixel_color_ref(sx, sy);

                            if let ColorRef::PaletteIndex(i) = color_ref {
                                let max = (1 << src.original_bit_depth) - 1;
                                let t = i as f32 / max as f32;

                                if has_fg && has_bg && Self::uses_back_color(src.original_bit_depth, ink) {
                                    src_color = (
                                        ((1.0 - t) * fg_color_resolved.0 as f32
                                            + t * bg_color_resolved.0 as f32) as u8,
                                        ((1.0 - t) * fg_color_resolved.1 as f32
                                            + t * bg_color_resolved.1 as f32) as u8,
                                        ((1.0 - t) * fg_color_resolved.2 as f32
                                            + t * bg_color_resolved.2 as f32) as u8,
                                    );
                                } else if has_fg && i == 0 {
                                    src_color = fg_color_resolved;
                                }
                            }
                        }
                    }
                }

                if src.original_bit_depth == 32 && ink == 0 && !params.is_text_rendering {
                    if !src.use_alpha {
                        sa = 255;
                    } else if self.bit_depth == 32 && self.use_alpha {
                        // Full RGBA verbatim copy when both src and dst have alpha.
                        // Transparent src pixels (sa=0) erase dst content — required
                        // for offscreen-buffer scrolling (chat history) where the
                        // updateView blit copies a shifted slice of pOffscreenImg
                        // into destimg and must clear stale pixels in the gaps.
                        // Write the colorized `src_color` (not raw sr/sg/sb) so
                        // the explicit-bgColor white→tint substitution above
                        // actually lands in the destination bitmap.
                        let (wr, wg, wb) = src_color;
                        let idx = (dst_y as usize * self.width as usize + dst_x as usize) * 4;
                        if idx + 3 < self.data.len() {
                            self.data[idx] = wr;
                            self.data[idx + 1] = wg;
                            self.data[idx + 2] = wb;
                            self.data[idx + 3] = sa;
                        }
                        self.matte = None;
                        continue;
                    } else if sa == 0 {
                        continue;
                    }
                }

                if src.original_bit_depth == 32 && ink == 8 && !params.is_text_rendering {
                    if !src.use_alpha {
                        if let Some(mask) = &matte_mask {
                            if mask[sy as usize][sx as usize] {
                                continue;
                            }
                        }
                        sa = 255;
                    }

                    let src_alpha = if src.use_alpha {
                        sa as f32 / 255.0
                    } else {
                        1.0
                    };

                    let mut src_color = (sr, sg, sb);

                    let sprite_fg = params.sprite.map_or(false, |sp| sp.has_fore_color);
                    let has_fg = sprite_fg || params.fore_color_explicit;
                    if has_fg && fg_color_resolved != (0, 0, 0) {
                        src_color = Self::apply_forecolor_tint(src_color, fg_color_resolved);
                    }

                    let dst_color =
                        if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                    let blended = if src_alpha >= 0.999 && alpha >= 0.999 {
                        src_color
                    } else {
                        blend_color_alpha(dst_color, src_color, src_alpha * alpha)
                    };

                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // ----------------------------------------------------------
                // Director ink 36 (Blend) alpha semantics
                // ----------------------------------------------------------
                if (ink == 2 || ink == 36) && sa == 0 && src.original_bit_depth == 32 {
                    if (sr, sg, sb) == bg_color_resolved {
                        continue;
                    }

                    sa = 255;
                }

                // ----------------------------------------------------------
                // 1. Skip background transparent ink
                // ----------------------------------------------------------
                if !params.is_text_rendering
                    && sa == 255
                    && (ink == 2 || ink == 36)
                    && (sr, sg, sb) == bg_color_resolved
                {
                    continue; // This pixel is background → transparent
                }

                // ----------------------------------------------------------
                // Ink 33 (Add Pin): on the actual stage, Director adds src to
                // dst (clamped at 255), so a dim halo pixel like (50,50,50)
                // turns brick (120,90,80) into (170,140,130) — visibly
                // lighter. We can't compute that here because the filmloop
                // is rendered into its OWN bitmap before being composited
                // onto the stage via alpha-blend. Plain alpha-blend of dim
                // src darkens brick instead of brightening it.
                //
                // Approximation: scale each src pixel up so its peak channel
                // hits 255 (preserves hue), and use the original peak as
                // alpha. When alpha-blended onto stage, dim halo pixels
                // become "bright but translucent" — `brick*(1-a) + bright*a`
                // pulls toward white/the hue, which matches Add Pin's
                // saturate-to-white behaviour visually without needing a
                // real additive composite path.
                if !params.is_text_rendering && ink == 33
                    && self.bit_depth == 32 && self.use_alpha
                {
                    let src_max = sr.max(sg).max(sb);
                    if src_max == 0 {
                        continue; // pure black: no additive contribution
                    }
                    let idx = (dst_y as usize * self.width as usize + dst_x as usize) * 4;
                    if idx + 3 < self.data.len() {
                        let dr = self.data[idx];
                        let dg = self.data[idx + 1];
                        let db = self.data[idx + 2];
                        let da = self.data[idx + 3];

                        if da > 0 {
                            // OFF state already drew here. Apply Director Add
                            // Pin per spec: src RGB added to dst, clamped at
                            // 255. The moodlight's cyan ray is unchanged where
                            // ON's bg is black (sr+0 = sr), and brightens
                            // toward white where ON's white halo passes over it.
                            self.data[idx] = ((dr as u16 + sr as u16).min(255)) as u8;
                            self.data[idx + 1] = ((dg as u16 + sg as u16).min(255)) as u8;
                            self.data[idx + 2] = ((db as u16 + sb as u16).min(255)) as u8;
                            self.data[idx + 3] = da.max(src_max);
                        } else {
                            // Empty area. We can't do real additive against
                            // brick (rendered later in compositing), so we
                            // scale src up to peak brightness (preserves hue)
                            // and use src_max as alpha — when alpha-blended
                            // onto stage, this pulls brick toward the bright
                            // hue, approximating Add Pin's "saturate-to-white"
                            // visual. Without scaling, dim grey halo pixels
                            // would DARKEN the warm brick instead of
                            // brightening it.
                            let scale = 255.0 / src_max as f32;
                            self.data[idx] = ((sr as f32 * scale).min(255.0)) as u8;
                            self.data[idx + 1] = ((sg as f32 * scale).min(255.0)) as u8;
                            self.data[idx + 2] = ((sb as f32 * scale).min(255.0)) as u8;
                            // Bright halo pixels write opaque; dim ones get
                            // a 2x boost so the soft fade reads on stage.
                            self.data[idx + 3] = if src_max >= 128 {
                                255
                            } else {
                                ((src_max as u32) * 2).min(255) as u8
                            };
                        }
                    }
                    continue;
                }

                // Ink 32 (Blend): the sprite uses its blend% as alpha.
                // For 32-bit alpha-aware destinations (filmloop bitmaps),
                // we must NOT pre-blend the RGB toward dst (which is
                // transparent and would darken bright src pixels) and we
                // must NOT let set_pixel_fast force dst alpha to 0xFF.
                // Write src RGB directly with `alpha = src_alpha * blend%`
                // so the eventual stage composite produces the correct
                // translucent fade (white spotlight at 30% opacity = white
                // at α=0.3, not opaque grey).
                if !params.is_text_rendering && ink == 32
                    && self.bit_depth == 32 && self.use_alpha
                {
                    let src_a = sa as f32 / 255.0;
                    let sa_f = src_a * alpha;
                    if sa_f < 0.001 {
                        continue;
                    }
                    let idx = (dst_y as usize * self.width as usize + dst_x as usize) * 4;
                    if idx + 3 < self.data.len() {
                        let dr = self.data[idx] as f32;
                        let dg = self.data[idx + 1] as f32;
                        let db = self.data[idx + 2] as f32;
                        let da = self.data[idx + 3] as f32 / 255.0;
                        // Standard "src over dst" alpha composite, preserving
                        // any pre-existing dst content (in case another sprite
                        // already drew here in the same filmloop frame).
                        let one_minus_sa = 1.0 - sa_f;
                        let out_a = sa_f + da * one_minus_sa;
                        if out_a < 0.001 {
                            self.data[idx + 3] = 0;
                        } else {
                            let inv = 1.0 / out_a;
                            self.data[idx]     = ((sr as f32 * sa_f + dr * da * one_minus_sa) * inv).clamp(0.0, 255.0) as u8;
                            self.data[idx + 1] = ((sg as f32 * sa_f + dg * da * one_minus_sa) * inv).clamp(0.0, 255.0) as u8;
                            self.data[idx + 2] = ((sb as f32 * sa_f + db * da * one_minus_sa) * inv).clamp(0.0, 255.0) as u8;
                            self.data[idx + 3] = (out_a * 255.0).round().clamp(0.0, 255.0) as u8;
                        }
                    }
                    continue;
                }

                // Ink 36/37/39 with auto-detected edge bg: skip when src
                // matches the most common edge color (handles custom-palette
                // bitmaps where bg_color_resolved is wrong).
                if !params.is_text_rendering
                    && (ink == 36 || ink == 37 || ink == 39)
                    && sa == 255
                {
                    if let Some(edge_bg) = edge_matte_color {
                        if (sr, sg, sb) == edge_bg {
                            continue;
                        }
                    }
                }

                // ----------------------------------------------------------
                // 2. Matte / Mask grayscale white = transparent
                // ----------------------------------------------------------
                if !params.is_text_rendering
                    && (ink == 8 || ink == 9)
                    && use_grayscale_as_alpha
                    && src.original_bit_depth <= 8
                    && (sr, sg, sb) == (255, 255, 255)
                {
                    continue;
                }

                // ----------------------------------------------------------
                // 3. TEXT RENDERING MODE
                // ----------------------------------------------------------
                if params.is_text_rendering {
                    // Black pixel → foreground color
                    if (sr, sg, sb) == (0, 0, 0) {
                        let dst_color =
                            if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };
                        let blended = blend_pixel(
                            dst_color,
                            fg_color_resolved,
                            ink,
                            bg_color_resolved,
                            fg_color_resolved,
                            is_indexed,
                            alpha,
                            sa as f32 / 255.0,
                        );
                        self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    }

                    // White pixel → FULLY TRANSPARENT → skip
                    continue;
                }

                // Ink 5 (NotTransparent) for image.copyPixels: source pixels
                // matching `#color` (the foreground param) are TRANSPARENT —
                // skipped entirely. Other pixels are multiply-blended with
                // `#bgColor`, then alpha-blended with the destination using
                // `#blend`. CS catalog floor preview uses
                // `[#ink: 5, #color: rgb(0,0,0), #bgColor: texturecolor,
                // #blend: 60, #maskImage: floormatte]` to tint a polygon
                // stencil — Director's vector-shape `.image` rasterizes the
                // outside-polygon area as solid rgb(0,0,0), and `#color:
                // rgb(0,0,0)` keys those pixels as transparent so only the
                // gradient-filled polygon contributes to the multiply.
                if ink == 5 && !params.is_text_rendering {
                    if (sr, sg, sb) == fg_color_resolved {
                        continue;
                    }
                    let mr = ((sr as u16 * bg_color_resolved.0 as u16) / 255) as u8;
                    let mg = ((sg as u16 * bg_color_resolved.1 as u16) / 255) as u8;
                    let mb = ((sb as u16 * bg_color_resolved.2 as u16) / 255) as u8;
                    let multiplied = (mr, mg, mb);
                    let dst = if !dst_palette_cache.is_empty() {
                        self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16)
                    } else {
                        self.get_pixel_color(palettes, dst_x as u16, dst_y as u16)
                    };
                    let blended = if alpha >= 0.999 {
                        multiplied
                    } else {
                        blend_color_alpha(dst, multiplied, alpha)
                    };
                    self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
                    continue;
                }

                // Blend and write destination pixel

                // ----------------------------------------------------------
                // 4. NON-TEXT normal rendering
                // ----------------------------------------------------------
                let src_alpha = sa as f32 / 255.0;
                let dst_color = if !dst_palette_cache.is_empty() { self.get_pixel_color_fast(dst_palette_cache.table(), dst_x as u16, dst_y as u16) } else { self.get_pixel_color(palettes, dst_x as u16, dst_y as u16) };

                let blended = blend_pixel(
                    dst_color,
                    src_color,
                    ink,
                    bg_color_resolved,
                    fg_color_resolved,
                    is_indexed,
                    alpha,
                    src_alpha,
                );

                self.set_pixel_fast(dst_x, dst_y, blended, &dst_palette_cache);
            }
        }
        // Uncomment below to debug copyPixel calls
        // self.stroke_rect(draw_min_x, draw_min_y, draw_max_x, draw_max_y, (0, 255, 0), palettes, 1.0);
    }

    pub fn _draw_bitmap(
        &mut self,
        palettes: &PaletteMap,
        bitmap: &Bitmap,
        loc_h: i32,
        loc_v: i32,
        width: i32,
        height: i32,
        ink: u32,
        bg_color: (u8, u8, u8),
        alpha: f32,
    ) {
        let mut params = HashMap::new();
        params.insert("blend".to_owned(), Datum::Int((alpha * 100.0) as i32));
        params.insert("ink".to_owned(), Datum::Int(ink as i32));
        params.insert(
            "bgColor".to_owned(),
            Datum::ColorRef(ColorRef::Rgb(bg_color.0, bg_color.1, bg_color.2)),
        );

        let src_rect = IntRect::from_tuple((0, 0, bitmap.width as i32, bitmap.height as i32));
        let dst_rect =
            IntRect::from_tuple((loc_h, loc_v, loc_h + width as i32, loc_v + height as i32));
        self.copy_pixels(palettes, bitmap, dst_rect, src_rect, &params, None);
    }

    pub fn draw_text(
        &mut self,
        text: &str,
        font: &BitmapFont,
        font_bitmap: &Bitmap,
        loc_h: i32,
        loc_v: i32,
        params: CopyPixelsParams,
        palettes: &PaletteMap,
        line_spacing: u16,
        top_spacing: i16,
    ) {
        let mut x = loc_h;
        // Paige draws the baseline at lineTop + ascent. For PFR strikes, anchor
        // the scanned cap-top at the sprite top so the baseline lands at the
        // strike's real ascent instead of ~2px low (see pfr_strike_vertical_metrics).
        let (cap_top, _desc_bottom) =
            crate::player::font::pfr_strike_vertical_metrics(font, font_bitmap);
        let mut y = match cap_top {
            Some(t) => loc_v - t,
            None => loc_v + top_spacing as i32,
        };
        // `line_spacing` is the member's fixedLineSpace. Director 11.5 defines
        // it as the ABSOLUTE height of each line ("height in absolute pixels of
        // each line"), NOT extra leading added on top of the glyph cell. This
        // must agree with `measure_text()` — which sizes this very bitmap plus
        // member.rect / member.height / charPosToLoc and uses `line_spacing` as
        // the per-line stride when set. Adding `char_height` on top of it (the
        // old behaviour) spaced lines ~1 glyph-cell too far apart, so text
        // rasterized via `member.image` (e.g. Habbo's window Text Wrapper, which
        // authors fixedLineSpace ≈ fontSize+1 and copyPixels the result into a
        // bitmap) overflowed its measured box and rendered with huge gaps.
        // Honour it as the absolute stride when set; fall back to the natural
        // glyph cell only when unset (0).
        let line_step = if line_spacing > 0 {
            line_spacing as i32
        } else {
            font.char_height as i32
        };

        for char_num in text.chars() {
            if char_num == '\r' || char_num == '\n' {
                x = loc_h;
                y += line_step;
                continue;
            }

            bitmap_font_copy_char(
                font,
                font_bitmap,
                char_num as u8,
                self,
                x,
                y,
                &palettes,
                &params,
            );

            // Use per-character advance width when available (PFR/proportional fonts)
            x += font.get_char_advance(char_num as u8) as i32;
        }
    }

    /// Draw text with word wrapping. Returns the number of lines drawn.
    pub fn draw_text_wrapped(
        &mut self,
        text: &str,
        font: &BitmapFont,
        font_bitmap: &Bitmap,
        loc_h: i32,
        loc_v: i32,
        max_width: i32,
        alignment: BuiltInSymbol,
        params: CopyPixelsParams,
        palettes: &PaletteMap,
        line_spacing: u16,
        top_spacing: i16,
    ) -> i32 {
        // fixedLineSpace is the absolute per-line height when set (see the note
        // in `draw_text`); fall back to the natural glyph cell when unset.
        let line_height = if line_spacing > 0 {
            line_spacing as i32
        } else {
            font.char_height as i32
        };

        // Break text into wrapped lines
        let lines = Self::wrap_text_lines(text, font, max_width);

        // Paige baseline = lineTop + ascent; anchor the strike cap-top at the
        // sprite top (see pfr_strike_vertical_metrics) so PFR text isn't ~2px low.
        let (cap_top, _desc_bottom) =
            crate::player::font::pfr_strike_vertical_metrics(font, font_bitmap);
        let mut y = match cap_top {
            Some(t) => loc_v - t,
            None => loc_v + top_spacing as i32,
        };
        for line in &lines {
            // Calculate x based on alignment
            let line_w: i32 = line.chars()
                .map(|ch| font.get_char_advance_for(ch) as i32)
                .sum();
            let x = match alignment {
                BuiltInSymbol::Center => loc_h + ((max_width - line_w) / 2).max(0),
                BuiltInSymbol::Right => loc_h + (max_width - line_w).max(0),
                _ => loc_h,
            };

            // Draw each character
            let mut cx = x;
            for ch in line.chars() {
                bitmap_font_copy_char(
                    font, font_bitmap, crate::io::encoding::glyph_byte_for(ch),
                    self, cx, y, palettes, &params,
                );
                cx += font.get_char_advance_for(ch) as i32;
            }
            y += line_height;
        }
        lines.len() as i32
    }

    /// Break text into lines that fit within max_width, wrapping at word boundaries.
    pub fn wrap_text_lines(text: &str, font: &BitmapFont, max_width: i32) -> Vec<String> {
        Self::wrap_lines_with_spans(text, font, max_width)
            .into_iter()
            .map(|s| s.text)
            .collect()
    }

    /// Break text into lines that fit within max_width, returning each line's byte
    /// range in the original text along with its visible content. Used by caret
    /// math so positions agree byte-for-byte with what's rendered.
    pub fn wrap_lines_with_spans(text: &str, font: &BitmapFont, max_width: i32) -> Vec<LineSpan> {
        let bytes = text.as_bytes();
        let len = bytes.len();
        let mut lines: Vec<LineSpan> = Vec::new();

        let mut i = 0usize;
        loop {
            let para_start = i;
            let mut para_end = para_start;
            while para_end < len && bytes[para_end] != b'\r' && bytes[para_end] != b'\n' {
                para_end += 1;
            }

            if max_width <= 0 || para_start == para_end {
                lines.push(LineSpan {
                    start: para_start,
                    end: para_end,
                    text: text[para_start..para_end].to_string(),
                });
            } else {
                let mut line_start = para_start;
                let mut line_w: i32 = 0;
                let mut last_space: Option<usize> = None;

                // Walk Unicode chars (via char_indices for byte positions)
                // rather than raw UTF-8 bytes. Bytes-based iteration both
                // (a) gave umlauts 2x phantom width by counting their
                // lead+continuation bytes as separate glyphs, and (b)
                // could leave `p` mid-codepoint, panicking at the next
                // `text[line_start..p]` slice when the wrap point landed
                // inside a multi-byte char (e.g. "lets tryäö+üß" at byte
                // 16 inside ß).
                let para_text = &text[para_start..para_end];
                for (local_p, ch) in para_text.char_indices() {
                    let p = para_start + local_p;
                    let cw = font.get_char_advance_for(ch) as i32;

                    if ch == ' ' {
                        last_space = Some(p);
                    }

                    if line_w + cw > max_width && p > line_start {
                        if let Some(sp) = last_space.filter(|&sp| sp > line_start) {
                            lines.push(LineSpan {
                                start: line_start,
                                end: sp,
                                text: text[line_start..sp].to_string(),
                            });
                            // ' ' is ASCII so sp + 1 is always a char
                            // boundary.
                            line_start = sp + 1;
                            last_space = None;
                            // If the wrap point IS the current char (the
                            // overflowing one), skip it without counting
                            // its width on the new line.
                            if line_start > p {
                                line_w = 0;
                                continue;
                            }
                            // Re-accumulate glyph advances for the chars
                            // that now form the start of the new line.
                            line_w = text[line_start..p]
                                .chars()
                                .map(|c| font.get_char_advance(c as u8) as i32)
                                .sum();
                        } else {
                            #[cfg(feature = "word_hard_break")]
                            {
                                lines.push(LineSpan {
                                    start: line_start,
                                    end: p,
                                    text: text[line_start..p].to_string(),
                                });
                                line_start = p;
                                last_space = None;
                                line_w = 0;
                            }
                        }
                    }

                    line_w += cw;
                }

                lines.push(LineSpan {
                    start: line_start,
                    end: para_end,
                    text: text[line_start..para_end].to_string(),
                });
            }

            if para_end >= len {
                break;
            }
            // Each \r and each \n is its own line terminator. Director text
            // is overwhelmingly single-\r, but legacy "a\r\nb" content from
            // imported sources renders as three lines (a, empty, b) and the
            // bitmap-font path counts paragraphs the same way, so caret math
            // must too.
            i = para_end + 1;
        }

        if lines.is_empty() {
            lines.push(LineSpan { start: 0, end: 0, text: String::new() });
        }
        lines
    }

    /// Map a caret byte index to a (dx, dy) offset relative to the text's top-left
    /// origin (loc_h, loc_v + top_spacing). Caller adds those.
    ///
    /// `line_height` is the actual per-line stride the renderer uses (the y
    /// distance between line N's top and line N+1's top). Keep this in sync
    /// with the renderer or the caret will drift vertically across lines.
    pub fn caret_index_to_xy(
        text: &str,
        font: &BitmapFont,
        max_width: i32,
        alignment: BuiltInSymbol,
        line_height: i32,
        idx: i32,
    ) -> (i32, i32) {
        let lines = Self::wrap_lines_with_spans(text, font, max_width);
        let idx = (idx.max(0) as usize).min(text.len());

        let mut line_idx = lines.len() - 1;
        for (i, l) in lines.iter().enumerate() {
            if idx >= l.start && idx <= l.end {
                line_idx = i;
                break;
            }
        }
        // At a soft-wrap boundary the same byte index may sit at the end of one
        // visual line and the start of the next (caused by a wrap on a long word).
        // Prefer the start of the following line so the caret appears where the
        // next inserted char will land.
        if line_idx + 1 < lines.len() {
            let cur = &lines[line_idx];
            let nxt = &lines[line_idx + 1];
            if idx == cur.end && nxt.start == idx {
                line_idx += 1;
            }
        }

        let line = &lines[line_idx];
        let col = idx.saturating_sub(line.start);
        // Iterate Unicode chars, not raw UTF-8 bytes. The bitmap renderer
        // advances one glyph per char (see render_html_text_to_bitmap_styled),
        // so the caret-pixel calculation must mirror that. The previous
        // .bytes() loop counted each lead+continuation byte of an umlaut
        // as separate glyph advances, producing 4 phantom advances for
        // "öäüß" (8 UTF-8 bytes → 8 advances instead of 4).
        let line_w: i32 = line.text.chars().map(|c| font.get_char_advance(c as u8) as i32).sum();
        let x_offset = if max_width > 0 {
            match alignment {
                BuiltInSymbol::Center => ((max_width - line_w) / 2).max(0),
                BuiltInSymbol::Right => (max_width - line_w).max(0),
                _ => 0,
            }
        } else {
            0
        };

        // Walk chars until we've covered `col` bytes from the line start.
        // `col` and `idx` are byte indices into the UTF-8 string; one umlaut
        // contributes 2 bytes but only one glyph advance.
        let mut x = x_offset;
        let mut byte_pos = 0usize;
        for c in line.text.chars() {
            if byte_pos >= col { break; }
            x += font.get_char_advance(c as u8) as i32;
            byte_pos += c.len_utf8();
        }
        (x, (line_idx as i32) * line_height)
    }

    /// Inverse of caret_index_to_xy. Coordinates are relative to (loc_h, loc_v + top_spacing).
    pub fn xy_to_caret_index(
        text: &str,
        font: &BitmapFont,
        max_width: i32,
        alignment: &str,
        line_height: i32,
        x: i32,
        y: i32,
    ) -> i32 {
        let lines = Self::wrap_lines_with_spans(text, font, max_width);
        let line_height = line_height.max(1);

        let line_idx = if y < 0 {
            0
        } else {
            ((y / line_height) as usize).min(lines.len() - 1)
        };

        let line = &lines[line_idx];
        // Walk chars instead of UTF-8 bytes — see caret_index_to_xy. This
        // also keeps the returned caret index aligned to char boundaries
        // (was bug source for the byte-index-7-mid-of-ß slice panic
        // observed in get_focused_field_selected_text / pixel_x_for_byte).
        let line_w: i32 = line.text.chars().map(|c| font.get_char_advance(c as u8) as i32).sum();
        let x_offset = if max_width > 0 {
            let key = alignment.trim().trim_start_matches('#').to_ascii_lowercase();
            match key.as_str() {
                "center" => ((max_width - line_w) / 2).max(0),
                "right" => (max_width - line_w).max(0),
                _ => 0,
            }
        } else {
            0
        };

        if x < x_offset {
            return line.start as i32;
        }

        let mut cx = x_offset;
        let mut byte_pos = 0usize;
        for c in line.text.chars() {
            let cw = font.get_char_advance(c as u8) as i32;
            if x < cx + cw / 2 {
                return (line.start + byte_pos) as i32;
            }
            cx += cw;
            byte_pos += c.len_utf8();
        }
        line.end as i32
    }

    pub fn trim_whitespace(&mut self, palettes: &PaletteMap) {
        let mut left = 0 as i32;
        let mut top = 0 as i32;
        let mut right = self.width as i32;
        let mut bottom = self.height as i32;
        let bg_color = self.get_bg_color_ref();

        for x in 0..self.width as i32 {
            let mut is_empty = true;
            for y in 0..self.height as i32 {
                let color = self.get_pixel_color_ref(x as u16, y as u16);
                if color != bg_color {
                    is_empty = false;
                    break;
                }
            }
            if !is_empty {
                left = x;
                break;
            }
        }

        for x in (0..self.width as i32).rev() {
            let mut is_empty = true;
            for y in 0..self.height as i32 {
                let color = self.get_pixel_color_ref(x as u16, y as u16);
                if color != bg_color {
                    is_empty = false;
                    break;
                }
            }
            if !is_empty {
                right = x + 1;
                break;
            }
        }

        for y in 0..self.height as i32 {
            let mut is_empty = true;
            for x in 0..self.width as i32 {
                let color = self.get_pixel_color_ref(x as u16, y as u16);
                if color != bg_color {
                    is_empty = false;
                    break;
                }
            }
            if !is_empty {
                top = y;
                break;
            }
        }

        for y in (0..self.height as i32).rev() {
            let mut is_empty = true;
            for x in 0..self.width as i32 {
                let color = self.get_pixel_color_ref(x as u16, y as u16);
                if color != bg_color {
                    is_empty = false;
                    break;
                }
            }
            if !is_empty {
                bottom = y + 1;
                break;
            }
        }

        let width = right - left;
        let height = bottom - top;

        let mut trimmed = Bitmap::new(
            width as u16,
            height as u16,
            self.bit_depth,
            self.original_bit_depth,
            0,
            self.palette_ref.clone(),
        );
        let params = CopyPixelsParams::default(&self);
        trimmed.copy_pixels_with_params(
            palettes,
            &self,
            IntRect::from(0, 0, width, height),
            IntRect::from(left, top, right, bottom),
            &params,
        );

        self.width = width as u16;
        self.height = height as u16;
        self.data = trimmed.data;
    }

    pub fn to_mask(&self) -> BitmapMask {
        let mut mask = BitmapMask::new(self.width, self.height, false);
        let bg_color = self.get_bg_color_ref();
        for y in 0..self.height {
            for x in 0..self.width {
                let pixel = self.get_pixel_color_ref(x, y);
                if pixel != bg_color {
                    mask.set_bit(x, y, true);
                }
            }
        }
        mask
    }

    /// Flood fills starting from a point, replacing the original color with the target color.
    /// Emulates Director's `image.floodFill(point, color)` behavior.
    pub fn flood_fill(
        &mut self,
        start_point: (i32, i32),
        target_color: (u8, u8, u8),
        palettes: &PaletteMap,
    ) {
        let (start_x, start_y) = start_point;

        // --- Bounds check (Director silently ignores invalid coords)
        if start_x < 0
            || start_y < 0
            || start_x >= self.width as i32
            || start_y >= self.height as i32
        {
            return;
        }

        // --- Capture the original color at the starting pixel
        let original_color = self.get_pixel_color(palettes, start_x as u16, start_y as u16);

        // --- If the starting color is already the target color, nothing to fill
        if Self::color_equal(original_color, target_color) {
            return;
        }

        use std::collections::HashSet;

        let mut stack = Vec::with_capacity(256);
        let mut visited = HashSet::with_capacity(256);

        stack.push((start_x, start_y));
        visited.insert((start_x as u16, start_y as u16));

        while let Some((x, y)) = stack.pop() {
            // --- Bounds check
            if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
                continue;
            }

            // --- Check current pixel color
            let current_color = self.get_pixel_color(palettes, x as u16, y as u16);

            // --- Only fill if the color matches the original color
            if !Self::color_equal(current_color, original_color) {
                continue;
            }

            // --- Set pixel to target color
            self.set_pixel(x, y, target_color, palettes);

            // --- Push 4-connected neighbors
            for (nx, ny) in [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)] {
                if nx >= 0 && ny >= 0 && nx < self.width as i32 && ny < self.height as i32 {
                    let pos = (nx as u16, ny as u16);
                    if visited.insert(pos) {
                        stack.push((nx, ny));
                    }
                }
            }
        }
    }

    fn color_equal(a: (u8, u8, u8), b: (u8, u8, u8)) -> bool {
        // Director treats colors as equal if their RGB values match exactly.
        // Ensure get_pixel_color() already resolved to RGB.
        a.0 == b.0 && a.1 == b.1 && a.2 == b.2
    }

    /// Draw a vector shape with proper type dispatch and ink/blend support.
    /// Renders the shape to a temporary bitmap, then copy_pixels onto destination
    /// to properly handle Director ink modes.
    /// Draw a vector shape directly onto this bitmap with ink/blend support.
    pub fn draw_shape_with_sprite(
        &mut self,
        sprite: &crate::player::sprite::Sprite,
        shape_info: &ShapeInfo,
        dst_rect: IntRect,
        palettes: &PaletteMap,
        palette_ref: &PaletteRef,
    ) {
        let x1 = dst_rect.left;
        let y1 = dst_rect.top;
        let x2 = dst_rect.right;
        let y2 = dst_rect.bottom;

        // Resolve foreground color
        let fg_rgb = resolve_color_ref(
            palettes,
            &sprite.color,
            palette_ref,
            self.original_bit_depth,
        );
        // Background colour — used as the "off" pixels of a 1-bit shape pattern.
        let bg_rgb = resolve_color_ref(
            palettes,
            &sprite.bg_color,
            palette_ref,
            self.original_bit_depth,
        );

        let filled = shape_info.fill_type != 0;
        // Director stores the border width 1-BASED: file 1 = no border, 2 = 1px,
        // … 6 = 5px (max) — the encoding the Lingo `lineSize of member` getter
        // decodes with `raw - 1` (cast_member_ref.rs), verified against Director.
        //
        // One byte, one meaning: the decode does not depend on `filled`. Reading
        // it raw for filled shapes gave them a 1px foreColor outline they were
        // never authored with (a black border around each shape).
        let thickness = (shape_info.line_thickness as i32) - 1;

        // Convert blend percentage to alpha (0.0-1.0)
        let alpha = (sprite.blend as f32 / 100.0).clamp(0.0, 1.0);

        // For ink=copy (0), draw directly onto destination bitmap with alpha blending.
        // For other inks, use temp bitmap + copy_pixels for proper ink handling.
        let use_direct = sprite.ink == 0;

        if use_direct {
            // Direct drawing onto destination bitmap
            match shape_info.shape_type {
                ShapeType::Rect => {
                    if filled {
                        // Director shape patterns: 1-56 = 1-bit QuickDraw patterns
                        // (recoloured fore/back; 1 = solid), 57-64 = tiled bitmaps
                        // (thead's pattern-63 background). 0/other = solid foreColor.
                        if let Some(tile) =
                            crate::player::bitmap::builtin_tiles::tile_for_pattern(shape_info.pattern)
                        {
                            self.fill_rect_tiled(x1, y1, x2, y2, tile, palettes, palette_ref, alpha);
                        } else if let Some(pat) =
                            crate::player::bitmap::quickdraw_patterns::quickdraw_pattern(shape_info.pattern)
                        {
                            self.fill_rect_pattern_1bit(x1, y1, x2, y2, pat, fg_rgb, bg_rgb, palettes, alpha);
                        } else {
                            self.fill_rect(x1, y1, x2, y2, fg_rgb, palettes, alpha);
                        }
                    }
                    if thickness > 0 {
                        for t in 0..thickness {
                            self.stroke_rect(x1 + t, y1 + t, x2 - t, y2 - t, fg_rgb, palettes, alpha);
                        }
                    }
                }
                ShapeType::OvalRect => {
                    let radius = 12;
                    if filled {
                        self.fill_round_rect(x1, y1, x2, y2, radius, fg_rgb, palettes, alpha);
                    }
                    if thickness > 0 {
                        self.stroke_round_rect(x1, y1, x2, y2, radius, fg_rgb, palettes, alpha, thickness);
                    }
                }
                ShapeType::Oval => {
                    if filled {
                        self.fill_ellipse(x1, y1, x2, y2, fg_rgb, palettes, alpha);
                    }
                    if thickness > 0 {
                        self.stroke_ellipse(x1, y1, x2, y2, fg_rgb, palettes, alpha, thickness);
                    }
                }
                ShapeType::Line => {
                    // Floor at 1 AFTER the 1-based decode — a #line member is
                    // nothing but its line, so it never vanishes. See the webgl2
                    // Line arm.
                    let t = ((shape_info.line_thickness as i32) - 1).max(1);
                    if shape_info.line_direction == 6 {
                        self.draw_line_thick(x1, y2 - 1, x2 - 1, y1, fg_rgb, palettes, alpha, t);
                    } else {
                        self.draw_line_thick(x1, y1, x2 - 1, y2 - 1, fg_rgb, palettes, alpha, t);
                    }
                }
                ShapeType::Unknown => {
                    self.fill_rect(x1, y1, x2, y2, fg_rgb, palettes, alpha);
                }
            }
        } else {
            // Non-copy ink: use temp bitmap + copy_pixels for proper ink handling
            let w = (x2 - x1).max(1);
            let h = (y2 - y1).max(1);
            let mut temp = Bitmap::new(
                w as u16, h as u16,
                self.bit_depth, self.original_bit_depth, 0,
                self.palette_ref.clone(),
            );

            match shape_info.shape_type {
                ShapeType::Rect | ShapeType::Unknown => {
                    if filled {
                        temp.fill_rect(0, 0, w, h, fg_rgb, palettes, 1.0);
                    }
                    if thickness > 0 {
                        for t in 0..thickness {
                            temp.stroke_rect(t, t, w - t, h - t, fg_rgb, palettes, 1.0);
                        }
                    }
                }
                ShapeType::OvalRect => {
                    let radius = 12;
                    if filled {
                        temp.fill_round_rect(0, 0, w, h, radius, fg_rgb, palettes, 1.0);
                    }
                    if thickness > 0 {
                        temp.stroke_round_rect(0, 0, w, h, radius, fg_rgb, palettes, 1.0, thickness);
                    }
                }
                ShapeType::Oval => {
                    if filled {
                        temp.fill_ellipse(0, 0, w, h, fg_rgb, palettes, 1.0);
                    }
                    if thickness > 0 {
                        temp.stroke_ellipse(0, 0, w, h, fg_rgb, palettes, 1.0, thickness);
                    }
                }
                ShapeType::Line => {
                    let t = ((shape_info.line_thickness as i32) - 1).max(1);
                    if shape_info.line_direction == 6 {
                        temp.draw_line_thick(0, h - 1, w - 1, 0, fg_rgb, palettes, 1.0, t);
                    } else {
                        temp.draw_line_thick(0, 0, w - 1, h - 1, fg_rgb, palettes, 1.0, t);
                    }
                }
            }

            let mut params = HashMap::new();
            params.insert("blend".into(), Datum::Int(sprite.blend as i32));
            params.insert("ink".into(), Datum::Int(sprite.ink as i32));
            params.insert("color".into(), Datum::ColorRef(sprite.color.clone()));
            params.insert("bgColor".into(), Datum::ColorRef(sprite.bg_color.clone()));

            self.copy_pixels(
                palettes,
                &temp,
                dst_rect,
                IntRect::from_tuple((0, 0, w, h)),
                &params,
                None,
            );
        }
    }

    /// Legacy wrapper for backward compatibility — calls draw_shape_with_sprite with default rect shape.
    pub fn fill_shape_rect_with_sprite(
        &mut self,
        sprite: &crate::player::sprite::Sprite,
        dst_rect: IntRect,
        palettes: &PaletteMap,
        palette_ref: &PaletteRef,
    ) {
        let w = (dst_rect.right - dst_rect.left).max(1);
        let h = (dst_rect.bottom - dst_rect.top).max(1);
        // Default to filled rect shape
        let default_shape = ShapeInfo {
            shape_type: ShapeType::Rect,
            rect_top: 0,
            rect_left: 0,
            rect_bottom: h as i16,
            rect_right: w as i16,
            pattern: 0,
            fore_color: 0,
            back_color: 0,
            fill_type: 1,
            line_thickness: 0,
            line_direction: 0,
        };
        self.draw_shape_with_sprite(sprite, &default_shape, dst_rect, palettes, palette_ref);
    }
}

#[cfg(test)]
mod shrink_sampling_tests {
    use super::*;
    use crate::player::bitmap::bitmap::{BuiltInPalette, PaletteRef};
    use crate::player::bitmap::palette_map::PaletteMap;

    // Three source columns with distinct reds, drawn into two: the floor rule
    // keeps columns 0 and 1 (floor(0 * 1.5), floor(1 * 1.5)); the centre rule
    // keeps 0 and 2 (floor(0.75), floor(2.25)).
    fn shrink(floor_rule: bool) -> Vec<u8> {
        let mut src = Bitmap::new(3, 1, 32, 32, 0, PaletteRef::BuiltIn(BuiltInPalette::SystemWin));
        for x in 0..3 { src.data[x * 4..x * 4 + 4].copy_from_slice(&[10 * (x as u8 + 1), 0, 0, 255]); }
        let mut dst = Bitmap::new(2, 1, 32, 32, 0, PaletteRef::BuiltIn(BuiltInPalette::SystemWin));
        let mut params = CopyPixelsParams::default(&src);
        params.floor_rule = floor_rule;
        dst.copy_pixels_with_params(&PaletteMap::new(), &src, IntRect::from(0, 0, 2, 1), IntRect::from(0, 0, 3, 1), &params);
        vec![dst.data[0], dst.data[4]]
    }

    #[test]
    fn an_authored_bitmap_shrinks_by_the_floor_rule() {
        assert_eq!(shrink(true), vec![10, 20]);
    }

    #[test]
    fn everything_else_keeps_the_centre_rule() {
        assert_eq!(shrink(false), vec![10, 30]);
    }
}

mod ink_colour_tests {
    use super::blend_pixel;

    const WHITE: (u8, u8, u8) = (255, 255, 255);
    const BLACK: (u8, u8, u8) = (0, 0, 0);

    #[test]
    fn lighten_adds_the_fore_colour() {
        let src = (100, 100, 100);
        assert_eq!(blend_pixel((0, 0, 0), src, 40, WHITE, (50, 25, 0), false, 1.0, 1.0), (150, 125, 100));
        assert_eq!(blend_pixel((0, 0, 0), src, 40, WHITE, BLACK, false, 1.0, 1.0), src, "the default foreColor changes nothing");
        assert_eq!(blend_pixel((0, 0, 0), (250, 250, 250), 40, WHITE, (50, 25, 0), false, 1.0, 1.0), (255, 255, 250), "pinned at 255");
        assert_eq!(blend_pixel((0, 0, 0), src, 40, WHITE, (50, 25, 0), true, 1.0, 1.0), src, "an indexed bitmap keeps its palette colours");
    }

    #[test]
    fn lighten_still_keys_the_background_colour() {
        let dst = (7, 8, 9);
        assert_eq!(blend_pixel(dst, WHITE, 40, WHITE, (50, 25, 0), false, 1.0, 1.0), dst);
    }

    #[test]
    fn darken_remaps_black_to_fore_and_white_to_back() {
        let fg = (50, 25, 0);
        let bg = (200, 220, 240);
        assert_eq!(blend_pixel((0, 0, 0), (0, 0, 0), 41, bg, fg, false, 1.0, 1.0), fg);
        assert_eq!(blend_pixel((0, 0, 0), (255, 255, 255), 41, bg, fg, false, 1.0, 1.0), bg);
        assert_eq!(blend_pixel((0, 0, 0), (100, 100, 100), 41, WHITE, BLACK, false, 1.0, 1.0), (100, 100, 100), "defaults are the identity");
    }
}
