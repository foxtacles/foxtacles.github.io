use std::{collections::HashMap, iter::FromIterator, sync::OnceLock};

pub fn get_keyboard_key_map_js_to_sw() -> &'static HashMap<u16, u16> {
    static MAP: OnceLock<HashMap<u16, u16>> = OnceLock::new();
    MAP.get_or_init(|| {
        HashMap::from_iter([
            (8, 51),    // backspace
            (13, 36),   // enter
            (32, 49),   // space
            (65, 0),    // a
            (66, 11),   // b
            (67, 8),    // c
            (68, 2),    // d
            (69, 14),   // e
            (70, 3),    // f
            (71, 5),    // g
            (72, 4),    // h
            (73, 34),   // i
            (74, 38),   // j
            (75, 40),   // k
            (76, 37),   // l
            (77, 46),   // m
            (78, 45),   // n
            (79, 31),   // o
            (80, 35),   // p
            (81, 12),   // q
            (82, 15),   // r
            (83, 1),    // s
            (84, 17),   // t
            (85, 32),   // u
            (86, 9),    // v
            (87, 13),   // w
            (88, 7),    // x
            (89, 16),   // y
            (90, 6),    // z
            (48, 29),   // 0
            (49, 18),   // 1
            (50, 19),   // 2
            (51, 20),   // 3
            (52, 21),   // 4
            (53, 23),   // 5
            (54, 22),   // 6
            (55, 26),   // 7
            (56, 28),   // 8
            (57, 25),   // 9
            (37, 123),  // left
            (38, 126),  // up
            (39, 124),  // right
            (40, 125),  // down
            (16, 56),   // shift
            (17, 55),   // ctrl
            (18, 58),   // alt
            (27, 53),   // esc
            (112, 122), // f1
            (113, 120), // f2
            (114, 99),  // f3
            (115, 118), // f4
            (116, 96),  // f5
            (117, 97),  // f6
            (118, 98),  // f7
            (119, 100), // f8
            (120, 101), // f9
            (121, 109), // f10
            (122, 111), // f11
            (123, 110), // f12
            (192, 50),  // `
            (189, 27),  // -
            (187, 24),  // =
            (219, 33),  // [
            (221, 30),  // ]
            (186, 41),  // ;
            (222, 39),  // '
            (220, 42),  // \
            (188, 43),  // ,
            (190, 47),  // .
            (191, 44),  // /
            (9, 48),    // tab
            (20, 57),
            (97, 83),  // numpad 1
            (98, 84),  // numpad 2
            (99, 85),  // numpad 3
            (100, 86), // numpad 4
            (101, 87), // numpad 5
            (102, 88), // numpad 6
            (103, 89), // numpad 7
            (104, 91), // numpad 8
            (105, 92), // numpad 9
        ])
    })
}

/// Director character codes for special keys.
/// In Lingo, numToChar(28-31) return control characters that represent arrow keys.
pub fn get_director_special_char_to_keycode_map() -> &'static HashMap<char, u16> {
    static MAP: OnceLock<HashMap<char, u16>> = OnceLock::new();
    MAP.get_or_init(|| {
        HashMap::from_iter([
            // Director arrow key character codes (used with numToChar)
            ('\x1C', 123), // ASCII 28 = Left Arrow -> SW keycode 123
            ('\x1D', 124), // ASCII 29 = Right Arrow -> SW keycode 124
            ('\x1E', 126), // ASCII 30 = Up Arrow -> SW keycode 126
            ('\x1F', 125), // ASCII 31 = Down Arrow -> SW keycode 125
            // Enter/Return
            ('\r', 36),    // ASCII 13 = Return -> SW keycode 36
            ('\n', 36),    // Newline also maps to Return
            // Tab and other control characters
            ('\t', 48),    // ASCII 9 = Tab -> SW keycode 48
            ('\x08', 51),  // ASCII 8 = Backspace -> SW keycode 51
            ('\x1B', 53),  // ASCII 27 = Escape -> SW keycode 53
            (' ', 49),     // Space -> SW keycode 49
        ])
    })
}

pub fn get_char_to_keycode_map() -> &'static HashMap<char, u16> {
    static MAP: OnceLock<HashMap<char, u16>> = OnceLock::new();
    MAP.get_or_init(|| {
        HashMap::from_iter([
            ('a', 0),
            ('b', 11),
            ('c', 8),
            ('d', 2),
            ('e', 14),
            ('f', 3),
            ('g', 5),
            ('h', 4),
            ('i', 34),
            ('j', 38),
            ('k', 40),
            ('l', 37),
            ('m', 46),
            ('n', 45),
            ('o', 31),
            ('p', 35),
            ('q', 12),
            ('r', 15),
            ('s', 1),
            ('t', 17),
            ('u', 32),
            ('v', 9),
            ('w', 13),
            ('x', 7),
            ('y', 16),
            ('z', 6),
            ('0', 29),
            ('1', 18),
            ('2', 19),
            ('3', 20),
            ('4', 21),
            ('5', 23),
            ('6', 22),
            ('7', 26),
            ('8', 28),
            ('9', 25),
        ])
    })
}
