//! The indexed PackBitsRect subset of QuickDraw PICT v2 used by Director
//! picture cast members. Unknown drawing operations are rejected explicitly.
use super::bitmap::{Bitmap, BuiltInPalette, PaletteRef};

struct Reader<'a> { bytes: &'a [u8], pos: usize }
impl<'a> Reader<'a> {
    fn take(&mut self, count: usize) -> Result<&'a [u8], String> {
        let end = self.pos.checked_add(count).ok_or("PICT offset overflow")?;
        let out = self.bytes.get(self.pos..end).ok_or("Truncated PICT")?;
        self.pos = end;
        Ok(out)
    }
    fn u8(&mut self) -> Result<u8, String> { Ok(self.take(1)?[0]) }
    fn u16(&mut self) -> Result<u16, String> {
        let b = self.take(2)?; Ok(u16::from_be_bytes([b[0], b[1]]))
    }
    fn rect(&mut self) -> Result<[i16; 4], String> {
        Ok([self.u16()? as i16, self.u16()? as i16, self.u16()? as i16, self.u16()? as i16])
    }
}

fn unpack_row(packed: &[u8], pitch: usize) -> Result<Vec<u8>, String> {
    let mut input = Reader {bytes: packed, pos: 0};
    let mut output = Vec::with_capacity(pitch);
    while input.pos < packed.len() {
        match input.u8()? {
            128 => (), // QuickDraw PackBits no-op (unlike Director BITD).
            control @ 129..=255 => {
                let value = input.u8()?;
                output.resize(output.len() + 257 - control as usize, value);
            }
            control => output.extend_from_slice(input.take(control as usize + 1)?),
        }
        if output.len() > pitch { return Err("PICT row exceeds declared stride".into()); }
    }
    if output.len() != pitch { return Err("PICT row does not fill declared stride".into()); }
    Ok(output)
}

pub fn decode_pict(bytes: &[u8]) -> Result<Bitmap, String> {
    let mut r = Reader {bytes, pos: 0};
    r.u16()?; // Legacy 16-bit length can wrap for pictures larger than 64 KiB.
    let bounds = r.rect()?;
    if r.take(4)? != [0, 0x11, 2, 0xff] { return Err("Expected PICT v2 version opcode".into()); }
    let width = bounds[3] as i32 - bounds[1] as i32;
    let height = bounds[2] as i32 - bounds[0] as i32;
    if width <= 0 || height <= 0 || width as usize * height as usize > 64 * 1024 * 1024 {
        return Err("Invalid PICT bounds".into());
    }
    let mut pixels = None;
    loop {
        if r.pos & 1 != 0 { r.take(1)?; }
        match r.u16()? {
            0x0c00 => { r.take(24)?; }
            0x00a1 => { r.u16()?; let length = r.u16()? as usize; r.take(length)?; }
            0x0001 => {
                if r.u16()? != 10 || r.rect()? != bounds { return Err("Unsupported PICT clipping region".into()); }
            }
            0x0098 => {
                if pixels.is_some() { return Err("Multiple PICT bitmap drawing operations".into()); }
                let row_bytes = r.u16()?;
                if row_bytes & 0x8000 == 0 { return Err("PICT PackBitsRect has no PixMap".into()); }
                let pitch = (row_bytes & 0x7fff) as usize;
                let rect = r.rect()?;
                r.u16()?; // PixMap version
                let pack_type = r.u16()?;
                r.take(12)?; // packSize and horizontal/vertical resolution
                let pixel_type = r.u16()?;
                let depth = r.u16()?;
                let components = r.u16()?;
                let component_depth = r.u16()?;
                r.take(12)?; // planeBytes, color-table handle, reserved
                if (pack_type, pixel_type, depth, components, component_depth) != (0, 0, 8, 1, 8) || pitch < width as usize {
                    return Err("Unsupported PICT pixel format".into());
                }
                r.take(4)?; // color table seed
                let flags = r.u16()?;
                let count = r.u16()? as usize + 1;
                if count > 256 { return Err("Oversized PICT color table".into()); }
                let mut colors = [[0u8; 3]; 256];
                for ordinal in 0..count {
                    let index = r.u16()? as usize;
                    let rgb = [(r.u16()? >> 8) as u8, (r.u16()? >> 8) as u8, (r.u16()? >> 8) as u8];
                    let index = if flags & 0x8000 != 0 { ordinal } else { index };
                    if index >= colors.len() { return Err("PICT color index out of bounds".into()); }
                    colors[index] = rgb;
                }
                let source = r.rect()?;
                let destination = r.rect()?;
                let mode = r.u16()?;
                if rect != bounds || source != bounds || destination != bounds || mode != 0 {
                    return Err("Unsupported PICT bitmap transfer geometry/mode".into());
                }
                let mut rgba = Vec::with_capacity(width as usize * height as usize * 4);
                for _ in 0..height {
                    let length = if pitch > 250 { r.u16()? as usize } else { r.u8()? as usize };
                    let row = unpack_row(r.take(length)?, pitch)?;
                    for &index in &row[..width as usize] {
                        rgba.extend_from_slice(&colors[index as usize]);
                        rgba.push(255);
                    }
                }
                pixels = Some(rgba);
            }
            0x00ff => {
                if r.pos != bytes.len() { return Err("Data after PICT end opcode".into()); }
                break;
            }
            opcode => return Err(format!("Unsupported PICT opcode {opcode:#06x}")),
        }
    }
    Ok(Bitmap {
        width: width as u16, height: height as u16, bit_depth: 32, original_bit_depth: 32,
        data: pixels.ok_or("PICT contains no supported bitmap drawing operation")?,
        palette_ref: PaletteRef::BuiltIn(BuiltInPalette::SystemMac), matte: None,
        use_alpha: false, trim_white_space: false, was_trimmed: false, version: 0,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn quickdraw_noop_and_director_repeat_are_distinct() {
        assert_eq!(unpack_row(&[128, 1, 7, 9, 255, 3], 4).unwrap(), [7, 9, 3, 3]);
        assert!(unpack_row(&[128, 7], 129).is_err());
    }
    #[test]
    fn truncated_and_oversized_rows_are_rejected() {
        assert!(unpack_row(&[2, 7], 3).is_err());
        assert!(unpack_row(&[254, 7], 2).is_err());
    }
}
