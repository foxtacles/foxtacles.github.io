use log::warn;
use wasm_bindgen::prelude::*;

use crate::director::lingo::datum::Datum;

use crate::player::symbols::builtin::BuiltInSymbol;
use crate::player::symbols::symbol::Symbol;
use crate::player::{
    cast_member::CastMemberType,
    font::{get_text_index_at_pos, DrawTextParams},
    player_call_script_handler, player_handle_scope_return,
    reserve_player_mut, reserve_player_ref,
    script::{script_get_prop, script_set_prop},
    script_ref::ScriptInstanceRef, DatumRef, DirPlayer, ScriptError, ScriptErrorCode,
    score::{get_concrete_sprite_rect, get_sprite_rect_in_context},
};

use super::script_instance::ScriptInstanceUtils;

/// The sprite's Shockwave3D camera list as one ordered vec (index 1 first).
///
/// Director gives every 3D sprite a camera list that ALREADY contains the cast
/// member's default camera at index 1 — `cameraCount()` is 1 before a script has
/// touched it, and `addCamera(cam)` with no index appends *after* that camera. We
/// store the list as `w3d_camera` (index 1) + `w3d_cameras` (2+), and both start
/// empty, so seed index 1 with the member's own default view.
///
/// Without the seed, SuperSonic RC's
///     tSprite.addCamera(p3d.camera("overlays"))
/// made the in-scene overlay camera index 1 — it replaced the game world's default
/// camera instead of layering over it, and since it clears on render the sprite
/// came out black.
fn sprite_camera_list(
    player: &DirPlayer,
    sprite_num: i16,
) -> Vec<crate::player::sprite::SpriteCamera> {
    let Some(sprite) = player.movie.score.get_sprite(sprite_num) else {
        return vec![];
    };
    let mut cams: Vec<_> = sprite.w3d_camera.iter().cloned().collect();
    cams.extend(sprite.w3d_cameras.iter().cloned());
    if cams.is_empty() {
        // Same default the renderer picks when no camera is active: the member's
        // "DefaultView", else its first view node.
        use crate::director::chunks::w3d::types::W3dNodeType;
        let name = sprite
            .member
            .as_ref()
            .and_then(|m| player.movie.cast_manager.find_member_by_ref(m))
            .and_then(|m| m.member_type.as_shockwave3d())
            .and_then(|o| o.parsed_scene.as_ref())
            .and_then(|sc| {
                sc.nodes
                    .iter()
                    .find(|n| {
                        n.node_type == W3dNodeType::View
                            && n.name.eq_ignore_ascii_case("DefaultView")
                    })
                    .or_else(|| sc.nodes.iter().find(|n| n.node_type == W3dNodeType::View))
                    .map(|n| n.name.as_str().to_string())
            })
            .unwrap_or_else(|| "DefaultView".to_string());
        cams.push(crate::player::sprite::SpriteCamera { member: None, name });
    }
    cams
}

/// Write an ordered camera list back to the sprite's primary + extras split.
fn set_sprite_camera_list(
    player: &mut DirPlayer,
    sprite_num: i16,
    mut cams: Vec<crate::player::sprite::SpriteCamera>,
) {
    let sprite = player.movie.score.get_sprite_mut(sprite_num);
    sprite.w3d_camera = if cams.is_empty() { None } else { Some(cams.remove(0)) };
    sprite.w3d_cameras = cams;
}

// JS bridge names use the `dirplayer_` prefix so this fork's globals don't
// collide with stock Ruffle if both are loaded on the same page (e.g. via a
// browser extension). Matching JS-side definitions live in
// src/services/flashPlayerManager.ts::initFlashBridge.
#[wasm_bindgen]
extern "C" {
    // All Lingo Flash bridge calls now take `sprite_num` because each Flash
    // sprite has its own Ruffle instance (per-sprite refactor — multiple
    // sprites sharing one cast member each get an independent player).
    /// `frame_or_label` is the raw Lingo argument as a string. Director's
    /// `sprite(N).gotoFrame(...)` accepts either a frame number (e.g. `3`)
    /// or a label (e.g. `"warm0"`); the JS side parses and routes to
    /// the appropriate Ruffle call. Always passing a string here lets us
    /// preserve labels — `.int_value()` on the Rust side silently parses
    /// non-numeric strings to `0`, and `GotoFrame(0, true)` is treated as
    /// a stop, which froze mello's Fire/Marshmello SWFs.
    #[wasm_bindgen(js_name = "dirplayer_ruffleGoToFrame")]
    fn ruffle_goto_frame(sprite_num: i32, frame_or_label: &str);
    #[wasm_bindgen(js_name = "dirplayer_ruffleStop")]
    fn ruffle_stop(sprite_num: i32);
    #[wasm_bindgen(js_name = "dirplayer_rufflePlay")]
    fn ruffle_play(sprite_num: i32);
    #[wasm_bindgen(js_name = "dirplayer_ruffleRewind")]
    fn ruffle_rewind(sprite_num: i32);
    #[wasm_bindgen(js_name = "dirplayer_ruffleCallFrame")]
    fn ruffle_call_frame(sprite_num: i32, frame: i32);
    #[wasm_bindgen(js_name = "dirplayer_ruffleGetVariable", catch)]
    fn ruffle_get_variable(sprite_num: i32, path: &str) -> Result<JsValue, JsValue>;
    #[wasm_bindgen(js_name = "dirplayer_ruffleSetVariable", catch)]
    fn ruffle_set_variable(sprite_num: i32, path: &str, value: &str) -> Result<JsValue, JsValue>;
    #[wasm_bindgen(js_name = "dirplayer_ruffleCallFunction", catch)]
    fn ruffle_call_function(sprite_num: i32, path: &str, args_xml: &str) -> Result<JsValue, JsValue>;
    /// Classify what's under a sprite-local point: 0 = #background,
    /// 1 = #normal, 2 = #button, 3 = #editText (Director Flash hitTest values).
    #[wasm_bindgen(js_name = "dirplayer_ruffleHitTest")]
    fn ruffle_hit_test(sprite_num: i32, x: f64, y: f64) -> i32;
    #[wasm_bindgen(js_name = "dirplayer_ruffleGetFlashProperty", catch)]
    fn ruffle_get_flash_property(sprite_num: i32, target: &str, prop_num: i32) -> Result<JsValue, JsValue>;
    #[wasm_bindgen(js_name = "dirplayer_ruffleSetFlashProperty")]
    fn ruffle_set_flash_property(sprite_num: i32, target: &str, prop_num: i32, value: &str);
    /// True once the sprite's Ruffle instance has loaded AND finished AS init.
    /// Used to BLOCK a Flash interop call until the SWF is ready (see call_async).
    #[wasm_bindgen(js_name = "dirplayer_isFlashInstanceReady", catch)]
    fn is_flash_instance_ready(sprite_num: i32) -> Result<JsValue, JsValue>;
}

/// Yield the frame loop until the sprite's Ruffle instance is ready (loaded +
/// AS-initialized), so a Flash interop call reads/writes a live instance rather
/// than returning null. Bounded (~10s) so a sprite that never gets a ready
/// instance falls back to the caller's existing lazy-handle / VOID behaviour.
async fn wait_for_flash_ready(sprite_num: i16) {
    for _ in 0..100u32 {
        let ready = is_flash_instance_ready(sprite_num as i32)
            .ok()
            .and_then(|v| v.as_bool())
            .unwrap_or(true);
        if ready {
            return;
        }
        let _ = async_std::future::timeout(
            std::time::Duration::from_millis(100),
            std::future::pending::<()>(),
        )
        .await;
    }
}

/// Root a bare Flash variable/function path.
///
/// The Ruffle fork's GetVariable/SetVariable/CallFunction run on a
/// `from_nothing` AVM1 activation where an unqualified timeline name does NOT
/// resolve — only explicit `_root`/`_level0`/`_global`/`this`/slash paths do
/// (confirmed empirically: `objMain` → undefined, `_root.objMain` → the
/// object). Director's own Flash Asset resolves such names relative to
/// `_level0`, so prefix a bare name with `_level0.` (JS translateLevel0 maps
/// `_level0` → `_root` before it reaches Ruffle). Already-qualified paths are
/// left untouched.
fn root_flash_path(path: &str) -> String {
    if path.is_empty()
        || path.starts_with("_level0")
        || path.starts_with("_root")
        || path.starts_with("_global")
        || path.starts_with("this")
        || path.starts_with('/')
    {
        path.to_string()
    } else {
        format!("_level0.{}", path)
    }
}

pub struct SpriteDatumHandlers {}

pub struct SpriteDatumUtils {}

impl SpriteDatumUtils {
    pub fn get_script_instance_ids(
        datum: &DatumRef,
        player: &DirPlayer,
    ) -> Result<Vec<ScriptInstanceRef>, ScriptError> {
        let sprite_num = player.get_datum(datum).to_sprite_ref()?;
        let sprite = player.movie.score.get_sprite(sprite_num);
        if sprite.is_none() {
            return Ok(vec![]);
        }
        let sprite = sprite.unwrap();
        let instances = &sprite.script_instance_list;
        Ok(instances.clone())
    }

    /// Resolves the text content and character index at a stage point for a text/field sprite.
    /// Returns (text, char_index) or None if the sprite has no text member.
    fn get_text_char_index_at_point(
        player: &DirPlayer,
        datum: &DatumRef,
        point_arg: &DatumRef,
    ) -> Result<Option<(String, usize)>, ScriptError> {
        let sprite_num = player.get_datum(datum).to_sprite_ref()?;
        let (vals, _flags) = player.get_datum(point_arg).to_point_inline()?;
        let stage_x = vals[0] as i32;
        let stage_y = vals[1] as i32;

        let sprite = match player.movie.score.get_sprite(sprite_num) {
            Some(s) => s,
            None => return Ok(None),
        };

        let member_ref = match &sprite.member {
            Some(r) => r.clone(),
            None => return Ok(None),
        };

        let sprite_rect = get_concrete_sprite_rect(player, sprite);
        let local_x = stage_x - sprite_rect.left;
        let local_y = stage_y - sprite_rect.top;

        let member = match player.movie.cast_manager.find_member_by_ref(&member_ref) {
            Some(m) => m,
            None => return Ok(None),
        };

        let (text, fixed_line_space, top_spacing) = match &member.member_type {
            CastMemberType::Text(t) => (t.text.clone(), t.fixed_line_space, t.top_spacing),
            CastMemberType::Field(f) => (f.text.clone(), f.fixed_line_space, f.top_spacing),
            _ => return Ok(None),
        };

        let font = player.font_manager.get_system_font().unwrap();
        let params = DrawTextParams {
            font: &font,
            line_height: None,
            line_spacing: fixed_line_space,
            top_spacing,
            char_spacing: 0,
            member_width: None,
            min_space_advance: None,
            per_char_advances: None,
        };

        let char_index = get_text_index_at_pos(&text, &params, local_x, local_y);
        Ok(Some((text, char_index)))
    }
}

impl SpriteDatumHandlers {
    /// Resolve a sprite datum to (sprite_num, cast_lib, cast_member). The
    /// sprite_num is the lookup key for the per-sprite Ruffle instance;
    /// cast_lib/cast_member are still needed by callers that build
    /// `FlashObjectRef`s. Returns None when the sprite has no member.
    fn resolve_sprite_flash_member(datum: &DatumRef) -> Result<Option<(i32, i32, i32)>, ScriptError> {
        reserve_player_ref(|player| {
            let sprite_num = player.get_datum(datum).to_sprite_ref()?;
            let sprite = match player.movie.score.get_sprite(sprite_num) {
                Some(s) => s,
                None => return Ok(None),
            };
            match &sprite.member {
                Some(member_ref) => Ok(Some((
                    sprite_num as i32,
                    member_ref.cast_lib,
                    member_ref.cast_member,
                ))),
                None => Ok(None),
            }
        })
    }

    /// Returns true if the handler should be called via the async path.
    /// This returns true for:
    /// 1. Handlers found on the sprite's attached script instances
    /// 2. Any handler that isn't a built-in sync handler (to allow fallback to global handlers)
    pub fn has_async_handler(datum: &DatumRef, handler_name: &str) -> Result<bool, ScriptError> {
        // First check if it's a built-in sync handler (case-insensitive)
        let name_lower = handler_name.to_lowercase();

        // Flash interop: async ONLY on the first access to a sprite whose Ruffle
        // instance isn't confirmed ready yet — call_async waits for readiness,
        // then whitelists the sprite (flash_ready_sprites). Every later call
        // finds it whitelisted and takes the SYNC fast path below, so the
        // hundreds of per-frame interop calls (Coke Studios) don't pay
        // async-dispatch overhead. Cleared on member unload/swap so it re-waits.
        if matches!(
            name_lower.as_str(),
            "getvariable" | "setvariable" | "callfunction" | "setcallback"
        ) {
            let ready = reserve_player_ref(|player| {
                match player.get_datum(datum).to_sprite_ref() {
                    Ok(sn) => player.flash_ready_sprites.contains(&sn),
                    Err(_) => false,
                }
            });
            return Ok(!ready);
        }

        let is_sync_handler = matches!(name_lower.as_str(),
            "intersects" | "getprop" | "getat" | "setat" | "getaprop" | "setaprop" | "pointtoword" | "pointtoline" |
            "gotoframe" | "callframe" | "stop" | "play" | "rewind" | "hold" |
            "newobject" |
            "hittest" | "getflashproperty" | "setflashproperty" | "telltarget" |
            "findlabel" | "flashtostage" | "stagetoflash" | "mapstagetomember" | "getpropref" |
            // `camera` belongs with the other 3D camera-list accessors: it must reach
            // SpriteDatumHandlers::call so `sprite(n).camera(i)` indexes the list.
            // Left off, it fell to the async path (sprite behaviours, then global
            // handlers) and the index was lost — every camera(i) answered with the
            // primary camera, so [PS] Fade's teardown never matched its own camera
            // and never removed it.
            "addcamera" | "removecamera" | "deletecamera" | "cameracount" | "camera"
        );
        if is_sync_handler {
            return Ok(false);
        }
        // pause and resume are not built-ins on an ordinary sprite, so they stay
        // on the async path where a behaviour may define them. On a sprite
        // showing an animated GIF they drive the animation.
        if matches!(name_lower.as_str(), "pause" | "resume")
            && crate::player::gif::sprite_has_gif(datum)
        {
            return Ok(false);
        }


        // For all other handlers, use the async path which will:
        // 1. Try sprite's attached scripts
        // 2. Fall back to global handlers
        Ok(true)
    }

    pub fn call(
        datum: &DatumRef,
        handler_name: &str,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name_lower = handler_name.to_lowercase();
        match name_lower.as_str() {
            // A movie drives an animated GIF through its sprite:
            // `sprite(n).pause()` freezes it, `rewind()` returns it to frame 1
            // and `resume()` starts it again. Without these the animation runs
            // continuously, so a plume meant to puff at intervals never stops.
            "pause" | "resume" | "rewind" | "play" | "stop"
                if crate::player::gif::sprite_has_gif(datum) =>
            {
                crate::player::gif::control_sprite_gif(datum, &name_lower)
            }
            // `sprite(N).pointToChar(point)` — 1-based char index at a stage
            // coordinate within the sprite's text/field member, or -1 if the
            // point isn't within the text (Director 11.5 Scripting Dictionary).
            // Shares the hit-test core with `the mouseChar` / the global
            // `pointToChar()` builtin.
            "pointtochar" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "pointToChar requires 1 argument (point)".to_string(),
                        ));
                    }
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let (pt_vals, _f) = player.get_datum(&args[0]).to_point_inline()?;
                    let result = crate::player::compute_char_at(
                        player, sprite_num, pt_vals[0] as i32, pt_vals[1] as i32,
                    );
                    Ok(player.alloc_datum(Datum::Int(result)))
                })
            }
            "intersects" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "intersects requires 1 argument (sprite number)".to_string(),
                        ));
                    }

                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let other_sprite_num =
                        player.get_datum(&args[0]).int_value()? as i16;

                    // Get both sprites' rects
                    let sprite1 = player.movie.score.get_sprite(sprite_num);
                    let sprite2 = player.movie.score.get_sprite(other_sprite_num);

                    if sprite1.is_none() || sprite2.is_none() {
                        return Ok(player.alloc_datum(Datum::Int(0)));
                    }

                    let sprite1 = sprite1.unwrap();
                    let sprite2 = sprite2.unwrap();

                    // Get the concrete rects of both sprites
                    let rect1 = get_concrete_sprite_rect(player, sprite1);
                    let rect2 = get_concrete_sprite_rect(player, sprite2);

                    // Check if rectangles intersect
                    let intersects = !(
                        rect1.right <= rect2.left
                            || rect1.left >= rect2.right
                            || rect1.bottom <= rect2.top
                            || rect1.top >= rect2.bottom
                    );

                    Ok(player.alloc_datum(Datum::Int(if intersects { 1 } else { 0 })))
                })
            }
            // `sprite(n).camera(i)` — INDEXED access into the sprite's camera list.
            // Without it the index was ignored and every `camera(i)` answered with the
            // primary camera, so [PS] Fade's teardown
            //     repeat with i = 1 to tCount
            //       if tSprite.camera(i).name = p.camera.name then tIndex = i
            //     if tIndex > 0 then tSprite.deleteCamera(tIndex)
            // never found its own camera and never removed it. Every fade then left
            // another Fade_Camera pass on the sprite; they stacked up, and one whose
            // clearAtRender defaulted to TRUE wiped the skybox, the 3D world and the
            // menu UI that had already been drawn that frame.
            "camera" => {
                reserve_player_mut(|player| {
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let index = if !args.is_empty() {
                        player.get_datum(&args[0]).int_value().unwrap_or(1)
                    } else { 1 };
                    let own = player.movie.score.get_sprite(sprite_num)
                        .and_then(|s| s.member.as_ref())
                        .cloned()
                        .unwrap_or(crate::player::cast_lib::NULL_CAST_MEMBER_REF);
                    let cams = sprite_camera_list(player, sprite_num as i16);
                    let idx = (index.max(1) as usize) - 1;
                    match cams.get(idx) {
                        Some(c) => {
                            let (cast_lib, cast_member) =
                                c.member.unwrap_or((own.cast_lib, own.cast_member));
                            Ok(player.alloc_datum(Datum::Shockwave3dObjectRef(
                                crate::director::lingo::datum::Shockwave3dObjectRef {
                                    cast_lib,
                                    cast_member,
                                    object_type: BuiltInSymbol::Camera,
                                    name: Symbol::from_str(&c.name),
                                },
                            )))
                        }
                        None => Ok(DatumRef::Void),
                    }
                })
            }
            "cameracount" => {
                reserve_player_mut(|player| {
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let count = sprite_camera_list(player, sprite_num as i16).len().max(1) as i32;
                    Ok(player.alloc_datum(Datum::Int(count)))
                })
            }
            "addcamera" => {
                reserve_player_mut(|player| {
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    // addCamera(cameraRef, index)
                    // index 1 = primary camera, 2+ = additional cameras rendered on top
                    // A camera reference carries the member that owns it; that member
                    // may differ from the sprite's own (Director composites each camera
                    // against its own member's world).
                    let cam_entry = if !args.is_empty() {
                        match player.get_datum(&args[0]) {
                            Datum::Shockwave3dObjectRef(r) => Some(crate::player::sprite::SpriteCamera {
                                member: Some((r.cast_lib, r.cast_member)),
                                name: r.name.as_str().to_string(),
                            }),
                            Datum::String(s) if !s.is_empty() => Some(crate::player::sprite::SpriteCamera {
                                member: None,
                                name: s.clone(),
                            }),
                            _ => None,
                        }
                    } else { None };
                    let index = if args.len() >= 2 {
                        Some(player.get_datum(&args[1]).int_value().unwrap_or(1) as usize)
                    } else { None };
                    if let Some(cam_entry) = cam_entry {
                        // Director 11.5 Scripting Dictionary, `addCamera`: "adds a camera
                        // to the list of cameras for the sprite … index … specifies the
                        // index in the list of cameras at which whichCamera is ADDED. If
                        // index is greater than the value of cameraCount(), the camera is
                        // added to the end of the list." Its example "inserts the camera
                        // named FlightCam at the fifth index position" — so an existing
                        // camera at that index shifts down, it is NOT replaced.
                        //
                        // Index 1 used to overwrite the primary camera outright, which
                        // silently DISCARDED it. AreaZero's [PS] Camera does
                        //     p.sprite.camera = Player1_Camera
                        //     p.sprite.addCamera(tSkyboxCamera, 1)
                        // so the camera the whole menu is framed through was thrown away
                        // the moment the skybox camera was added, and the sprite rendered
                        // through an unrelated fallback view that never moved.
                        //
                        // The sprite stores the list as primary + extras; treat them as
                        // one ordered list so an insert anywhere shifts correctly. The
                        // list already holds the member's default camera at index 1 (see
                        // sprite_camera_list), so a plain append layers over the world
                        // rather than replacing it.
                        let mut cams = sprite_camera_list(player, sprite_num as i16);
                        let at = match index {
                            Some(i) => i.saturating_sub(1).min(cams.len()),
                            None => cams.len(), // addCamera(cam) — append
                        };
                        cams.insert(at, cam_entry);
                        set_sprite_camera_list(player, sprite_num as i16, cams);
                    }
                    Ok(player.alloc_datum(Datum::Void))
                })
            }
            // Director 11.5 Scripting Dictionary, `deleteCamera`:
            // "sprite(whichSprite).deleteCamera(cameraOrIndex) … removes the camera
            // from the sprite's list of cameras. The camera is not deleted from the
            // cast member." The argument is "a string or an integer that specifies the
            // name or index position", and the doc's own example also passes a camera
            // REFERENCE — so accept all three. Only `removeCamera` existed before, so
            // the documented `deleteCamera` fell through to the async path and did
            // nothing: [PS] Fade could never drop its camera.
            "deletecamera" | "removecamera" => {
                reserve_player_mut(|player| {
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let target = args.first().map(|a| player.get_datum(a).clone());
                    // Mirror addCamera: one ordered list, so removing index 1 promotes
                    // the next camera instead of being a silent no-op.
                    let mut cams = sprite_camera_list(player, sprite_num as i16);
                    let at = match &target {
                        Some(Datum::Shockwave3dObjectRef(r)) => cams
                            .iter()
                            .position(|c| r.name.eq_ignore_ascii_case(&c.name)),
                        Some(Datum::String(name)) => cams
                            .iter()
                            .position(|c| c.name.eq_ignore_ascii_case(name)),
                        Some(other) => other
                            .int_value()
                            .ok()
                            .map(|i| (i.max(1) as usize) - 1),
                        None => None,
                    };
                    if let Some(at) = at {
                        if at < cams.len() {
                            cams.remove(at);
                        }
                    }
                    set_sprite_camera_list(player, sprite_num as i16, cams);
                    Ok(player.alloc_datum(Datum::Void))
                })
            }
            "getprop" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "getProp requires at least 1 argument".to_string(),
                        ));
                    }

                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;

                    // Get the property name from the first arg
                    let prop_name = player.get_datum(&args[0]).symbol_value()?;

                    // First, try to get it as a built-in sprite property
                    match crate::player::score::sprite_get_prop(
                        player,
                        sprite_num as i16,
                        prop_name,
                    ) {
                        Ok(prop_datum) => {
                            let result = player.last_sprite_prop_ref.take()
                                .unwrap_or_else(|| player.alloc_datum(prop_datum));

                            // If there's a second argument, it's a sub-property access
                            if args.len() > 1 {
                                return crate::player::handlers::types::TypeUtils::get_sub_prop(
                                    &result, &args[1], player,
                                );
                            }

                            return Ok(result);
                        }
                        Err(_) => {
                            // Not a built-in sprite property, try script instances
                        }
                    }

                    let sprite = player.movie.score.get_sprite(sprite_num);
                    if sprite.is_none() {
                        return Err(ScriptError::new(format!("Sprite {} not found", sprite_num)));
                    }

                    // Clone the script instance list to avoid borrow conflicts
                    let instance_refs = sprite.unwrap().script_instance_list.clone();

                    // Try to get the property from the sprite's script instances
                    for instance_ref in instance_refs {
                        if let Ok(result) = script_get_prop(
                            player,
                            &instance_ref,
                            prop_name,
                        ) {
                            // If there's a second argument, it's a sub-property access
                            if args.len() > 1 {
                                return crate::player::handlers::types::TypeUtils::get_sub_prop(
                                    &result, &args[1], player,
                                );
                            }
                            return Ok(result);
                        }
                    }

                    // If not found anywhere, return void
                    Ok(DatumRef::Void)
                })
            }
            // getAt / getaProp: bracket access on sprite, e.g. sprite(9)[#pLevel]
            "getat" | "getaprop" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "getAt requires 1 argument".to_string(),
                        ));
                    }

                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let prop_name = player.get_datum(&args[0]).symbol_value()?;

                    // Try built-in sprite property first
                    match crate::player::score::sprite_get_prop(
                        player,
                        sprite_num as i16,
                        prop_name,
                    ) {
                        Ok(prop_datum) => {
                            return Ok(player.last_sprite_prop_ref.take()
                                .unwrap_or_else(|| player.alloc_datum(prop_datum)));
                        }
                        Err(_) => {}
                    }

                    // Fall back to sprite's script instance properties. Same
                    // rule as `sprite_get_prop`: resolve through
                    // get_sprite_script_instance_ids so behaviours attached at
                    // runtime via `scriptInstanceList.add/addAt` are included —
                    // the sprite's internal Vec holds only score-authored ones.
                    let sprite = player.movie.score.get_sprite(sprite_num);
                    if sprite.is_none() {
                        return Ok(DatumRef::Void);
                    }
                    let fallback = sprite.unwrap().script_instance_list.clone();
                    let instance_refs =
                        player.get_sprite_script_instance_ids(sprite_num, fallback.as_slice());
                    for instance_ref in instance_refs {
                        if let Ok(result) = script_get_prop(player, &instance_ref, prop_name) {
                            return Ok(result);
                        }
                    }

                    Ok(DatumRef::Void)
                })
            }
            "getpropref" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "getPropRef requires at least 1 argument".to_string(),
                        ));
                    }

                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let prop_name = player.get_datum(&args[0]).symbol_value()?;

                    // Get the property value (this handles scriptInstanceList cache etc.)
                    match crate::player::score::sprite_get_prop(
                        player,
                        sprite_num as i16,
                        prop_name,
                    ) {
                        Ok(prop_datum) => {
                            let result = player.last_sprite_prop_ref.take()
                                .unwrap_or_else(|| player.alloc_datum(prop_datum));

                            // If there's a second argument, it's an index into
                            // the property value. A property list is indexed by
                            // KEY (symbol/string), not a positional int — e.g.
                            // Summer Resort's `sprite(i).pData[#item]`, where
                            // pData is a #-keyed prop list. The old code coerced
                            // the key via int_value() (a symbol → 0) and only
                            // handled positional Lists, so it errored "cannot
                            // index into prop_list with 0". Mirror the PropList
                            // handler's key lookup here.
                            if args.len() > 1 {
                                let list_datum = player.get_datum(&result).clone();
                                match list_datum {
                                    Datum::PropList(pairs, pairs_sorted) => {
                                        return crate::player::handlers::datum_handlers::prop_list::PropListUtils::get_by_key(
                                            &pairs, &args[1], &player.allocator, pairs_sorted,
                                        );
                                    }
                                    Datum::List(_, item_refs, _) => {
                                        let index = player.get_datum(&args[1]).int_value()?;
                                        if index < 1 || index as usize > item_refs.len() {
                                            return Err(ScriptError::new(format!(
                                                "getPropRef: index {} out of range for list of length {}",
                                                index, item_refs.len()
                                            )));
                                        }
                                        return Ok(item_refs[(index - 1) as usize].clone());
                                    }
                                    _ => {
                                        let index = player.get_datum(&args[1]).int_value().unwrap_or(0);
                                        return Err(ScriptError::new(format!(
                                            "getPropRef: cannot index into {} with {}",
                                            player.get_datum(&result).type_str(), index
                                        )));
                                    }
                                }
                            }

                            return Ok(result);
                        }
                        Err(_) => {
                            // Not a built-in sprite property, try script instances
                        }
                    }

                    // Fall back to script instance properties
                    let sprite = player.movie.score.get_sprite(sprite_num);
                    if sprite.is_none() {
                        return Err(ScriptError::new(format!("Sprite {} not found", sprite_num)));
                    }
                    let instance_refs = sprite.unwrap().script_instance_list.clone();
                    for instance_ref in instance_refs {
                        if let Ok(result) = script_get_prop(player, &instance_ref, prop_name) {
                            if args.len() > 1 {
                                return crate::player::handlers::types::TypeUtils::get_sub_prop(
                                    &result, &args[1], player,
                                );
                            }
                            return Ok(result);
                        }
                    }

                    Ok(DatumRef::Void)
                })
            }
            // setAt / setaProp: bracket assignment on sprite, e.g. sprite(9)[#pLevel] = value
            "setat" | "setaprop" => {
                reserve_player_mut(|player| {
                    if args.len() < 2 {
                        return Err(ScriptError::new(
                            "setAt requires 2 arguments".to_string(),
                        ));
                    }

                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let prop_name = player.get_datum(&args[0]).symbol_value()?;
                    let value = player.get_datum(&args[1]).clone();
                    let value_ref = &args[1];

                    // Try built-in sprite property first
                    match crate::player::score::sprite_set_prop(
                        sprite_num as i16,
                        prop_name,
                        value,
                    ) {
                        Ok(_) => return Ok(DatumRef::Void),
                        Err(_) => {}
                    }

                    // Fall back to sprite's script instance properties
                    let sprite = player.movie.score.get_sprite(sprite_num);
                    if sprite.is_none() {
                        return Err(ScriptError::new(format!("Sprite {} not found", sprite_num)));
                    }
                    let instance_refs = sprite.unwrap().script_instance_list.clone();
                    for instance_ref in instance_refs {
                        if let Ok(_) = script_set_prop(player, &instance_ref, prop_name, value_ref, false) {
                            return Ok(DatumRef::Void);
                        }
                    }

                    Err(ScriptError::new(format!(
                        "Property {} not found on sprite {}", prop_name, sprite_num
                    )))
                })
            }
            "pointtoword" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "pointToWord requires 1 argument (point)".to_string(),
                        ));
                    }

                    let (text, char_index) = match SpriteDatumUtils::get_text_char_index_at_point(player, datum, &args[0])? {
                        Some(r) => r,
                        None => return Ok(player.alloc_datum(Datum::Int(-1))),
                    };

                    // Find which word (1-based) the character at char_index belongs to
                    let mut word_num = 0;
                    let mut char_count = 0;
                    let mut in_word = false;
                    for c in text.chars() {
                        if c.is_whitespace() {
                            in_word = false;
                        } else if !in_word {
                            word_num += 1;
                            in_word = true;
                        }
                        if char_count == char_index {
                            return Ok(player.alloc_datum(Datum::Int(word_num)));
                        }
                        char_count += 1;
                    }

                    // Past end of text: return the last word number
                    Ok(player.alloc_datum(Datum::Int(word_num)))
                })
            }
            "pointtoline" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "pointToLine requires 1 argument (point)".to_string(),
                        ));
                    }

                    let (text, char_index) = match SpriteDatumUtils::get_text_char_index_at_point(player, datum, &args[0])? {
                        Some(r) => r,
                        None => return Ok(player.alloc_datum(Datum::Int(-1))),
                    };

                    // Find which line (1-based) the character at char_index belongs to
                    let mut line_num = 1;
                    let mut char_count = 0;
                    for c in text.chars() {
                        if char_count == char_index {
                            return Ok(player.alloc_datum(Datum::Int(line_num)));
                        }
                        if c == '\r' || c == '\n' {
                            line_num += 1;
                        }
                        char_count += 1;
                    }

                    // Past end of text: return the last line number
                    Ok(player.alloc_datum(Datum::Int(line_num)))
                })
            }
            // Flash (SWF) sprite methods
            "gotoframe" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    // Pass the raw arg as a string — Lingo callers use
                    // either a numeric frame or a string label (e.g.
                    // `sprite(N).gotoFrame("warm0")`). The JS bridge
                    // parses the string and routes to GotoFrame(int) or
                    // an AS1 `gotoAndStop(label)` call as appropriate.
                    let frame_or_label = reserve_player_ref(|player| {
                        if args.is_empty() { return Ok("1".to_string()); }
                        player.get_datum(&args[0]).string_value()
                    })?;
                    ruffle_goto_frame(sn, &frame_or_label);
                }
                Ok(DatumRef::Void)
            }
            "callframe" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    let frame = reserve_player_ref(|player| {
                        if args.is_empty() { return Ok(1); }
                        player.get_datum(&args[0]).int_value()
                    })?;
                    ruffle_call_frame(sn, frame);
                }
                Ok(DatumRef::Void)
            }
            "stop" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    ruffle_stop(sn);
                }
                Ok(DatumRef::Void)
            }
            "play" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    // play() overrides a prior `sprite.frame = N` hold — clear
                    // the asserted frame so a fresh instance plays, not pins.
                    reserve_player_mut(|player| {
                        player.movie.score.get_sprite_mut(sn as i16).flash_asserted_frame = None;
                    });
                    ruffle_play(sn);
                }
                Ok(DatumRef::Void)
            }
            "rewind" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    ruffle_rewind(sn);
                }
                Ok(DatumRef::Void)
            }
            // Director 11.5 `hold()` (spec: "stops a Flash movie sprite that is
            // playing in the current frame, but any audio continues to play").
            // We map it to the same root-timeline stop as `stop()` — stopFlash
            // halts the root MovieClip while leaving the player alive to render
            // (we don't split audio in the Ruffle bridge, an acceptable
            // divergence). bogey_nights' bogeyman #hiding relies on hold to
            // actually halt the idle SWF.
            "hold" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    ruffle_stop(sn);
                }
                Ok(DatumRef::Void)
            }
            "getvariable" => {
                // Resolve the target sprite number FIRST, even if its cast
                // member isn't resolvable at this instant. Director's
                // getVariable(sprite(N), path, 0) yields a Flash object handle
                // BOUND TO THAT SPRITE; it must not degrade to VOID just because
                // the member/Ruffle instance isn't ready yet — a beginSprite can
                // run before the Flash member is committed to the channel, and a
                // VOID handle stored in a global (e.g. gDemoFlash) crashes the
                // deferred `gDemoFlash.play()`. We capture the sprite's cast
                // member when available (so cast-based lookups still work) but
                // always bind the handle to the sprite number as the primary key.
                let sn = reserve_player_ref(|player| player.get_datum(datum).to_sprite_ref())?;
                let (cl, cm) = reserve_player_ref(|player| {
                    player
                        .movie
                        .score
                        .get_sprite(sn)
                        .and_then(|s| s.member.as_ref())
                        .map(|m| (m.cast_lib, m.cast_member))
                        .unwrap_or((0, 0))
                });
                let (path, return_as_object) = reserve_player_ref(|player| {
                    if args.is_empty() { return Ok((String::new(), false)); }
                    let p = player.get_datum(&args[0]).string_value()?;
                    // Second arg: 0 = return as Flash object reference, otherwise string
                    let as_obj = if args.len() >= 2 {
                        player.get_datum(&args[1]).int_value().unwrap_or(1) == 0
                    } else {
                        false
                    };
                    Ok((p, as_obj))
                })?;

                if return_as_object {
                    // Root a bare variable name so it addresses the real
                    // timeline object — DGS `getVariable("objMain", 0)` returns a
                    // handle used for `objMain.includeIsLoaded()` etc. See
                    // root_flash_path for why bare names don't resolve.
                    let rooted = root_flash_path(&path);

                    // In Director, getVariable(path, 0) returns an object reference.
                    // But if the Flash variable is a simple string/number, Director
                    // returns the value directly. We check via GetVariable first:
                    // if it returns a JS string, return as Datum::String so that
                    // stringp() works. If it returns an object or undefined, return
                    // a FlashObjectRef for setCallback/call usage.
                    if let Ok(val) = ruffle_get_variable(sn as i32, &rooted) {
                        if val.is_string() {
                            let s = val.as_string().unwrap();
                            // Ruffle's GetVariable ALWAYS returns a string, coercing
                            // an AS OBJECT to "[object Object]" / "[type Object]" /
                            // "[object MovieClip]". The object form
                            // (getVariable(path, 0)) must return a FlashObjectRef for
                            // those, NOT the coercion text — DGS does
                            // `objMain = getVariable("objMain", 0)` then
                            // `objMain.setBaseUrls(...)` (a method call). Only a
                            // genuine primitive string returns as Datum::String.
                            let is_object_coercion =
                                s.starts_with("[object ") || s.starts_with("[type ");
                            if !is_object_coercion {
                                return reserve_player_mut(|player| {
                                    Ok(player.alloc_datum(Datum::String(s)))
                                });
                            }
                        }
                        // Object / object-coercion / undefined → FlashObjectRef.
                    }
                    // Return a sprite-bound FlashObjectRef for use with
                    // setCallback / call / play etc. Never VOID for the object form.
                    return reserve_player_mut(|player| {
                        use crate::director::lingo::datum::FlashObjectRef;
                        Ok(player.alloc_datum(Datum::FlashObjectRef(
                            FlashObjectRef::from_path_with_sprite(&rooted, cl, cm, sn as i32),
                        )))
                    });
                }

                // Member-swap guard: when the score has just swapped this
                // sprite to a NEW Flash member, the PREVIOUS member's Ruffle
                // instance can still be resident until the new one loads.
                // Reading the old member's variables is wrong — e.g. BioBoxing's
                // menu frame swaps sprite 1 loading.swf -> start.swf, and reading
                // loading.swf's stale `/:cont="1"` (instead of start.swf's "00")
                // skips the whole menu. If the sprite's CURRENT (cl,cm) isn't in
                // `flash_sprite_loaded`, treat the value read as not-ready (VOID)
                // so the frame's `if cont = 1 ... else go(the frame)` loop holds
                // until the new member loads and its real value can be read.
                let member_ready = reserve_player_ref(|player| {
                    (cl == 0 && cm == 0)
                        || player.flash_sprite_loaded.contains(&(sn, cl, cm))
                });
                if !member_ready {
                    return Ok(DatumRef::Void);
                }

                match ruffle_get_variable(sn as i32, &root_flash_path(&path)) {
                    Ok(val) => {
                        // Convert the AS value to a Lingo datum. GetVariable's
                        // value form (2nd arg non-zero) isn't string-only — an AS
                        // number or boolean must come back as a comparable value,
                        // not VOID. Neopets DGS state 81 polls
                        // `getVariable("preloaderTranslationSuccess", 1) = 1`,
                        // where the AS var is a Number/Boolean; returning VOID for
                        // those (`as_string()` is None) made the comparison never
                        // true and stalled the loader. Bools → Int(0/1), integral
                        // Numbers → Int, else Float, matching the callFunction
                        // converter that already let `includeIsLoaded() = 1` work.
                        let datum = if let Some(s) = val.as_string() {
                            Datum::String(s)
                        } else if let Some(b) = val.as_bool() {
                            Datum::Int(if b { 1 } else { 0 })
                        } else if let Some(n) = val.as_f64() {
                            if n.fract() == 0.0 && n.abs() < i32::MAX as f64 {
                                Datum::Int(n as i32)
                            } else {
                                Datum::Float(n)
                            }
                        } else {
                            Datum::Void
                        };
                        return reserve_player_mut(|player| Ok(player.alloc_datum(datum)));
                    }
                    Err(e) => warn!("sprite.getVariable error: {:?}", e),
                }
                Ok(DatumRef::Void)
            }
            "setvariable" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    let path = reserve_player_ref(|player| {
                        player.get_datum(&args[0]).string_value()
                    })?;
                    let value = reserve_player_ref(|player| {
                        player.get_datum(&args[1]).string_value()
                    })?;
                    if let Err(e) = ruffle_set_variable(sn, &root_flash_path(&path), &value) {
                        warn!("sprite.setVariable error: {:?}", e);
                    }
                }
                Ok(DatumRef::Void)
            }
            "callfunction" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    let path = reserve_player_ref(|player| {
                        player.get_datum(&args[0]).string_value().map(|p| root_flash_path(&p))
                    })?;
                    let args_xml = if args.len() > 1 {
                        reserve_player_ref(|player| {
                            player.get_datum(&args[1]).string_value()
                        })?
                    } else {
                        String::new()
                    };
                    match ruffle_call_function(sn, &path, &args_xml) {
                        Ok(val) => {
                            if let Some(s) = val.as_string() {
                                return reserve_player_mut(|player| {
                                    Ok(player.alloc_datum(Datum::String(s)))
                                });
                            }
                        }
                        Err(e) => warn!("sprite.callFunction error: {:?}", e),
                    }
                }
                Ok(DatumRef::Void)
            }
            "hittest" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    // Director's `sprite.hitTest(point)` takes a *stage* point
                    // (e.g. `sprite(5).hitTest(_mouse.mouseLoc)`). Accept a
                    // Point datum, or a legacy two-int (x, y) form. Rebase to
                    // sprite-local pixels (the classifier's coordinate space)
                    // by subtracting the sprite's top-left.
                    let (sx, sy) = reserve_player_ref(|player| -> Result<(i32, i32), ScriptError> {
                        match player.get_datum(&args[0]) {
                            Datum::Point([px, py], _) => Ok((*px as i32, *py as i32)),
                            other => {
                                let x = other.int_value()?;
                                let y = if let Some(a) = args.get(1) {
                                    player.get_datum(a).int_value()?
                                } else {
                                    0
                                };
                                Ok((x, y))
                            }
                        }
                    })?;
                    let rect = reserve_player_ref(|player| {
                        get_sprite_rect_in_context(player, sn as i16)
                    });
                    let lx = (sx - rect.0 as i32) as f64;
                    let ly = (sy - rect.1 as i32) as f64;
                    // 0 = #background, 1 = #normal, 2 = #button, 3 = #editText.
                    let symbol = match ruffle_hit_test(sn, lx, ly) {
                        2 => "button",
                        3 => "editText",
                        1 => "normal",
                        _ => "background",
                    };
                    return reserve_player_mut(|player| {
                        Ok(player.alloc_datum(Datum::Symbol(Symbol::from_str(&symbol.to_string()))))
                    });
                }
                Ok(DatumRef::Void)
            }
            "getflashproperty" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    let target = reserve_player_ref(|player| player.get_datum(&args[0]).string_value())?;
                    let prop_num = reserve_player_ref(|player| player.get_datum(&args[1]).int_value())?;
                    match ruffle_get_flash_property(sn, &target, prop_num) {
                        Ok(val) => {
                            if let Some(s) = val.as_string() {
                                return reserve_player_mut(|player| {
                                    Ok(player.alloc_datum(Datum::String(s)))
                                });
                            }
                        }
                        Err(e) => warn!("sprite.getFlashProperty error: {:?}", e),
                    }
                }
                Ok(DatumRef::Void)
            }
            "setflashproperty" => {
                if let Some((sn, _cl, _cm)) = Self::resolve_sprite_flash_member(datum)? {
                    let target = reserve_player_ref(|player| player.get_datum(&args[0]).string_value())?;
                    let prop_num = reserve_player_ref(|player| player.get_datum(&args[1]).int_value())?;
                    let value = reserve_player_ref(|player| player.get_datum(&args[2]).string_value())?;
                    ruffle_set_flash_property(sn, &target, prop_num, &value);
                }
                Ok(DatumRef::Void)
            }
            "setcallback" => {
                // setCallback(flashObject, flashMethod, lingoHandler, lingoTarget)
                if args.len() >= 3 {
                    reserve_player_mut(|player| {
                        let flash_object_path = match player.get_datum(&args[0]) {
                            Datum::FlashObjectRef(fo) => fo.path.clone(),
                            Datum::String(s) => s.clone(),
                            other => {
                                let type_name = other.type_str();
                                return Err(ScriptError::new(format!("setCallback: first argument must be a Flash object or string, got {}", type_name)));
                            }
                        };
                        let flash_method = player.get_datum(&args[1]).string_value()?;
                        let lingo_handler = player.get_datum(&args[2]).symbol_value().unwrap_or_else(|_| {
                            player.get_datum(&args[2]).symbol_value().unwrap_or(Symbol::empty())
                        });

                        // Translate _level0 to _root
                        let translated_path = if flash_object_path.starts_with("_level0") {
                            flash_object_path.replace("_level0", "_root")
                        } else {
                            flash_object_path.clone()
                        };

                        // Resolve the lingo target's cast_lib/cast_member for callback dispatch
                        // args[3] (if present) is the lingo target (a script instance)
                        let (cast_lib, cast_member) = if args.len() >= 4 {
                            match player.get_datum(&args[3]) {
                                Datum::ScriptInstanceRef(si_ref) => {
                                    use crate::player::allocator::ScriptInstanceAllocatorTrait;
                                    let si = player.allocator.get_script_instance(&si_ref);
                                    (si.script.cast_lib, si.script.cast_member)
                                }
                                _ => {
                                    // Fallback to sprite's Flash member
                                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                                    if let Some(sprite) = player.movie.score.get_sprite(sprite_num) {
                                        if let Some(member_ref) = &sprite.member {
                                            (member_ref.cast_lib, member_ref.cast_member)
                                        } else {
                                            (0, 0)
                                        }
                                    } else {
                                        (0, 0)
                                    }
                                }
                            }
                        } else {
                            // No target specified, use sprite's Flash member
                            let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                            if let Some(sprite) = player.movie.score.get_sprite(sprite_num) {
                                if let Some(member_ref) = &sprite.member {
                                    (member_ref.cast_lib, member_ref.cast_member)
                                } else {
                                    (0, 0)
                                }
                            } else {
                                (0, 0)
                            }
                        };

                        // Get Flash member's cast_lib/cast_member from the flash object ref or sprite
                        let (flash_cl, flash_cm) = match player.get_datum(&args[0]) {
                            Datum::FlashObjectRef(fo) => (fo.cast_lib, fo.cast_member),
                            _ => {
                                // Fallback: get from sprite's member
                                let sprite_num = player.get_datum(datum).to_sprite_ref().unwrap_or(0);
                                if let Some(sprite) = player.movie.score.get_sprite(sprite_num) {
                                    if let Some(member_ref) = &sprite.member {
                                        (member_ref.cast_lib, member_ref.cast_member)
                                    } else { (0, 0) }
                                } else { (0, 0) }
                            }
                        };

                        // dirplayer LocalConnection: also record
                        // (lc_path, method) -> (handler, target instance) so a
                        // forwarded AS `LocalConnection.send` can dispatch the
                        // Lingo handler on the ORIGINAL instance (keeps `me`
                        // correct in `on myOnStatus me, aInfo, aMessage`). Harmless
                        // for non-LC setCallbacks — never looked up unless a
                        // matching connect()+send() arrives for that path/method.
                        let lc_target = if args.len() >= 4 {
                            match player.get_datum(&args[3]) {
                                Datum::ScriptInstanceRef(r) => Some(r.clone()),
                                _ => None,
                            }
                        } else {
                            None
                        };
                        if let Some(target_ref) = lc_target {
                            player.flash_lc_callbacks.insert(
                                (translated_path.clone(), flash_method.clone()),
                                (lingo_handler.clone().to_string(), target_ref),
                            );
                        }

                        // Call the JS bridge to register the callback in Ruffle.
                        // The export is exposed under the dirplayer_ prefix
                        // (see ruffle/web/src/lib.rs and the matching JS in
                        // src/services/flashPlayerManager.ts).
                        if let Some(window) = web_sys::window() {
                            if let Ok(func) = js_sys::Reflect::get(&window, &"dirplayer_ruffleRegisterLingoCallback".into()) {
                                if func.is_function() {
                                    let func = js_sys::Function::from(func);
                                    let js_args = js_sys::Array::new();
                                    js_args.push(&translated_path.clone().into());
                                    js_args.push(&flash_method.clone().into());
                                    js_args.push(&cast_lib.into());
                                    js_args.push(&cast_member.into());
                                    js_args.push(&lingo_handler.as_str().into());
                                    js_args.push(&flash_cl.into());
                                    js_args.push(&flash_cm.into());
                                    let _ = func.apply(&JsValue::NULL, &js_args);
                                }
                            }
                        }

                        Ok(player.alloc_datum(Datum::Int(1)))
                    })
                } else {
                    Ok(DatumRef::Void)
                }
            }
            "mapstagetomember" => {
                reserve_player_mut(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "mapStageToMember requires 1 argument (point)".to_string(),
                        ));
                    }
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let (vals, _flags) = player.get_datum(&args[0]).to_point_inline().map_err(|_| ScriptError::new(
                        "mapStageToMember requires a point argument".to_string(),
                    ))?;
                    let (stage_x, stage_y) = (vals[0] as i32, vals[1] as i32);

                    let sprite = player.movie.score.get_sprite(sprite_num);
                    if sprite.is_none() {
                        return Ok(DatumRef::Void);
                    }
                    let sprite = sprite.unwrap();

                    let rect = get_concrete_sprite_rect(player, sprite);

                    // Convert stage coords to member-local coords
                    let member = sprite.member.as_ref()
                        .and_then(|mr| player.movie.cast_manager.find_member_by_ref(mr));

                    let (member_w, member_h) = if let Some(m) = &member {
                        match &m.member_type {
                            CastMemberType::Bitmap(bm) => (bm.info.width as i32, bm.info.height as i32),
                            _ => (rect.right - rect.left, rect.bottom - rect.top),
                        }
                    } else {
                        (rect.right - rect.left, rect.bottom - rect.top)
                    };

                    let sprite_w = rect.right - rect.left;
                    let sprite_h = rect.bottom - rect.top;

                    if sprite_w == 0 || sprite_h == 0 {
                        return Ok(DatumRef::Void);
                    }

                    // Map stage point to member coordinates, accounting for scaling
                    let local_x = (stage_x - rect.left) * member_w / sprite_w;
                    let local_y = (stage_y - rect.top) * member_h / sprite_h;

                    Ok(player.alloc_datum(Datum::Point([local_x as f64, local_y as f64], 0)))
                })
            }
            // `sprite(N).findLabel(whichLabelName)` — "returns the frame
            // number (within the Flash movie) that is associated with the
            // label name requested. A 0 is returned if the label doesn't
            // exist, or if that portion of the Flash movie has not yet been
            // streamed in" (Director 11.5 Scripting Dictionary, findLabel()).
            //
            // Resolved from the member's SWF bytes, not from Ruffle: frame
            // labels are static SWF content, so this answers correctly even
            // before the Ruffle instance has loaded (and the legacy Flash
            // Player JS API exposes no label lookup to ask in the first
            // place). Movies drive whole animation state machines off this —
            // monsterattack stores `#start: findLabel("AttackT"), #end:
            // findLabel("AttackT.end")` and then steps `sprite.frame = start
            // + counter` — so returning VOID here stalls them outright.
            "findlabel" => {
                let label = reserve_player_ref(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "findLabel requires a label name".to_string(),
                        ));
                    }
                    player.get_datum(&args[0]).string_value()
                })?;
                reserve_player_mut(|player| {
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let frame = player
                        .movie
                        .score
                        .get_sprite(sprite_num)
                        .and_then(|s| s.member.as_ref())
                        .and_then(|m| player.movie.cast_manager.find_member_by_ref(m))
                        .and_then(|m| m.member_type.as_flash())
                        .map(|flash| {
                            crate::player::cast_member::CastMember::find_swf_frame_label(
                                &flash.data,
                                &label,
                            )
                        })
                        .unwrap_or(0);
                    Ok(player.alloc_datum(Datum::Int(frame as i32)))
                })
            }
            "telltarget" | "flashtostage" | "stagetoflash" => {
                warn!("Flash sprite method '{}' called but not yet implemented", handler_name);
                Ok(DatumRef::Void)
            }
            "newobject" => {
                // Flash sprite command: sprite(N).newObject(objectType {, args...})
                // Per the Director 11.5 Scripting Dictionary this "creates an
                // ActionScript object of the specified type" in the Flash movie and
                // returns a *reference* to it, for use with setCallback() / call() /
                // connect() etc (e.g. `sprite(3).newObject("LocalConnection")`).
                //
                // We return a sprite-bound FlashObjectRef with a unique synthetic
                // path — never VOID — mirroring getVariable()'s object form so the
                // chained setCallback()/connect() calls resolve. The callback bridge
                // (dirplayer_ruffleRegisterLingoCallback) and method dispatch
                // (dirplayer_ruffleCallFunction) key off this path. NOTE: extra
                // constructor args are not yet forwarded to a real AS constructor —
                // that needs a Ruffle-side newObject bridge to physically host the
                // object (e.g. so a LocalConnection can actually receive messages).
                let object_type = reserve_player_ref(|player| {
                    if args.is_empty() {
                        return Err(ScriptError::new(
                            "newObject requires at least one argument".to_string(),
                        ));
                    }
                    player.get_datum(&args[0]).string_value()
                })?;
                reserve_player_mut(|player| {
                    use crate::director::lingo::datum::FlashObjectRef;
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    let (cl, cm) = player
                        .movie
                        .score
                        .get_sprite(sprite_num)
                        .and_then(|s| s.member.as_ref())
                        .map(|m| (m.cast_lib, m.cast_member))
                        .unwrap_or((0, 0));
                    let id = super::flash_object::FLASH_OBJECT_COUNTER.with(|c| {
                        let v = c.get() + 1;
                        c.set(v);
                        v
                    });
                    // Sanitise the class name into a readable, valid AS path segment.
                    let safe: String = object_type
                        .chars()
                        .map(|ch| if ch.is_ascii_alphanumeric() { ch } else { '_' })
                        .collect();
                    let path = format!("_root.__dpObj_{}_{}", safe, id);
                    Ok(player.alloc_datum(Datum::FlashObjectRef(
                        FlashObjectRef::from_path_with_sprite(&path, cl, cm, sprite_num as i32),
                    )))
                })
            }
            "setscriptlist" => {
                // sprite.setScriptList(list)
                // list = [[memberRef, "propString"], [memberRef, "propString"], ...]
                // Creates new behavior instances from member refs and serialised
                // property lists, then replaces the sprite's script_instance_list.
                use super::script::ScriptDatumHandlers;
                use crate::player::ci_string::CiString;

                reserve_player_mut(|player| {
                    let sprite_num = player.get_datum(datum).to_sprite_ref()?;
                    if args.is_empty() {
                        return Err(ScriptError::new("setScriptList requires 1 argument".to_string()));
                    }

                    let outer = player.get_datum(&args[0]).to_list()?
                        .iter().cloned().collect::<Vec<_>>();

                    // Collect (member_ref, props_str) pairs under the borrow
                    let mut pairs: Vec<(crate::player::cast_lib::CastMemberRef, String)> = Vec::new();
                    for pair_ref in &outer {
                        let pair = player.get_datum(pair_ref).to_list()?
                            .iter().cloned().collect::<Vec<_>>();
                        if pair.len() < 2 { continue; }
                        let member_ref = match player.get_datum(&pair[0]) {
                            Datum::CastMember(r) => r.clone(),
                            _ => continue,
                        };
                        let props_str = player.get_datum(&pair[1]).string_value().unwrap_or_default();
                        pairs.push((member_ref, props_str));
                    }
                    Ok((sprite_num, pairs))
                }).and_then(|(sprite_num, pairs)| {
                    // Create instances outside the player borrow using the existing
                    // ScriptDatumHandlers::create_script_instance helper.
                    let mut new_instances: Vec<crate::player::script_ref::ScriptInstanceRef> = Vec::new();

                    for (member_ref, props_str) in &pairs {
                        match ScriptDatumHandlers::create_script_instance(member_ref) {
                            Ok((instance_ref, _datum_ref)) => {
                                // Parse the property string and set properties on the instance
                                // via script_set_prop (standard Lingo property setter).
                                let trimmed = props_str.trim();
                                let inner = if trimmed.starts_with('[') && trimmed.ends_with(']') {
                                    &trimmed[1..trimmed.len()-1]
                                } else {
                                    trimmed
                                };
                                for part in inner.split(',') {
                                    let part = part.trim();
                                    if let Some((key, val)) = part.split_once(':') {
                                        let key = key.trim().trim_start_matches('#').to_string();
                                        let val = val.trim();
                                        let datum_val = if let Ok(i) = val.parse::<i32>() {
                                            Datum::Int(i)
                                        } else if let Ok(f) = val.parse::<f64>() {
                                            Datum::Float(f)
                                        } else if val.starts_with('"') && val.ends_with('"') {
                                            Datum::String(val[1..val.len()-1].to_string())
                                        } else if val.starts_with('#') {
                                            Datum::Symbol(Symbol::from_str(&val[1..]))
                                        } else {
                                            Datum::String(val.to_string())
                                        };
                                        reserve_player_mut(|player| {
                                            let val_ref = player.alloc_datum(datum_val);
                                            let _ = crate::player::script::script_set_prop(
                                                player,
                                                &instance_ref,
                                                Symbol::from_str(&key),
                                                &val_ref,
                                                false,
                                            );
                                        });
                                    }
                                }
                                new_instances.push(instance_ref);
                            }
                            Err(e) => {
                                warn!(
                                    "[setScriptList] Failed to create instance for member({},{}): {}",
                                    member_ref.cast_lib, member_ref.cast_member, e.message
                                );
                            }
                        }
                    }

                    // Replace the sprite's behavior list
                    reserve_player_mut(|player| {
                        let sprite = player.movie.score.get_sprite_mut(sprite_num);
                        sprite.script_instance_list = new_instances;
                        player.remove_script_instance_list_cache(sprite_num);
                        player.refresh_stage_behavior_channel_cache_entry(sprite_num);
                    });

                    Ok(DatumRef::Void)
                })
            }
            _ => Err(ScriptError::new_code(
                ScriptErrorCode::HandlerNotFound,
                format!("No sync handler {handler_name} for sprite"),
            )),
        }
    }

    pub async fn call_async(
        datum: DatumRef,
        handler_name: Symbol,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        // Flash (SWF) interop: block until the sprite's Ruffle instance has
        // loaded + finished AS init, THEN run the (sync) op against a live
        // instance. A one-shot Lingo init that reads Flash objects (Coke
        // Studios' SF gateway: oLoginServlet / oStatusServlet / ...) runs before
        // the async createFlashInstance completes, so without this wait every
        // read comes back null and the gateway never connects. The wait is
        // per-sprite (see wait_for_flash_ready), so it can't stall unrelated
        // display-only Flash sprites.
        let name_lower = handler_name.to_lowercase();
        if matches!(
            name_lower.as_str(),
            "getvariable" | "setvariable" | "callfunction" | "setcallback"
        ) {
            // Reached only for a sprite NOT yet whitelisted (has_async_handler
            // routes whitelisted sprites straight to the sync path). If its
            // instance is ALREADY ready, don't pay for pre_dispatch/the wait —
            // just whitelist and fall through to the sync arm. Only a genuinely
            // not-ready sprite kicks off the dispatch + waits: a script can call
            // into a Flash sprite before the render loop has dispatched its
            // Ruffle instance (Coke Studios' one-shot `SESSION_createSession`
            // runs before sprite#1's SWF is dispatched), and without triggering
            // the dispatch here the wait would block the frame before render ever
            // dispatches it (deadlock). Whitelist so all later calls are sync.
            if let Ok(sn) =
                reserve_player_ref(|player| player.get_datum(&datum).to_sprite_ref())
            {
                let ready = is_flash_instance_ready(sn as i32)
                    .ok()
                    .and_then(|v| v.as_bool())
                    .unwrap_or(true);
                if !ready {
                    reserve_player_mut(|player| player.pre_dispatch_flash_members());
                    wait_for_flash_ready(sn).await;
                }
                reserve_player_mut(|player| {
                    player.flash_ready_sprites.insert(sn);
                });
            }
            return Self::call(&datum, handler_name.as_str(), args);
        }

        // First, try the sprite's attached script instances
        let instance_refs =
            reserve_player_ref(|player| SpriteDatumUtils::get_script_instance_ids(&datum, player))?;
        for instance_ref in instance_refs {
            let handler_ref = reserve_player_ref(|player| {
                ScriptInstanceUtils::get_script_instance_handler(
                    handler_name,
                    &instance_ref,
                    player,
                )
            })?;
            if let Some(handler_ref) = handler_ref {
                let result_scope =
                    player_call_script_handler(Some(instance_ref), handler_ref, args).await?;
                player_handle_scope_return(&result_scope);
                return Ok(result_scope.return_value);
            }
        }

        // Direct Flash method call: `sprite(N).someFn(args)` on a Flash-member
        // sprite invokes the SWF's ActionScript function of that name (Director's
        // Flash asset method surface — e.g. unicraft's `sprite(12).readUnlockLevel()`
        // / `writeUnlockLevel(n)` save system). No built-in or behaviour handled it,
        // so forward to Ruffle. Wait for the instance to be ready first (matching the
        // getVariable/callFunction path); the JS bridge also queues+replays the call
        // if it fires early, so the side effect (a callback into Lingo) still runs.
        if let Ok(Some((sn, cl, cm))) = Self::resolve_sprite_flash_member(&datum) {
            let is_flash = reserve_player_ref(|player| {
                player.movie.cast_manager
                    .find_member_by_ref(&crate::player::cast_lib::CastMemberRef { cast_lib: cl, cast_member: cm })
                    .map(|m| matches!(m.member_type, crate::player::cast_member::CastMemberType::Flash(_)))
                    .unwrap_or(false)
            });
            if is_flash {
                let ready = is_flash_instance_ready(sn).ok().and_then(|v| v.as_bool()).unwrap_or(true);
                if !ready {
                    reserve_player_mut(|player| player.pre_dispatch_flash_members());
                    wait_for_flash_ready(sn as i16).await;
                }
                reserve_player_mut(|player| { player.flash_ready_sprites.insert(sn as i16); });
                // Ruffle's argsXml is a JSON array (see flashPlayerManager callFunction).
                let json_args = reserve_player_ref(|player| {
                    let parts: Vec<String> = args.iter().map(|a| match player.get_datum(a) {
                        Datum::Int(i) => i.to_string(),
                        Datum::Float(f) => f.to_string(),
                        Datum::String(s) => format!("{:?}", s),
                        Datum::Symbol(s) => format!("{:?}", s),
                        _ => "null".to_string(),
                    }).collect();
                    format!("[{}]", parts.join(","))
                });
                match ruffle_call_function(sn, &root_flash_path(handler_name.as_str()), &json_args) {
                    Ok(val) => {
                        let datum = if let Some(s) = val.as_string() {
                            Datum::String(s)
                        } else if let Some(b) = val.as_bool() {
                            Datum::Int(if b { 1 } else { 0 })
                        } else if let Some(n) = val.as_f64() {
                            if n.fract() == 0.0 && n.abs() < i32::MAX as f64 { Datum::Int(n as i32) } else { Datum::Float(n) }
                        } else {
                            Datum::Void
                        };
                        return reserve_player_mut(|player| Ok(player.alloc_datum(datum)));
                    }
                    Err(e) => warn!("sprite direct Flash method '{}' error: {:?}", handler_name, e),
                }
                return Ok(DatumRef::Void);
            }
        }

        // In Director, calling a handler on a sprite that doesn't handle it
        // is silently ignored and returns void.
        Ok(DatumRef::Void)
    }
}
