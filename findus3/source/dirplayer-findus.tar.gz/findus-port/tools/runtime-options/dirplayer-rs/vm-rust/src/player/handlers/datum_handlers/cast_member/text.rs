use std::collections::VecDeque;

use log::{debug, warn};
use crate::{
    director::{enums::TextInfo, lingo::{datum::{
        Datum, DatumType, StringChunkExpr, StringChunkSource, StringChunkType, datum_bool
    }, decompiler::TokenType::Builtin}},
    player::{
        DatumRef, DirPlayer, ScriptError, bitmap::{
            bitmap::{Bitmap, PaletteRef, get_system_default_palette},
            drawing::CopyPixelsParams,
        }, cast_lib::CastMemberRef, font::{DrawTextParams, GlyphPreference, get_glyph_preference, get_text_index_at_pos, measure_text, measure_text_wrapped}, handlers::datum_handlers::{
            cast_member::font::{FontMemberHandlers, HtmlParser, HtmlStyle, OutlineCharStyle, StyledSpan, TextAlignment},
            cast_member_ref::borrow_member_mut, string_chunk::StringChunkUtils,
        }, symbols::{builtin::BuiltInSymbol, symbol::Symbol}
    },
};

pub struct TextMemberHandlers {}
const DEBUG_TEXT_IMAGE: bool = true;

/// Per-line vertical step in pixels for `linePosToLocV` / `locVToLinePos`.
/// Matches what `charPosToLoc` in [handlers/manager.rs] uses: explicit
/// `fixed_line_space` when set, otherwise font_size as the implicit line
/// height. Field members behave identically.
pub(crate) fn line_step_px(fixed_line_space: u16, font_size: u16) -> i32 {
    if fixed_line_space > 0 { fixed_line_space as i32 } else { font_size as i32 }
}

/// Effective line height (px) used for scroll math on a field or text member:
/// the fixed-line-space override, else the font size, else 12. Mirrors the
/// fallback the field `scrollByLine` path used before it was shared.
pub(crate) fn scroll_line_height(fixed_line_space: u16, font_size: u16) -> i32 {
    if fixed_line_space > 0 {
        fixed_line_space as i32
    } else if font_size > 0 {
        font_size as i32
    } else {
        12
    }
}

/// Count the number of VISUAL lines a text member produces, walking the SAME
/// greedy word-wrap rule the renderer and the `.image` getter use (split on
/// line breaks, then wrap on spaces at `wrap_width` using per-char advances +
/// `char_spacing`).
///
/// The `.rect`/`.height` getters previously derived the line count as
/// `measure_text_wrapped().height / (char_height - 1)`. For PFR fonts whose
/// atlas cell (`char_height` ≈ 26 for Volter-9) dwarfs the authored
/// `fixedLineSpace` (≈ 10), `measure_text_wrapped` strides by `fixedLineSpace`
/// while the divisor was `char_height - 1` — so the count came out ~2.3× too
/// SMALL, making `.rect`/`.height` report ~43% of `.image`'s height. Habbo's
/// window Text-Wrapper bakes text via
/// `pimage.copyPixels(member.image, dst = member.image.rect, src = member.rect)`,
/// so that mismatch stretched the registration ToS (Origins "Habbo Details")
/// ~2.3× vertically. Sharing this walk keeps `.rect`/`.height` == `.image`.
pub(crate) fn count_text_lines(
    text: &str,
    font: &crate::player::font::BitmapFont,
    word_wrap: bool,
    wrap_width: i32,
    char_spacing: i32,
) -> usize {
    if word_wrap && wrap_width > 0 {
        let cs = char_spacing;
        let space_w = font.get_char_advance(b' ') as i32 + cs;
        let normalised: String = text.replace("\r\n", "\n").replace('\r', "\n");
        let mut count: usize = 0;
        for raw in normalised.split('\n') {
            if raw.is_empty() {
                count += 1;
                continue;
            }
            let mut current_w: i32 = 0;
            let mut had_word = false;
            for word in raw.split(' ') {
                if word.is_empty() {
                    continue;
                }
                let word_w: i32 = word
                    .chars()
                    .map(|c| font.get_char_advance(c as u8) as i32 + cs)
                    .sum();
                let candidate = if !had_word {
                    word_w
                } else {
                    current_w + space_w + word_w
                };
                if candidate <= wrap_width || !had_word {
                    current_w = candidate;
                    had_word = true;
                } else {
                    count += 1;
                    current_w = word_w;
                }
            }
            count += 1;
        }
        count.max(1)
    } else {
        text.replace("\r\n", "\n")
            .chars()
            .filter(|c| *c == '\r' || *c == '\n')
            .count()
            + 1
    }
}

/// Read `(fixed_line_space, font_size, height_px)` from a field or text member,
/// or `None` for any other member type. `height_px` is the member's box height
/// (used to size a "page" for `scrollByPage`).
fn member_scroll_metrics(
    player: &crate::player::DirPlayer,
    member_ref: &CastMemberRef,
) -> Option<(u16, u16, i32)> {
    use crate::player::cast_member::CastMemberType;
    let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;
    match &member.member_type {
        CastMemberType::Field(f) => Some((f.fixed_line_space, f.font_size, f.height as i32)),
        CastMemberType::Text(t) => Some((t.fixed_line_space, t.font_size, t.height as i32)),
        _ => None,
    }
}

/// Shared core for `member.scrollByLine(amount)` / global `scrollByLine`
/// (Director 11.5 Scripting Dictionary): scroll a field/text member by `amount`
/// lines (positive = down, negative = up). Fractional amounts are honored
/// (Fugue No.4 nudges by ±0.1). `scrollTop` is clamped at 0; the upper bound is
/// left to callers (the MM scroll bar clamps to its own maxScroll).
pub(crate) fn scroll_member_by_lines(
    player: &mut crate::player::DirPlayer,
    member_ref: &CastMemberRef,
    amount: f64,
) {
    let (fls, fs, _h) = match member_scroll_metrics(player, member_ref) {
        Some(m) => m,
        None => return,
    };
    let line_h = scroll_line_height(fls, fs) as f64;
    let delta_px = (amount * line_h).round() as i32;
    use crate::player::cast_member::CastMemberType;
    if let Some(member) = player.movie.cast_manager.find_mut_member_by_ref(member_ref) {
        match &mut member.member_type {
            CastMemberType::Field(field) => {
                field.scroll_top = (field.scroll_top as i32 + delta_px).max(0) as u16;
            }
            CastMemberType::Text(text) => {
                if let Some(info) = text.info.as_mut() {
                    info.scroll_top = (info.scroll_top as i32 + delta_px).max(0) as u32;
                }
            }
            _ => {}
        }
    }
}

/// Shared core for `member.scrollByPage(amount)` / global `scrollByPage`
/// (Director 11.5 Scripting Dictionary): scroll by `amount` pages, where a page
/// is the number of text lines visible in the member's box. Implemented as a
/// line scroll of `amount * visibleLines`.
pub(crate) fn scroll_member_by_pages(
    player: &mut crate::player::DirPlayer,
    member_ref: &CastMemberRef,
    amount: f64,
) {
    let (fls, fs, height) = match member_scroll_metrics(player, member_ref) {
        Some(m) => m,
        None => return,
    };
    let line_h = scroll_line_height(fls, fs);
    let visible_lines = (height / line_h.max(1)).max(1);
    scroll_member_by_lines(player, member_ref, amount * visible_lines as f64);
}

/// Count the lines of a Director-style string. Director uses bare `\r` as
/// its line separator; `str::lines()` only handles `\n` and `\r\n`, so a
/// `\r`-separated text reads as a single line. We treat each `\r`, `\n`, or
/// `\r\n` as one separator and return `separator_count + 1` (minimum 1).
pub(crate) fn count_director_lines(text: &str) -> usize {
    if text.is_empty() {
        return 1;
    }
    let bytes = text.as_bytes();
    let mut lines = 1usize;
    let mut i = 0;
    while i < bytes.len() {
        let c = bytes[i];
        if c == b'\r' {
            lines += 1;
            if i + 1 < bytes.len() && bytes[i + 1] == b'\n' {
                i += 2;
                continue;
            }
        } else if c == b'\n' {
            lines += 1;
        }
        i += 1;
    }
    lines
}

/// Result of parsing a Director-style RTF document back into the
/// fields a TextMember holds. Symmetric counterpart to the data
/// `generate_rtf_from_text_member` reads when emitting RTF.
struct ParsedRtf {
    text: String,
    spans: Vec<StyledSpan>,
    par_infos: Vec<crate::director::chunks::xmedia_styled_text::ParInfo>,
    par_runs: Vec<crate::director::chunks::xmedia_styled_text::ParRun>,
    /// Member-level `top_spacing` (pt) extracted from the first
    /// `\sb<n>` value. Director's RTF stores per-paragraph `\sb`
    /// values that are uniformly the member-level top_spacing
    /// (Buggy: `\sb100` everywhere = 5pt). Hoisting it to the
    /// member level lets Lingo `member.RTF = ...` round-trip the
    /// value across distinct text members.
    member_top_spacing: Option<i16>,
    /// Member-level `bottom_spacing` (pt), companion to
    /// `member_top_spacing` from `\sa<n>`.
    member_bottom_spacing: Option<i16>,
}

impl TextMemberHandlers {
    pub fn call(
        player: &mut DirPlayer,
        datum: &DatumRef,
        handler_name: &str,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let member_ref = player.get_datum(datum).to_member_ref()?;
        let member = player
            .movie
            .cast_manager
            .find_member_by_ref(&member_ref)
            .unwrap();
        let text = member.member_type.as_text().unwrap();
        match handler_name {
            "count" => {
                let count_of = player.get_datum(&args[0]).symbol_value()?;
                if args.len() != 1 {
                    return Err(ScriptError::new("count requires 1 argument".to_string()));
                }
                let delimiter = player.movie.item_delimiter;
                let count = StringChunkUtils::resolve_chunk_count(
                    &text.text,
                    StringChunkType::from(count_of),
                    delimiter,
                )?;
                Ok(player.alloc_datum(Datum::Int(count as i32)))
            }
            "getPropRef" => {
                let prop_name = player.get_datum(&args[0]).symbol_value()?;
                let start = player.get_datum(&args[1]).int_value()?;
                let end = if args.len() > 2 {
                    player.get_datum(&args[2]).int_value()?
                } else {
                    start
                };
                let chunk_type = std::panic::catch_unwind(|| StringChunkType::from(prop_name))
                    .map_err(|_| ScriptError::new(format!("Invalid chunk type '{}' for text member getPropRef", prop_name)))?;
                let chunk_expr = StringChunkExpr {
                    chunk_type,
                    start,
                    end,
                    item_delimiter: player.movie.item_delimiter.clone(),
                };
                let resolved_str =
                    StringChunkUtils::resolve_chunk_expr_string(&text.text, &chunk_expr)?;
                Ok(player.alloc_datum(Datum::StringChunk(
                    StringChunkSource::Member(member_ref),
                    chunk_expr,
                    resolved_str,
                )))
            }
            "locToCharPos" => {
                let (pt_vals, _flags) = player.get_datum(&args[0]).to_point_inline()?;
                let x = pt_vals[0] as i32;
                let y = pt_vals[1] as i32;

                let params = DrawTextParams {
                    font: &player.font_manager.get_system_font().unwrap(),
                    line_height: None,
                    line_spacing: text.fixed_line_space,
                    top_spacing: text.top_spacing,
                    char_spacing: 0,
                    member_width: None,
                    min_space_advance: None,
                    per_char_advances: None,
                };

                let index = get_text_index_at_pos(&text.text, &params, x, y);
                Ok(player.alloc_datum(Datum::Int((index + 1) as i32)))
            }
            // `member.scrollByLine(amount)` / `member.scrollByPage(amount)` —
            // Director 11.5 Scripting Dictionary p.618/619. Shared core handles
            // both field and text members (see scroll_member_by_lines).
            "scrollByLine" => {
                let amount = player.get_datum(&args[0]).to_float()?;
                scroll_member_by_lines(player, &member_ref, amount);
                Ok(DatumRef::Void)
            }
            "scrollByPage" => {
                let amount = player.get_datum(&args[0]).to_float()?;
                scroll_member_by_pages(player, &member_ref, amount);
                Ok(DatumRef::Void)
            }
            // Director 11.5 Scripting Dictionary p.443 / p.449.
            //
            // Director returns the BASELINE Y of the line, not its top edge.
            // Hover-highlight idiom in scripts (e.g. spineworld_dcr's
            // pDropList) is `rect(..., tPosV - 9, ..., tPosV + 5)` —
            // asymmetric around tPosV (9 above, 5 below). The numbers
            // -9/+5 are tuned for a 12pt font where the baseline sits
            // ~9px from the line top (ascent ≈ 0.75 × font_size). With
            // that convention the highlight top aligns with the line's
            // top and the rect covers ~14px down, matching Director's
            // natural line height. Returning line top or line center
            // shifts the highlight off the line bucket (one line above
            // the cursor; or overlapping into the previous line's
            // click bucket).
            "linePosToLocV" => {
                let line_num = player.get_datum(&args[0]).int_value()?.max(1);
                let line_step = line_step_px(text.fixed_line_space, text.font_size);
                let baseline_offset = (line_step * 3) / 4;
                let y = text.top_spacing as i32 + (line_num - 1) * line_step + baseline_offset;
                Ok(player.alloc_datum(Datum::Int(y)))
            }
            "locVToLinePos" => {
                let loc_v = player.get_datum(&args[0]).int_value()?;
                let line_step = line_step_px(text.fixed_line_space, text.font_size).max(1);
                // Director uses bare \r as its line separator. Rust's
                // `str::lines()` only splits on \n / \r\n, so a \r-separated
                // Director text reads as one line and the line-count clamp
                // forces every locVToLinePos result back to 1 (spineworld_dcr's
                // pDropList country list selected Afghanistan no matter where
                // you clicked). Count any of \r, \n, or \r\n as a separator.
                let line_count = count_director_lines(&text.text) as i32;
                let line = ((loc_v - text.top_spacing as i32) / line_step) + 1;
                Ok(player.alloc_datum(Datum::Int(line.clamp(1, line_count))))
            }
            "setProp" => {
                // setProp(#line, index, value) or setProp(#word, index, value) etc.
                let prop_name = player.get_datum(&args[0]).symbol_value()?;
                let index = player.get_datum(&args[1]).int_value()?;
                let new_value = player.get_datum(&args[2]).string_value()?;
                let chunk_type = StringChunkType::from(prop_name);
                let chunk_expr = StringChunkExpr {
                    chunk_type,
                    start: index,
                    end: index,
                    item_delimiter: player.movie.item_delimiter,
                };
                let current_text = text.text.clone();
                let new_text = StringChunkUtils::string_by_putting_into_chunk(&current_text, &chunk_expr, &new_value)?;
                // Need mutable access - drop immutable borrows first
                let cast_member = player.movie.cast_manager.find_mut_member_by_ref(&member_ref).unwrap();
                let text_member = cast_member.member_type.as_text_mut().unwrap();
                text_member.set_text_preserving_caret(new_text.trim_end_matches('\0').to_string());
                Ok(DatumRef::Void)
            }
            // `put X into member("name")` lowers to `setContents` (and the
            // `into`/`after`/`before` variants) — see decompiler/handler.rs.
            // Field members already implement these (cast_member/field.rs);
            // text members need the same support so D6+ Text-formatted
            // members (e.g. ClubMarian's LoginName) accept the same syntax
            // without throwing "No handler setContents for text member type".
            "setContents" | "setContentsAfter" | "setContentsBefore" => {
                if args.len() != 1 {
                    return Err(ScriptError::new(format!(
                        "{handler_name} requires 1 argument"
                    )));
                }
                let new_str = player.get_datum(&args[0]).string_value()?
                    .trim_end_matches('\0')
                    .to_string();
                let cast_member = player
                    .movie
                    .cast_manager
                    .find_mut_member_by_ref(&member_ref)
                    .unwrap();
                let text_member = cast_member.member_type.as_text_mut().unwrap();
                text_member.text = match handler_name {
                    "setContents" => new_str,
                    "setContentsAfter" => format!("{}{}", text_member.text, new_str),
                    "setContentsBefore" => format!("{}{}", new_str, text_member.text),
                    _ => unreachable!(),
                };
                // Clear stale styled spans — same as the `.text` property setter
                // above. `put X into member` lowers to setContents; without this
                // the parse-time `html_styled_spans` keep their ORIGINAL text
                // (and the native renderer draws them, not the updated `.text`),
                // so a score/round display frozen at its authored value
                // (pengapop gameScore/gameRound: `put newScore into member`
                // updated `.text` to "8600" but the span still said "0", so the
                // HUD never changed). Clearing lets the next render synthesise a
                // clean default span from the member-level font/size/color and
                // the new text — matching Director resetting styling on a text
                // rewrite.
                text_member.html_styled_spans.clear();
                Ok(DatumRef::Void)
            }
            _ => Err(ScriptError::new(format!(
                "No handler {handler_name} for text member type"
            ))),
        }
    }

    pub fn get_prop(
        player: &mut DirPlayer,
        cast_member_ref: &CastMemberRef,
        prop: &str,
    ) -> Result<Datum, ScriptError> {
        let member = player
            .movie
            .cast_manager
            .find_member_by_ref(cast_member_ref)
            .unwrap();
        let text_data = member.member_type.as_text().unwrap().clone();
        // Director property names are case-insensitive
        let prop_lc = prop.to_ascii_lowercase();
        match prop_lc.as_str() {
            // See the setter: the renderer already honours info.scroll_top, so
            // report the same value back. Scrollbar code reads it while dragging.
            "scrolltop" => Ok(Datum::Int(
                text_data.info.as_ref().map(|i| i.scroll_top as i32).unwrap_or(0),
            )),
            "text" => Ok(Datum::String(text_data.text.to_owned())),
            "line" => {
                // Return a list of StringChunk references (one per
                // \r-separated line) rooted at the member, NOT a list of
                // plain strings. The chunk reference preserves the member-
                // source link so subsequent property access like
                // `member.line[N].fixedLineSpace` (or `.fontSize`,
                // `.alignment`, ...) can walk back to the member and
                // resolve per-line par_info / styled-span values via
                // script.rs's StringChunk arm. With plain strings the
                // chained access falls through to the string built-in
                // handler and fails with
                // "Invalid string built-in property fixedLineSpace".
                let item_delimiter = player.movie.item_delimiter;
                let member_ref = cast_member_ref.clone();
                let lines: Vec<String> = text_data.text.split('\r').map(|s| s.to_string()).collect();
                let line_datums: VecDeque<_> = lines
                    .into_iter()
                    .enumerate()
                    .map(|(i, l)| {
                        let chunk_expr = StringChunkExpr {
                            chunk_type: StringChunkType::Line,
                            // Lingo line indices are 1-based.
                            start: (i + 1) as i32,
                            end: (i + 1) as i32,
                            item_delimiter,
                        };
                        Datum::StringChunk(
                            StringChunkSource::Member(member_ref.clone()),
                            chunk_expr,
                            l,
                        )
                    })
                    .map(|d| player.alloc_datum(d))
                    .collect();
                Ok(Datum::List(DatumType::List, line_datums, false))
            }
            "alignment" => Ok(Datum::String(text_data.alignment.to_string())),
            "wordwrap" => Ok(datum_bool(text_data.word_wrap)),
            "width" => Ok(Datum::Int(text_data.width as i32)),
            "font" => Ok(Datum::String(text_data.font.to_owned())),
            "fontsize" => Ok(Datum::Int(text_data.font_size as i32)),
            "fontstyle" => {
                // Director surfaces `[#plain]` when no bold/italic/underline
                // is applied. We only push real styling flags into
                // `text_data.font_style`, so an empty list here means the
                // member has plain styling — return `[#plain]` to match
                // Director's getter, not an empty list.
                let mut item_refs = VecDeque::new();
                if text_data.font_style.is_empty() {
                    item_refs.push_back(
                        player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Plain))),
                    );
                } else {
                    for item in &text_data.font_style {
                        item_refs.push_back(
                            player.alloc_datum(Datum::Symbol((*item).into())),
                        );
                    }
                }
                Ok(Datum::List(DatumType::List, item_refs, false))
            }
            "fixedlinespace" => Ok(Datum::Int(text_data.fixed_line_space as i32)),
            "topspacing" => Ok(Datum::Int(text_data.top_spacing as i32)),
            "boxtype" => Ok(Datum::Symbol(text_data.box_type.into())),
            "antialias" => Ok(datum_bool(text_data.anti_alias)),
            "html" => {
                // Generate Director-style HTML from current text member state
                // Director always generates HTML from current properties, not stored HTML
                let mut html = String::new();

                // Get colors for body tag
                let bg_color = match member.bg_color {
                    crate::player::sprite::ColorRef::PaletteIndex(idx) => format!("#{:06X}", idx as u32),
                    crate::player::sprite::ColorRef::Rgb(r, g, b) => format!("#{:02X}{:02X}{:02X}", r, g, b),
                };
                let text_color = match member.color {
                    crate::player::sprite::ColorRef::PaletteIndex(idx) => format!("#{:06X}", idx as u32),
                    crate::player::sprite::ColorRef::Rgb(r, g, b) => format!("#{:02X}{:02X}{:02X}", r, g, b),
                };

                // Build body tag with color attributes (Director style uses bg= not bgcolor=)
                html.push_str(&format!(
                    "<html><body bg={} text={} link={} alink={} vlink={}>",
                    bg_color, text_color, text_color, text_color, text_color
                ));

                // Add alignment wrapper
                let alignment_start = match text_data.alignment.as_str() {
                    "center" => "<center>",
                    "right" => "<p align=right>",
                    _ => "",
                };
                let alignment_end = match text_data.alignment.as_str() {
                    "center" => "</center>",
                    "right" => "</p>",
                    _ => "",
                };
                html.push_str(alignment_start);

                // Add font tag if font is set
                if !text_data.font.is_empty() {
                    html.push_str(&format!("<font face=\"{}\">", text_data.font));
                }

                // Add text content
                html.push_str(&text_data.text);

                // Close tags
                if !text_data.font.is_empty() {
                    html.push_str("</font>");
                }
                html.push_str(alignment_end);
                html.push_str("</body></html>");

                Ok(Datum::String(html))
            }
            "rect" => {
                // Load the font IDENTICALLY to the `.image` getter
                // (`get_font_with_cast_and_bitmap`, which rasterizes the PFR atlas
                // at the requested size). `get_font_with_cast` returned a font with
                // different (wider) char advances, so `count_text_lines` wrapped to
                // ~2x more lines here than `.image` did — making `.rect` over-report
                // and the Text-Wrapper bake squish the terms text. Must match.
                let font = if !text_data.font.is_empty() {
                    player
                        .font_manager
                        .get_font_with_cast_and_bitmap(
                            &text_data.font,
                            &player.movie.cast_manager,
                            &mut player.bitmap_manager,
                            Some(text_data.font_size),
                            None,
                        )
                        .or_else(|| player.font_manager.get_system_font())
                        .unwrap()
                } else {
                    player.font_manager.get_system_font().unwrap()
                };
                let is_pfr = font.char_widths.is_some();
                // When the member will render via Canvas2D (standard font +
                // prefer_native flag) the measurement MUST come from Canvas2D
                // too — PFR wraps text at different points because browser
                // fonts are measurably wider than the PFR atlas, so a PFR
                // line-count can disagree with the Canvas2D render, leaving
                // wrapped text clipped or the bitmap over-sized.
                let requested_font_for_measure = if !text_data.font.is_empty() {
                    text_data.font.as_str()
                } else {
                    "Arial"
                };
                let measure_with_canvas = !is_pfr;
                // Pass bold/italic to Canvas2D measurement so wrap decisions
                // match the actual rendered text — bold glyphs are measurably
                // wider than regular and the member's `fontStyle` plain-vs-bold
                // flag moves the wrap point on long catalog / button labels.
                let member_style_bits: u8 = {
                    let mut s = 0u8;
                    for tag in &text_data.font_style {
                        match tag.as_str() {
                            "bold" => s |= 0x01,
                            "italic" => s |= 0x02,
                            "underline" => s |= 0x04,
                            _ => {}
                        }
                    }
                    s
                };
                let (width, measured_height) = if measure_with_canvas {
                    // Canvas2D measurement — matches the Canvas2D render path
                    // used by `.image` for non-PFR and native-standard fonts.
                    let font_size = if text_data.font_size > 0 { text_data.font_size } else { 12 };
                    FontMemberHandlers::measure_text_native_styled(
                        &text_data.text,
                        requested_font_for_measure,
                        font_size,
                        Some(member_style_bits),
                        text_data.word_wrap,
                        if text_data.width > 0 { text_data.width as i32 } else { 0 },
                        text_data.top_spacing,
                        text_data.bottom_spacing,
                        text_data.fixed_line_space,
                    )
                } else {
                    // PFR path: measure_text returns the full PFR bitmap-cell height
                    // (char_height-1), which can be ~2x the Lingo-authored font size
                    // because the rasterised PFR cell includes generous padding.
                    // Director's `.rect` returns a glyph-extent height ≈ font_size + 4
                    // (~1.4x). Use the Lingo-set text_data.font_size, NOT font.font_size
                    // (the loaded bitmap's internal size — often the rasterisation size,
                    // e.g. 20 for 10pt). CS centering formulas like
                    //   sprite.locV = locV + (btn_h/2) - (member.rect.height/2)
                    // (windows script.ls:564) depend on matching Director's value here.
                    let (w, _) = measure_text(
                        &text_data.text,
                        &font,
                        None,
                        text_data.fixed_line_space,
                        text_data.top_spacing,
                        text_data.bottom_spacing,
                    );
                    // Count lines, accounting for word-wrap when enabled. Without
                    // wrap-aware counting, HTML-set #adjust members (e.g. CS recycler
                    // help text — one paragraph wrapped to 6 lines at width 355)
                    // collapse to a single-line `line_count = 1` here and the
                    // returned rect-bottom (17) disagrees with `.height` (~85),
                    // since `.height` already calls measure_text_wrapped.
                    let wrap_width = if text_data.width > 0 {
                        text_data.width
                    } else if let Some(ref info) = text_data.info {
                        if info.width > 0 { info.width as u16 } else { 0 }
                    } else { 0 };
                    // Count visual lines with the SAME word-wrap walk the
                    // `.image` getter + renderer use (see `count_text_lines`).
                    // The old `measure_text_wrapped().height / (char_height-1)`
                    // shortcut under-counted PFR lines ~2.3x, making `.rect`
                    // disagree with `.image` and triggering Habbo's window
                    // Text-Wrapper to copyPixels-stretch the terms text.
                    let line_count = count_text_lines(
                        &text_data.text, &font, text_data.word_wrap,
                        wrap_width as i32, text_data.char_spacing,
                    );
                    let nominal = if text_data.font_size > 0 {
                        text_data.font_size
                    } else if font.font_size > 0 {
                        font.font_size
                    } else {
                        font.char_height
                    };
                    // When the member has an explicit fixed_line_space,
                    // trust it as the per-line extent — `cell_h = char_h - 1`
                    // is one pixel taller than fixed_line_space for pixel
                    // fonts, which inflates a 16-line list by 16 px.
                    // Otherwise this is Paige auto leading — see
                    // `pfr_auto_line_height`, which every other site
                    // (`.height`, `.image` measure + render) shares so the
                    // Text-Wrapper bake stays 1:1.
                    let line_h = if text_data.fixed_line_space > 0 {
                        text_data.fixed_line_space
                    } else {
                        crate::player::font::outline_auto_line_height_for_font(
                            player, &text_data.font, nominal,
                        ).unwrap_or_else(|| crate::player::font::pfr_auto_line_height(
                            &font,
                            player.bitmap_manager.get_bitmap(font.bitmap_ref),
                            nominal,
                        ))
                    };
                    // Match the renderer's per-line advance at font.rs:921 —
                    // it adds top_spacing AND bottom_spacing to the line step
                    // every iteration. The CS Hotel Navigator Writer maps
                    // `define([#fixedLineSpace: 18])` to `pMember.fixedLineSpace=10
                    // pMember.topSpacing=8`, so the renderer steps 18 px per row
                    // but a `line_step = fixed_line_space` would only allocate 10
                    // — clipping rows 7-10 of a 10-row list. Folding both
                    // spacings into line_step keeps `.height` / `.image` aligned
                    // with what the renderer actually draws.
                    let line_step = (if text_data.fixed_line_space > 0 {
                        text_data.fixed_line_space
                    } else {
                        line_h
                    }) as i32
                        + text_data.top_spacing as i32
                        + text_data.bottom_spacing as i32;
                    let h = (text_data.top_spacing as i32
                        + line_h as i32
                        + (line_count as i32 - 1) * line_step)
                        .max(0) as u16;
                    (w, h)
                };
                // Use member's explicit width/height when available (matches .image box dimensions).
                // This is important for center/right-aligned text where visible pixels
                // are offset from the left edge within the member's full width.
                let mut box_width = width;
                if text_data.width > 0 {
                    box_width = text_data.width;
                } else if let Some(ref info) = text_data.info {
                    if info.width > 0 { box_width = info.width as u16; }
                }
                // Mirror the `.height` getter: trust `text_data.height`
                // for non-#adjust members and for #adjust members whose
                // text has explicit line breaks (where the stored value is
                // the laid-out total). Also trust it for members that were
                // AUTHORED with multi-paragraph data (par_runs.len() > 1) —
                // Director keeps `member.rect`/`.height` immutable across
                // `member.text = "…"` writes, so a Junkbot level-name list
                // authored with 16 paragraphs reports 331 even after Lingo
                // overwrites the text with a single name. Without the
                // par_runs gate we re-measured the 1-line content and
                // reported `line_h ≈ fixed_line_space + 1 = 22`, clipping
                // the rendered bitmap to one line.
                // Wrap-only #adjust (single paragraph, no \n — member 82
                // recycler help, par_runs.len() ≤ 1) still falls through.
                let text_has_breaks = text_data.text.contains('\n')
                    || text_data.text.contains('\r');
                let is_multi_par_authored = text_data.par_runs.len() > 1;
                // Reserve PFR descender/underline overflow so a content-sized box
                // matches the `.image` getter (the Origins Text-Wrapper bakes with
                // `src = member.rect`, so a `.rect` shorter than `.image` would drop
                // the underline of links like `login_b_login_forgotten`).
                let measured_height = measured_height + player
                    .bitmap_manager
                    .get_bitmap(font.bitmap_ref)
                    .map_or(0, |fb| crate::player::font::pfr_underline_descender_overflow(
                        &font, fb, text_data.fixed_line_space, text_data.top_spacing,
                    ));
                let box_height = if text_data.box_type == BuiltInSymbol::Adjust {
                    if text_data.rect_set_at_runtime {
                        // #adjust + runtime-set rect: auto-grow to content but keep
                        // the set height when content fits. CS navigator toggles
                        // boxType=#adjust to capture the FULL room list (content >>
                        // set box); Origins' Text-Wrapper sizes the box to the
                        // content (set >= content, so this stays text_data.height).
                        // EXCEPTION: a NON-WRAPPING #adjust member auto-sizes its
                        // height to the content (Director), even when its canvas rect
                        // is much taller. The v7 Habbo Purse reuses one big-text
                        // writer (rect 60x480) to render "9366" (~22px); checkSaldo
                        // CENTRES member.image, so a 480-tall image shoved the digits
                        // off the top. The bake-users that rely on the set height
                        // (CS roomlist / Origins ToS / Spineworld droplist) all WRAP.
                        if !text_data.word_wrap {
                            measured_height
                        } else {
                            text_data.height.max(measured_height)
                        }
                    } else if (text_has_breaks || is_multi_par_authored)
                        && !text_data.text_set_at_runtime
                    {
                        text_data.height
                    } else {
                        measured_height
                    }
                } else if text_data.height > 0 {
                    text_data.height
                } else if let Some(ref info) = text_data.info {
                    if info.height > 0 { info.height as u16 } else { measured_height }
                } else {
                    measured_height
                };
                Ok(Datum::Rect([0.0, 0.0, box_width as f64, box_height as f64], 0))
            }
            "height" => {
                // Trust the stored `text_data.height` whenever it represents
                // a laid-out total — that's the case for:
                //   - non-#adjust members (lock-to-authored-size)
                //   - #adjust members whose text has EXPLICIT line breaks
                //     (\n / \r). Creation derives box_h from page_height
                //     (Paige's doc_bottom = laid-out total) for these, and
                //     re-measuring with our PFR metrics drifts from
                //     Director (CS Junkbot credits member 171: stored
                //     375 = Director's value, but our wrap-aware re-measure
                //     produces 483).
                // Wrap-only #adjust (single paragraph, no \n — member 82
                // recycler help) still falls through to the dynamic
                // measurement, since stored text_info.height there is the
                // single-line authored value (~85), smaller than Director's
                // laid-out 108.
                // Members authored with multi-paragraph data (par_runs.len()
                // > 1) also trust the stored value: Director keeps the
                // authored layout height immutable through `.text = …`
                // writes, so Junkbot's level-name list reports 331 even
                // when Lingo has temporarily overwritten the text with a
                // single line.
                let text_has_breaks = text_data.text.contains('\n')
                    || text_data.text.contains('\r');
                let is_multi_par_authored = text_data.par_runs.len() > 1;
                let measured: u16 = {
                    // Match the `.image` getter's font load exactly (see `.rect`).
                    let font = if !text_data.font.is_empty() {
                        player
                            .font_manager
                            .get_font_with_cast_and_bitmap(
                                &text_data.font,
                                &player.movie.cast_manager,
                                &mut player.bitmap_manager,
                                Some(text_data.font_size),
                                None,
                            )
                            .or_else(|| player.font_manager.get_system_font())
                            .unwrap()
                    } else {
                        player.font_manager.get_system_font().unwrap()
                    };
                    let is_pfr = font.char_widths.is_some();
                    let wrap_width = if text_data.width > 0 {
                        text_data.width
                    } else if let Some(ref info) = text_data.info {
                        if info.width > 0 { info.width as u16 } else { 0 }
                    } else { 0 };
                    let requested_font_for_measure = if !text_data.font.is_empty() {
                        text_data.font.as_str()
                    } else {
                        "Arial"
                    };
                    let measure_with_canvas = !is_pfr;
                    let member_style_bits: u8 = {
                        let mut s = 0u8;
                        for tag in &text_data.font_style {
                            match tag.as_str() {
                                "bold" => s |= 0x01,
                                "italic" => s |= 0x02,
                                "underline" => s |= 0x04,
                                _ => {}
                            }
                        }
                        s
                    };
                    let height = if measure_with_canvas {
                        let font_size = if text_data.font_size > 0 { text_data.font_size } else { 12 };
                        let (_, h) = FontMemberHandlers::measure_text_native_styled(
                            &text_data.text, requested_font_for_measure, font_size,
                            Some(member_style_bits),
                            text_data.word_wrap,
                            if wrap_width > 0 { wrap_width as i32 } else { 0 },
                            text_data.top_spacing, text_data.bottom_spacing, text_data.fixed_line_space,
                        );
                        h
                    } else {
                        // PFR path: mirror the `.rect` getter — `measure_text`
                        // returns the full PFR cell height (char_height-1),
                        // which over-reports by ~2x for fonts with generous
                        // cell padding (Verdana 10pt char_height=26). Director's
                        // `.height` is a glyph-extent height ≈ font_size × 1.4,
                        // so CS chat's `nameHeight = member(...).height` centring
                        // math and similar layouts match Shockwave.
                        let nominal = if text_data.font_size > 0 {
                            text_data.font_size
                        } else if font.font_size > 0 {
                            font.font_size
                        } else {
                            font.char_height
                        };
                        // Count lines with the SAME word-wrap walk `.image` uses
                        // (see `count_text_lines`). The old `wrapped_h /
                        // (char_height-1)` shortcut under-counted PFR lines ~2.3x
                        // (atlas cell ≫ fixedLineSpace), so `.height` disagreed
                        // with `.image` and Habbo's Text-Wrapper stretched the
                        // baked terms text vertically.
                        let line_count = count_text_lines(
                            &text_data.text, &font, text_data.word_wrap,
                            wrap_width as i32, text_data.char_spacing,
                        );
                        // Trust the member's fixed_line_space when set —
                        // `cell_h = char_h - 1` runs one pixel hotter than
                        // the authored stride for PFR pixel fonts (e.g.
                        // fixed_line_space=21 → cell_h=22), inflating
                        // single-line height to fixed_line_space+1.
                        // Otherwise: shared Paige auto leading (see `.rect`).
                        let line_h = if text_data.fixed_line_space > 0 {
                            text_data.fixed_line_space
                        } else {
                            crate::player::font::outline_auto_line_height_for_font(
                                player, &text_data.font, nominal,
                            ).unwrap_or_else(|| crate::player::font::pfr_auto_line_height(
                                &font,
                                player.bitmap_manager.get_bitmap(font.bitmap_ref),
                                nominal,
                            ))
                        };
                        // See `.rect` getter for rationale on folding
                        // top_spacing + bottom_spacing into line_step.
                        let line_step = (if text_data.fixed_line_space > 0 {
                            text_data.fixed_line_space
                        } else {
                            line_h
                        }) as i32
                            + text_data.top_spacing as i32
                            + text_data.bottom_spacing as i32;
                        (text_data.top_spacing as i32
                                + line_h as i32
                            + (line_count as i32 - 1) * line_step)
                            .max(0) as u16
                    };
                    // Reserve PFR descender/underline overflow so `.height` agrees
                    // with `.image`/`.rect` (the Origins Text-Wrapper bakes with
                    // src=member.rect, dropping the underline otherwise —
                    // login_b_login_forgotten).
                    let overflow = player
                        .bitmap_manager
                        .get_bitmap(font.bitmap_ref)
                        .map_or(0, |fb| crate::player::font::pfr_underline_descender_overflow(
                            &font, fb, text_data.fixed_line_space, text_data.top_spacing,
                        ));
                    height + overflow
                };
                let box_height = if text_data.box_type == BuiltInSymbol::Adjust {
                    if text_data.rect_set_at_runtime {
                        // #adjust + runtime-set rect: auto-grow to content but keep
                        // the set height when content fits (mirrors `.rect`/`.image`).
                        // Non-wrapping #adjust auto-sizes to content (see `.rect`).
                        if !text_data.word_wrap {
                            measured
                        } else {
                            text_data.height.max(measured)
                        }
                    } else if (text_has_breaks || is_multi_par_authored)
                        && !text_data.text_set_at_runtime
                    {
                        text_data.height
                    } else {
                        measured
                    }
                } else if text_data.height > 0 {
                    text_data.height
                } else {
                    measured
                };
                Ok(Datum::Int(box_height as i32))
            }
            "forecolor" | "color" => {
                // Get foreground color from cast member
                match member.color {
                    crate::player::sprite::ColorRef::PaletteIndex(idx) => Ok(Datum::Int(idx as i32)),
                    crate::player::sprite::ColorRef::Rgb(r, g, b) => {
                        // Convert RGB to a packed integer
                        let rgb = ((r as i32) << 16) | ((g as i32) << 8) | (b as i32);
                        Ok(Datum::Int(rgb))
                    }
                }
            }
            "bgcolor" | "backcolor" => {
                // Get background color from cast member
                match member.bg_color {
                    crate::player::sprite::ColorRef::PaletteIndex(idx) => Ok(Datum::Int(idx as i32)),
                    crate::player::sprite::ColorRef::Rgb(r, g, b) => {
                        // Convert RGB to a packed integer
                        let rgb = ((r as i32) << 16) | ((g as i32) << 8) | (b as i32);
                        Ok(Datum::Int(rgb))
                    }
                }
            }
            "lineheight" => {
                // Line height is typically font height + fixed line space
                Ok(Datum::Int(text_data.fixed_line_space as i32))
            }
            // TextInfo (3D text / D6+ text member) properties
            "displayface" => {
                if let Some(ref info) = text_data.info {
                    let faces = info.display_face_list();
                    let mut item_refs = VecDeque::new();
                    for face in faces {
                        item_refs.push_back(player.alloc_datum(Datum::Symbol(face.into())));
                    }
                    Ok(Datum::List(DatumType::List, item_refs, false))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "tunneldepth" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Int(info.tunnel_depth as i32))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "beveltype" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Symbol(info.bevel_type_symbol().into()))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "beveldepth" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Int(info.bevel_depth as i32))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "smoothness" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Int(info.smoothness as i32))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "displaymode" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Symbol(info.display_mode_symbol().into()))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "directionalpreset" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Symbol(info.directional_preset_symbol().into()))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "texturetype" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Symbol(info.texture_type_symbol().into()))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "reflectivity" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Float(info.reflectivity as f64))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "directionalcolor" => {
                if let Some(ref info) = text_data.info {
                    let (r, g, b) = info.directional_color_rgb();
                    let rgb = ((r as i32) << 16) | ((g as i32) << 8) | (b as i32);
                    Ok(Datum::Int(rgb))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "ambientcolor" => {
                if let Some(ref info) = text_data.info {
                    let (r, g, b) = info.ambient_color_rgb();
                    let rgb = ((r as i32) << 16) | ((g as i32) << 8) | (b as i32);
                    Ok(Datum::Int(rgb))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "specularcolor" => {
                if let Some(ref info) = text_data.info {
                    let (r, g, b) = info.specular_color_rgb();
                    let rgb = ((r as i32) << 16) | ((g as i32) << 8) | (b as i32);
                    Ok(Datum::Int(rgb))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "cameraposition" => {
                if let Some(ref info) = text_data.info {
                    // Return as a vector(x, y, z)
                    let x_ref = player.alloc_datum(Datum::Float(info.camera_position_x as f64));
                    let y_ref = player.alloc_datum(Datum::Float(info.camera_position_y as f64));
                    let z_ref = player.alloc_datum(Datum::Float(info.camera_position_z as f64));
                    Ok(Datum::List(DatumType::Vector, VecDeque::from(vec![x_ref, y_ref, z_ref]), false))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "camerarotation" => {
                if let Some(ref info) = text_data.info {
                    // Return as a vector(x, y, z)
                    let x_ref = player.alloc_datum(Datum::Float(info.camera_rotation_x as f64));
                    let y_ref = player.alloc_datum(Datum::Float(info.camera_rotation_y as f64));
                    let z_ref = player.alloc_datum(Datum::Float(info.camera_rotation_z as f64));
                    Ok(Datum::List(DatumType::Vector, VecDeque::from(vec![x_ref, y_ref, z_ref]), false))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "texturemember" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::String(info.texture_member.clone()))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "editable" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.editable))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "autotab" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.auto_tab))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "directtostage" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.direct_to_stage))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "prerender" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Symbol(info.pre_render_symbol().into()))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "savebitmap" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.save_bitmap))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "kerning" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.kerning))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "kerningthreshold" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Int(info.kerning_threshold as i32))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "usehypertextstyles" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.use_hypertext_styles))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "antialiasthreshold" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Int(info.anti_alias_threshold as i32))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "scrolltop" => {
                if let Some(ref info) = text_data.info {
                    Ok(Datum::Int(info.scroll_top as i32))
                } else {
                    Err(ScriptError::new("TextInfo not available for this member".to_string()))
                }
            }
            "centerregpoint" => {
                if let Some(ref info) = text_data.info {
                    Ok(datum_bool(info.center_reg_point))
                } else {
                    // Older/runtime-created text members may not carry D6+ TextInfo.
                    // Director still treats centerRegPoint as a boolean property; default false.
                    Ok(datum_bool(false))
                }
            }
            "image" => {
                if DEBUG_TEXT_IMAGE {
                    debug!(
                        "[text.image] member={}:{} text_len={} spans={} font='{}' size={} wrap={} align='{}'",
                        cast_member_ref.cast_lib,
                        cast_member_ref.cast_member,
                        text_data.text.len(),
                        text_data.html_styled_spans.len(),
                        text_data.font,
                        text_data.font_size,
                        text_data.word_wrap,
                        text_data.alignment
                    );
                }
                // Use the same rendering approach as sprite display
                // Get dimensions - use styled spans if available for accurate measurement
                let mut preferred_font_name: Option<String> = None;
                let mut preferred_font_size: Option<u16> = None;
                if !text_data.html_styled_spans.is_empty() {
                    let first_style = &text_data.html_styled_spans[0].style;
                    let font_size = first_style.font_size
                        .filter(|&s| s > 0)
                        .or_else(|| if text_data.font_size > 0 { Some(text_data.font_size as i32) } else { None })
                        .unwrap_or(12) as u16;
                    let font_name = if !text_data.font.is_empty() {
                        text_data.font.clone()
                    } else {
                        first_style.font_face.clone()
                            .filter(|f| !f.is_empty())
                            .unwrap_or_else(|| "Arial".to_string())
                    };
                    preferred_font_name = Some(font_name);
                    preferred_font_size = Some(font_size);
                } else {
                    if !text_data.font.is_empty() {
                        preferred_font_name = Some(text_data.font.clone());
                    }
                    if text_data.font_size > 0 {
                        preferred_font_size = Some(text_data.font_size);
                    }
                }
                if DEBUG_TEXT_IMAGE {
                    debug!(
                        "[text.image] font='{}' size={}",
                        preferred_font_name.as_deref().unwrap_or("(none)"),
                        preferred_font_size.unwrap_or(0)
                    );
                }

                // Load font to determine if it's PFR
                let font = {
                    let font_name = preferred_font_name.as_deref()
                        .or(if !text_data.font.is_empty() { Some(text_data.font.as_str()) } else { None });
                    let font_size = preferred_font_size
                        .or(if text_data.font_size > 0 { Some(text_data.font_size) } else { None });
                    let mut loaded = if let Some(name) = font_name {
                        player.font_manager.get_font_with_cast_and_bitmap(
                            name,
                            &player.movie.cast_manager,
                            &mut player.bitmap_manager,
                            font_size,
                            None,
                        )
                    } else {
                        None
                    };
                    if loaded.is_none() {
                        if let Some(name) = font_name {
                            let name_lower = name.to_lowercase();
                            for (key, font) in player.font_manager.font_cache.iter() {
                                if key.to_lowercase() == name_lower
                                    || key.to_lowercase().starts_with(&format!("{}_", name_lower))
                                {
                                    loaded = Some(font.clone());
                                    break;
                                }
                            }
                        }
                    }
                    loaded.or_else(|| player.font_manager.get_system_font())
                        .ok_or_else(|| ScriptError::new("No font available for text rendering".to_string()))?
                };
                let is_pfr_font = font.char_widths.is_some();

                // For SMOOTH PFR OUTLINE fonts (no bitmap strikes), grab the
                // parsed outlines so the renderer can compose text from sub-pixel
                // glyph outlines instead of the atlas-copy path (which quantizes
                // side bearings to 0 at small sizes — Coke Studios Verdana 10px).
                //
                // PFR carries NO "pixel font" flag (its physical-font flags are
                // only proportional / vertical / charcode width — confirmed
                // against FreeType's pfr driver), and the member's anti-alias bit
                // doesn't separate them either (Habbo authors both Volter AND
                // CS-Verdana with anti_alias=false). So we classify by glyph
                // GEOMETRY (`is_pixel_font`): pixel fonts (Volter, FFF Reaction)
                // are drawn as axis-aligned rectangles (~0% béziers, ~100% H/V
                // edges) and must render crisp via atlas-copy; smooth fonts
                // (Verdana, Arial) are curve-heavy and need sub-pixel composition.
                //
                // Cloned once (consistent with `text_data` above); .image is not
                // a per-frame call for cached members.
                let pfr_outline: Option<crate::director::chunks::pfr1::types::Pfr1ParsedFont> = if is_pfr_font {
                    let name = preferred_font_name.as_deref().unwrap_or("");
                    if name.is_empty() {
                        None
                    } else {
                        use crate::player::cast_member::CastMemberType;
                        use crate::player::font::FontManager;
                        let lc = name.to_ascii_lowercase();
                        let canon = FontManager::canonical_font_name(name);
                        let mut found = None;
                        'find_outline: for cast in &player.movie.cast_manager.casts {
                            for m in cast.members.values() {
                                if let CastMemberType::Font(fd) = &m.member_type {
                                    let matches = fd.font_info.name.to_lowercase() == lc
                                        || m.name.to_lowercase() == lc
                                        || (!canon.is_empty()
                                            && (FontManager::canonical_font_name(&fd.font_info.name) == canon
                                                || FontManager::canonical_font_name(&m.name) == canon));
                                    if matches {
                                        if let Some(p) = &fd.pfr_parsed {
                                            // Smooth outline-only fonts only.
                                            // Bitmap-strike fonts AND pixel fonts
                                            // (rectilinear, e.g. Volter) stay on
                                            // the atlas path for crisp pixels.
                                            if !p.glyphs.is_empty()
                                                && p.bitmap_glyphs.is_empty()
                                                && !p.is_pixel_font
                                            {
                                                found = Some(p.clone());
                                                break 'find_outline;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        found
                    }
                } else {
                    None
                };

                // Compute the authored box width (used as max_width for word wrap).
                // Doing this BEFORE measuring so PFR measurement can wrap correctly.
                let explicit_box_width = if text_data.width > 0 {
                    Some(text_data.width)
                } else if let Some(ref info) = text_data.info {
                    if info.width > 0 { Some(info.width as u16) } else { None }
                } else {
                    None
                };

                // Decide the measurement path. When the member will render via
                // Canvas2D (non-PFR, or standard-font with prefer_native), measure
                // with Canvas2D so `.rect` / `.height` / `.image` dimensions match
                // the actual rendered bitmap — PFR wrap points disagree with
                // Canvas2D's wider browser-font metrics and would size the bitmap
                // for the wrong line count.
                let requested_font_for_measure = preferred_font_name.as_deref()
                    .filter(|n| !n.is_empty())
                    .or(if !text_data.font.is_empty() { Some(text_data.font.as_str()) } else { None })
                    .unwrap_or("Arial");
                let measure_with_canvas = !is_pfr_font;
                let member_style_bits: u8 = {
                    let mut s = 0u8;
                    for tag in &text_data.font_style {
                        match tag.as_str() {
                            "bold" => s |= 0x01,
                            "italic" => s |= 0x02,
                            "underline" => s |= 0x04,
                            _ => {}
                        }
                    }
                    s
                };

                let (mut width, mut height) = if measure_with_canvas {
                    let font_size = preferred_font_size.unwrap_or(12);
                    FontMemberHandlers::measure_text_native_styled(
                        &text_data.text,
                        requested_font_for_measure,
                        font_size,
                        Some(member_style_bits),
                        text_data.word_wrap,
                        if text_data.width > 0 { text_data.width as i32 } else { 0 },
                        text_data.top_spacing,
                        text_data.bottom_spacing,
                        text_data.fixed_line_space,
                    )
                } else if text_data.word_wrap && explicit_box_width.map_or(false, |w| w > 0) {
                    // PFR font with word wrap: use measure_text_wrapped so the
                    // measured height accounts for wrapped lines. Pass char_spacing
                    // so measurement matches the renderer's `x += adv + char_spacing`.
                    measure_text_wrapped(
                        &text_data.text,
                        &font,
                        explicit_box_width.unwrap(),
                        true,
                        text_data.fixed_line_space,
                        text_data.top_spacing,
                        text_data.bottom_spacing,
                        text_data.char_spacing,
                    )
                } else {
                    measure_text(
                        &text_data.text,
                        &font,
                        None,
                        text_data.fixed_line_space,
                        text_data.top_spacing,
                        text_data.bottom_spacing,
                    )
                };
                let mut box_width = width;
                let mut box_height = height;
                if let Some(w) = explicit_box_width {
                    // For text members with an authored box width, keep wrapping constrained to that box.
                    box_width = w.max(1);
                }
                // PFR bitmap-font path: raw `measure_text*` reports the full PFR
                // cell height (char_height-1) which over-reports vs Director's
                // glyph-extent height (~font_size × 1.4). Recompute to match
                // the `.height` getter so CS chat's
                // `nameImage.copyPixels(nameTempImage, nameImage.rect, nameImage.rect)`
                // uses consistent bounds. Skipped when measuring with Canvas2D
                // (above branch) because that already returns the right height.
                if is_pfr_font && !measure_with_canvas {
                    let nominal = if text_data.font_size > 0 {
                        text_data.font_size
                    } else if font.font_size > 0 {
                        font.font_size
                    } else {
                        font.char_height
                    };
                    // For wrapped text, re-walk the wrap logic to count visual
                    // lines directly. The previous `height / raw_line_h` formula
                    // was wrong: `raw_line_h = font.char_height - 1` can be much
                    // larger than the actual `line_step` used by measure_text_wrapped
                    // (which honours `fixed_line_space`), so 2-line text divided by
                    // a 25-px PFR cell rounds down to 1 line. CS catalog rows that
                    // wrapped to ["Premier Studio Chair - 500", "dB"] were getting
                    // a 14-px-tall bitmap that clipped the second line.
                    let line_count = if text_data.word_wrap && explicit_box_width.map_or(false, |w| w > 0) {
                        let max_w = explicit_box_width.unwrap() as i32;
                        let cs = text_data.char_spacing;
                        let space_w =
                            font.get_char_advance(b' ') as i32 + cs;
                        let normalised: String = text_data.text
                            .replace("\r\n", "\n")
                            .replace('\r', "\n");
                        let mut count: usize = 0;
                        for raw in normalised.split('\n') {
                            if raw.is_empty() {
                                count += 1;
                                continue;
                            }
                            let mut current_w: i32 = 0;
                            let mut had_word = false;
                            for word in raw.split(' ') {
                                if word.is_empty() { continue; }
                                let word_w: i32 = word
                                    .chars()
                                    .map(|c| font.get_char_advance(c as u8) as i32 + cs)
                                    .sum();
                                let candidate = if !had_word {
                                    word_w
                                } else {
                                    current_w + space_w + word_w
                                };
                                if candidate <= max_w || !had_word {
                                    current_w = candidate;
                                    had_word = true;
                                } else {
                                    count += 1;
                                    current_w = word_w;
                                }
                            }
                            count += 1;
                        }
                        count.max(1)
                    } else {
                        text_data.text
                            .replace("\r\n", "\n")
                            .chars()
                            .filter(|c| *c == '\r' || *c == '\n')
                            .count() + 1
                    };
                    // Honor the member's explicit line height (set from the font
                    // struct's #lineHeight → fixedLineSpace) so the produced bitmap
                    // is one line tall (Volter: lineHeight 10 + topSpacing 1 = 11,
                    // matching the baked login_b_title bitmap). The bitmap is
                    // drawn 1:1. With no fixedLineSpace this is Paige auto
                    // leading — the shared helper, NOT the old font_size×1.4
                    // guess, which disagreed with the renderer's own fallback
                    // (13 here vs 25 there) and sized the box for the wrong
                    // number of lines.
                    let line_h = if text_data.fixed_line_space > 0 {
                        text_data.fixed_line_space
                    } else {
                        crate::player::font::outline_auto_line_height_for_font(
                            player, &text_data.font, nominal,
                        ).unwrap_or_else(|| crate::player::font::pfr_auto_line_height(
                            &font,
                            player.bitmap_manager.get_bitmap(font.bitmap_ref),
                            nominal,
                        ))
                    };
                    // See `.rect` getter for rationale on folding
                    // top_spacing + bottom_spacing into line_step.
                    let line_step = (if text_data.fixed_line_space > 0 {
                        text_data.fixed_line_space
                    } else {
                        line_h
                    }) as i32
                        + text_data.top_spacing as i32
                        + text_data.bottom_spacing as i32;
                    box_height = (text_data.top_spacing as i32
                        + line_h as i32
                        + (line_count as i32 - 1) * line_step)
                        .max(1) as u16;
                }
                // CRITICAL: member.image.height MUST equal member.rect.height
                // (Director invariant) — otherwise Habbo's Text-Wrapper bake
                // `pimage.copyPixels(member.image, dest=image-height, src=member.rect)`
                // stretches the text vertically (login text 2px tall, registration
                // paragraph blown up to one giant line). Use the IDENTICAL box_height
                // selection as the `.rect`/`.height` getters above.
                {
                    // `.image` must always render the FULL content (>= measured) so
                    // movies that capture it to build scroll buffers / dropdowns get
                    // every line — Director's text `.image` never clips the rendered
                    // content. This is unlike the `.rect`/`.height` getters, which
                    // REPORT a logical size (and trust text_data.height for authored
                    // multi-line members like Junkbot credits). Capturing movies:
                    // CS navigator roomlist (copyPixels member.image), Spineworld
                    // GUI_droplist (makeListImage reads txt_droplist.image).
                    // Reserve the PFR descender overflow for the auto-sized
                    // (non-wrapping #adjust) case below: the Writer forces
                    // fixedLineSpace=fontSize, but the glyph descender (and the
                    // underline drawn on it — `underline_y = y_pos + pfr_desc_bottom`)
                    // reaches BELOW that. Shrinking the box to the fixedLineSpace-based
                    // `measured` then clipped the v7 Navigator "Go" link underline.
                    // Adds 0 when fixedLineSpace already covers the descender.
                    let pfr_descender_overflow: u16 = player
                        .bitmap_manager
                        .get_bitmap(font.bitmap_ref)
                        .map_or(0, |fb| crate::player::font::pfr_underline_descender_overflow(
                            &font, fb, text_data.fixed_line_space, text_data.top_spacing,
                        ));
                    // Fold the descender/underline overflow into `measured` so every
                    // content-sized branch (and the `.rect`/`.height` getters) agree —
                    // the Origins Text-Wrapper bakes with src=member.rect, so .image
                    // and .rect must match or the underline ("login_b_login_forgotten",
                    // Navigator "Go") is dropped.
                    let measured = box_height + pfr_descender_overflow;
                    box_height = if text_data.box_type == BuiltInSymbol::Adjust {
                        if text_data.rect_set_at_runtime {
                            // CS / Origins runtime-set rect: grow to content, keep the
                            // set height when it fits (keeps .image == .rect so the
                            // Origins Text-Wrapper bake stays 1:1, no stretch).
                            // Non-wrapping #adjust auto-sizes to content (see `.rect`):
                            // the v7 Habbo Purse big-text writer's 480-tall canvas
                            // must shrink to the digits so checkSaldo's centred
                            // copyPixels keeps them on-screen.
                            if !text_data.word_wrap {
                                measured
                            } else {
                                text_data.height.max(measured)
                            }
                        } else {
                            measured
                        }
                    } else {
                        // #fixed/#scroll/#limit: still render the full content so list
                        // members overflowing a fixed box can be captured whole.
                        let mut h = measured;
                        if text_data.height > 0 { h = h.max(text_data.height); }
                        if let Some(ref info) = text_data.info {
                            if info.height > 0 { h = h.max(info.height as u16); }
                        }
                        h
                    };
                }

                // Create 32-bit bitmap with TRANSPARENT background for .image.
                // Director's text member .image produces foreColor text with alpha=255
                // on a transparent (alpha=0) background. This supports two common patterns:
                //   1. copyPixels to grayscale for alpha mask: black bg → low alpha, text → high alpha
                //   2. extractAlpha(): returns alpha channel where bg=0, text=255
                let mut bitmap = Bitmap::new(
                    box_width.max(1),
                    box_height.max(1),
                    32,
                    32,
                    8, // alpha depth
                    PaletteRef::BuiltIn(get_system_default_palette()),
                );
                bitmap.use_alpha = true;
                // Start fully transparent (RGBA = 0,0,0,0)
                bitmap.data.fill(0);

                // Determine alignment
                let text_alignment: TextAlignment = text_data.alignment.into();


                let glyph_pref = get_glyph_preference();
                // font and is_pfr_font already loaded above for measurement

                let use_native = if !text_data.tab_stops.is_empty() {
                    true // Force native rendering for tab stop support
                } else if !is_pfr_font {
                    true // Always use Canvas2D for non-PFR fonts (system/browser fonts)
                } else {
                    match glyph_pref {
                        GlyphPreference::Native => true,
                        GlyphPreference::Bitmap | GlyphPreference::Outline => false,
                        GlyphPreference::Auto => false, // PFR bitmap glyph rendering
                    }
                };

                // Set when the PFR outline compositor handled this member, so
                // the binary anti-alias threshold below is skipped — outline
                // output is already crisp anti-aliased text matching Shockwave,
                // and binarizing it would shred the thin strokes.
                let mut rendered_via_outline = false;

                if use_native && !is_pfr_font {
                    // Native Canvas2D rendering for standard fonts
                    let font_name_str = preferred_font_name.as_deref().unwrap_or("Arial");
                    let font_size_val = preferred_font_size.unwrap_or(12);
                    // Use the member's actual foreColor for .image rendering.
                    // Director renders text members with their foreColor on their bgColor.
                    let (r, g, b) = {
                        use crate::player::bitmap::bitmap::resolve_color_ref;
                        let palettes = player.movie.cast_manager.palettes();
                        resolve_color_ref(
                            &palettes,
                            &member.color,
                            &bitmap.palette_ref,
                            bitmap.original_bit_depth,
                        )
                    };
                    let default_color_u32 = ((r as u32) << 16) | ((g as u32) << 8) | (b as u32);
                    let default_bold = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Bold);
                    let default_italic = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Italic);
                    let default_underline = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Underline);

                    // Prefer the stored styled spans (set via chunk style setters
                    // or XMED parsing) over a single synthetic span. Fill in any
                    // Nones from the spans with member-level defaults so each span
                    // has a concrete font / size / color for the renderer.
                    let spans: Vec<StyledSpan> = if text_data.html_styled_spans.len() >= 2 {
                        text_data.html_styled_spans.iter().map(|sp| {
                            let mut s = sp.style.clone();
                            if s.font_face.is_none() {
                                s.font_face = Some(font_name_str.to_string());
                            }
                            if s.font_size.is_none() {
                                s.font_size = Some(font_size_val as i32);
                            }
                            if s.color.is_none() {
                                s.color = Some(default_color_u32);
                            }
                            // Member-level fontStyle defaults apply only when the
                            // span has no overrides of its own. We can't perfectly
                            // tell "no override" from "explicitly off" at this
                            // layer, but the chunk-style setters set bold/italic/
                            // underline explicitly whenever Lingo writes fontStyle,
                            // so the OR-with-defaults here just carries the member-
                            // wide `[#underline]` CS sets before per-chunk writes.
                            s.bold = s.bold || default_bold;
                            s.italic = s.italic || default_italic;
                            s.underline = s.underline || default_underline;
                            StyledSpan { text: sp.text.clone(), style: s }
                        }).collect()
                    } else {
                        let mut style = HtmlStyle::default();
                        style.font_face = Some(font_name_str.to_string());
                        style.font_size = Some(font_size_val as i32);
                        style.color = Some(default_color_u32);
                        style.bold = default_bold;
                        style.italic = default_italic;
                        style.underline = default_underline;
                        vec![StyledSpan {
                            text: text_data.text.clone(),
                            style,
                        }]
                    };
                    if let Err(e) = FontMemberHandlers::render_native_text_to_bitmap(
                        &mut bitmap,
                        &spans,
                        0,
                        text_data.top_spacing as i32,
                        box_width as i32,
                        box_height as i32,
                        text_alignment,
                        box_width as i32,
                        text_data.word_wrap,
                        None,
                        text_data.fixed_line_space,
                        text_data.top_spacing,
                        text_data.bottom_spacing,
                        &text_data.tab_stops,
                        &text_data.par_infos,
                        &text_data.par_runs,
                    ) {
                        warn!("[text.image] Native render error: {:?}", e);
                    }
                } else {
                    // Sub-pixel outline composition for OUTLINE PFR fonts —
                    // preserves side bearings at small sizes (Verdana 10px in
                    // the Coke Studios Navigator). Falls through to the
                    // atlas-copy path below when there's no outline data or the
                    // Canvas2D render errors.
                    if let Some(ref parsed) = pfr_outline {
                        let default_bold = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Bold);
                        let default_italic = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Italic);
                        let default_underline = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Underline);
                        let (dr, dg, db) = {
                            use crate::player::bitmap::bitmap::resolve_color_ref;
                            let palettes = player.movie.cast_manager.palettes();
                            resolve_color_ref(&palettes, &member.color, &bitmap.palette_ref, bitmap.original_bit_depth)
                        };
                        let default_style = OutlineCharStyle {
                            color: (dr, dg, db),
                            bold: default_bold,
                            italic: default_italic,
                            underline: default_underline,
                        };
                        // Per-char styles aligned to CRLF-normalised text (same
                        // convention the renderer uses to index `per_char`).
                        let mut per_char: Vec<OutlineCharStyle> = Vec::new();
                        if text_data.html_styled_spans.len() >= 2 {
                            let mut prev_was_cr = false;
                            for span in &text_data.html_styled_spans {
                                let col = span.style.color
                                    .map(|c| (((c >> 16) & 0xFF) as u8, ((c >> 8) & 0xFF) as u8, (c & 0xFF) as u8))
                                    .unwrap_or((dr, dg, db));
                                let entry = OutlineCharStyle {
                                    color: col,
                                    bold: span.style.bold,
                                    italic: span.style.italic,
                                    underline: span.style.underline,
                                };
                                for c in span.text.chars() {
                                    if prev_was_cr && c == '\n' { prev_was_cr = false; continue; }
                                    prev_was_cr = c == '\r';
                                    per_char.push(entry);
                                }
                            }
                        }
                        // Fall back to the MEMBER's charSpacing when there are no HTML
                        // styled spans to carry one. A plain text member set from Lingo
                        // (`member.charSpacing = -1`) has no spans at all, so defaulting
                        // to 0 silently dropped the authored tracking.
                        //
                        // AreaZero's menu styles all carry `#kerning: -1`, which
                        // `[M] Text Director` assigns as `tTextMember.charSpacing`.
                        // Losing it made every baked string 1px per character too wide:
                        // "[MEDIUM]" overflowed its 105px member (the mesh is exactly
                        // 105 wide) and lost the closing bracket, and "PLAY MORE GAMES"
                        // came out 15px wide of where Director centres it.
                        let cs_px: i32 = text_data.html_styled_spans.first()
                            .map(|s| s.style.char_spacing)
                            .unwrap_or(text_data.char_spacing);
                        let osize = preferred_font_size.unwrap_or_else(|| font.font_size.max(12));
                        match FontMemberHandlers::render_pfr_outline_text_to_bitmap(
                            &mut bitmap, parsed, osize, &text_data.text, &per_char, default_style,
                            // start_y = 0: the renderer applies `top_spacing`
                            // internally (y_top starts at top_spacing), matching
                            // the atlas-copy path. Passing it here too would
                            // double the top inset.
                            0, 0, box_width as i32, box_height as i32,
                            text_alignment, box_width as i32, text_data.word_wrap,
                            text_data.fixed_line_space, text_data.top_spacing, text_data.bottom_spacing,
                            cs_px, &text_data.tab_stops,
                        ) {
                            Ok(()) => rendered_via_outline = true,
                            Err(e) => warn!("[text.image] PFR outline render failed, atlas fallback: {:?}", e),
                        }
                    }
                    if !rendered_via_outline {
                    // Bitmap glyph rendering using PFR rasterizer font
                    let font_bitmap = player
                        .bitmap_manager
                        .get_bitmap(font.bitmap_ref)
                        .ok_or_else(|| ScriptError::new("Font bitmap not found".to_string()))?;
                    let palettes = player.movie.cast_manager.palettes();
                    let params = CopyPixelsParams {
                        blend: 100,
                        ink: 36,
                        color: member.color.clone(),
                        bg_color: crate::player::sprite::ColorRef::Rgb(255, 255, 255),
                        mask_image: None,
                        is_text_rendering: true,
                        rotation: 0.0,
                        skew: 0.0,
                        sprite: None,
                        mask_offset: (0, 0),
                        original_dst_rect: None,
                        bg_color_explicit: false,
                        fore_color_explicit: false,
                        ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                        floor_rule: false,
                    };

                    use crate::player::bitmap::bitmap::resolve_color_ref;
                    use crate::player::font::{bitmap_font_copy_char, bitmap_font_copy_char_tight};

                    let text_color = resolve_color_ref(
                        &palettes,
                        &params.color,
                        &bitmap.palette_ref,
                        bitmap.original_bit_depth,
                    );
                    let default_bold = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Bold);
                    let default_italic = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Italic);
                    let default_underline = text_data.font_style.iter().any(|s| *s == BuiltInSymbol::Underline);
                    let is_pfr_font = font.char_widths.is_some();

                    // PFR pixel-font vertical anchoring (Paige semantics). Recover
                    // the strike's cap-top / descender-bottom from the atlas so the
                    // first line's cell top anchors at lineTop and the underline lands
                    // in the descent, matching Shockwave. Shared with the on-stage
                    // `Bitmap::draw_text` path so both render identically.
                    let (pfr_cap_top, pfr_desc_bottom) =
                        crate::player::font::pfr_strike_vertical_metrics(&font, font_bitmap);

                    let max_width = box_width as i32;
                    // Anchor the first line's atlas cell top at box row 0. In Paige
                    // the line is placed by its baseline = lineTop + ascent, and the
                    // PFR atlas cell top already corresponds to (baseline - ascent) =
                    // lineTop, so the cell top maps straight onto box row 0. The
                    // natural ascent-to-cap gap (cap_top) above the capitals is kept,
                    // exactly as Shockwave renders it. (Previously this subtracted
                    // cap_top, pulling the caps onto row 0 and the whole block ~3-4px
                    // too high.) Non-PFR fonts keep the historical top_spacing.
                    let mut y = match (pfr_cap_top, pfr_desc_bottom) {
                        // Director positions baked text using BOTH the authored
                        // topSpacing (extra space above the line) AND the
                        // fixedLineSpace leading distributed above the glyph:
                        //   - The v7 Navigator ROOM ROWS go through Habbo's Writer
                        //     Class, which FORCES `fixedLineSpace = fontSize` (9) and
                        //     puts the real line height into `topSpacing`
                        //     (= fixedLineSpace(18) - fontSize(9) = 9). Their offset
                        //     therefore lives in topSpacing, not fixedLineSpace.
                        //   - The TITLE is a non-Writer member that keeps
                        //     fixedLineSpace=15 over a ~11px glyph, so its offset is
                        //     fixedLineSpace leading (descender sits at line bottom).
                        // Volter strikes' taller atlas cell masked both; the scaling
                        // outline exposed them, baking text ~7px too high (the
                        // window-element bitmap PLACEMENT is correct). For tight
                        // lines both terms are ~0, so the registration ToS / headings
                        // are unchanged. No member has both terms large, so summing
                        // does not double-count.
                        //
                        // The topSpacing term carries a -1: the glyph descender (db)
                        // already overruns the Writer-forced `fixedLineSpace=fontSize`
                        // by ~1px, so applying the raw topSpacing dropped the room rows
                        // 1px below Shockwave. Calibrated against the v7 Navigator room
                        // list (topSpacing=9 -> 8px effective).
                        (Some(_), Some(db)) if text_data.fixed_line_space > 0 => {
                            (text_data.fixed_line_space as i32 - 1 - db).max(0)
                                + (text_data.top_spacing as i32 - 1).max(0)
                        }
                        (Some(_), _) => text_data.top_spacing as i32,
                        (None, _) => text_data.top_spacing as i32,
                    };
                    // Underline row sits just below the line's baseline, and this
                    // is also the per-line advance below. Use the member's explicit
                    // line height (fixedLineSpace) when set so the underline lands
                    // inside the bitmap (Volter login link text is 11px tall);
                    // otherwise Paige auto leading via the shared helper. The raw
                    // atlas cell (char_height-1, ~25 for Volter-9) is NOT a line
                    // height — it put 25 px between Habbo v31's 9 px catalogue
                    // lines and sized the box for a different line count than the
                    // measure pass above.
                    let line_height = if text_data.fixed_line_space > 0 {
                        (text_data.fixed_line_space as i32).max(1)
                    } else {
                        let nominal = if text_data.font_size > 0 {
                            text_data.font_size
                        } else if font.font_size > 0 {
                            font.font_size
                        } else {
                            font.char_height
                        };
                        // Same rule as the measure pass above, so the atlas path
                        // can't drift from the box it was given.
                        (crate::player::font::outline_auto_line_height_for_font(
                            player, &text_data.font, nominal,
                        ).unwrap_or_else(|| crate::player::font::pfr_auto_line_height(
                            &font, Some(font_bitmap), nominal,
                        )) as i32).max(1)
                    };

                    // Get char_spacing from styled spans (XMED data)
                    let char_spacing: i32 = text_data.html_styled_spans.first()
                        .map(|s| s.style.char_spacing)
                        .unwrap_or(0);

                    // Build a per-character style map. Indexed by character
                    // position in `text_data.text`, each entry gives the style
                    // overrides for that character. Coke Studios applies
                    // per-line / per-item colour + bold/underline via chunk
                    // setters, and relies on this bitmap render path honouring
                    // them. When no styled spans are present every char gets
                    // the member-level defaults.
                    #[derive(Clone, Copy)]
                    struct PerCharStyle {
                        bold: bool,
                        italic: bool,
                        underline: bool,
                        color: (u8, u8, u8),
                    }
                    let default_per_char = PerCharStyle {
                        bold: default_bold,
                        italic: default_italic,
                        underline: default_underline,
                        color: text_color,
                    };
                    let mut per_char: Vec<PerCharStyle> = Vec::new();
                    if text_data.html_styled_spans.len() >= 2 {
                        // Build per-char with the SAME normalisation the renderer
                        // applies (CRLF → LF, lone CR → LF). The renderer iterates
                        // normalised lines and indexes per_char by
                        // `line_char_offset + ch_idx`, where line_char_offset
                        // assumes single-char line breaks. If we kept the raw
                        // `\r\n` here, per_char would be one entry longer per
                        // CRLF and styles would shift backwards on every CRLF
                        // — Coke Studios' roomlist (Windows-saved with `\r\n`)
                        // bleeds audition row's bold/blue down by N lines.
                        let mut prev_was_cr = false;
                        for span in &text_data.html_styled_spans {
                            let col = if let Some(c) = span.style.color {
                                (((c >> 16) & 0xFF) as u8,
                                 ((c >> 8) & 0xFF) as u8,
                                 (c & 0xFF) as u8)
                            } else {
                                text_color
                            };
                            // Spans set via chunk-style setters are authoritative
                            // for that range: don't OR with member defaults, or
                            // `[#plain]` wouldn't be able to strip underline from
                            // a member that has underline as its default style.
                            let style_entry = PerCharStyle {
                                bold: span.style.bold,
                                italic: span.style.italic,
                                underline: span.style.underline,
                                color: col,
                            };
                            for c in span.text.chars() {
                                if prev_was_cr && c == '\n' {
                                    // Drop \n that follows \r — the \r already
                                    // contributed an entry that the renderer
                                    // treats as the single break.
                                    prev_was_cr = false;
                                    continue;
                                }
                                prev_was_cr = c == '\r';
                                per_char.push(style_entry);
                            }
                        }
                    }

                    // Capture tab stops for the closure (line_char_offset usage below
                    // also needs them, but the closure can't borrow text_data through
                    // reserve_player_mut). Clone to a small Vec.
                    let line_tab_stops: Vec<(BuiltInSymbol, i32)> = text_data
                        .tab_stops
                        .iter()
                        .map(|t| (t.tab_type.clone(), t.position as i32))
                        .collect();

                    let mut flush_line = |line: &str, line_char_offset: usize, y_pos: i32, bitmap: &mut Bitmap| {
                        // Helper: width of a substring (character advances).
                        let segment_width = |s: &str| -> i32 {
                            s.chars()
                                .map(|c| font.get_char_advance(c as u8) as i32 + char_spacing)
                                .sum::<i32>()
                        };

                        // Split the line into tab-delimited segments. Each segment
                        // starts at a tab-stop position (or 0 for the first one).
                        // Director tab-stop semantics applied here:
                        //   - #left:    next segment renders starting at the stop
                        //   - #right:   next segment renders ending at the stop
                        //   - #center:  next segment centred on the stop
                        //   - #decimal: treated as #right for now (CS doesn't use it)
                        // Without tab stops we fall back to advance-as-glyph (TAB
                        // glyphs in PFR atlases are usually zero-width).
                        let segments: Vec<&str> = line.split('\t').collect();
                        let mut segment_starts: Vec<i32> = Vec::with_capacity(segments.len());

                        // Compute the line's logical width for alignment when there
                        // are no tabs OR when tabs leave the line left-anchored.
                        let logical_line_width: i32 = if segments.len() == 1 {
                            segment_width(line)
                        } else {
                            let mut acc = 0i32;
                            for (i, seg) in segments.iter().enumerate() {
                                let seg_w = segment_width(seg);
                                if i == 0 {
                                    acc = seg_w;
                                } else if let Some((tab_type, tab_pos)) = line_tab_stops.get(i - 1) {
                                    acc = match tab_type.as_str() {
                                        "right" => *tab_pos,
                                        "center" => (*tab_pos + seg_w / 2).max(acc),
                                        _ => (*tab_pos + seg_w).max(acc + seg_w),
                                    };
                                } else {
                                    acc += seg_w;
                                }
                            }
                            acc
                        };

                        // Apply line-level alignment offset (only meaningful when no
                        // right-type tabs anchor the right edge — tabs already
                        // place segments at fixed positions).
                        let has_right_tab = line_tab_stops
                            .iter()
                            .any(|(t, _)| *t == BuiltInSymbol::Right);
                        let line_offset = if has_right_tab {
                            0
                        } else {
                            match text_alignment {
                                TextAlignment::Center => ((max_width - logical_line_width) / 2).max(0),
                                TextAlignment::Right => (max_width - logical_line_width).max(0),
                                _ => 0,
                            }
                        };

                        // First segment always starts at line_offset (no preceding tab).
                        segment_starts.push(line_offset);
                        let mut cursor_x = line_offset + segment_width(segments[0]);
                        for i in 1..segments.len() {
                            let seg_w = segment_width(segments[i]);
                            let stop_x = match line_tab_stops.get(i - 1) {
                                Some((tab_type, tab_pos)) => match tab_type {
                                    BuiltInSymbol::Right => (*tab_pos - seg_w).max(cursor_x),
                                    BuiltInSymbol::Center => (*tab_pos - seg_w / 2).max(cursor_x),
                                    _ => (*tab_pos).max(cursor_x), // #left / #decimal
                                },
                                None => cursor_x, // no more tab stops — render inline
                            };
                            segment_starts.push(stop_x);
                            cursor_x = stop_x + seg_w;
                        }

                        // Walk the line again to draw, skipping `\t` chars and using
                        // the precomputed segment starts.
                        let mut current_segment = 0usize;
                        let mut x = segment_starts[0];
                        for (ch_idx, ch) in line.chars().enumerate() {
                            if ch == '\t' {
                                current_segment += 1;
                                if let Some(&sx) = segment_starts.get(current_segment) {
                                    x = sx;
                                }
                                continue;
                            }
                            let adv = font.get_char_advance_for(ch) as i32;
                            let per = per_char
                                .get(line_char_offset + ch_idx)
                                .copied()
                                .unwrap_or(default_per_char);
                            // Use tight copy for PFR fonts when cell width is much larger
                            // than character advance, to prevent transparent cell areas from
                            // overlapping and erasing adjacent characters.
                            let use_tight = is_pfr_font && (font.char_width as i32) > (adv * 2).max(16);
                            let ch_params = CopyPixelsParams {
                                blend: params.blend,
                                ink: params.ink,
                                color: crate::player::sprite::ColorRef::Rgb(per.color.0, per.color.1, per.color.2),
                                bg_color: params.bg_color.clone(),
                                mask_image: None,
                                is_text_rendering: params.is_text_rendering,
                                rotation: params.rotation,
                                skew: params.skew,
                                sprite: None,
                                mask_offset: params.mask_offset,
                                original_dst_rect: params.original_dst_rect.clone(),
                                bg_color_explicit: false,
                                fore_color_explicit: false,
                                ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                                floor_rule: false,
                            };
                            if use_tight {
                                bitmap_font_copy_char_tight(
                                    &font, font_bitmap, crate::io::encoding::glyph_byte_for(ch), bitmap,
                                    x, y_pos, &palettes, &ch_params,
                                );
                            } else {
                                bitmap_font_copy_char(
                                    &font, font_bitmap, crate::io::encoding::glyph_byte_for(ch), bitmap,
                                    x, y_pos, &palettes, &ch_params,
                                );
                            }
                            if per.bold {
                                if use_tight {
                                    bitmap_font_copy_char_tight(
                                        &font, font_bitmap, crate::io::encoding::glyph_byte_for(ch), bitmap,
                                        x + 1, y_pos, &palettes, &ch_params,
                                    );
                                } else {
                                    bitmap_font_copy_char(
                                        &font, font_bitmap, crate::io::encoding::glyph_byte_for(ch), bitmap,
                                        x + 1, y_pos, &palettes, &ch_params,
                                    );
                                }
                            }
                            if per.underline {
                                // Per-character underline so per-span underline
                                // is honoured (CS uses underline on some items
                                // only). Draw one pixel row under this glyph.
                                // Paige draws the underline in the descent. For
                                // PFR strikes put it on the descender's lowest row
                                // (scanned), so it sits just under the text instead
                                // of at the oversized atlas cell bottom.
                                let underline_y = match pfr_desc_bottom {
                                    Some(db) => y_pos + db,
                                    None => y_pos + line_height - 1,
                                };
                                let run_end = (x + adv + char_spacing).max(x);
                                for ux in x..run_end {
                                    bitmap.set_pixel(ux, underline_y, per.color, &palettes);
                                }
                            }
                            x += adv + char_spacing;
                        }
                    };

                    // Normalise CRLF / lone CR to \n first so a `\r\n` pair counts
                    // as ONE line break — splitting on either char individually
                    // would double the line count for Lingo strings produced via
                    // `& RETURN` on platforms where RETURN is `\r\n`. Coke
                    // Studios' roomlist hits exactly this: every row of
                    // "London I\tGo!\r\n..." was rendering with an empty line
                    // between, doubling the visual line spacing.
                    let normalised_text: String = text_data.text
                        .replace("\r\n", "\n")
                        .replace('\r', "\n");
                    let raw_lines: Vec<&str> = normalised_text.split('\n').collect();
                    let mut lines_to_draw: Vec<String> = Vec::new();

                    if text_data.word_wrap && max_width > 0 {
                        for raw in raw_lines {
                            if raw.is_empty() {
                                lines_to_draw.push(String::new());
                                continue;
                            }
                            // Wrap on space-separated words but preserve TAB
                            // characters. Splitting via split_whitespace() and
                            // re-joining with " " would silently strip tabs and
                            // break tab-stop layouts (CS roomlist relies on a
                            // right-tab to anchor "Go!" at the row's right
                            // edge — tab-stripped lines collapsed everything
                            // back to the left).
                            let mut current = String::new();
                            for word in raw.split(' ') {
                                if word.is_empty() {
                                    // Multiple spaces in a row — preserve them
                                    if !current.is_empty() {
                                        current.push(' ');
                                    }
                                    continue;
                                }
                                let candidate = if current.is_empty() {
                                    word.to_string()
                                } else {
                                    format!("{} {}", current, word)
                                };
                                let candidate_width: i32 = candidate
                                    .chars()
                                    .map(|c| font.get_char_advance(c as u8) as i32 + char_spacing)
                                    .sum();
                                if candidate_width <= max_width || current.is_empty() {
                                    current = candidate;
                                } else {
                                    lines_to_draw.push(current);
                                    current = word.to_string();
                                }
                            }
                            if !current.is_empty() {
                                lines_to_draw.push(current);
                            }
                        }
                    } else {
                        lines_to_draw = raw_lines.iter().map(|s| s.to_string()).collect();
                    }

                    let effective_line_height = if text_data.fixed_line_space > 0 {
                        text_data.fixed_line_space as i32
                    } else {
                        line_height
                    };
                    let line_step = effective_line_height
                        + text_data.bottom_spacing as i32
                        + text_data.top_spacing as i32;
                    // Track the character offset into `text_data.text` so
                    // per-span styling aligns with the chars being drawn.
                    // Word-wrap rebuilds lines from whitespace-split tokens so
                    // the offset tracking is approximate there; for the
                    // non-wrap case (which is what CS uses for the roomlist)
                    // it's exact.
                    let mut char_offset = 0usize;
                    for line in lines_to_draw {
                        flush_line(&line, char_offset, y, &mut bitmap);
                        y += line_step;
                        char_offset += line.chars().count() + 1; // +1 for the line break
                    }
                    } // end !rendered_via_outline (atlas-copy fallback)

                } // end bitmap glyph else branch

                // Honour `member.antialias = 0` by thresholding the bitmap's
                // alpha channel to binary (0 or 255). Director with antialias
                // disabled produces crisp 1-bit text; coverage-as-alpha (what
                // Canvas2D and the PFR rasterizer both emit) shows up as a
                // faded grey halo around the strokes when later composited
                // via `[#ink: 36]`. The Coke Studios jukebox catalog disables
                // AA explicitly (see cataloglist script line 85) and expects
                // sharp text — without the threshold the catalog list looks
                // washed out compared to Shockwave.
                if !text_data.anti_alias && bitmap.bit_depth == 32 && !rendered_via_outline {
                    // Director with `anti_alias=false` rasterises text as 1-bit
                    // — no coverage to threshold. Our pipeline renders via
                    // Canvas2D (always AA) and then thresholds the alpha to
                    // simulate the 1-bit effect. The file's
                    // `anti_alias_threshold` is often 0 for these members
                    // (spineworld_dcr txt_droplist authored at 0); honouring
                    // that value lets every halo pixel through and produces a
                    // thick / double-struck appearance. Floor at 128 — the
                    // midpoint of the coverage scale, which empirically
                    // matches Director's crispness for non-AA text (Coke
                    // Studios jukebox catalog and others).
                    let threshold = text_data.info.as_ref()
                        .map(|i| i.anti_alias_threshold as u8)
                        .unwrap_or(128)
                        .max(128);
                    for i in (3..bitmap.data.len()).step_by(4) {
                        bitmap.data[i] = if bitmap.data[i] >= threshold { 255 } else { 0 };
                    }
                }

                // Text `.image` snapshots are produced per-call and not owned
                // by any cast member; let the DatumRef refcount free them.
                let bitmap_ref = player.bitmap_manager.add_ephemeral_bitmap(bitmap);
                Ok(Datum::BitmapRef(bitmap_ref))
            }
            "rtf" => {
                // Return stored RTF source, or generate minimal RTF from plain text
                if !text_data.rtf_source.is_empty() {
                    Ok(Datum::String(text_data.rtf_source.clone()))
                } else {
                    // Build a Director-style RTF string from the text member's
                    // styled spans (XMED `html_styled_spans`). Round-tripping
                    // through `member.rtf = member("X").rtf` then needs to
                    // preserve color/bold/italic/font/size — without per-span
                    // styling the destination's labels render as plain text
                    // and the visual loses the gray "Terrain:"/"Speed:"/etc
                    // labels Director emits via `\cf<n>` color runs.
                    Ok(Datum::String(Self::generate_rtf_from_text_member(&text_data)))
                }
            }
            "state" => Ok(Datum::Int(4)), // 4 = loaded (all embedded members are fully loaded)
            // Chunk count shortcuts — computed from text string.
            // StringChunkUtils::resolve_chunk_count handles delimiter semantics.
            "charcount" => {
                let delimiter = player.movie.item_delimiter;
                let count = StringChunkUtils::resolve_chunk_count(
                    &text_data.text, StringChunkType::Char, delimiter,
                )?;
                Ok(Datum::Int(count as i32))
            }
            "wordcount" => {
                let delimiter = player.movie.item_delimiter;
                let count = StringChunkUtils::resolve_chunk_count(
                    &text_data.text, StringChunkType::Word, delimiter,
                )?;
                Ok(Datum::Int(count as i32))
            }
            "linecount" => {
                let delimiter = player.movie.item_delimiter;
                let count = StringChunkUtils::resolve_chunk_count(
                    &text_data.text, StringChunkType::Line, delimiter,
                )?;
                Ok(Datum::Int(count as i32))
            }
            "paragraphcount" => {
                // Director treats paragraphs as \r-delimited, same as lines.
                let delimiter = player.movie.item_delimiter;
                let count = StringChunkUtils::resolve_chunk_count(
                    &text_data.text, StringChunkType::Line, delimiter,
                )?;
                Ok(Datum::Int(count as i32))
            }
            // Runtime selection state
            "selstart" => Ok(Datum::Int(text_data.sel_start)),
            "selend" => Ok(Datum::Int(text_data.sel_end)),
            // Director 11.5 Scripting Dictionary p.1164. Returns a two-element
            // linear list `[start, end]` so scripts can test for an active
            // selection via `selection[1] <> selection[2]`.
            "selection" => {
                let start = player.alloc_datum(Datum::Int(text_data.sel_start));
                let end = player.alloc_datum(Datum::Int(text_data.sel_end));
                Ok(Datum::List(DatumType::List, VecDeque::from(vec![start, end]), false))
            }
            "selectedtext" => {
                let len = text_data.text.len() as i32;
                let lo = text_data.sel_start.min(text_data.sel_end).clamp(0, len);
                let hi = text_data.sel_start.max(text_data.sel_end).clamp(0, len);
                Ok(Datum::String(text_data.text[lo as usize..hi as usize].to_string()))
            }
            // Previously-unstaged stored properties
            "bottomspacing" => Ok(Datum::Int(text_data.bottom_spacing as i32)),
            "charspacing" => Ok(Datum::Int(text_data.char_spacing)),
            "antialiastype" => Ok(Datum::Symbol(text_data.anti_alias_type.into())),
            "tabcount" => Ok(Datum::Int(text_data.tab_stops.len() as i32)),
            "tabs" => {
                let mut items: VecDeque<DatumRef> = VecDeque::new();
                for t in &text_data.tab_stops {
                    let type_key = player.alloc_datum(Datum::Symbol(BuiltInSymbol::Type.into()));
                    let type_val = player.alloc_datum(Datum::Symbol(t.tab_type.into()));
                    let pos_key = player.alloc_datum(Datum::Symbol(BuiltInSymbol::Position.into()));
                    let pos_val = player.alloc_datum(Datum::Int(t.position));
                    let entries: VecDeque<(DatumRef, DatumRef)> = VecDeque::from([
                        (type_key, type_val),
                        (pos_key, pos_val),
                    ]);
                    items.push_back(player.alloc_datum(Datum::PropList(entries, false)));
                }
                Ok(Datum::List(DatumType::List, items, false))
            }
            // `member.hyperlinks` — Director returns a linear list of
            // [startChar, endChar] ranges, one per hyperlink (Director 11.5
            // Scripting Dictionary). Parsed from XMED Section 0x0129 into
            // 1-based inclusive pairs; empty for members with no links. Used by
            // the `customHyperlink` behavior (help_menu navigation).
            "hyperlinks" => {
                let items: VecDeque<DatumRef> = text_data.hyperlinks
                    .iter()
                    .map(|(start, end)| {
                        let s = player.alloc_datum(Datum::Int(*start));
                        let e = player.alloc_datum(Datum::Int(*end));
                        player.alloc_datum(Datum::List(
                            DatumType::List,
                            VecDeque::from(vec![s, e]),
                            false,
                        ))
                    })
                    .collect();
                Ok(Datum::List(DatumType::List, items, false))
            }
            _ => Err(ScriptError::new(format!(
                "Cannot get castMember property {} for text",
                prop
            ))),
        }
    }

    pub fn set_prop(
        member_ref: &CastMemberRef,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        // Director property names are case-insensitive
        let prop_lc = prop.to_ascii_lowercase();
        match prop_lc.as_str() {
            // `scrollTop` — Director 11.5: the distance in pixels from the top of a
            // scrolling text/field member to the top of its visible area. Fields
            // already supported it; text members did not, even though the renderer
            // ALREADY offsets the draw origin by `text_member.info.scroll_top`. Only
            // the accessor was missing, so dkbarrel's help panel
            // (`Generic Help Dialog box` sets `member(...).scrollTop`) never moved.
            "scrolltop" => borrow_member_mut(
                member_ref,
                |_player| value.int_value(),
                |cast_member, v| -> Result<(), ScriptError> {
                    let v = v?;
                    if let Some(text_member) = cast_member.member_type.as_text_mut() {
                        if let Some(info) = text_member.info.as_mut() {
                            info.scroll_top = v.max(0) as u32;
                        }
                    }
                    Ok(())
                },
            ),
            "text" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    let new_text = value?.trim_end_matches('\0').to_string();

                    let old_color = text_member.html_styled_spans.first()
                        .and_then(|s| s.style.color)
                        .map(|c| format!("#{:06X}", c & 0xFFFFFF))
                        .unwrap_or_else(|| "none".to_string());
                    debug!(
                        "[text_setter] member='{}' old_color={} spans={} new_text='{}'",
                        cast_member.name, old_color,
                        text_member.html_styled_spans.len(),
                        new_text.chars().take(30).collect::<String>(),
                    );


                    // Update the plain text + caret state in one go.
                    text_member.set_text_preserving_caret(new_text.clone());
                    // The authored box no longer describes this content — an
                    // #adjust member must re-measure from here on (see
                    // `text_set_at_runtime`).
                    text_member.text_set_at_runtime = true;

                    // Clear html_styled_spans on .text assignment. Inheriting the
                    // first existing span's style carried colour/bold from prior
                    // chunk-style writes into the fresh text, so Coke Studios'
                    // `listmember.text = listmember.text & roomname & ...` loop
                    // ended up with every roomlist line tinted the audition blue
                    // (or bold) from the last render. Clearing lets the next
                    // render synthesise a clean default span, and any chunk-style
                    // setter will seed from member-level defaults — matching
                    // Director's behaviour where rewriting `.text` resets styling.
                    text_member.html_styled_spans.clear();

                    Ok(())
                },
            ),
            "alignment" => borrow_member_mut(
                member_ref,
                |player| value.symbol_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().alignment = value?.into_builtin_or_error()?;
                    Ok(())
                },
            ),
            "wordwrap" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().word_wrap = value?;
                    Ok(())
                },
            ),
            "width" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().width = value? as u16;
                    Ok(())
                },
            ),
            "font" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let font_name = value?;
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    text_member.font = font_name.clone();
                    for span in &mut text_member.html_styled_spans {
                        span.style.font_face = Some(font_name.clone());
                    }
                    Ok(())
                },
            ),
            "fontsize" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let size = value? as u16;
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    text_member.font_size = size;
                    for span in &mut text_member.html_styled_spans {
                        span.style.font_size = Some(size as i32);
                    }
                    Ok(())
                },
            ),
            "fontstyle" => borrow_member_mut(
                member_ref,
                |player| {
                    // Lingo accepts fontStyle as a list of symbols
                    // (`[#plain, #bold]`), a single symbol (`#plain`), or a
                    // bare string (`"plain"`). The previous unwrap() on
                    // `to_list()` panicked for the latter two — Coke Studios'
                    // InfoStandObject does `oDescMember.fontStyle = "plain"`
                    // which caused the displayDescription handler to abort
                    // mid-flow and the description sprite never finished
                    // wiring up.
                    let mut item_strings = Vec::new();
                    match value {
                        Datum::List(_, items, _) => {
                            for x in items {
                                item_strings.push(player.get_datum(&x).symbol_value()?);
                            }
                        }
                        _ => {
                            // Best-effort: try symbol conversion, otherwise empty.
                            if let Ok(s) = value.symbol_value() {
                                if !s.is_empty() {
                                    item_strings.push(s);
                                }
                            }
                        }
                    }
                    Ok(item_strings)
                },
                |cast_member, value| {
                    let styles = value?;
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    let bold = styles.iter().any(|s| s.eq_builtin(BuiltInSymbol::Bold));
                    let italic = styles.iter().any(|s| s.eq_builtin(BuiltInSymbol::Italic));
                    let underline = styles.iter().any(|s| s.eq_builtin(BuiltInSymbol::Underline));
                    text_member.font_style = styles.iter().map(|s| s.into_builtin_or_error()).collect::<Result<_, _>>()?;
                    for span in &mut text_member.html_styled_spans {
                        span.style.bold = bold;
                        span.style.italic = italic;
                        span.style.underline = underline;
                    }
                    Ok(())
                },
            ),
            "fixedlinespace" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    cast_member
                        .member_type
                        .as_text_mut()
                        .unwrap()
                        .fixed_line_space = value? as u16;
                    Ok(())
                },
            ),
            "topspacing" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().top_spacing = value? as i16;
                    Ok(())
                },
            ),
            "boxtype" => borrow_member_mut(
                member_ref,
                |player| value.symbol_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().box_type = value?.into_builtin_or_error()?;
                    Ok(())
                },
            ),
            "antialias" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().anti_alias = value?;
                    Ok(())
                },
            ),
            "html" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let html_string = value?;
                    let spans = HtmlParser::parse_html(&html_string).map_err(|e| {
                        ScriptError::new(format!("Failed to parse HTML: {}", e))
                    })?;
                    let text_member = cast_member.member_type.as_text_mut().unwrap();

                    let old_color = text_member.html_styled_spans.first()
                        .and_then(|s| s.style.color)
                        .map(|c| format!("#{:06X}", c & 0xFFFFFF))
                        .unwrap_or_else(|| "none".to_string());
                    let new_color = spans.first()
                        .and_then(|s| s.style.color)
                        .map(|c| format!("#{:06X}", c & 0xFFFFFF))
                        .unwrap_or_else(|| "none".to_string());
                    debug!(
                        "[html_setter] member='{}' old_color={} new_color={} new_spans={} html='{}'",
                        cast_member.name, old_color, new_color, spans.len(),
                        html_string.chars().take(80).collect::<String>(),
                    );

                    // Store original HTML source
                    text_member.html_source = html_string.clone();

                    // Extract plain text from all spans
                    text_member.set_text_preserving_caret(spans.iter().map(|s| s.text.clone()).collect());

                    // Ensure the HTML-derived text ends with a paragraph
                    // terminator. Director appends a trailing `\r` to
                    // member.text when text is set via `member.html = ...`
                    // even when the HTML lacks an explicit `<br>` — it's
                    // the implicit close of the surrounding `<body>` /
                    // `<p>` block. Without this, FurniFactory alertbox_text
                    // (member 30) reports `length(member.text) = 138`
                    // where Director reports 139, and `measure_text_wrapped`
                    // sees 5 visual lines instead of Director's 6 (5
                    // content + 1 trailing empty), so sprite_rect grows
                    // to ~90 px instead of ~108 and the last line gets
                    // clipped.
                    if !text_member.text.ends_with('\r')
                        && !text_member.text.ends_with('\n')
                    {
                        text_member.text.push('\n');
                    }

                    // Extract alignment from <p align="..."> or <center> tag
                    let html_lower = html_string.to_lowercase();
                    if html_lower.contains("align=\"center\"") || html_lower.contains("align='center'") || html_lower.contains("<center") {
                        text_member.alignment = BuiltInSymbol::Center;
                    } else if html_lower.contains("align=\"right\"") || html_lower.contains("align='right'") {
                        text_member.alignment = BuiltInSymbol::Right;
                    } else if html_lower.contains("align=\"left\"") || html_lower.contains("align='left'") {
                        text_member.alignment = BuiltInSymbol::Left;
                    }

                    // Extract bgcolor and text color from body tag
                    // Director uses both standard "bgcolor" and short "bg" forms
                    if let Some(body_start) = html_lower.find("<body") {
                        if let Some(body_end) = html_lower[body_start..].find('>') {
                            let body_tag = &html_string[body_start..body_start + body_end];

                            // Try bgcolor="..." or bg="..."
                            let bg_color_str = HtmlParser::extract_tag_attr(body_tag, "bgcolor")
                                .or_else(|| HtmlParser::extract_tag_attr(body_tag, "bg"));
                            if let Some(color_str) = bg_color_str {
                                if let Some(color) = HtmlParser::parse_color(&color_str) {
                                    cast_member.bg_color = crate::player::sprite::ColorRef::Rgb(
                                        ((color >> 16) & 0xFF) as u8,
                                        ((color >> 8) & 0xFF) as u8,
                                        (color & 0xFF) as u8,
                                    );
                                }
                            }

                            // Try text="..." for foreground color
                            if let Some(color_str) = HtmlParser::extract_tag_attr(body_tag, "text") {
                                if let Some(color) = HtmlParser::parse_color(&color_str) {
                                    cast_member.color = crate::player::sprite::ColorRef::Rgb(
                                        ((color >> 16) & 0xFF) as u8,
                                        ((color >> 8) & 0xFF) as u8,
                                        (color & 0xFF) as u8,
                                    );
                                }
                            }
                        }
                    }

                    // Apply style properties from the first span to the text member
                    if let Some(first_span) = spans.first() {
                        let style = &first_span.style;

                        // Apply font face if specified
                        if let Some(ref font_face) = style.font_face {
                            text_member.font = font_face.clone();
                        }

                        // Apply font size if specified
                        if let Some(font_size) = style.font_size {
                            text_member.font_size = font_size as u16;
                        }

                        // Apply font color if specified
                        if let Some(color) = style.color {
                            cast_member.color = crate::player::sprite::ColorRef::Rgb(
                                ((color >> 16) & 0xFF) as u8,
                                ((color >> 8) & 0xFF) as u8,
                                (color & 0xFF) as u8,
                            );
                        }

                        // Build font_style list from bold/italic/underline flags
                        let mut font_styles = Vec::new();
                        if style.bold {
                            font_styles.push(BuiltInSymbol::Bold);
                        }
                        if style.italic {
                            font_styles.push(BuiltInSymbol::Italic);
                        }
                        if style.underline {
                            font_styles.push(BuiltInSymbol::Underline);
                        }
                        text_member.font_style = font_styles;
                    }

                    // Store all styled spans for rendering
                    text_member.html_styled_spans = spans;
                    Ok(())
                },
            ),
            "rect" => borrow_member_mut(
                member_ref,
                |_player| {
                    let (vals, _flags) = value.to_rect_inline()?;

                    let r1 = vals[1] as i16;
                    let r0 = vals[0] as i16;
                    let r3 = vals[3] as i16;
                    let r2 = vals[2] as i16;

                    Ok((r1, r0, r3, r2))
                },
                |cast_member, value| {
                    let value = value?;
                    let text_data = cast_member.member_type.as_text_mut().unwrap();
                    let left = value.1;
                    let top = value.0;
                    let bottom = value.2;
                    let right = value.3;
                    let w = (right - left).max(0) as u16;
                    let h = (bottom - top).max(0) as u16;
                    if w > 0 {
                        text_data.width = w;
                    }
                    // An explicit `member.rect = …` resizes the member even for
                    // #adjust (Habbo's Text-Wrapper relies on this). Record that
                    // the height is runtime-set so the `.rect`/`.height`/`.image`
                    // getters report this height consistently — keeping
                    // member.image.height == member.rect.height so the bake
                    // copyPixels doesn't stretch the text vertically.
                    if h > 0 {
                        text_data.height = h;
                        text_data.rect_set_at_runtime = true;
                    }

                    Ok(())
                },
            ),
            "height" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_data = cast_member.member_type.as_text_mut().unwrap();
                    // Explicit `member.height = …` resizes even #adjust members
                    // (see the `rect` setter for the bake-stretch rationale).
                    text_data.height = value? as u16;
                    text_data.rect_set_at_runtime = true;
                    Ok(())
                },
            ),
            "forecolor" | "color" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let color_val = value?;
                    // If value > 255, treat as RGB, otherwise as palette index
                    if color_val > 255 {
                        let r = ((color_val >> 16) & 0xFF) as u8;
                        let g = ((color_val >> 8) & 0xFF) as u8;
                        let b = (color_val & 0xFF) as u8;
                        cast_member.color = crate::player::sprite::ColorRef::Rgb(r, g, b);
                    } else {
                        cast_member.color = crate::player::sprite::ColorRef::PaletteIndex(color_val as u8);
                    }
                    // Director's `the color of member` recolors the WHOLE text,
                    // overriding per-run/span colors. Clear the styled spans'
                    // explicit colors so the renderer falls back to the new
                    // member color (otherwise multi-span text — e.g. spectral-
                    // wizard's LOADING dialog with two differently-sized lines —
                    // keeps its authored black and ignores the white the script
                    // sets). Per-line `member.line[i].color` setters run after
                    // and re-apply concrete colors where needed.
                    if let Some(text) = cast_member.member_type.as_text_mut() {
                        for span in &mut text.html_styled_spans {
                            span.style.color = None;
                        }
                    }
                    Ok(())
                },
            ),
            "bgcolor" | "backcolor" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let color_val = value?;
                    // If value > 255, treat as RGB, otherwise as palette index
                    if color_val > 255 {
                        let r = ((color_val >> 16) & 0xFF) as u8;
                        let g = ((color_val >> 8) & 0xFF) as u8;
                        let b = (color_val & 0xFF) as u8;
                        cast_member.bg_color = crate::player::sprite::ColorRef::Rgb(r, g, b);
                    } else {
                        cast_member.bg_color = crate::player::sprite::ColorRef::PaletteIndex(color_val as u8);
                    }
                    Ok(())
                },
            ),
            "lineheight" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().fixed_line_space = value? as u16;
                    Ok(())
                },
            ),
            // TextInfo (3D text / D6+ text member) property setters
            "tunneldepth" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.tunnel_depth = value? as u16;
                    }
                    Ok(())
                },
            ),
            "beveldepth" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.bevel_depth = value? as u16;
                    }
                    Ok(())
                },
            ),
            "smoothness" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.smoothness = value? as u32;
                    }
                    Ok(())
                },
            ),
            "reflectivity" => borrow_member_mut(
                member_ref,
                |player| value.float_value().or_else(|_| value.int_value().map(|i| i as f64)),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.reflectivity = value? as u32;
                    }
                    Ok(())
                },
            ),
            "beveltype" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let val = value?;
                        info.bevel_type = match val.trim_start_matches('#') {
                            "none" => 0,
                            "miter" => 1,
                            "round" => 2,
                            _ => 0,
                        };
                    }
                    Ok(())
                },
            ),
            "displaymode" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let val = value?;
                        info.display_mode = match val.trim_start_matches('#') {
                            "normal" => 0,
                            "mode3d" => 1,
                            _ => 0,
                        };
                    }
                    Ok(())
                },
            ),
            "directionalpreset" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let val = value?;
                        info.directional_preset = match val.trim_start_matches('#') {
                            "none" => 0,
                            "topLeft" => 1,
                            "topCenter" => 2,
                            "topRight" => 3,
                            "middleLeft" => 4,
                            "middleCenter" => 5,
                            "middleRight" => 6,
                            "bottomLeft" => 7,
                            "bottomCenter" => 8,
                            "bottomRight" => 9,
                            _ => 0,
                        };
                    }
                    Ok(())
                },
            ),
            "texturetype" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let val = value?;
                        info.texture_type = match val.trim_start_matches('#') {
                            "none" => 0,
                            "default" => 1,
                            "member" => 2,
                            _ => 0,
                        };
                    }
                    Ok(())
                },
            ),
            "directionalcolor" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let color_val = value?;
                        // Convert RGB to format RR GG BB 00
                        let r = ((color_val >> 16) & 0xFF) as u32;
                        let g = ((color_val >> 8) & 0xFF) as u32;
                        let b = (color_val & 0xFF) as u32;
                        info.directional_color = (r << 24) | (g << 16) | (b << 8);
                    }
                    Ok(())
                },
            ),
            "ambientcolor" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let color_val = value?;
                        let r = ((color_val >> 16) & 0xFF) as u32;
                        let g = ((color_val >> 8) & 0xFF) as u32;
                        let b = (color_val & 0xFF) as u32;
                        info.ambient_color = (r << 24) | (g << 16) | (b << 8);
                    }
                    Ok(())
                },
            ),
            "specularcolor" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let color_val = value?;
                        let r = ((color_val >> 16) & 0xFF) as u32;
                        let g = ((color_val >> 8) & 0xFF) as u32;
                        let b = (color_val & 0xFF) as u32;
                        info.specular_color = (r << 24) | (g << 16) | (b << 8);
                    }
                    Ok(())
                },
            ),
            "cameraposition" => borrow_member_mut(
                member_ref,
                |player| {
                    let list = value.to_list()?;
                    if list.len() >= 3 {
                        let x = player.get_datum(&list[0]).float_value()?;
                        let y = player.get_datum(&list[1]).float_value()?;
                        let z = player.get_datum(&list[2]).float_value()?;
                        Ok((x, y, z))
                    } else {
                        Err(ScriptError::new("cameraPosition requires a vector with 3 elements".to_string()))
                    }
                },
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let (x, y, z) = value?;
                        info.camera_position_x = x as f32;
                        info.camera_position_y = y as f32;
                        info.camera_position_z = z as f32;
                    }
                    Ok(())
                },
            ),
            "camerarotation" => borrow_member_mut(
                member_ref,
                |player| {
                    let list = value.to_list()?;
                    if list.len() >= 3 {
                        let x = player.get_datum(&list[0]).float_value()?;
                        let y = player.get_datum(&list[1]).float_value()?;
                        let z = player.get_datum(&list[2]).float_value()?;
                        Ok((x, y, z))
                    } else {
                        Err(ScriptError::new("cameraRotation requires a vector with 3 elements".to_string()))
                    }
                },
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let (x, y, z) = value?;
                        info.camera_rotation_x = x as f32;
                        info.camera_rotation_y = y as f32;
                        info.camera_rotation_z = z as f32;
                    }
                    Ok(())
                },
            ),
            "texturemember" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.texture_member = value?;
                    }
                    Ok(())
                },
            ),
            "displayface" => borrow_member_mut(
                member_ref,
                |player| {
                    let list = value.to_list()?;
                    let mut face_mask: i32 = 0;
                    for item_ref in list {
                        let face_str = player.get_datum(&item_ref).string_value()?;
                        match face_str.trim_start_matches('#') {
                            "front" => face_mask |= 1,
                            "tunnel" => face_mask |= 2,
                            "back" => face_mask |= 4,
                            _ => {}
                        }
                    }
                    // If all faces are enabled, use -1
                    if face_mask == 7 {
                        face_mask = -1;
                    }
                    Ok(face_mask)
                },
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.display_face = value?;
                    }
                    Ok(())
                },
            ),
            "editable" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.editable = value?;
                    }
                    Ok(())
                },
            ),
            "autotab" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.auto_tab = value?;
                    }
                    Ok(())
                },
            ),
            "directtostage" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.direct_to_stage = value?;
                    }
                    Ok(())
                },
            ),
            "prerender" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        let val = value?;
                        info.pre_render = match val.trim_start_matches('#') {
                            "none" => 0,
                            "copyInk" => 1,
                            "otherInk" => 2,
                            _ => 0,
                        };
                    }
                    Ok(())
                },
            ),
            "savebitmap" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.save_bitmap = value?;
                    }
                    Ok(())
                },
            ),
            "kerning" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.kerning = value?;
                    }
                    Ok(())
                },
            ),
            "kerningthreshold" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.kerning_threshold = value? as u32;
                    }
                    Ok(())
                },
            ),
            "usehypertextstyles" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.use_hypertext_styles = value?;
                    }
                    Ok(())
                },
            ),
            "antialiasthreshold" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.anti_alias_threshold = value? as u32;
                    }
                    Ok(())
                },
            ),
            "scrolltop" => borrow_member_mut(
                member_ref,
                |player| value.int_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if let Some(ref mut info) = text_member.info {
                        info.scroll_top = value? as u32;
                    }
                    Ok(())
                },
            ),
            "centerregpoint" => borrow_member_mut(
                member_ref,
                |player| value.bool_value(),
                |cast_member, value| {
                    let text_member = cast_member.member_type.as_text_mut().unwrap();
                    if text_member.info.is_none() {
                        text_member.info = Some(TextInfo::default());
                    }
                    if let Some(ref mut info) = text_member.info {
                        info.center_reg_point = value?;
                    }
                    Ok(())
                },
            ),
            "rtf" => borrow_member_mut(
                member_ref,
                |player| value.string_value(),
                |cast_member, value| {
                    let rtf_string = value?;
                    let text_member = cast_member.member_type.as_text_mut().unwrap();

                    // Round-trip preservation: if the incoming RTF byte-matches
                    // what `generate_rtf_from_text_member` would emit from the
                    // current state, treat as a no-op so XMED-only data the
                    // RTF format lossy-collapses (empty paragraphs, exact
                    // par_run boundaries) is preserved. Director's RTF emits
                    // `\par` once per visible line break and discards
                    // empty paragraphs — running the round-trip through our
                    // parser otherwise resynthesizes a flatter structure
                    // that the renderer can't recover the original visual
                    // gap from (e.g. the Junkbot Buggy info-card has a
                    // blank line between description and "Terrain:" that
                    // exists as `\r\r` in the XMED text but as a single
                    // `\par` in the emitted RTF).
                    let current_rtf = Self::generate_rtf_from_text_member(text_member);
                    if rtf_string == current_rtf {
                        text_member.rtf_source = rtf_string;
                        return Ok(());
                    }

                    text_member.rtf_source = rtf_string.clone();
                    let parsed = Self::parse_rtf_to_styled_text(&rtf_string);
                    // Sync member-level font/font_size from the first span so
                    // future RTF generation emits the correct document
                    // default `\fs<n>`. Otherwise members created blank by
                    // Lingo (font_size=0) regenerate as `\fs2` and break the
                    // no-op round-trip detection.
                    if let Some(first) = parsed.spans.first() {
                        if let Some(sz) = first.style.font_size.filter(|s| *s > 0) {
                            text_member.font_size = sz as u16;
                        }
                        if let Some(face) = first.style.font_face.as_ref().filter(|f| !f.is_empty()) {
                            text_member.font = face.clone();
                        }
                    }

                    text_member.text = parsed.text.clone();
                    text_member.html_styled_spans = parsed.spans;
                    text_member.par_infos = parsed.par_infos;
                    text_member.par_runs = parsed.par_runs;
                    if let Some(ts) = parsed.member_top_spacing {
                        text_member.top_spacing = ts;
                    }
                    if let Some(bs) = parsed.member_bottom_spacing {
                        text_member.bottom_spacing = bs;
                    }
                    Ok(())
                },
            ),
            "charspacing" => borrow_member_mut(
                member_ref,
                |_player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().char_spacing = value?;
                    Ok(())
                },
            ),
            "bottomspacing" => borrow_member_mut(
                member_ref,
                |_player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().bottom_spacing = value? as i16;
                    Ok(())
                },
            ),
            "selstart" => borrow_member_mut(
                member_ref,
                |_player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().sel_start = value?;
                    Ok(())
                },
            ),
            "selend" => borrow_member_mut(
                member_ref,
                |_player| value.int_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().sel_end = value?;
                    Ok(())
                },
            ),
            "selectedtext" => borrow_member_mut(
                member_ref,
                |_player| value.string_value(),
                |cast_member, value| {
                    let s = value?;
                    let text = cast_member.member_type.as_text_mut().unwrap();
                    let len = text.text.len() as i32;
                    let lo = text.sel_start.min(text.sel_end).clamp(0, len);
                    let hi = text.sel_start.max(text.sel_end).clamp(0, len);
                    text.text.replace_range(lo as usize..hi as usize, &s);
                    let new_caret = lo + s.len() as i32;
                    text.sel_start = new_caret;
                    text.sel_end = new_caret;
                    text.sel_anchor = new_caret;
                    Ok(())
                },
            ),
            "antialiastype" => borrow_member_mut(
                member_ref,
                |_player| value.symbol_value(),
                |cast_member, value| {
                    cast_member.member_type.as_text_mut().unwrap().anti_alias_type = value?.into_builtin_or_error()?;
                    Ok(())
                },
            ),
            "tabs" => {
                use crate::player::cast_member::TabStop;
                borrow_member_mut(
                    member_ref,
                    |player| {
                        // tabs is a list of prop lists: [[#type: #right, #position: 200]]
                        let list_result = value.to_list_tuple();
                        let tab_items = if let Ok((_, items, _)) = list_result {
                            items.clone()
                        } else {
                            VecDeque::new()
                        };
                        let mut tab_stops = Vec::new();
                        for item_ref in &tab_items {
                            let item_datum = player.get_datum(item_ref);
                            if let Ok((entries, _)) = item_datum.to_map_tuple() {
                                let entries = entries.clone();
                                let mut tab_type = BuiltInSymbol::Left;
                                let mut position = 0i32;
                                for (key_ref, val_ref) in &entries {
                                    let key = player.get_datum(key_ref).symbol_value().unwrap_or(Symbol::empty()).into_builtin();
                                    match key {
                                        Some(BuiltInSymbol::Type) => {
                                            let t = player.get_datum(val_ref).symbol_value().unwrap_or(Symbol::empty()).into_builtin().unwrap_or(BuiltInSymbol::Left);
                                            tab_type = t;
                                        }
                                        Some(BuiltInSymbol::Position) => {
                                            position = player.get_datum(val_ref).int_value().unwrap_or(0);
                                        }
                                        _ => {}
                                    }
                                }
                                tab_stops.push(TabStop { tab_type, position });
                            }
                        }
                        tab_stops
                    },
                    |cast_member, tab_stops| {
                        if let Some(text) = cast_member.member_type.as_text_mut() {
                            text.tab_stops = tab_stops;
                        }
                        Ok(())
                    },
                )
            }
            _ => Err(ScriptError::new(format!(
                "Cannot set castMember prop {} for text",
                prop
            ))),
        }
    }

    /// Build a Director-style RTF document from a TextMember's styled spans.
    ///
    /// Mirrors the format Director emits for `the rtf of member`:
    /// header (`\rtf1\ansi\deff0`), `\fonttbl` with the unique font names,
    /// `\colortbl` with each unique span color (entry 0 reserved for
    /// default black), a minimal `\stylesheet`, document margins, then
    /// per-span `{\pard \plain\f<n>\fs<n>\sb<n>\sa<n>\sl<n>... text}`
    /// blocks. Per-span paragraph spacing (`\sb`/`\sa`/`\sl`) is sourced
    /// from `par_infos`/`par_runs` indexed by the span's text position.
    ///
    /// Default colon-escape `:` -> `\:` matches Director's output.
    /// Trailing `\par` is emitted on the final span so the document ends
    /// with a paragraph terminator (Director appends one).
    ///
    /// This is the encode side of the round-trip Director scripts rely on
    /// (`member("Y").rtf = member("X").rtf`). Without per-span styling,
    /// labels like "Terrain:"/"Speed:" rendered as plain text instead of
    /// the authored gray (Junkbot V7 Buggy info-card).
    fn generate_rtf_from_text_member(text_data: &crate::player::cast_member::TextMember) -> String {
        let spans = &text_data.html_styled_spans;
        let default_size_halfpts = (text_data.font_size as i32).max(1) * 2;

        // Build font table. Director emits two fonts for this Buggy member
        // (`Arial` at f0, `Arial *` at f1 — the `*`-suffixed form is the
        // PFR cast member alias). To keep our table aligned with that
        // convention, always seed `Arial` at index 0 and append the
        // member's actual font (and any unique span fonts) after it.
        let mut fonts: Vec<String> = Vec::new();
        fonts.push("Arial".to_string());
        let member_font = if text_data.font.is_empty() {
            String::new()
        } else {
            text_data.font.clone()
        };
        if !member_font.is_empty() && !fonts.iter().any(|f| f == &member_font) {
            fonts.push(member_font);
        }
        for span in spans {
            if let Some(face) = &span.style.font_face {
                if !face.is_empty() && !fonts.iter().any(|f| f == face) {
                    fonts.push(face.clone());
                }
            }
        }
        // Index for the member's primary font (used for spans that don't
        // override font_face). When the member font isn't "Arial", the
        // primary index is 1; otherwise 0.
        let primary_font_idx = if text_data.font.is_empty() || text_data.font == "Arial" {
            0
        } else {
            fonts.iter().position(|f| f == &text_data.font).unwrap_or(0)
        };

        // Build color table. Director seeds the table with a preset
        // palette so spans emit `\cf<n>` at well-known indices regardless
        // of which colors the document actually uses:
        //   0: black (0,0,0) — default text
        //   1: blue  (0,0,224)
        //   2: red   (224,0,0)
        //   3: magenta (224,0,224)
        //   4: gray  (119,119,119) — used for `\cf4` labels
        // Match that ordering so a script that does
        // `member("Y").rtf = member("X").rtf` round-trips with the same
        // `\cf<n>` indices. Unique span colors not already in the preset
        // palette are appended after index 4.
        let mut colors: Vec<u32> = vec![
            0x000000, // black
            0x0000E0, // blue (0, 0, 224)
            0xE00000, // red (224, 0, 0)
            0xE000E0, // magenta (224, 0, 224)
            0x777777, // gray (119, 119, 119)
        ];
        for span in spans {
            if let Some(c) = span.style.color {
                let c_rgb = c & 0x00FFFFFF;
                if !colors.iter().any(|x| *x == c_rgb) {
                    colors.push(c_rgb);
                }
            }
        }

        let mut rtf = String::new();
        rtf.push_str("{\\rtf1\\ansi\\deff0 ");

        // Font table
        rtf.push_str("{\\fonttbl");
        for (idx, font) in fonts.iter().enumerate() {
            rtf.push_str(&format!("{{\\f{}\\fswiss {};}}", idx, font));
        }
        rtf.push('}');

        // Color table
        rtf.push_str("{\\colortbl");
        for c in &colors {
            let r = (c >> 16) & 0xFF;
            let g = (c >> 8) & 0xFF;
            let b = c & 0xFF;
            rtf.push_str(&format!("\\red{}\\green{}\\blue{};", r, g, b));
        }
        rtf.push('}');

        // Minimal stylesheet. Director emits this; some RTF readers
        // require it for default-style fallback.
        rtf.push_str(&format!("{{\\stylesheet{{\\s0\\fs{} Normal Text;}}}}", default_size_halfpts));

        // Document margins (twips) — Director's defaults.
        rtf.push_str("\\margl1800 \\margr1800 \\margt1440 \\margb1440 ");

        // Document-level paragraph defaults.
        rtf.push_str(&format!("\\pard \\f0\\fs{}", default_size_halfpts));

        // Helper to escape a text run's payload. Director escapes `:` as
        // `\:`; mirror that so round-trip fidelity is preserved.
        let escape_run = |s: &str, out: &mut String, ends_with_par: bool| {
            // Iterate chars; on `\r`/`\n` emit `\par\n`. The terminal
            // `\par` is appended outside this fn (when ends_with_par is
            // true) so the helper doesn't have to track final-position.
            let chars: Vec<char> = s.chars().collect();
            for (i, ch) in chars.iter().enumerate() {
                let is_last = i + 1 == chars.len();
                match ch {
                    '\\' => out.push_str("\\\\"),
                    '{' => out.push_str("\\{"),
                    '}' => out.push_str("\\}"),
                    ':' => out.push_str("\\:"),
                    '\r' | '\n' => {
                        // Last char break is handled by caller's
                        // `\par\n` emission to avoid double-stamping.
                        if !(is_last && ends_with_par) {
                            out.push_str("\\par\n");
                        }
                    }
                    other => out.push(*other),
                }
            }
        };

        // Compute par_info-derived spacing for a span at a given text byte
        // offset. Returns (sb, sa, sl) twips. Director's RTF stores all
        // three in twips (1/20pt). Our `par_info.line_spacing` is the
        // pixel/point value Paige reports (e.g. 14 for the description's
        // 14pt line height); convert by ×20 to match Director's twips.
        // Director's `\sb`/`\sa` are typically a fixed 100 twips for text
        // members regardless of par_info content, so use 100 as the
        // floor.
        let par_spacing_at = |position: u32| -> (i32, i32, i32) {
            if text_data.par_runs.is_empty() || text_data.par_infos.is_empty() {
                return (100, 100, 100);
            }
            // Find the par_run whose `position` is the largest <= this offset.
            let mut active_idx: u16 = 0;
            for run in &text_data.par_runs {
                if run.position <= position {
                    active_idx = run.par_info_index;
                } else {
                    break;
                }
            }
            let par_info = text_data.par_infos.get(active_idx as usize)
                .cloned()
                .unwrap_or_default();
            let sb = if par_info.top_spacing > 0 { par_info.top_spacing * 20 } else { 100 };
            let sa = if par_info.bottom_spacing > 0 { par_info.bottom_spacing * 20 } else { 100 };
            let sl = if par_info.line_spacing > 0 { par_info.line_spacing * 20 } else { 100 };
            (sb, sa, sl)
        };

        if spans.is_empty() {
            // No styled spans — single paragraph with member-level font/size.
            let (sb, sa, sl) = par_spacing_at(0);
            rtf.push_str(&format!(
                "{{\\pard \\plain\\f{}\\fs{}\\sb{}\\sa{}\\sl{} ",
                primary_font_idx, default_size_halfpts, sb, sa, sl,
            ));
            escape_run(&text_data.text, &mut rtf, true);
            rtf.push_str("\\par\n}");
        } else {
            let span_count = spans.len();
            let mut text_pos: u32 = 0;
            for (idx, span) in spans.iter().enumerate() {
                let span_start = text_pos;
                let font_idx = span.style.font_face
                    .as_ref()
                    .and_then(|f| fonts.iter().position(|x| x == f))
                    .unwrap_or(primary_font_idx);
                let color_idx = span.style.color
                    .map(|c| c & 0x00FFFFFF)
                    .and_then(|c| colors.iter().position(|x| *x == c))
                    .unwrap_or(0);
                let size_halfpts = span.style.font_size
                    .map(|sz| sz.max(1) * 2)
                    .unwrap_or(default_size_halfpts);
                let (sb, sa, sl) = par_spacing_at(span_start);

                rtf.push_str("{\\pard ");
                // `\plain` resets character formatting before this run —
                // Director emits this for the "default style" runs (the
                // text content). After `\plain` we must re-declare font
                // and size; colored/bold/etc. runs inherit `\fs<default>`
                // from the outer context so they emit only `\f<n>` and
                // skip `\fs<n>` to match Director's compact output.
                let is_styled_label = color_idx != 0
                    || span.style.bold
                    || span.style.italic
                    || span.style.underline;
                let emit_size = !is_styled_label || size_halfpts != default_size_halfpts;
                if !is_styled_label {
                    rtf.push_str("\\plain");
                }
                rtf.push_str(&format!("\\f{}", font_idx));
                if emit_size {
                    rtf.push_str(&format!("\\fs{}", size_halfpts));
                }
                if color_idx != 0 {
                    rtf.push_str(&format!("\\cf{}", color_idx));
                }
                if span.style.bold {
                    rtf.push_str("\\b");
                }
                if span.style.italic {
                    rtf.push_str("\\i");
                }
                if span.style.underline {
                    rtf.push_str("\\ul");
                }
                rtf.push_str(&format!("\\sb{}\\sa{}\\sl{} ", sb, sa, sl));

                let is_final_span = idx + 1 == span_count;
                let span_ends_with_break = span.text.ends_with('\r')
                    || span.text.ends_with('\n');
                let needs_terminal_par = is_final_span && !span_ends_with_break;

                escape_run(&span.text, &mut rtf, false);
                if needs_terminal_par {
                    rtf.push_str("\\par\n");
                }
                rtf.push('}');

                text_pos += span.text.chars().count() as u32;
            }
        }

        rtf.push('}');
        rtf
    }

    /// Parse a Director-style RTF document into text + styled spans +
    /// paragraph spacing data. Symmetric counterpart to
    /// `generate_rtf_from_text_member` for the
    /// `member.rtf = member("X").rtf` round-trip.
    ///
    /// Handles:
    ///  - `{\fonttbl ...}` — collects font names indexed by `\fN`.
    ///  - `{\colortbl \red<r>\green<g>\blue<b>;...}` — collects RGB colors
    ///    indexed by `\cfN`.
    ///  - `{\stylesheet ...}` / `{\info ...}` / `{\fonttbl{\*...}}` —
    ///    skipped as metadata.
    ///  - Per-character-run styling: `\f<n>`, `\fs<n>`, `\cf<n>`, `\b`,
    ///    `\i`, `\ul`, `\plain` (resets to defaults).
    ///  - Per-paragraph spacing: `\sb<n>`, `\sa<n>`, `\sl<n>` (twips).
    ///    Stored in `par_infos` and indexed via `par_runs` keyed on the
    ///    paragraph's text-position.
    ///  - `\par` / `\line` — emit `\r` and start a new paragraph.
    ///  - `\tab` — emit `\t`.
    ///  - `\'XX` — hex escape → byte → char.
    ///  - `\:` etc. — literal char.
    ///  - `{` / `}` — push/pop style stack.
    fn parse_rtf_to_styled_text(rtf: &str) -> ParsedRtf {
        use crate::player::handlers::datum_handlers::cast_member::font::{HtmlStyle, StyledSpan};
        use crate::director::chunks::xmedia_styled_text::{ParInfo, ParRun};

        // First pass: extract font table and color table.
        let fonts = Self::rtf_extract_font_table(rtf);
        let colors = Self::rtf_extract_color_table(rtf);

        // State frame for the style stack. Each `{` pushes a copy of the
        // current frame; `}` pops back. RTF formatting flows down the
        // group hierarchy and resets at group boundaries.
        #[derive(Clone)]
        struct Frame {
            font_idx: Option<usize>,
            font_size_halfpts: Option<u32>,
            color_idx: Option<usize>,
            bold: bool,
            italic: bool,
            underline: bool,
            // Per-paragraph spacing in twips. These attach to the
            // paragraph the run is part of, not the run itself.
            sb: Option<i32>,
            sa: Option<i32>,
            sl: Option<i32>,
        }
        impl Default for Frame {
            fn default() -> Self {
                Frame {
                    font_idx: None,
                    font_size_halfpts: None,
                    color_idx: None,
                    bold: false,
                    italic: false,
                    underline: false,
                    sb: None,
                    sa: None,
                    sl: None,
                }
            }
        }

        let mut text = String::new();
        let mut spans: Vec<StyledSpan> = Vec::new();
        let mut par_infos: Vec<ParInfo> = Vec::new();
        let mut par_runs: Vec<ParRun> = Vec::new();

        // Ensure index 0 exists with paragraph defaults so par_runs always
        // has something to point at.
        par_infos.push(ParInfo::default());

        let mut stack: Vec<Frame> = vec![Frame::default()];
        let mut depth: i32 = 0;
        let mut skip_depth: Option<i32> = None;

        // Current paragraph state — accumulated until a `\par` is hit.
        let mut current_par_sb: Option<i32> = None;
        let mut current_par_sa: Option<i32> = None;
        let mut current_par_sl: Option<i32> = None;
        // First `\sb`/`\sa` value (twips) — hoisted to member-level
        // top_spacing/bottom_spacing in the setter.
        let mut first_sb_twips: Option<i32> = None;
        let mut first_sa_twips: Option<i32> = None;

        // Current paragraph's text start position (chars). Each `\par`
        // commits a par_info entry and a par_run for this position.
        let mut paragraph_start_pos: u32 = 0;

        // Buffer for the run currently being built. Flushed into a
        // StyledSpan whenever the active style changes or a paragraph
        // break is emitted.
        let mut run_buf = String::new();
        let mut run_style: Option<HtmlStyle> = None;

        let chars: Vec<char> = rtf.chars().collect();
        let len = chars.len();
        let mut i = 0;

        // Build an HtmlStyle from a frame, resolving font_idx → font name
        // and color_idx → RGB.
        let frame_to_style = |frame: &Frame, fonts: &[String], colors: &[u32]| -> HtmlStyle {
            HtmlStyle {
                font_face: frame.font_idx
                    .and_then(|i| fonts.get(i))
                    .filter(|f| !f.is_empty())
                    .cloned(),
                font_size: frame.font_size_halfpts.map(|halfpts| (halfpts / 2) as i32),
                color: frame.color_idx
                    .and_then(|i| colors.get(i))
                    .copied(),
                bg_color: None,
                bold: frame.bold,
                italic: frame.italic,
                underline: frame.underline,
                kerning: 0,
                char_spacing: 0,
                hyperlink: None,
            }
        };

        // Flush the current run buffer to a StyledSpan with the current
        // style. Called before a style change OR before a `\par`.
        let mut flush_run = |run_buf: &mut String,
                             run_style: &mut Option<HtmlStyle>,
                             spans: &mut Vec<StyledSpan>| {
            if !run_buf.is_empty() {
                let style = run_style.clone().unwrap_or_default();
                spans.push(StyledSpan {
                    text: std::mem::take(run_buf),
                    style,
                });
            }
            *run_style = None;
        };

        while i < len {
            let ch = chars[i];
            match ch {
                '{' => {
                    depth += 1;
                    // Detect groups whose contents we should skip entirely.
                    let rest: String = chars[i + 1..len.min(i + 32)].iter().collect();
                    if rest.starts_with("\\fonttbl")
                        || rest.starts_with("\\colortbl")
                        || rest.starts_with("\\stylesheet")
                        || rest.starts_with("\\info")
                        || rest.starts_with("\\*")
                    {
                        if skip_depth.is_none() {
                            skip_depth = Some(depth);
                        }
                    }
                    // Push a copy of the current frame so the `}` later
                    // restores the outer state.
                    let top = stack.last().cloned().unwrap_or_default();
                    stack.push(top);
                    i += 1;
                }
                '}' => {
                    if skip_depth == Some(depth) {
                        skip_depth = None;
                    }
                    if !skip_depth.is_some() {
                        // Style about to change at the `}` — flush.
                        flush_run(&mut run_buf, &mut run_style, &mut spans);
                    }
                    if stack.len() > 1 {
                        stack.pop();
                    }
                    depth -= 1;
                    i += 1;
                }
                '\\' if skip_depth.is_none() => {
                    i += 1;
                    if i >= len {
                        break;
                    }
                    let next = chars[i];
                    if next == '\'' && i + 2 < len {
                        // \'XX hex escape
                        let hex: String = chars[i + 1..i + 3].iter().collect();
                        if let Ok(byte) = u8::from_str_radix(&hex, 16) {
                            // Ensure run_style matches current frame.
                            if run_style.is_none() {
                                run_style = Some(frame_to_style(stack.last().unwrap(), &fonts, &colors));
                            }
                            run_buf.push(byte as char);
                            text.push(byte as char);
                        }
                        i += 3;
                    } else if next == '\\' || next == '{' || next == '}' {
                        if run_style.is_none() {
                            run_style = Some(frame_to_style(stack.last().unwrap(), &fonts, &colors));
                        }
                        run_buf.push(next);
                        text.push(next);
                        i += 1;
                    } else if next == '\n' || next == '\r' {
                        // Line break right after backslash — RTF source
                        // formatting, skip.
                        i += 1;
                    } else if !next.is_ascii_alphabetic() {
                        // Non-letter escape (`\:`, `\-`, etc.) — emit literal.
                        if run_style.is_none() {
                            run_style = Some(frame_to_style(stack.last().unwrap(), &fonts, &colors));
                        }
                        run_buf.push(next);
                        text.push(next);
                        i += 1;
                    } else {
                        // Control word
                        let mut word = String::new();
                        while i < len && chars[i].is_ascii_alphabetic() {
                            word.push(chars[i]);
                            i += 1;
                        }
                        // Optional numeric param
                        let mut numeric_param: Option<i32> = None;
                        if i < len && (chars[i] == '-' || chars[i].is_ascii_digit()) {
                            let mut num_str = String::new();
                            if chars[i] == '-' {
                                num_str.push('-');
                                i += 1;
                            }
                            while i < len && chars[i].is_ascii_digit() {
                                num_str.push(chars[i]);
                                i += 1;
                            }
                            numeric_param = num_str.parse::<i32>().ok();
                        }
                        // Skip single trailing space delimiter
                        if i < len && chars[i] == ' ' {
                            i += 1;
                        }

                        // Style-changing words flush the current run before
                        // applying so the previous style is preserved.
                        match word.as_str() {
                            "par" | "line" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                // Commit current paragraph spacing to
                                // par_infos, recording a par_run pointing
                                // at the paragraph's start position.
                                let par_info_idx = if current_par_sb.is_some()
                                    || current_par_sa.is_some()
                                    || current_par_sl.is_some()
                                {
                                    // Verified against XMED-load dumps:
                                    //   - `\sb`/`\sa` are 0 in authored
                                    //     par_infos across the board.
                                    //     Director emits `\sb100\sa100` as
                                    //     a default sentinel; map exact
                                    //     100 twips back to 0 to match.
                                    //   - `\sl` is authored as a literal
                                    //     value (Buggy labels: sl=5, desc:
                                    //     sl=14, Terrain:Normal: sl=15).
                                    //     Sentinel-mapping `\sl100` to 0
                                    //     would lose the 5pt label value
                                    //     and diverge from the truth, so
                                    //     pass `\sl` through verbatim.
                                    //     The renderer must clamp the
                                    //     effective line height to
                                    //     `max(line_spacing, line.max_size)`
                                    //     so a 5pt sl with a 12pt font
                                    //     still gets a 12pt line stride.
                                    let unsentinel_sb_sa = |t: Option<i32>| -> i32 {
                                        match t {
                                            Some(100) | None => 0,
                                            Some(v) => v / 20,
                                        }
                                    };
                                    let pt_sl = |t: Option<i32>| -> i32 {
                                        t.map(|v| v / 20).unwrap_or(0)
                                    };
                                    let new_par = ParInfo {
                                        line_spacing: pt_sl(current_par_sl),
                                        line_height: 0,
                                        left_indent: 0,
                                        right_indent: 0,
                                        first_indent: 0,
                                        top_spacing: unsentinel_sb_sa(current_par_sb),
                                        bottom_spacing: unsentinel_sb_sa(current_par_sa),
                                        justification: 0,
                                    };
                                    // Deduplicate par_infos: Director's
                                    // XMED stores ONE par_info per distinct
                                    // value-set and points multiple
                                    // paragraphs at the same index via
                                    // par_runs (Buggy labels Speed/Actions/
                                    // Drop Off/Capacity all share par_info
                                    // sl=5). Without this, every `\par`
                                    // gets its own par_info and the
                                    // renderer sees a paragraph transition
                                    // between every line — adding member-
                                    // level top/bottom_spacing at every
                                    // `\par` instead of only at genuine
                                    // par_info group changes.
                                    let existing_idx = par_infos.iter().enumerate().find_map(|(i, pi)| {
                                        if pi.line_spacing == new_par.line_spacing
                                            && pi.line_height == new_par.line_height
                                            && pi.left_indent == new_par.left_indent
                                            && pi.right_indent == new_par.right_indent
                                            && pi.first_indent == new_par.first_indent
                                            && pi.top_spacing == new_par.top_spacing
                                            && pi.bottom_spacing == new_par.bottom_spacing
                                            && pi.justification == new_par.justification
                                        { Some(i as u16) } else { None }
                                    });
                                    match existing_idx {
                                        Some(idx) => idx,
                                        None => {
                                            par_infos.push(new_par);
                                            par_infos.len() as u16 - 1
                                        }
                                    }
                                } else {
                                    0
                                };
                                // Push a par_run only when the par_info
                                // index actually changes — Director's
                                // par_runs are coalesced (one entry per
                                // par_info group, not per `\par`).
                                let push_run = par_runs
                                    .last()
                                    .map_or(true, |r| r.par_info_index != par_info_idx);
                                if push_run {
                                    par_runs.push(ParRun {
                                        position: paragraph_start_pos,
                                        par_info_index: par_info_idx,
                                    });
                                }
                                // Don't reset paragraph spacing on `\par` —
                                // RTF semantics keep `\sb`/`\sa`/`\sl` in
                                // effect for subsequent paragraphs in the
                                // same group until `\pard` resets them or a
                                // new value overrides. Resetting here made
                                // "Drop Off\par" (which lives in the same
                                // `{\pard ... Pick Up,\par\nDrop Off\par}`
                                // group as Pick Up) lose the group's
                                // `\sl100\sb100\sa100` and fall back to the
                                // default par_info[0] entry.
                                // Append the actual `\r` to text and to the
                                // current run buffer (so the span carries
                                // its terminating break the same way the
                                // generator emits).
                                if run_style.is_none() {
                                    run_style = Some(frame_to_style(stack.last().unwrap(), &fonts, &colors));
                                }
                                run_buf.push('\r');
                                text.push('\r');
                                paragraph_start_pos = text.chars().count() as u32;
                            }
                            "tab" => {
                                if run_style.is_none() {
                                    run_style = Some(frame_to_style(stack.last().unwrap(), &fonts, &colors));
                                }
                                run_buf.push('\t');
                            }
                            "plain" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.bold = false;
                                frame.italic = false;
                                frame.underline = false;
                                frame.color_idx = None;
                                // \plain doesn't reset font_idx/font_size
                                // by RTF spec — those follow `\fN\fsN`
                                // that appears next.
                            }
                            "f" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.font_idx = numeric_param.map(|n| n.max(0) as usize);
                            }
                            "fs" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.font_size_halfpts = numeric_param.map(|n| n.max(1) as u32);
                            }
                            "cf" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.color_idx = numeric_param.map(|n| n.max(0) as usize);
                            }
                            "b" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.bold = numeric_param != Some(0);
                            }
                            "i" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.italic = numeric_param != Some(0);
                            }
                            "ul" | "ulnone" => {
                                flush_run(&mut run_buf, &mut run_style, &mut spans);
                                let frame = stack.last_mut().unwrap();
                                frame.underline = word == "ul" && numeric_param != Some(0);
                            }
                            "sb" => {
                                current_par_sb = numeric_param;
                                if first_sb_twips.is_none() {
                                    first_sb_twips = numeric_param;
                                }
                            }
                            "sa" => {
                                current_par_sa = numeric_param;
                                if first_sa_twips.is_none() {
                                    first_sa_twips = numeric_param;
                                }
                            }
                            "sl" => {
                                current_par_sl = numeric_param;
                            }
                            "pard" => {
                                // Reset paragraph properties to defaults.
                                current_par_sb = None;
                                current_par_sa = None;
                                current_par_sl = None;
                            }
                            // Ignore everything else (margins, deff, ansi,
                            // stylesheet refs, etc.). Already-skipped groups
                            // (fonttbl, colortbl) handled by skip_depth.
                            _ => {}
                        }
                    }
                }
                '\n' | '\r' => {
                    // Bare newlines in RTF source are formatting whitespace.
                    i += 1;
                }
                _ => {
                    if skip_depth.is_none() {
                        // Initialize run style on first content char of a
                        // run so style changes flush the previous run
                        // before applying.
                        if run_style.is_none() {
                            run_style = Some(frame_to_style(stack.last().unwrap(), &fonts, &colors));
                        }
                        run_buf.push(ch);
                        text.push(ch);
                    }
                    i += 1;
                }
            }
        }

        // Flush any trailing run.
        flush_run(&mut run_buf, &mut run_style, &mut spans);

        ParsedRtf {
            text,
            spans,
            par_infos,
            par_runs,
            member_top_spacing: first_sb_twips.map(|t| (t / 20) as i16),
            member_bottom_spacing: first_sa_twips.map(|t| (t / 20) as i16),
        }
    }

    /// Walk an RTF string and extract `{\fonttbl{\fN\fswiss <name>;}...}`
    /// into a Vec where index N holds the font name. Missing indices are
    /// filled with empty strings.
    fn rtf_extract_font_table(rtf: &str) -> Vec<String> {
        let mut fonts: Vec<String> = Vec::new();
        let bytes = rtf.as_bytes();
        let len = bytes.len();
        let Some(start) = rtf.find("\\fonttbl") else {
            return fonts;
        };
        // Find the matching `}` for the `{\fonttbl ...}` group.
        let mut depth = 1;
        let mut i = start + "\\fonttbl".len();
        // Walk from start of group; we entered at depth 1.
        while i < len && depth > 0 {
            match bytes[i] as char {
                '{' => depth += 1,
                '}' => {
                    depth -= 1;
                    if depth == 0 {
                        break;
                    }
                }
                _ => {}
            }
            i += 1;
        }
        let group_end = i;
        let group = &rtf[start..group_end.min(rtf.len())];

        // Each font entry is `{\fN ...; }` or `{\fN\fswiss <name>;}`.
        let chars: Vec<char> = group.chars().collect();
        let mut p = 0;
        while p < chars.len() {
            if chars[p] == '\\' && p + 1 < chars.len() && chars[p + 1] == 'f' {
                // Try to read \fN
                let mut q = p + 2;
                let mut num_str = String::new();
                while q < chars.len() && chars[q].is_ascii_digit() {
                    num_str.push(chars[q]);
                    q += 1;
                }
                if let Ok(idx) = num_str.parse::<usize>() {
                    // Find the font name — next text up to `;` or `}`.
                    let mut name = String::new();
                    let mut depth_inner = 0;
                    while q < chars.len() {
                        let c = chars[q];
                        if c == '{' {
                            depth_inner += 1;
                            q += 1;
                            continue;
                        }
                        if c == '}' {
                            if depth_inner == 0 {
                                break;
                            }
                            depth_inner -= 1;
                            q += 1;
                            continue;
                        }
                        if c == ';' {
                            break;
                        }
                        if c == '\\' {
                            // Skip control word (e.g. \fswiss, \froman).
                            q += 1;
                            while q < chars.len() && chars[q].is_ascii_alphabetic() {
                                q += 1;
                            }
                            // optional numeric
                            if q < chars.len() && (chars[q] == '-' || chars[q].is_ascii_digit()) {
                                if chars[q] == '-' {
                                    q += 1;
                                }
                                while q < chars.len() && chars[q].is_ascii_digit() {
                                    q += 1;
                                }
                            }
                            // optional space delim
                            if q < chars.len() && chars[q] == ' ' {
                                q += 1;
                            }
                            continue;
                        }
                        name.push(c);
                        q += 1;
                    }
                    let trimmed = name.trim().to_string();
                    while fonts.len() <= idx {
                        fonts.push(String::new());
                    }
                    fonts[idx] = trimmed;
                    p = q;
                    continue;
                }
            }
            p += 1;
        }
        fonts
    }

    /// Walk an RTF string and extract `{\colortbl \red<r>\green<g>\blue<b>;...}`
    /// into a Vec<u32> of 0xRRGGBB values. Index 0 always exists (default
    /// black).
    fn rtf_extract_color_table(rtf: &str) -> Vec<u32> {
        let mut colors: Vec<u32> = vec![0x000000];
        let Some(start) = rtf.find("\\colortbl") else {
            return colors;
        };
        // Find matching `}` for the colortbl group.
        let bytes = rtf.as_bytes();
        let len = bytes.len();
        let mut depth = 1;
        let mut i = start + "\\colortbl".len();
        while i < len && depth > 0 {
            match bytes[i] as char {
                '{' => depth += 1,
                '}' => {
                    depth -= 1;
                    if depth == 0 {
                        break;
                    }
                }
                _ => {}
            }
            i += 1;
        }
        let group = &rtf[start..i.min(rtf.len())];

        // Reset colors to empty so we collect strictly from the table
        // (the caller-side default-black at index 0 will be the first
        // entry parsed below for Director's table).
        colors.clear();

        // Walk control words in order, accumulating r/g/b until we hit
        // a `;` which commits the color.
        let chars: Vec<char> = group.chars().collect();
        let mut p = 0;
        let mut cur_r: u32 = 0;
        let mut cur_g: u32 = 0;
        let mut cur_b: u32 = 0;
        let mut have_any = false;
        while p < chars.len() {
            let c = chars[p];
            if c == '\\' && p + 1 < chars.len() {
                let mut q = p + 1;
                let mut word = String::new();
                while q < chars.len() && chars[q].is_ascii_alphabetic() {
                    word.push(chars[q]);
                    q += 1;
                }
                let mut num_str = String::new();
                while q < chars.len() && chars[q].is_ascii_digit() {
                    num_str.push(chars[q]);
                    q += 1;
                }
                let num = num_str.parse::<u32>().unwrap_or(0);
                match word.as_str() {
                    "red" => {
                        cur_r = num.min(255);
                        have_any = true;
                    }
                    "green" => {
                        cur_g = num.min(255);
                        have_any = true;
                    }
                    "blue" => {
                        cur_b = num.min(255);
                        have_any = true;
                    }
                    _ => {}
                }
                p = q;
                continue;
            }
            if c == ';' {
                if have_any {
                    let color = (cur_r << 16) | (cur_g << 8) | cur_b;
                    colors.push(color);
                } else {
                    // `;` with no preceding triplet → default black.
                    colors.push(0x000000);
                }
                cur_r = 0;
                cur_g = 0;
                cur_b = 0;
                have_any = false;
            }
            p += 1;
        }

        if colors.is_empty() {
            colors.push(0x000000);
        }
        colors
    }

    /// Extract plain text from an RTF string by stripping control words and groups.
    fn extract_text_from_rtf(rtf: &str) -> String {
        let mut result = String::new();
        let mut depth = 0i32;
        let chars: Vec<char> = rtf.chars().collect();
        let len = chars.len();
        let mut i = 0;
        // Skip content inside {\fonttbl ...}, {\colortbl ...}, {\stylesheet ...}, etc.
        let mut skip_depth: Option<i32> = None;

        while i < len {
            let ch = chars[i];
            match ch {
                '{' => {
                    depth += 1;
                    // Check if this group starts with a known skip keyword
                    let rest: String = chars[i+1..len.min(i+20)].iter().collect();
                    if rest.starts_with("\\fonttbl")
                        || rest.starts_with("\\colortbl")
                        || rest.starts_with("\\stylesheet")
                        || rest.starts_with("\\info")
                        || rest.starts_with("\\*")
                    {
                        skip_depth = Some(depth);
                    }
                    i += 1;
                }
                '}' => {
                    if skip_depth == Some(depth) {
                        skip_depth = None;
                    }
                    depth -= 1;
                    i += 1;
                }
                '\\' if skip_depth.is_none() => {
                    i += 1;
                    if i >= len { break; }
                    let next = chars[i];
                    if next == '\'' && i + 2 < len {
                        // \'XX hex escape
                        let hex: String = chars[i+1..i+3].iter().collect();
                        if let Ok(byte) = u8::from_str_radix(&hex, 16) {
                            result.push(byte as char);
                        }
                        i += 3;
                    } else if next == '\\' || next == '{' || next == '}' {
                        result.push(next);
                        i += 1;
                    } else if next == '\n' || next == '\r' {
                        // Line break after backslash - skip
                        i += 1;
                    } else {
                        // Control word: read letters, then optional numeric param
                        let mut word = String::new();
                        while i < len && chars[i].is_ascii_alphabetic() {
                            word.push(chars[i]);
                            i += 1;
                        }
                        // Skip optional numeric parameter (including negative sign)
                        if i < len && (chars[i] == '-' || chars[i].is_ascii_digit()) {
                            if chars[i] == '-' { i += 1; }
                            while i < len && chars[i].is_ascii_digit() {
                                i += 1;
                            }
                        }
                        // Skip single trailing space delimiter
                        if i < len && chars[i] == ' ' {
                            i += 1;
                        }
                        // Convert known control words to text
                        match word.as_str() {
                            "par" | "line" => result.push('\r'),
                            "tab" => result.push('\t'),
                            _ => {}
                        }
                    }
                }
                '\n' | '\r' => {
                    // Bare newlines in RTF are ignored
                    i += 1;
                }
                _ => {
                    if skip_depth.is_none() {
                        result.push(ch);
                    }
                    i += 1;
                }
            }
        }
        result
    }
}
