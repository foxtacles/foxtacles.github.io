use std::collections::VecDeque;
use itertools::Itertools;
use log::debug;

use crate::{
    director::lingo::datum::{Datum, DatumType, HavokObjectRef},
    player::{
        DatumRef, ScriptError, cast_lib::CastMemberRef, cast_member::{
            CastMemberType, HavokAngularDashpot, HavokCollisionInterest,
            HavokLinearDashpot, HavokRigidBody, HavokSpring,
        }, reserve_player_mut, symbols::{builtin::BuiltInSymbol, symbol::Symbol}
    },
};


/// Build a large static quad collision mesh for an (infinite) Havok plane
/// primitive, centred at `center` with surface normal `n_world` (both in
/// Director world units). Two triangles, wound so their geometric normal
/// matches `n_world` (pointing toward the bodies that rest on it).
fn build_plane_quad(
    name: &str,
    center: [f64; 3],
    n_world: [f64; 3],
) -> Option<super::havok_physics::CollisionMesh> {
    use super::havok_physics::{v3_add, v3_cross, v3_normalized, v3_scale, v3_sub};
    let n = v3_normalized(n_world);
    if n[0] == 0.0 && n[1] == 0.0 && n[2] == 0.0 { return None; }
    // Half-size large enough to act as floor/wall for any reasonable room.
    const S: f64 = 5000.0;
    let helper = if n[2].abs() < 0.9 { [0.0, 0.0, 1.0] } else { [1.0, 0.0, 0.0] };
    let t1 = v3_normalized(v3_cross(n, helper));
    let t2 = v3_normalized(v3_cross(n, t1)); // cross(t1, t2) == n
    let a = v3_scale(t1, S);
    let b = v3_scale(t2, S);
    let v0 = v3_sub(v3_sub(center, a), b);
    let v1 = v3_sub(v3_add(center, a), b);
    let v2 = v3_add(v3_add(center, a), b);
    let v3 = v3_add(v3_sub(center, a), b);
    let mut cmesh = super::havok_physics::CollisionMesh {
        name: Symbol::from_str(&name.to_string()),
        vertices: vec![v0, v1, v2, v3],
        triangles: vec![[0, 1, 2], [0, 2, 3]],
        aabb_min: [0.0; 3],
        aabb_max: [0.0; 3],
        body_index: None, // static scenery
    };
    cmesh.compute_aabb();
    Some(cmesh)
}

/// Repair the POSITIONAL references into `rigid_bodies` after some bodies were
/// removed from that vector.
///
/// `CollisionMesh::body_index` and `HavokCable::body_index` are plain indices,
/// so `Vec::remove` / `retain` silently shifts every later body out from under
/// them: a mesh owned by the last body ends up pointing at `rigid_bodies.len()`,
/// and the narrow phase panics on `bodies[owner]`. Anything belonging to a
/// deleted body is dropped outright — a movable body's collision mesh only
/// exists to represent that body (an unowned mesh is static scenery), and a
/// cable anchored to nothing has no constraint left to solve.
///
/// `removed` are the ORIGINAL indices, i.e. as they were before any of the
/// removals happened; ascending order is not required.
fn reindex_after_body_removal(
    state: &mut crate::player::cast_member::HavokPhysicsState,
    removed: &[usize],
) {
    if removed.is_empty() {
        return;
    }
    // Old index -> new index, or None if that body itself went away.
    let remap = |old: usize| -> Option<usize> {
        if removed.contains(&old) {
            return None;
        }
        Some(old - removed.iter().filter(|&&r| r < old).count())
    };

    state.collision_meshes.retain_mut(|mesh| match mesh.body_index {
        Some(owner) => match remap(owner) {
            Some(new_owner) => {
                mesh.body_index = Some(new_owner);
                true
            }
            None => false,
        },
        // Unowned: static scenery, unaffected by body removal.
        None => true,
    });
    state
        .cable_constraints
        .retain_mut(|cable| match remap(cable.body_index) {
            Some(new_owner) => {
                cable.body_index = new_owner;
                true
            }
            None => false,
        });
}

#[cfg(all(test, not(target_arch = "wasm32")))]
mod reindex_tests {
    //! Run with:
    //!   cargo test --lib --manifest-path vm-rust/Cargo.toml reindex

    use super::reindex_after_body_removal;
    use crate::player::cast_member::{HavokCable, HavokPhysicsState, HavokRigidBody};
    use crate::player::symbols::symbol::Symbol;
    use crate::player::symbols::symbol_table::init_symbol_table;

    fn state_with_bodies(n: usize) -> HavokPhysicsState {
        let mut state = HavokPhysicsState::default();
        for i in 0..n {
            state.rigid_bodies.push(HavokRigidBody::new_movable(
                Symbol::from_str(&format!("body{i}")),
                1.0,
                true,
            ));
            state.collision_meshes.push(super::super::havok_physics::CollisionMesh {
                name: Symbol::from_str(&format!("body{i}")),
                vertices: Vec::new(),
                triangles: Vec::new(),
                aabb_min: [0.0; 3],
                aabb_max: [0.0; 3],
                body_index: Some(i),
            });
        }
        // One unowned mesh: static scenery, must always survive untouched.
        state.collision_meshes.push(super::super::havok_physics::CollisionMesh {
            name: Symbol::from_str("scenery"),
            vertices: Vec::new(),
            triangles: Vec::new(),
            aabb_min: [0.0; 3],
            aabb_max: [0.0; 3],
            body_index: None,
        });
        state
    }

    fn owners(state: &HavokPhysicsState) -> Vec<Option<usize>> {
        state.collision_meshes.iter().map(|m| m.body_index).collect()
    }

    #[test]
    fn reindex_shifts_meshes_after_a_removed_body() {
        init_symbol_table();
        let mut state = state_with_bodies(3);
        // Simulate `deleteRigidBody(1)`: body index 0 removed.
        state.rigid_bodies.remove(0);
        reindex_after_body_removal(&mut state, &[0]);

        // Body 0's mesh is gone; 1 and 2 slide down to 0 and 1; scenery intact.
        assert_eq!(owners(&state), vec![Some(0), Some(1), None]);
        // Every surviving owner is a valid index — this is what the narrow
        // phase panicked on (`len is 115 but the index is 115`).
        for owner in owners(&state).into_iter().flatten() {
            assert!(owner < state.rigid_bodies.len());
        }
    }

    #[test]
    fn reindex_handles_the_last_body_and_multiple_removals() {
        init_symbol_table();
        let mut state = state_with_bodies(4);
        // `deleteRigidBody("body1")` semantics: several indices at once,
        // including the LAST body — the case that produced index == len.
        state.rigid_bodies.remove(3);
        state.rigid_bodies.remove(1);
        reindex_after_body_removal(&mut state, &[1, 3]);

        assert_eq!(state.rigid_bodies.len(), 2);
        assert_eq!(owners(&state), vec![Some(0), Some(1), None]);
    }

    #[test]
    fn reindex_drops_cables_anchored_to_a_deleted_body() {
        init_symbol_table();
        let mut state = state_with_bodies(3);
        state.cable_constraints.push(HavokCable {
            body_index: 0,
            anchor: [0.0; 3],
            attach_local: [0.0; 3],
            length: 1.0,
        });
        state.cable_constraints.push(HavokCable {
            body_index: 2,
            anchor: [0.0; 3],
            attach_local: [0.0; 3],
            length: 1.0,
        });

        state.rigid_bodies.remove(0);
        reindex_after_body_removal(&mut state, &[0]);

        // The cable on the deleted body goes; the other follows its body down.
        let cable_owners: Vec<usize> =
            state.cable_constraints.iter().map(|c| c.body_index).collect();
        assert_eq!(cable_owners, vec![1]);
    }
}

pub struct HavokPhysicsMemberHandlers {}

impl HavokPhysicsMemberHandlers {
    pub fn get_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        prop: &str,
    ) -> Result<Datum, ScriptError> {
        // First, read whatever we need from the member with an immutable borrow
        let member = player
            .movie
            .cast_manager
            .find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let state = &havok.state;

        // For simple properties, return immediately (no borrow conflict)
        match prop {
            "initialized" => return Ok(Datum::Int(if state.initialized { 1 } else { 0 })),
            "tolerance" => return Ok(Datum::Float(state.tolerance)),
            "scale" => return Ok(Datum::Float(state.scale)),
            "gravity" => return Ok(Datum::Vector(state.gravity)),
            "simTime" | "simtime" => return Ok(Datum::Float(state.sim_time)),
            "timeStep" | "timestep" => return Ok(Datum::Float(state.time_step)),
            "subSteps" | "substeps" => return Ok(Datum::Int(state.sub_steps)),
            "collisionList" | "collisionlist" => {
                // Return collision data from last step
                // Format: [[bodyA, bodyB, cx, cy, cz, nx, ny, nz], ...]
                let collisions: Vec<_> = state.collision_list_cache.iter().map(|c| {
                    (c.body_a.clone(), c.body_b.clone(), c.point, c.normal)
                }).collect();
                drop(member);  // Release borrow
                let mut items = VecDeque::new();
                for (na, nb, pt, nm) in collisions {
                    let sub_items: VecDeque<DatumRef> = VecDeque::from([
                        player.alloc_datum(Datum::String(na.to_string())),
                        player.alloc_datum(Datum::String(nb.to_string())),
                        player.alloc_datum(Datum::Float(pt[0])),
                        player.alloc_datum(Datum::Float(pt[1])),
                        player.alloc_datum(Datum::Float(pt[2])),
                        player.alloc_datum(Datum::Float(nm[0])),
                        player.alloc_datum(Datum::Float(nm[1])),
                        player.alloc_datum(Datum::Float(nm[2])),
                    ]);
                    items.push_back(player.alloc_datum(Datum::List(DatumType::List, sub_items, false)));
                }
                return Ok(Datum::List(DatumType::List, items, false));
            }
            _ => {} // fall through to list properties below
        }

        // For list properties, collect data first, then drop the borrow
        let names: Vec<Symbol>;
        let list_type: BuiltInSymbol;
        match prop {
            "rigidBody" | "rigidbody" => {
                names = state.rigid_bodies.iter().map(|rb| rb.name.clone()).collect();
                list_type = BuiltInSymbol::RigidBody;
            }
            "spring" => {
                names = state.springs.iter().map(|s| s.name.clone()).collect();
                list_type = BuiltInSymbol::Spring;
            }
            "linearDashpot" | "lineardashpot" => {
                names = state.linear_dashpots.iter().map(|d| d.name.clone()).collect();
                list_type = BuiltInSymbol::LinearDashpot;
            }
            "angularDashpot" | "angulardashpot" => {
                names = state.angular_dashpots.iter().map(|d| d.name.clone()).collect();
                list_type = BuiltInSymbol::AngularDashpot;
            }
            "deactivationParameters" | "deactivationparameters" => {
                let params = state.deactivation_params;
                // Drop borrow by falling out of scope, then alloc
                let a = player.alloc_datum(Datum::Float(params[0]));
                let b = player.alloc_datum(Datum::Float(params[1]));
                return Ok(Datum::List(DatumType::List, VecDeque::from([a, b]), false));
            }
            "dragParameters" | "dragparameters" => {
                let params = state.drag_params;
                let a = player.alloc_datum(Datum::Float(params[0]));
                let b = player.alloc_datum(Datum::Float(params[1]));
                return Ok(Datum::List(DatumType::List, VecDeque::from([a, b]), false));
            }
            _ => return Err(ScriptError::new(format!(
                "Cannot get Havok member property: {}",
                prop
            ))),
        }

        // Now borrow is dropped, we can use player.alloc_datum
        let items: VecDeque<DatumRef> = names.iter().map(|name| {
            player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
                cast_lib: member_ref.cast_lib,
                cast_member: member_ref.cast_member,
                object_type: list_type,
                name: name.clone(),
            }))
        }).collect();
        Ok(Datum::List(DatumType::List, items, false))
    }

    pub fn set_prop(
        member_ref: &CastMemberRef,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        reserve_player_mut(|player| {
            // For list properties, extract float values before borrowing the member mutably
            match prop {
                "deactivationParameters" | "deactivationparameters" => {
                    if let Datum::List(_, items, _) = &value {
                        if items.len() >= 2 {
                            let v0 = player.get_datum(&items[0]).to_float()?;
                            let v1 = player.get_datum(&items[1]).to_float()?;
                            let member = player
                                .movie
                                .cast_manager
                                .find_mut_member_by_ref(member_ref)
                                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                            let havok = match &mut member.member_type {
                                CastMemberType::HavokPhysics(h) => h,
                                _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                            };
                            havok.state.deactivation_params = [v0, v1];
                        }
                    }
                    return Ok(());
                }
                "dragParameters" | "dragparameters" => {
                    if let Datum::List(_, items, _) = &value {
                        if items.len() >= 2 {
                            let v0 = player.get_datum(&items[0]).to_float()?;
                            let v1 = player.get_datum(&items[1]).to_float()?;
                            let member = player
                                .movie
                                .cast_manager
                                .find_mut_member_by_ref(member_ref)
                                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                            let havok = match &mut member.member_type {
                                CastMemberType::HavokPhysics(h) => h,
                                _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                            };
                            havok.state.drag_params = [v0, v1];
                        }
                    }
                    return Ok(());
                }
                _ => {}
            }

            let member = player
                .movie
                .cast_manager
                .find_mut_member_by_ref(member_ref)
                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
            let havok = match &mut member.member_type {
                CastMemberType::HavokPhysics(h) => h,
                _ => return Err(ScriptError::new("Not a Havok member".to_string())),
            };
            let state = &mut havok.state;
            match prop {
                "gravity" => {
                    if let Datum::Vector(v) = &value {
                        state.gravity = *v;
                        // Gravity stored in state.gravity — used by havok_physics::step_native
                    } else {
                        return Err(ScriptError::new("gravity must be a vector".to_string()));
                    }
                    Ok(())
                }
                "timeStep" | "timestep" => {
                    state.time_step = value.to_float()?;
                    Ok(())
                }
                "subSteps" | "substeps" => {
                    state.sub_steps = value.int_value()?;
                    Ok(())
                }
                _ => Err(ScriptError::new(format!(
                    "Cannot set Havok member property: {}",
                    prop
                ))),
            }
        })
    }

    /// Run physics step and return callback info for async invocation.
    /// Returns: (step_result, step_callbacks, collision_callbacks)
    /// Step callbacks: Vec<(handler_name, script_instance, sub_dt)>
    /// Collision callbacks: Vec<(handler_name, script_instance, collision_info_datum)>
    pub fn step_with_callbacks(
        datum: &DatumRef,
        args: &Vec<DatumRef>,
    ) -> Result<(DatumRef, Vec<(Symbol, DatumRef, f64)>, Vec<(Symbol, DatumRef, DatumRef)>), ScriptError> {
        reserve_player_mut(|player| {
            let member_ref = match player.get_datum(datum) {
                Datum::CastMember(r) => r.to_owned(),
                _ => return Err(ScriptError::new("Cannot call Havok handler on non-cast-member".to_string())),
            };

            // Run the physics step
            let step_result = Self::step(player, &member_ref, args)?;

            // Collect step callback and collision interest info as raw data first,
            // then allocate datums afterward (to avoid borrow conflicts with player).
            let member = player.movie.cast_manager.find_member_by_ref(&member_ref);
            let havok = member.and_then(|m| match &m.member_type {
                CastMemberType::HavokPhysics(h) => Some(h),
                _ => None,
            });

            let mut step_cbs: Vec<(Symbol, DatumRef, f64)> = Vec::new();
            // Raw collision data: (handler, instance, body_a, body_b, point, normal, nrv)
            let mut raw_collisions: Vec<(Symbol, DatumRef, Symbol, Symbol, [f64;3], [f64;3], f64)> = Vec::new();

            if let Some(havok) = havok {
                // Step callbacks
                let time_step = havok.state.time_step;
                let sub_steps = havok.state.sub_steps;
                let sub_dt = {
                    let time_inc = if !args.is_empty() {
                        player.get_datum(&args[0]).to_float().unwrap_or(time_step)
                    } else {
                        time_step
                    };
                    let num_sub = if args.len() > 1 {
                        player.get_datum(&args[1]).int_value().unwrap_or(sub_steps)
                    } else {
                        sub_steps
                    };
                    if num_sub > 0 { time_inc / num_sub as f64 } else { time_inc }
                };
                for (handler, instance) in &havok.state.step_callbacks {
                    step_cbs.push((handler.clone(), instance.clone(), sub_dt));
                }

                // Collision interests matched against cached contacts
                for contact in &havok.state.collision_list_cache {
                    for interest in &havok.state.collision_interests {
                        if interest.handler_name.is_none() || interest.script_instance.is_none() { continue; }
                        let matches = if interest.rb_name2 == BuiltInSymbol::All || interest.rb_name2 == BuiltInSymbol::All {
                            contact.body_a == interest.rb_name1
                                || contact.body_b == interest.rb_name1
                        } else {
                            (contact.body_a == interest.rb_name1 && contact.body_b == interest.rb_name2)
                            || (contact.body_a == interest.rb_name2 && contact.body_b == interest.rb_name1)
                        };
                        // Gate on the registerInterest threshold: the Xtra only
                        // fires the callback when the impact (normal relative)
                        // speed reaches the threshold, so a body merely resting on
                        // or sliding along a surface (nrv≈0) doesn't trigger a
                        // collision event. (Frequency throttling is not yet
                        // applied; freq is 0 for the player car so it's a no-op
                        // there, and the scripts self-throttle via sndCollisionWait.)
                        if matches && contact.normal_rel_vel >= interest.threshold {
                            // Report the registered body (rb_name1) first so the
                            // callback can treat cd[1] as "self" and cd[2] as the
                            // other object (matches the Havok Xtra ordering).
                            let (name_self, name_other) =
                                if contact.body_b.eq_ignore_ascii_case(&interest.rb_name1.as_str()) {
                                    (contact.body_b.clone(), contact.body_a.clone())
                                } else {
                                    (contact.body_a.clone(), contact.body_b.clone())
                                };
                            raw_collisions.push((
                                interest.handler_name.clone().unwrap(),
                                interest.script_instance.clone().unwrap(),
                                name_self, name_other,
                                contact.point, contact.normal, contact.normal_rel_vel,
                            ));
                        }
                    }
                }
            }
            drop(member);

            // Now allocate datums (requires mutable player, no longer borrowing havok)
            let mut collision_cbs = Vec::new();
            for (handler, instance, ba, bb, pt, nm, nrv) in raw_collisions {
                // Match the Havok Xtra collision-callback signature
                // `(bodyNameA, bodyNameB, contactPoint, contactNormal, nrv)`:
                // cd[3]/cd[4] are VECTORS and cd[5] is the impact speed. (The old
                // 8-flat-scalar form put contactPoint.z at cd[5], so scripts that
                // read cd[5] as an impact speed — On the Run's DriveHuman damage
                // logic — saw a position instead.)
                let ba_r = player.alloc_datum(Datum::String(ba.to_string()));
                let bb_r = player.alloc_datum(Datum::String(bb.to_string()));
                let pt_r = player.alloc_datum(Datum::Vector(pt));
                let nm_r = player.alloc_datum(Datum::Vector(nm));
                let nrv_r = player.alloc_datum(Datum::Float(nrv));
                let info = player.alloc_datum(Datum::List(
                    DatumType::List,
                    VecDeque::from([ba_r, bb_r, pt_r, nm_r, nrv_r]),
                    false,
                ));
                collision_cbs.push((handler, instance, info));
            }

            Ok((step_result, step_cbs, collision_cbs))
        })
    }

    pub fn call(
        datum: &DatumRef,
        handler_name: &str,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let member_ref = match player.get_datum(datum) {
                Datum::CastMember(r) => r.to_owned(),
                _ => {
                    return Err(ScriptError::new(
                        "Cannot call Havok handler on non-cast-member".to_string(),
                    ))
                }
            };

            match handler_name {
                "initialize" | "Initialize" => Self::initialize(player, &member_ref, args),
                "shutdown" | "shutDown" | "Shutdown" => Self::shutdown(player, &member_ref),
                "step" => Self::step(player, &member_ref, args),

                "reset" => Self::reset(player, &member_ref),
                "rigidBody" | "rigidbody" => Self::get_rigid_body(player, &member_ref, args),
                "spring" => Self::get_spring(player, &member_ref, args),
                "linearDashpot" | "lineardashpot" => {
                    Self::get_linear_dashpot(player, &member_ref, args)
                }
                "angularDashpot" | "angulardashpot" => {
                    Self::get_angular_dashpot(player, &member_ref, args)
                }
                "makeMovableRigidBody" | "makemovablerigidbody" => {
                    Self::make_movable_rigid_body(player, &member_ref, args)
                }
                "makeFixedRigidBody" | "makefixedrigidbody" => {
                    Self::make_fixed_rigid_body(player, &member_ref, args)
                }
                "makeSpring" | "makespring" => Self::make_spring(player, &member_ref, args),
                "makeLinearDashpot" | "makelineardashpot" => {
                    Self::make_linear_dashpot(player, &member_ref, args)
                }
                "makeAngularDashpot" | "makeangulardashpot" => {
                    Self::make_angular_dashpot(player, &member_ref, args)
                }
                "deleteRigidBody" | "deleterigidbody" => {
                    Self::delete_rigid_body(player, &member_ref, args)
                }
                "deleteSpring" | "deletespring" => {
                    Self::delete_spring(player, &member_ref, args)
                }
                "deleteLinearDashpot" | "deletelineardashpot" => {
                    Self::delete_linear_dashpot(player, &member_ref, args)
                }
                "deleteAngularDashpot" | "deleteangulardashpot" => {
                    Self::delete_angular_dashpot(player, &member_ref, args)
                }
                "registerInterest" | "registerinterest" => {
                    Self::register_interest(player, &member_ref, args)
                }
                "removeInterest" | "removeinterest" => {
                    Self::remove_interest(player, &member_ref, args)
                }
                "registerStepCallback" | "registerstepcallback" => {
                    Self::register_step_callback(player, &member_ref, args)
                }
                "removeStepCallback" | "removestepcallback" => {
                    Self::remove_step_callback(player, &member_ref, args)
                }
                "enableCollision" | "enablecollision" => {
                    Self::enable_collision(player, &member_ref, args)
                }
                "disableCollision" | "disablecollision" => {
                    Self::disable_collision(player, &member_ref, args)
                }
                "enableAllCollisions" | "enableallcollisions" => {
                    Self::enable_all_collisions(player, &member_ref, args)
                }
                "disableAllCollisions" | "disableallcollisions" => {
                    Self::disable_all_collisions(player, &member_ref, args)
                }
                "getProp" => {
                    let prop = player.get_datum(&args[0]).string_value()?;
                    let result = Self::get_prop(player, &member_ref, &prop)?;
                    Ok(player.alloc_datum(result))
                }
                "count" => {
                    // count(#rigidBody) etc.
                    let prop = player.get_datum(&args[0]).string_value()?;
                    let list_datum = Self::get_prop(player, &member_ref, &prop)?;
                    if let Datum::List(_, items, _) = &list_datum {
                        Ok(player.alloc_datum(Datum::Int(items.len() as i32)))
                    } else {
                        Ok(player.alloc_datum(Datum::Int(0)))
                    }
                }
                "getAt" | "getPropRef" => {
                    // member("havok").rigidBody[i] — getAt dispatches here
                    let prop = player.get_datum(&args[0]).string_value()?;
                    let list_datum = Self::get_prop(player, &member_ref, &prop)?;
                    if args.len() > 1 {
                        let index = player.get_datum(&args[1]).int_value()?;
                        if let Datum::List(_, items, _) = &list_datum {
                            let idx = (index as usize).saturating_sub(1);
                            if idx < items.len() {
                                Ok(items[idx].clone())
                            } else {
                                Ok(DatumRef::Void)
                            }
                        } else {
                            Ok(DatumRef::Void)
                        }
                    } else {
                        Ok(player.alloc_datum(list_datum))
                    }
                }
                _ => Err(ScriptError::new(format!(
                    "No handler {} for Havok member",
                    handler_name
                ))),
            }
        })
    }

    // --- Method implementations ---

    fn initialize(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        // initialize(w3dMember [, tolerance, worldScale])
        let w3d_ref = match player.get_datum(&args[0]) {
            Datum::CastMember(r) => r.to_owned(),
            _ => {
                return Err(ScriptError::new(
                    "Havok initialize: first argument must be a W3D member".to_string(),
                ))
            }
        };

        let tolerance = if args.len() > 1 {
            player.get_datum(&args[1]).to_float()?
        } else {
            0.1
        };
        // Use the HKE worldScale when no explicit scale arg is provided.
        // SuperSonic HKE: 0.0254, HavokCarDemo HKE: 0.0125.
        let hke_scale = {
            let member = player.movie.cast_manager.find_member_by_ref(member_ref);
            member.and_then(|m| match &m.member_type {
                CastMemberType::HavokPhysics(h) if !h.state.hke_data.is_empty() => {
                    let hke = super::hke_parser::parse_hke(&h.state.hke_data);
                    if hke.world_scale > 0.001 { Some(hke.world_scale as f64) } else { None }
                }
                _ => None,
            })
        };
        let scale = if args.len() > 2 {
            player.get_datum(&args[2]).to_float()?
        } else if let Some(hs) = hke_scale {
            hs
        } else {
            0.0254
        };

        // Read existing rigid body names and model transforms from the W3D scene
        let (model_names, model_transforms): (Vec<Symbol>, std::collections::HashMap<Symbol, [f32; 16]>) = {
            let w3d_member = player
                .movie
                .cast_manager
                .find_member_by_ref(&w3d_ref);
            if let Some(m) = w3d_member {
                if let Some(w3d) = m.member_type.as_shockwave3d() {
                    if let Some(scene) = &w3d.parsed_scene {
                        let names = scene.nodes.iter().map(|n| n.name).collect_vec();
                        let transforms: std::collections::HashMap<Symbol, [f32; 16]> = scene.nodes.iter()
                            .map(|n| (n.name, n.transform))
                            .collect();
                        (names, transforms)
                    } else {
                        (Vec::new(), std::collections::HashMap::new())
                    }
                } else {
                    (Vec::new(), std::collections::HashMap::new())
                }
            } else {
                (Vec::new(), std::collections::HashMap::new())
            }
        };

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        havok.state.initialized = true;
        havok.state.w3d_cast_lib = w3d_ref.cast_lib;
        havok.state.w3d_cast_member = w3d_ref.cast_member;
        havok.state.tolerance = tolerance;
        havok.state.scale = scale;
        // Default gravity: 9.81 m/s² converted to display units via worldScale.
        // With scale=0.0254 (inches): -9.81/0.0254 = -386.22 in/s²
        // With scale=0.03: -9.81/0.03 = -327.0 units/s²
        let g = if scale.abs() > 1e-10 { 9.81 / scale } else { 386.22 };
        havok.state.gravity = [0.0, 0.0, -g];
        havok.state.sim_time = 0.0;

        // Load HKE meshes into native collision system (for havok_physics.rs)
        // and auto-create rigid bodies for each model with HKE collision data.
        // The real Havok Xtra creates rigid bodies during Initialize() so that
        // scripts can look them up via rigidBody("name") without explicit
        // makeFixedRigidBody/makeMovableRigidBody calls.
        if !havok.state.hke_data.is_empty() {
            let hke = super::hke_parser::parse_hke(&havok.state.hke_data);

            // Apply HKE gravity (in Havok meters/s², convert to display units)
            if let Some(g) = hke.gravity {
                let inv_s = if scale.abs() > 1e-10 { 1.0 / scale } else { 1.0 };
                havok.state.gravity = [
                    g[0] as f64 * inv_s,
                    g[1] as f64 * inv_s,
                    g[2] as f64 * inv_s,
                ];
            }

            // Apply the modeler-authored collision tolerance from the HKE subspace
            // unless the movie passed an explicit tolerance to initialize(). The
            // Xtra (and the C# HkeParser) take it from the .hke; our hardcoded 0.1
            // default is only meant for `initialize(member)` calls whose HKE omits
            // it. On the Run authors 0.35 — the tolerance sets how far a resting
            // body floats above a surface, so with 0.1 the car sat ~0.1 above the
            // road, below the ~0.2 raised (visual-only) sidewalk curbs, and
            // modelsUnderRay then found no ground (pheight=9999 → couldn't drive).
            if args.len() <= 1 {
                if let Some(t) = hke.tolerance {
                    havok.state.tolerance = t as f64;
                }
            }

            // Apply HKE drag parameters as initial defaults
            // (scripts can override via havok.dragParameters = [...])
            if let Some(ref drag) = hke.drag {
                havok.state.drag_params = [drag.linear_drag as f64, drag.angular_drag as f64];
            }

            // Disable ground constraint hack for HKE scenes with movable bodies.
            // Those scenes handle ground contact via script hover/spring forces.
            let has_movable = hke.bodies.iter().any(|b| b.total_mass > 0.0);
            if has_movable {
                havok.state.use_ground_constraint = false;
            }

            let inv_scale = if scale.abs() > 1e-10 { 1.0 / scale } else { 1.0 };
            havok.state.collision_meshes.clear();
            havok.state.rigid_bodies.clear();

            // Build lookup from body name → parsed properties (mass, restitution, etc.)
            let body_props: std::collections::HashMap<Symbol, &super::hke_parser::HkeBodyProps> = hke.bodies.iter()
                .map(|b| (b.name, b))
                .collect();

            for mesh in &hke.meshes {
                if mesh.vertices.is_empty() || mesh.triangles.is_empty() { continue; }
                let model_xform = model_transforms.get(&Symbol::from_str(&mesh.name.to_lowercase()));
                let xform_rt: Option<[f64; 12]> = model_xform.map(|t| {
                    let mut c0 = [t[0] as f64, t[1] as f64, t[2] as f64];
                    let mut c1 = [t[4] as f64, t[5] as f64, t[6] as f64];
                    let mut c2 = [t[8] as f64, t[9] as f64, t[10] as f64];
                    let n0 = (c0[0]*c0[0]+c0[1]*c0[1]+c0[2]*c0[2]).sqrt();
                    let n1 = (c1[0]*c1[0]+c1[1]*c1[1]+c1[2]*c1[2]).sqrt();
                    let n2 = (c2[0]*c2[0]+c2[1]*c2[1]+c2[2]*c2[2]).sqrt();
                    if n0 > 1e-9 { for k in 0..3 { c0[k] /= n0; } }
                    if n1 > 1e-9 { for k in 0..3 { c1[k] /= n1; } }
                    if n2 > 1e-9 { for k in 0..3 { c2[k] /= n2; } }
                    [c0[0],c0[1],c0[2], c1[0],c1[1],c1[2], c2[0],c2[1],c2[2], t[12] as f64, t[13] as f64, t[14] as f64]
                });
                // Primitive shape offset, body-local, Havok metres -> display units.
                //
                // `Import` moves the body origin onto DISPLACEMENT (the authored centre
                // of mass) and offsets every primitive by -DISPLACEMENT so the shape
                // stays where it was authored. We honoured the COM half of that pair but
                // read `local_translation` only for Sphere primitives, so mesh hulls sat
                // at the body origin instead of under it. Age of Speed's chassis is
                // offset by (0.007, 3.52, -27.11): without it the hull spans z
                // [-7.8, 61.0] and cannot touch the road until jump 7.8, where Director
                // scrapes the loop continuously from jump 43.5 and never sinks past 27.8.
                let mesh_name_lc = mesh.name.to_string().to_lowercase();
                let prim_offset: [f64; 3] = body_props.get(&mesh.name)
                    .and_then(|p| p.primitives.iter().find_map(|pr| match &pr.kind {
                        super::hke_parser::HkePrimitiveKind::Mesh { mesh_name }
                            if mesh_name.to_lowercase() == mesh_name_lc => Some(pr.local_translation),
                        _ => None,
                    }))
                    .map(|t| [t[0] as f64 * inv_scale, t[1] as f64 * inv_scale, t[2] as f64 * inv_scale])
                    .unwrap_or([0.0; 3]);

                let vertices: Vec<[f64; 3]> = mesh.vertices.iter()
                    .map(|v| {
                        let lx = v[0] as f64 * inv_scale + prim_offset[0];
                        let ly = v[1] as f64 * inv_scale + prim_offset[1];
                        let lz = v[2] as f64 * inv_scale + prim_offset[2];
                        if let Some(r) = &xform_rt {
                            let wx = r[0]*lx + r[3]*ly + r[6]*lz + r[9];
                            let wy = r[1]*lx + r[4]*ly + r[7]*lz + r[10];
                            let wz = r[2]*lx + r[5]*ly + r[8]*lz + r[11];
                            [wx, wy, wz]
                        } else {
                            [lx, ly, lz]
                        }
                    })
                    .collect();

                // Look up parsed body properties from HKE tail
                let props = body_props.get(&mesh.name);

                // DIAG: Director's chassis hull touches the road from jump 43.5 down,
                // ours only below ~18. Dump everything the HKE authors for the body so
                // the missing depth can be attributed to a real field rather than
                // guessed at.
                let mass = props.map(|p| p.total_mass as f64).unwrap_or(0.0);

                let mut rb = if mass > 0.0 {
                    HavokRigidBody::new_movable(mesh.name, mass, true)
                } else {
                    HavokRigidBody::new_fixed(mesh.name, true)
                };

                // Apply parsed properties
                if let Some(p) = props {
                    if let Some(r) = p.restitution { rb.restitution = r as f64; }
                    if let Some(f) = p.static_friction { rb.friction = f as f64; }
                    // Honour the HKE active flag: bodies authored at rest start
                    // asleep (frozen) and only simulate once disturbed. This is
                    // why the warehouse stack stays put until the lone active
                    // crate slides into it.
                    if mass > 0.0 { if let Some(act) = p.active { rb.active = act; } }
                    if let Some(v) = p.linear_velocity {
                        rb.linear_velocity = [v[0] as f64*inv_scale, v[1] as f64*inv_scale, v[2] as f64*inv_scale];
                    }
                    // Angular velocity is rad/s — scale-independent, do NOT × inv_scale.
                    if let Some(w) = p.angular_velocity {
                        rb.angular_velocity = [w[0] as f64, w[1] as f64, w[2] as f64];
                    }
                    // Initial orientation from the HKE body's axis-angle. The renderer
                    // syncs the W3D model from rb.orientation (build_sync_transform), so
                    // without this a mesh-derived body kept its identity rotation and
                    // the car spawned facing the wrong way — the HKE places AutoPlayer
                    // rotated 90 degrees about Z. Axis-angle is scale-independent.
                    if let Some(o) = p.orientation {
                        rb.orientation = super::havok_physics::quat_from_axis_angle(
                            [o[1] as f64, o[2] as f64, o[3] as f64], o[0] as f64);
                    }
                    // COLLISIONS_DISABLED: keep the body out of the collision detector.
                    if let Some(cd) = p.collisions_disabled { rb.collisions_disabled = cd; }
                    // CASTS_SHADOWS: render metadata (no physics effect).
                    if let Some(cs) = p.casts_shadows { rb.casts_shadows = cs; }
                    // DISPLACEMENT is the authored centre of mass (Havok metres); Import
                    // writes it over the geometric COM. Scale metres → display units.
                    if let Some(d) = p.displacement {
                        rb.center_of_mass = [d[0] as f64*inv_scale, d[1] as f64*inv_scale, d[2] as f64*inv_scale];
                    }
                }

                // Set position + authored model scale from the W3D transform.
                if let Some(t) = model_xform {
                    rb.position = [t[12] as f64, t[13] as f64, t[14] as f64];
                    let s0 = ((t[0]as f64).powi(2)+(t[1]as f64).powi(2)+(t[2]as f64).powi(2)).sqrt();
                    let s1 = ((t[4]as f64).powi(2)+(t[5]as f64).powi(2)+(t[6]as f64).powi(2)).sqrt();
                    let s2 = ((t[8]as f64).powi(2)+(t[9]as f64).powi(2)+(t[10]as f64).powi(2)).sqrt();
                    rb.sync_scale = [
                        if s0 > 1e-9 { s0 } else { 1.0 },
                        if s1 > 1e-9 { s1 } else { 1.0 },
                        if s2 > 1e-9 { s2 } else { 1.0 },
                    ];
                }
                let rb_index = havok.state.rigid_bodies.len();
                havok.state.rigid_bodies.push(rb);

                // Store the collision hull in BODY-LOCAL space for movable bodies.
                // `vertices` is baked in world space at the spawn pose; convert it to
                // local (relative to the body's spawn position, un-rotated by its spawn
                // orientation) so the narrow phase can transform it to the live pose
                // each frame. Lets a hover vehicle collide with its actual chassis
                // shape against scenery instead of a blocky bounding box.
                if mass > 0.0 {
                    use super::havok_physics::{quat_conjugate, quat_rotate_v, v3_sub};
                    let spawn = &havok.state.rigid_bodies[rb_index];
                    let pos0 = spawn.position;
                    let inv_q = quat_conjugate(spawn.orientation);
                    let local: Vec<[f64; 3]> = vertices.iter()
                        .map(|w| quat_rotate_v(inv_q, v3_sub(*w, pos0)))
                        .collect();
                    havok.state.rigid_bodies[rb_index].collision_hull_local = local;
                }

                // Only link collision mesh to movable bodies. Fixed body meshes
                // stay unowned (body_index=None) so the ground contact filter
                // can skip them — hover/spring scripts handle ground interaction.
                let mesh_body_index = if mass > 0.0 { Some(rb_index) } else { None };
                let mut cmesh = super::havok_physics::CollisionMesh {
                    name: mesh.name.clone(),
                    vertices,
                    triangles: mesh.triangles.clone(),
                    aabb_min: [0.0; 3],
                    aabb_max: [0.0; 3],
                    body_index: mesh_body_index,
                };
                cmesh.compute_aabb();

                if mass > 0.0 {
                    let (mut lmn, mut lmx) = ([f64::MAX; 3], [f64::MIN; 3]);
                    for v in &mesh.vertices {
                        for i in 0..3 {
                            let c = v[i] as f64 * inv_scale + prim_offset[i];
                            if c < lmn[i] { lmn[i] = c; }
                            if c > lmx[i] { lmx[i] = c; }
                        }
                    }
                    let he = [0.5*(lmx[0]-lmn[0]).abs(), 0.5*(lmx[1]-lmn[1]).abs(), 0.5*(lmx[2]-lmn[2]).abs()];
                    // COM = local box centre = body-frame offset from the node
                    // origin (model base) to the collision-box centre.
                    let com = [0.5*(lmn[0]+lmx[0]), 0.5*(lmn[1]+lmx[1]), 0.5*(lmn[2]+lmx[2])];
                    // Unit inertia from the actual mesh polyhedron (the engine derives
                    // mass properties from geometry). A box-AABB inertia is wrong about
                    // the pitch axis for a long flat chassis. Box fallback for
                    // degenerate/open meshes.
                    // Inertia is built from the RAW, UNROTATED mesh vertices — the body's
                    // own frame. It must NOT be pre-rotated by the node/spawn transform.
                    //
                    // The previous code pre-rotated these by the node/spawn transform,
                    // on the assumption that the integrator would otherwise rotate the
                    // tensor a second time when forming the world inverse inertia. That
                    // assumption is wrong: the angular update applies the BODY-frame
                    // inverse inertia DIRECTLY to a world-frame torque, with no
                    // R·Iinv·Rᵀ. Pre-rotating therefore baked the placement rotation
                    // into the tensor and applied it once too often.
                    //
                    // Verified against Director on FinalDrive's chassis: the angular
                    // response to a known torque, predicted from the raw-vertex tensor
                    // applied body-direct, matches Director's measured direction to
                    // 0.00°; the pre-rotated form is 28.45° off. (applyAngularImpulse is
                    // a separate path that does use the world tensor, and already matched.)
                    let local_verts: Vec<[f64; 3]> = mesh.vertices.iter()
                        .map(|v| [
                            v[0] as f64 * inv_scale,
                            v[1] as f64 * inv_scale,
                            v[2] as f64 * inv_scale,
                        ])
                        .collect();
                    let unit_i = super::havok_physics::compute_polyhedron_unit_inertia(&local_verts, &mesh.triangles)
                        .map(|(ui, _com, _vol)| ui)
                        .unwrap_or_else(|| super::havok_physics::box_unit_inertia(he));
                    let (mut it, mut inv_it, mut inv_m) = ([0.0; 9], [0.0; 9], 0.0);
                    super::havok_physics::recompute_body_inertia(mass, unit_i, &mut it, &mut inv_it, &mut inv_m);
                    let rb = &mut havok.state.rigid_bodies[rb_index];
                    rb.inertia_half_extents = he;
                    // Keep the authored DISPLACEMENT (the HKE's real COM, already assigned
                    // from p.displacement above) — only fall back to the geometric box-centre
                    // when no COM was authored. The unconditional overwrite discarded it: the
                    // FinalDrive chassis got the mesh-AABB centre (0.37,2.72,-3.65) instead of
                    // its real COM (0.49,4.20,-4.95), shifting wheel ray origins + mis-kicking.
                    if props.and_then(|p| p.displacement).is_none() {
                        rb.center_of_mass = com;
                    }
                    rb.unit_inertia_tensor = unit_i;
                    rb.inertia_tensor = it;
                    rb.inverse_inertia_tensor = inv_it;
                    rb.inverse_mass = inv_m;
                }

                havok.state.collision_meshes.push(cmesh);
            }

            // Per-ENTRY-mesh half-extents in Director units, plus a shared
            // fallback box (the first mesh) for bodies whose mesh primitive
            // references geometry that is only stored once (e.g. the warehouse
            // crates all reuse the single "Crate01" box).
            // mesh name -> (half-extents, local centre), both Director units.
            let mut mesh_geo: std::collections::HashMap<String, ([f64; 3], [f64; 3])> = std::collections::HashMap::new();
            let mut fallback_geo: Option<([f64; 3], [f64; 3])> = None;
            for mesh in &hke.meshes {
                if mesh.vertices.is_empty() { continue; }
                let (mut mn, mut mx) = ([f64::MAX; 3], [f64::MIN; 3]);
                for v in &mesh.vertices {
                    for i in 0..3 {
                        let c = v[i] as f64 * inv_scale;
                        if c < mn[i] { mn[i] = c; }
                        if c > mx[i] { mx[i] = c; }
                    }
                }
                let he = [0.5*(mx[0]-mn[0]).abs(), 0.5*(mx[1]-mn[1]).abs(), 0.5*(mx[2]-mn[2]).abs()];
                let center = [0.5*(mn[0]+mx[0]), 0.5*(mn[1]+mx[1]), 0.5*(mn[2]+mx[2])];
                mesh_geo.insert(mesh.name.to_lowercase(), (he, center));
                if fallback_geo.is_none() { fallback_geo = Some((he, center)); }
            }

            // Create rigid bodies for HKE tail entries that have no ENTRY mesh.
            // Positions come from the matching W3D node transform (so the
            // physics world aligns with the rendered scene); plane primitives
            // become large static quad colliders (floor + walls).
            for body_def in &hke.bodies {
                let already_exists = havok.state.rigid_bodies.iter()
                    .any(|rb| rb.name == body_def.name);
                if already_exists { continue; }

                let mass = body_def.total_mass as f64;
                let mut rb = if mass > 0.0 {
                    HavokRigidBody::new_movable(body_def.name, mass, true)
                } else {
                    HavokRigidBody::new_fixed(body_def.name, true)
                };
                if let Some(r) = body_def.restitution { rb.restitution = r as f64; }
                if let Some(f) = body_def.static_friction { rb.friction = f as f64; }
                if mass > 0.0 { if let Some(act) = body_def.active { rb.active = act; } }
                if let Some(v) = body_def.linear_velocity {
                    rb.linear_velocity = [v[0] as f64*inv_scale, v[1] as f64*inv_scale, v[2] as f64*inv_scale];
                }
                // Angular velocity is rad/s — scale-independent, do NOT × inv_scale.
                if let Some(w) = body_def.angular_velocity {
                    rb.angular_velocity = [w[0] as f64, w[1] as f64, w[2] as f64];
                }
                if let Some(cd) = body_def.collisions_disabled { rb.collisions_disabled = cd; }
                if let Some(cs) = body_def.casts_shadows { rb.casts_shadows = cs; }
                // DISPLACEMENT = authored centre of mass (Havok metres), overrides geometric.
                if let Some(d) = body_def.displacement {
                    rb.center_of_mass = [d[0] as f64*inv_scale, d[1] as f64*inv_scale, d[2] as f64*inv_scale];
                }

                // World transform: prefer the W3D node (matches the render),
                // fall back to the HKE translation converted to Director units.
                let xform = model_transforms.get(&Symbol::from_str(&body_def.name.to_lowercase())).copied();
                if let Some(t) = xform {
                    rb.position = [t[12] as f64, t[13] as f64, t[14] as f64];
                } else if let Some(t) = body_def.translation {
                    rb.position = [t[0] as f64 * inv_scale, t[1] as f64 * inv_scale, t[2] as f64 * inv_scale];
                }

                // Size + inertia for movable bodies from their primitive geometry.
                if mass > 0.0 {
                    let (he, com) = body_def.primitives.iter().find_map(|p| match &p.kind {
                        super::hke_parser::HkePrimitiveKind::Mesh { mesh_name } =>
                            mesh_geo.get(&mesh_name.to_lowercase()).copied().or(fallback_geo),
                        super::hke_parser::HkePrimitiveKind::Sphere { radius } => {
                            let r = (*radius as f64 * inv_scale).abs();
                            // Sphere centre offset = its primitive-local translation.
                            let lt = p.local_translation;
                            Some(([r, r, r], [lt[0] as f64*inv_scale, lt[1] as f64*inv_scale, lt[2] as f64*inv_scale]))
                        }
                        super::hke_parser::HkePrimitiveKind::Plane { .. } => None,
                    }).or(fallback_geo).unwrap_or(([10.0; 3], [0.0; 3]));

                    let unit_i = super::havok_physics::box_unit_inertia(he);
                    let (mut it, mut inv_it, mut inv_m) = ([0.0; 9], [0.0; 9], 0.0);
                    super::havok_physics::recompute_body_inertia(mass, unit_i, &mut it, &mut inv_it, &mut inv_m);
                    rb.inertia_half_extents = he;
                    // Keep the authored DISPLACEMENT COM (tail-only body path) — same fix as
                    // the mesh-body path above; only use the geometric centre if none authored.
                    if body_def.displacement.is_none() {
                        rb.center_of_mass = com;
                    }
                    rb.unit_inertia_tensor = unit_i;
                    rb.inertia_tensor = it;
                    rb.inverse_inertia_tensor = inv_it;
                    rb.inverse_mass = inv_m;
                }

                let body_pos = rb.position;
                havok.state.rigid_bodies.push(rb);

                // Build static quad colliders from plane primitives (floor/walls).
                if mass <= 0.0 {
                    for prim in &body_def.primitives {
                        if let super::hke_parser::HkePrimitiveKind::Plane { normal, .. } = &prim.kind {
                            // World normal = body rotation * local plane normal.
                            let n_world = if let Some(t) = xform {
                                // 3x3 columns of the column-major 4x4.
                                let n = [
                                    t[0] as f64*normal[0] as f64 + t[4] as f64*normal[1] as f64 + t[8] as f64*normal[2] as f64,
                                    t[1] as f64*normal[0] as f64 + t[5] as f64*normal[1] as f64 + t[9] as f64*normal[2] as f64,
                                    t[2] as f64*normal[0] as f64 + t[6] as f64*normal[1] as f64 + t[10] as f64*normal[2] as f64,
                                ];
                                super::havok_physics::v3_normalized(n)
                            } else if let Some(o) = body_def.orientation {
                                let q = super::havok_physics::quat_from_axis_angle(
                                    [o[1] as f64, o[2] as f64, o[3] as f64], o[0] as f64);
                                super::havok_physics::v3_normalized(
                                    super::havok_physics::quat_rotate_v(q, [normal[0] as f64, normal[1] as f64, normal[2] as f64]))
                            } else {
                                [normal[0] as f64, normal[1] as f64, normal[2] as f64]
                            };

                            if let Some(cmesh) = build_plane_quad(&body_def.name.as_str(), body_pos, n_world) {
                                havok.state.collision_meshes.push(cmesh);
                            }
                        }
                    }
                }
            }
        }

        // Build point-to-point (cable) constraints. Keyed by the HKE constraint
        // TYPE, not by name — the anchor is body A's world-transformed pivot,
        // the bob is body B (the movable one, e.g. the lamp). We hold the bob at
        // its initial distance from the anchor so it hangs where authored and
        // swings like a pendulum rather than falling.
        if !havok.state.hke_data.is_empty() {
            let hke = super::hke_parser::parse_hke(&havok.state.hke_data);
            for cable in &hke.cables {
                let idx_b = havok.state.rigid_bodies.iter()
                    .position(|rb| rb.name.eq_ignore_ascii_case(&cable.body_b));
                let idx_b = match idx_b { Some(i) => i, None => continue };

                // Anchor = body A's world transform applied to pivot A.
                let xform_a = model_transforms.get(&Symbol::from_str(&cable.body_a.to_lowercase())).copied();
                let inv_scale = if scale.abs() > 1e-10 { 1.0 / scale } else { 1.0 };
                let pa = [cable.pivot_a[0] as f64*inv_scale, cable.pivot_a[1] as f64*inv_scale, cable.pivot_a[2] as f64*inv_scale];
                let anchor = if let Some(t) = xform_a {
                    [
                        t[0] as f64*pa[0] + t[4] as f64*pa[1] + t[8] as f64*pa[2] + t[12] as f64,
                        t[1] as f64*pa[0] + t[5] as f64*pa[1] + t[9] as f64*pa[2] + t[13] as f64,
                        t[2] as f64*pa[0] + t[6] as f64*pa[1] + t[10] as f64*pa[2] + t[14] as f64,
                    ]
                } else {
                    pa
                };

                let attach_local = [cable.pivot_b[0] as f64*inv_scale, cable.pivot_b[1] as f64*inv_scale, cable.pivot_b[2] as f64*inv_scale];

                // Bob world attach point at init, and the constraint distance.
                let rb = &havok.state.rigid_bodies[idx_b];
                let attach_world = super::havok_physics::v3_add(
                    rb.position,
                    super::havok_physics::quat_rotate_v(rb.orientation, attach_local),
                );
                let init_dist = super::havok_physics::v3_len(
                    super::havok_physics::v3_sub(attach_world, anchor));
                let length = if init_dist > 1e-3 { init_dist } else { (cable.length as f64 * inv_scale).abs() };

                havok.state.cable_constraints.push(crate::player::cast_member::HavokCable {
                    body_index: idx_b,
                    anchor,
                    attach_local,
                    length,
                });
            }
        }

        // Snapshot every body's authored state so havok.reset() can revert the
        // scene to the .hke-defined state.
        for rb in &mut havok.state.rigid_bodies {
            rb.snapshot_initial();
        }

        let movable_names: Vec<String> = havok.state.rigid_bodies.iter()
            .filter(|rb| !rb.pinned && rb.mass > 0.0)
            .map(|rb| format!("{}({:.1})", rb.name, rb.mass)).collect();
        debug!(
            "Havok initialized: scale={}, gravity=({:.2},{:.2},{:.2}), drag=({:.2},{:.2}), bodies={} ({} movable: {:?})",
            scale,
            havok.state.gravity[0], havok.state.gravity[1], havok.state.gravity[2],
            havok.state.drag_params[0], havok.state.drag_params[1],
            havok.state.rigid_bodies.len(), movable_names.len(), movable_names
        );

        Ok(DatumRef::Void)
    }

    fn shutdown(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
    ) -> Result<DatumRef, ScriptError> {
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        havok.state.initialized = false;
        havok.state.rigid_bodies.clear();
        havok.state.springs.clear();
        havok.state.cable_constraints.clear();
        havok.state.linear_dashpots.clear();
        havok.state.angular_dashpots.clear();
        havok.state.collision_meshes.clear();
        havok.state.collision_interests.clear();
        havok.state.step_callbacks.clear();
        havok.state.disabled_collision_pairs.clear();
        havok.state.collision_list_cache.clear();
        havok.state.sim_time = 0.0;

        Ok(DatumRef::Void)
    }

    fn step(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let time_increment = if !args.is_empty() {
            player.get_datum(&args[0]).to_float()?
        } else {
            let member = player
                .movie
                .cast_manager
                .find_member_by_ref(member_ref)
                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
            match &member.member_type {
                CastMemberType::HavokPhysics(h) => h.state.time_step,
                _ => 1.0 / 60.0,
            }
        };
        let num_sub_steps = if args.len() > 1 {
            player.get_datum(&args[1]).int_value()?
        } else {
            let member = player
                .movie
                .cast_manager
                .find_member_by_ref(member_ref)
                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
            match &member.member_type {
                CastMemberType::HavokPhysics(h) => h.state.sub_steps,
                _ => 4,
            }
        };

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        // Use native Havok physics (replaces Rapier)
        super::havok_physics::step_native(&mut havok.state, time_increment, num_sub_steps);

        // Detect ground Z on first step if not set
        // Derive ground Z from the scene if not set yet.
        // If we have collision meshes, the per-body raycast in
        // apply_ground_constraints handles it. Otherwise use the
        // lowest fixed body as a ground plane estimate.
        if havok.state.ground_z < -1e10 {
            let mut min_z = f64::MAX;
            for rb in &havok.state.rigid_bodies {
                if rb.is_fixed && rb.position[2] < min_z {
                    min_z = rb.position[2];
                }
            }
            if min_z < f64::MAX {
                havok.state.ground_z = min_z;
            }
        }

        // Collect W3D sync data using quaternion-based transform builder
        let w3d_cast_lib = havok.state.w3d_cast_lib;
        let w3d_cast_member = havok.state.w3d_cast_member;
        let sync_data: Vec<(Symbol, [f32; 16])> = havok.state.rigid_bodies.iter()
            .filter(|rb| !rb.is_fixed && rb.active)
            .map(|rb| {
                let t = super::havok_physics::build_sync_transform(
                    rb.position, rb.orientation, rb.center_of_mass, rb.sync_scale,
                );
                (rb.name, t)
            })
            .collect();

        // Clear forces (already done in step_native, but ensure clean state)

        // Drop havok borrow, sync to W3D. Use set_node_transform so that both
        // the renderer's node_transforms AND the cached persistent Transform3d
        // datum (read by Lingo via pCar.getModel().transform) are updated.
        // Without this, Lingo sees a stale initial transform and wheel.ls's
        // `pCar.getModel().transform.inverse() * pRealWorldPos` produces garbage
        // local points → wrong torque lever arms → car flips.
        drop(member);
        let w3d_ref = CastMemberRef { cast_lib: w3d_cast_lib, cast_member: w3d_cast_member };
        for (name, t) in &sync_data {
            if t.iter().any(|v| !v.is_finite()) { continue; }
            crate::player::handlers::datum_handlers::shockwave3d_object::set_node_transform(
                player, &w3d_ref, *name, *t,
            );
        }

        Ok(DatumRef::Void)
    }

    fn reset(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
    ) -> Result<DatumRef, ScriptError> {
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        // havok.reset() "reverts the entire scene back to the state defined in
        // the .hke file": restore every body to its authored initial transform,
        // velocity and active flag, and clear runtime state.
        havok.state.sim_time = 0.0;
        havok.state.collision_list_cache.clear();
        for rb in &mut havok.state.rigid_bodies {
            rb.restore_initial();
        }

        // Write the restored transforms back to the W3D scene so the models snap
        // to their start positions (same path step() uses). Sync all non-fixed
        // bodies regardless of active flag so even authored-asleep bodies reset.
        let w3d_cast_lib = havok.state.w3d_cast_lib;
        let w3d_cast_member = havok.state.w3d_cast_member;
        let sync_data: Vec<(Symbol, [f32; 16])> = havok.state.rigid_bodies.iter()
            .filter(|rb| !rb.is_fixed)
            .map(|rb| {
                let t = super::havok_physics::build_sync_transform(
                    rb.position, rb.orientation, rb.center_of_mass, rb.sync_scale,
                );
                (rb.name, t)
            })
            .collect();
        drop(member);
        let w3d_ref = CastMemberRef { cast_lib: w3d_cast_lib, cast_member: w3d_cast_member };
        for (name, t) in &sync_data {
            if t.iter().any(|v| !v.is_finite()) { continue; }
            crate::player::handlers::datum_handlers::shockwave3d_object::set_node_transform(
                player, &w3d_ref, Symbol::from_str(name.as_str()), *t,
            );
        }
        Ok(DatumRef::Void)
    }

    fn get_rigid_body(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        // Verify the rigid body exists
        let member = player
            .movie
            .cast_manager
            .find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let found = havok
            .state
            .rigid_bodies
            .iter()
            .any(|rb| rb.name == name);

        // Director returns VOID for a name that isn't a live rigid body; scripts
        // rely on it (unicraft's initHavok: `repeat with rb in getRBList(...) / if
        // rb = VOID then exit repeat`). Returning a ref for a missing body made a
        // later `disableCollision(rb.name, ...)` throw "not found".
        if !found {
            return Ok(player.alloc_datum(Datum::Void));
        }

        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::RigidBody,
            name,
        })))
    }

    fn get_spring(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::Spring,
            name,
        })))
    }

    fn get_linear_dashpot(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::LinearDashpot,
            name,
        })))
    }

    fn get_angular_dashpot(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::AngularDashpot,
            name,
        })))
    }

    fn make_movable_rigid_body(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let model_name = player.get_datum(&args[0]).symbol_value()?;
        let mass = player.get_datum(&args[1]).to_float()?;
        let is_convex = if args.len() > 2 {
            player.get_datum(&args[2]).int_value()? != 0
        } else {
            true
        };
        // Optional 4th arg: shape type (#sphere, #box). Default = convex hull from mesh.
        let shape_type = if args.len() > 3 {
            player.get_datum(&args[3]).symbol_value().unwrap_or_default()
        } else {
            Symbol::empty()
        };

        // Read model's initial transform + mesh bounding box + vertices/faces from W3D scene
        let (initial_position, mesh_half_extents, mesh_vertices, mesh_faces, prim_type) = {
            let member = player
                .movie
                .cast_manager
                .find_member_by_ref(member_ref)
                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
            let havok = match &member.member_type {
                CastMemberType::HavokPhysics(h) => h,
                _ => return Err(ScriptError::new("Not a Havok member".to_string())),
            };
            let w3d_ref = CastMemberRef {
                cast_lib: havok.state.w3d_cast_lib,
                cast_member: havok.state.w3d_cast_member,
            };
            let w3d_member = player.movie.cast_manager.find_member_by_ref(&w3d_ref);
            if let Some(m) = w3d_member {
                if let Some(w3d) = m.member_type.as_shockwave3d() {
                    // Read position from: 1) runtime node_transforms, 2) persistent
                    // Transform3d datum (set by Lingo but not yet synced to renderer),
                    // 3) parsed scene node transform, 4) default [0,0,0].
                    let pos = w3d.runtime_state.node_transforms
                        .get(&model_name)
                        .or_else(|| w3d.runtime_state.node_transforms.iter()
                            .find(|(k, _)| **k == model_name).map(|(_, v)| v))
                        .map(|t| [t[12] as f64, t[13] as f64, t[14] as f64])
                        .or_else(|| {
                            // Check persistent datum (Lingo may have set transform.position
                            // but sync_persistent_transforms hasn't run yet)
                            w3d.runtime_state.node_transform_datums.get(&model_name)
                                .or_else(|| w3d.runtime_state.node_transform_datums.iter()
                                    .find(|(k, _)| **k == model_name).map(|(_, v)| v))
                                .and_then(|datum_ref| {
                                    match player.get_datum(datum_ref) {
                                        Datum::Transform3d(m) => Some([m[12], m[13], m[14]]),
                                        _ => None,
                                    }
                                })
                        })
                        .or_else(|| {
                            // Fallback to parsed scene node transform
                            w3d.parsed_scene.as_ref().and_then(|s|
                                s.nodes.iter().find(|n| n.name == model_name)
                                    .map(|n| [n.transform[12] as f64, n.transform[13] as f64, n.transform[14] as f64])
                            )
                        })
                        .unwrap_or([0.0; 3]);

                    // Collect vertices + triangle indices from every CLOD submesh,
                    // offsetting face indices so they remain valid in the merged buffer.
                    let node = w3d.parsed_scene.as_ref()
                        .and_then(|s| s.nodes.iter().find(|n| n.name == model_name));
                    let res_name = node.map(|n| {
                        if !n.model_resource_name.is_empty() { &n.model_resource_name }
                        else { &n.resource_name }
                    });
                    let (half_ext, verts, faces) = res_name
                        .and_then(|rn| w3d.parsed_scene.as_ref().and_then(|s| s.clod_meshes.get(rn)))
                        .map(|meshes| {
                            let (mut mn, mut mx) = ([f32::MAX; 3], [f32::MIN; 3]);
                            let mut all_verts: Vec<[f64; 3]> = Vec::new();
                            let mut all_faces: Vec<[u32; 3]> = Vec::new();
                            for mesh in meshes {
                                let offset = all_verts.len() as u32;
                                for p in &mesh.positions {
                                    for i in 0..3 { mn[i] = mn[i].min(p[i]); mx[i] = mx[i].max(p[i]); }
                                    all_verts.push([p[0] as f64, p[1] as f64, p[2] as f64]);
                                }
                                for f in &mesh.faces {
                                    all_faces.push([f[0] + offset, f[1] + offset, f[2] + offset]);
                                }
                            }
                            let he = [(mx[0]-mn[0]) as f64 / 2.0, (mx[1]-mn[1]) as f64 / 2.0, (mx[2]-mn[2]) as f64 / 2.0];
                            (he, all_verts, all_faces)
                        })
                        .unwrap_or(([10.0, 10.0, 10.0], Vec::new(), Vec::new()));

                    // Primitive kind of the model resource (#box / #sphere / …), so
                    // physics can treat a box differently from a rolling sphere.
                    let prim_type = res_name
                        .and_then(|rn| w3d.parsed_scene.as_ref()
                            .and_then(|s| s.model_resources.get(&rn)))
                        .and_then(|mr| mr.primitive_type.clone())
                        .unwrap_or_default();

                    (pos, half_ext, verts, faces, prim_type)
                } else {
                    ([0.0; 3], [10.0, 10.0, 10.0], Vec::new(), Vec::new(), String::new())
                }
            } else {
                ([0.0; 3], [10.0, 10.0, 10.0], Vec::new(), Vec::new(), String::new())
            }
        };

        // Compute unit inertia from the actual mesh geometry.
        // This matches Havok's InertialTensorComputer pipeline (PPC 0x5d3c0):
        // Tonon polyhedron tet-decomposition over the mesh triangles.
        // Fall back to an AABB-box approximation if the mesh is unavailable or degenerate.
        //
        // Previously we applied an empirical per-axis scale (×8.43 pitch/roll,
        // ×3.24 yaw) to compensate for an over-large angular response. After
        // decoding Havok's integrator more carefully, we moved that
        // compensation into the TORQUE divider in step_native (torque_scale =
        // 434 = /N² × 62/7) which mirrors Havok's "clear force/torque after
        // first inner integrate step" behaviour. With the divider handling
        // angular attenuation, the inertia reverts to the mathematically
        // correct polyhedron values here.
        // Compute the unit inertia AND the local centre of mass. The COM is the lever
        // origin for applyForceAtPoint/applyImpulse — leaving it [0,0,0] when the mesh's
        // true COM is offset (e.g. the SuperSonic car box spans z∈[0,10] → COM z=+5) makes
        // every off-centre force torque about the wrong point (lever 15 vs 10 → 1.5× error).
        let (unit_inertia, com) = if shape_type.eq_ignore_ascii_case("sphere") {
            // Sphere inertia: I = (2/5) * r² on all axes (isotropic); centred.
            let r = mesh_half_extents[0].max(mesh_half_extents[1]).max(mesh_half_extents[2]);
            let i_diag = 0.4 * r * r;
            ([i_diag, 0.0, 0.0, 0.0, i_diag, 0.0, 0.0, 0.0, i_diag], [0.0_f64; 3])
        } else {
            crate::player::handlers::datum_handlers::cast_member::havok_physics
                ::compute_polyhedron_unit_inertia(&mesh_vertices, &mesh_faces)
                .map(|(ui, com, _vol)| (ui, com))
                .unwrap_or_else(|| (crate::player::handlers::datum_handlers::cast_member::havok_physics
                    ::box_unit_inertia(mesh_half_extents), [0.0_f64; 3]))
        };

        // Diagnostic: log mesh + computed unit inertia so we can verify it matches
        // Director. For a 15×30×10 box we expect diag (83.33, 27.08, 93.75).
        debug!(
            "[HAVOK-RB '{}'] verts={} faces={} he=({:.1},{:.1},{:.1}) unit_I_diag=({:.2},{:.2},{:.2}) (polyhedron, unscaled)",
            model_name,
            mesh_vertices.len(), mesh_faces.len(),
            mesh_half_extents[0], mesh_half_extents[1], mesh_half_extents[2],
            unit_inertia[0], unit_inertia[4], unit_inertia[8],
        );

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        // Remove any auto-created body with the same name (from Initialize HKE loading)
        // and update collision mesh body_index references
        if let Some(old_idx) = havok.state.rigid_bodies.iter().position(|r| r.name == model_name) {
            havok.state.rigid_bodies.remove(old_idx);
            // Shift collision mesh body_index references
            for cmesh in &mut havok.state.collision_meshes {
                if let Some(bi) = cmesh.body_index {
                    if bi == old_idx {
                        cmesh.body_index = None; // will be re-set below
                    } else if bi > old_idx {
                        cmesh.body_index = Some(bi - 1);
                    }
                }
            }
        }

        let mut rb = HavokRigidBody::new_movable(model_name, mass, is_convex);
        rb.position = initial_position;
        // Default a Lingo-created movable body to the script-driven vehicle path
        // (the raycast cars are held up by hover forces and stay off the
        // box-stacking path). A body that is only ever positioned kinematically
        // (interpolatingMoveTo) without ever receiving an applied force is
        // reclassified there to a passive stacking body, so the add-cubes demo
        // still box-stacks. HKE-authored bodies load as driven=false already.
        rb.driven = true;
        // Box primitives must not be given sphere "rolling" on resting surfaces —
        // a cube slides/tumbles, it doesn't roll. Flag it from the shape-type arg
        // (#box) or the model resource's primitive type. Spheres, cylinders/coins,
        // cars and meshes are left to roll exactly as before.
        rb.is_box = shape_type.eq_ignore_ascii_case("box")
            || prim_type.eq_ignore_ascii_case("box");
        rb.inertia_half_extents = mesh_half_extents;
        rb.unit_inertia_tensor = unit_inertia;
        // The mesh-derived local COM is the lever origin for force/impulse-at-point. The
        // car box's COM is (0,0,+5); without this, off-centre forces torque about the origin.
        rb.center_of_mass = com;
        // Apply mass → finalise inertia / inverseInertia.
        crate::player::handlers::datum_handlers::cast_member::havok_physics::recompute_body_inertia(
            mass,
            rb.unit_inertia_tensor,
            &mut rb.inertia_tensor,
            &mut rb.inverse_inertia_tensor,
            &mut rb.inverse_mass,
        );

        havok.state.rigid_bodies.push(rb);
        let new_rb_index = havok.state.rigid_bodies.len() - 1;

        // Collision shape from the MODEL'S OWN GEOMETRY. Per the Xtra contract,
        // `makeMovableRigidBody(model, mass)` / `(model, mass, isConvex)` builds a
        // CONVEX HULL of the model's mesh; only the 4-arg form with an explicit
        // #box / #sphere asks for a primitive. Without this the body fell back to
        // the axis-aligned bounding box of that same mesh, which is both fatter
        // than the real shape at every corner and centred on the node origin
        // rather than on the geometry — so a chassis catches its phantom corners
        // on ramp lips and wall edges that the real hull clears.
        //
        // The vertices are stored body-local (the mesh is already expressed about
        // the node origin, which is the body position) and welded, since the
        // narrow phase samples them per triangle per step. HKE-authored movable
        // bodies populate the same field from their HKE mesh.
        let wants_primitive = shape_type.eq_ignore_ascii_case("box")
            || shape_type.eq_ignore_ascii_case("sphere");
        if !wants_primitive && !mesh_vertices.is_empty() {
            let mut welded: Vec<[f64; 3]> = Vec::new();
            let mut seen: std::collections::HashSet<(i64, i64, i64)> = std::collections::HashSet::new();
            for v in &mesh_vertices {
                let key = ((v[0] * 4.0) as i64, (v[1] * 4.0) as i64, (v[2] * 4.0) as i64);
                if seen.insert(key) {
                    welded.push(*v);
                }
            }
            debug!(
                "[HAVOK-RB '{}'] collision hull: {} mesh verts -> {} welded",
                model_name, mesh_vertices.len(), welded.len()
            );
            havok.state.rigid_bodies[new_rb_index].collision_hull_local = welded;
        }

        havok.state.rigid_bodies[new_rb_index].snapshot_initial();
        // Re-link collision mesh for this body
        for cmesh in &mut havok.state.collision_meshes {
            if cmesh.name == model_name && cmesh.body_index.is_none() {
                cmesh.body_index = Some(new_rb_index);
            }
        }

        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::RigidBody,
            name: model_name,
        })))
    }

    fn make_fixed_rigid_body(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let model_name = player.get_datum(&args[0]).symbol_value()?;
        let is_convex = if args.len() > 1 {
            player.get_datum(&args[1]).int_value()? != 0
        } else {
            true
        };

        // Build a collision mesh from the W3D model geometry so physics can
        // detect contacts against this fixed body (e.g. a ground plane created
        // dynamically via newModelResource).
        let collision_mesh = {
            let member = player
                .movie
                .cast_manager
                .find_member_by_ref(member_ref)
                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
            let havok = match &member.member_type {
                CastMemberType::HavokPhysics(h) => h,
                _ => return Err(ScriptError::new("Not a Havok member".to_string())),
            };
            let w3d_ref = CastMemberRef {
                cast_lib: havok.state.w3d_cast_lib,
                cast_member: havok.state.w3d_cast_member,
            };
            let w3d_member = player.movie.cast_manager.find_member_by_ref(&w3d_ref);
            w3d_member.and_then(|m| m.member_type.as_shockwave3d()).and_then(|w3d| {
                let scene = w3d.parsed_scene.as_ref()?;
                let node = scene.nodes.iter()
                    .find(|n| n.name == model_name)?;
                let res_name = if !node.model_resource_name.is_empty() {
                    &node.model_resource_name
                } else {
                    &node.resource_name
                };
                let meshes = scene.clod_meshes.get(res_name)?;

                // Get model transform: 1) runtime node_transforms,
                // 2) persistent Transform3d datum (set by Lingo),
                // 3) parsed scene node transform.
                let xform: Option<[f32; 16]> = w3d.runtime_state.node_transforms
                    .get(&model_name)
                    .or_else(|| w3d.runtime_state.node_transforms.iter()
                        .find(|(k, _)| **k == model_name).map(|(_, v)| v))
                    .copied()
                    .or_else(|| {
                        w3d.runtime_state.node_transform_datums.get(&model_name)
                            .or_else(|| w3d.runtime_state.node_transform_datums.iter()
                                .find(|(k, _)| **k == model_name).map(|(_, v)| v))
                            .and_then(|datum_ref| {
                                match player.get_datum(datum_ref) {
                                    Datum::Transform3d(m) => {
                                        let mut arr = [0.0f32; 16];
                                        for i in 0..16 { arr[i] = m[i] as f32; }
                                        Some(arr)
                                    },
                                    _ => None,
                                }
                            })
                    })
                    .or_else(|| Some(node.transform));

                let mut all_verts: Vec<[f64; 3]> = Vec::new();
                let mut all_faces: Vec<[u32; 3]> = Vec::new();
                for mesh in meshes {
                    let offset = all_verts.len() as u32;
                    for p in &mesh.positions {
                        let (lx, ly, lz) = (p[0] as f64, p[1] as f64, p[2] as f64);
                        let v = if let Some(t) = &xform {
                            [
                                t[0] as f64*lx + t[4] as f64*ly + t[8] as f64*lz + t[12] as f64,
                                t[1] as f64*lx + t[5] as f64*ly + t[9] as f64*lz + t[13] as f64,
                                t[2] as f64*lx + t[6] as f64*ly + t[10] as f64*lz + t[14] as f64,
                            ]
                        } else {
                            [lx, ly, lz]
                        };
                        all_verts.push(v);
                    }
                    for f in &mesh.faces {
                        all_faces.push([f[0] + offset, f[1] + offset, f[2] + offset]);
                    }
                }
                if all_verts.is_empty() { return None; }
                let mut cmesh = super::havok_physics::CollisionMesh {
                    name: model_name.clone(),
                    vertices: all_verts,
                    triangles: all_faces,
                    aabb_min: [0.0; 3],
                    aabb_max: [0.0; 3],
                    body_index: None, // set after rigid body is pushed
                };
                cmesh.compute_aabb();
                debug!(
                    "[HAVOK] makeFixedRigidBody '{}': built collision mesh {} verts, {} tris, AABB ({:.1},{:.1},{:.1})→({:.1},{:.1},{:.1})",
                    model_name, cmesh.vertices.len(), cmesh.triangles.len(),
                    cmesh.aabb_min[0], cmesh.aabb_min[1], cmesh.aabb_min[2],
                    cmesh.aabb_max[0], cmesh.aabb_max[1], cmesh.aabb_max[2],
                );
                Some(cmesh)
            })
        };

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        // Remove any auto-created body with the same name (from Initialize HKE loading)
        if let Some(old_idx) = havok.state.rigid_bodies.iter().position(|r| r.name == model_name) {
            havok.state.rigid_bodies.remove(old_idx);
            for cmesh in &mut havok.state.collision_meshes {
                if let Some(bi) = cmesh.body_index {
                    if bi == old_idx {
                        cmesh.body_index = None;
                    } else if bi > old_idx {
                        cmesh.body_index = Some(bi - 1);
                    }
                }
            }
        }

        let rb = HavokRigidBody::new_fixed(model_name, is_convex);
        havok.state.rigid_bodies.push(rb);
        let rb_index = havok.state.rigid_bodies.len() - 1;
        havok.state.rigid_bodies[rb_index].snapshot_initial();

        if let Some(mut cmesh) = collision_mesh {
            cmesh.body_index = Some(rb_index);
            havok.state.collision_meshes.push(cmesh);
        }
        // Also re-link any existing HKE collision mesh for this body
        for cmesh in &mut havok.state.collision_meshes {
            if cmesh.name == model_name && cmesh.body_index.is_none() {
                cmesh.body_index = Some(rb_index);
            }
        }

        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::RigidBody,
            name: model_name,
        })))
    }

    fn make_spring(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        let rb_a = player.get_datum(&args[1]).symbol_value()?;

        let mut spring = HavokSpring::new(name);
        spring.rigid_body_a = Some(rb_a);

        if args.len() > 2 {
            let arg2 = player.get_datum(&args[2]).clone();
            match &arg2 {
                Datum::String(s) => spring.rigid_body_b = Some(Symbol::from_str(s)),
                Datum::Vector(v) => spring.point_b = *v,
                _ => {
                    let s = arg2.string_value()?;
                    spring.rigid_body_b = Some(Symbol::from_str(&s));
                }
            }
        }

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok.state.springs.push(spring);

        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::Spring,
            name,
        })))
    }

    fn make_linear_dashpot(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        let rb_a = player.get_datum(&args[1]).symbol_value()?;

        let mut dashpot = HavokLinearDashpot::new(name);
        dashpot.rigid_body_a = Some(rb_a);

        if args.len() > 2 {
            let arg2 = player.get_datum(&args[2]).clone();
            match &arg2 {
                Datum::String(s) => dashpot.rigid_body_b = Some(Symbol::from_str(s)),
                Datum::Vector(v) => dashpot.point_b = *v,
                _ => {
                    let s = arg2.string_value()?;
                    dashpot.rigid_body_b = Some(Symbol::from_str(&s));
                }
            }
        }

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok.state.linear_dashpots.push(dashpot);

        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::LinearDashpot,
            name,
        })))
    }

    fn make_angular_dashpot(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let name = player.get_datum(&args[0]).symbol_value()?;
        let rb_a = player.get_datum(&args[1]).symbol_value()?;

        let mut dashpot = HavokAngularDashpot::new(name);
        dashpot.rigid_body_a = Some(rb_a);

        if args.len() > 2 {
            let s = player.get_datum(&args[2]).string_value()?;
            dashpot.rigid_body_b = Some(Symbol::from_str(&s));
        }

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok.state.angular_dashpots.push(dashpot);

        Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
            cast_lib: member_ref.cast_lib,
            cast_member: member_ref.cast_member,
            object_type: BuiltInSymbol::AngularDashpot,
            name,
        })))
    }

    fn delete_rigid_body(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let arg = player.get_datum(&args[0]).clone();
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        // Remove from havok state. `collision_meshes` and `cable_constraints`
        // hold POSITIONAL indices into `rigid_bodies`, so removing an element
        // shifts every later body out from under them — `reindex_after_body_removal`
        // repairs that. Springs / dashpots / hinges reference bodies by NAME and
        // need no fixup.
        let removed: Vec<usize> = match &arg {
            Datum::String(name) => {
                let target = Symbol::from_str(name.as_str());
                let removed: Vec<usize> = havok
                    .state
                    .rigid_bodies
                    .iter()
                    .enumerate()
                    .filter(|(_, rb)| rb.name == target)
                    .map(|(i, _)| i)
                    .collect();
                havok.state.rigid_bodies.retain(|rb| rb.name != target);
                removed
            }
            Datum::Int(index) => {
                let idx = (*index as usize).saturating_sub(1);
                if idx < havok.state.rigid_bodies.len() {
                    havok.state.rigid_bodies.remove(idx);
                    vec![idx]
                } else {
                    Vec::new()
                }
            }
            _ => Vec::new(),
        };
        reindex_after_body_removal(&mut havok.state, &removed);
        Ok(DatumRef::Void)
    }

    fn delete_spring(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let arg = player.get_datum(&args[0]).clone();
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        match &arg {
            Datum::String(name) => {
                havok
                    .state
                    .springs
                    .retain(|s| s.name != Symbol::from_str(name.as_str()));
            }
            Datum::Int(index) => {
                let idx = (*index as usize).saturating_sub(1);
                if idx < havok.state.springs.len() {
                    havok.state.springs.remove(idx);
                }
            }
            _ => {}
        }
        Ok(DatumRef::Void)
    }

    fn delete_linear_dashpot(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let arg = player.get_datum(&args[0]).clone();
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        match &arg {
            Datum::String(name) => {
                havok
                    .state
                    .linear_dashpots
                    .retain(|d| d.name != Symbol::from_str(name.as_str()));
            }
            Datum::Int(index) => {
                let idx = (*index as usize).saturating_sub(1);
                if idx < havok.state.linear_dashpots.len() {
                    havok.state.linear_dashpots.remove(idx);
                }
            }
            _ => {}
        }
        Ok(DatumRef::Void)
    }

    fn delete_angular_dashpot(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let arg = player.get_datum(&args[0]).clone();
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        match &arg {
            Datum::String(name) => {
                havok
                    .state
                    .angular_dashpots
                    .retain(|d| d.name != Symbol::from_str(name.as_str()));
            }
            Datum::Int(index) => {
                let idx = (*index as usize).saturating_sub(1);
                if idx < havok.state.angular_dashpots.len() {
                    havok.state.angular_dashpots.remove(idx);
                }
            }
            _ => {}
        }
        Ok(DatumRef::Void)
    }

    fn register_interest(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let rb_name1 = player.get_datum(&args[0]).symbol_value()?;
        let rb_name2 = player.get_datum(&args[1]).symbol_value()?;
        let frequency = player.get_datum(&args[2]).to_float()?;
        let threshold = player.get_datum(&args[3]).to_float()?;

        let handler_name = if args.len() > 4 {
            Some(player.get_datum(&args[4]).symbol_value()?)
        } else {
            None
        };
        let script_instance = if args.len() > 5 {
            Some(args[5].clone())
        } else {
            None
        };

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        havok.state.collision_interests.push(HavokCollisionInterest {
            rb_name1,
            rb_name2,
            frequency,
            threshold,
            handler_name,
            script_instance,
        });

        Ok(DatumRef::Void)
    }

    fn remove_interest(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let rb_name = player.get_datum(&args[0]).symbol_value()?;
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok
            .state
            .collision_interests
            .retain(|ci| ci.rb_name1 != rb_name);
        Ok(DatumRef::Void)
    }

    fn register_step_callback(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let handler_name = player.get_datum(&args[0]).symbol_value()?;
        let script_instance = args[1].clone();

        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok
            .state
            .step_callbacks
            .push((handler_name, script_instance));
        Ok(DatumRef::Void)
    }

    fn remove_step_callback(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let handler_name = player.get_datum(&args[0]).symbol_value()?;
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok
            .state
            .step_callbacks
            .retain(|(name, _)| name != &handler_name);
        Ok(DatumRef::Void)
    }

    fn enable_collision(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let rb_a = player.get_datum(&args[0]).symbol_value()?;
        let rb_b = player.get_datum(&args[1]).symbol_value()?;
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok.state.disabled_collision_pairs.retain(|(a, b)| {
            !(*a == rb_a && *b == rb_b || *a == rb_b && *b == rb_a)
        });
        Ok(DatumRef::Void)
    }

    fn disable_collision(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let rb_a = player.get_datum(&args[0]).symbol_value()?;
        let rb_b = player.get_datum(&args[1]).symbol_value()?;
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok
            .state
            .disabled_collision_pairs
            .push((rb_a, rb_b));
        Ok(DatumRef::Void)
    }

    fn enable_all_collisions(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let rb_name = player.get_datum(&args[0]).symbol_value()?;
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        havok.state.disabled_collision_pairs.retain(|(a, b)| {
            !(*a == rb_name) && !(*b == rb_name)
        });
        Ok(DatumRef::Void)
    }

    fn disable_all_collisions(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let rb_name = player.get_datum(&args[0]).symbol_value()?;
        let member = player
            .movie
            .cast_manager
            .find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        // Disable collisions with all other rigid bodies
        for rb in &havok.state.rigid_bodies {
            if rb.name != rb_name {
                havok
                    .state
                    .disabled_collision_pairs
                    .push((rb_name, rb.name));
            }
        }
        Ok(DatumRef::Void)
    }
}

/// Build a column-major 4x4 f32 transform from f64 axis-angle rotation + translation.
pub fn axis_angle_to_transform_f64(rot_axis: [f64; 3], rot_angle: f64, pos: [f64; 3]) -> [f32; 16] {
    axis_angle_to_transform(
        rot_axis[0] as f32, rot_axis[1] as f32, rot_axis[2] as f32,
        rot_angle as f32,
        pos[0] as f32, pos[1] as f32, pos[2] as f32,
    )
}

/// Build a column-major 4x4 transform from axis-angle rotation + translation.
fn axis_angle_to_transform(ax: f32, ay: f32, az: f32, angle: f32, px: f32, py: f32, pz: f32) -> [f32; 16] {
    let axis_len = (ax*ax + ay*ay + az*az).sqrt();
    if axis_len < 1e-6 || angle.abs() < 1e-10 {
        return [
            1.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0,
            px,  py,  pz,  1.0,
        ];
    }
    let (x, y, z) = (ax / axis_len, ay / axis_len, az / axis_len);
    let c = angle.cos();
    let s = angle.sin();
    let t = 1.0 - c;
    [
        t*x*x + c,   t*x*y + s*z, t*x*z - s*y, 0.0,
        t*x*y - s*z, t*y*y + c,   t*y*z + s*x, 0.0,
        t*x*z + s*y, t*y*z - s*x, t*z*z + c,   0.0,
        px,          py,          pz,          1.0,
    ]
}
