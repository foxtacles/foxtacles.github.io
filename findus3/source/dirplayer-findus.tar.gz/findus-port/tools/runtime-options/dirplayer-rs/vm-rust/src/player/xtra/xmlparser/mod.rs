use std::collections::VecDeque;
use fxhash::FxHashMap;
use xml::reader::{EventReader, XmlEvent};

use crate::{
    director::lingo::datum::{Datum, DatumType},
    player::{DatumRef, ScriptError, reserve_player_mut, symbols::{builtin::BuiltInSymbol, symbol::Symbol}},
};

/// Represents a parsed XML node
#[derive(Clone, Debug)]
pub struct XmlNode {
    pub name: String,
    pub attributes: Vec<(String, String)>,
    pub children: Vec<XmlNodeChild>,
}

#[derive(Clone, Debug)]
pub enum XmlNodeChild {
    Element(XmlNode),
    Text(String),
}

pub struct XmlParserXtraInstance {
    pub parsed_root: Option<XmlNode>,
    pub error: Option<String>,
    pub ignore_whitespace: bool,
    pub done_parsing: bool,
}

impl XmlParserXtraInstance {
    pub fn new() -> Self {
        XmlParserXtraInstance {
            parsed_root: None,
            error: None,
            ignore_whitespace: false,
            done_parsing: true,
        }
    }

    /// Parse an XML string into the internal node structure
    pub fn parse_string(&mut self, xml_string: &str) -> i32 {
        self.error = None;
        self.parsed_root = None;

        // Director's XML Xtra tolerates duplicate attributes (last wins).
        // xml-rs is strict and errors out, so preprocess the source to drop
        // earlier duplicates within each element's attribute list.
        let cleaned = dedup_duplicate_attributes(xml_string);
        let parser = EventReader::from_str(&cleaned);
        let mut stack: Vec<XmlNode> = Vec::new();
        let mut root: Option<XmlNode> = None;

        for event in parser {
            match event {
                Ok(XmlEvent::StartElement { name, attributes, .. }) => {
                    let node = XmlNode {
                        name: name.local_name,
                        attributes: attributes
                            .into_iter()
                            .map(|attr| (attr.name.local_name, attr.value))
                            .collect(),
                        children: Vec::new(),
                    };
                    stack.push(node);
                }
                Ok(XmlEvent::EndElement { .. }) => {
                    if let Some(completed_node) = stack.pop() {
                        if stack.is_empty() {
                            root = Some(completed_node);
                        } else {
                            if let Some(parent) = stack.last_mut() {
                                parent.children.push(XmlNodeChild::Element(completed_node));
                            }
                        }
                    }
                }
                Ok(XmlEvent::Characters(text)) | Ok(XmlEvent::CData(text)) => {
                    let trimmed = if self.ignore_whitespace {
                        text.trim().to_string()
                    } else {
                        text.clone()
                    };

                    // Only add non-empty text nodes (or all if not ignoring whitespace)
                    if !self.ignore_whitespace || !trimmed.is_empty() {
                        if let Some(current) = stack.last_mut() {
                            current.children.push(XmlNodeChild::Text(trimmed));
                        }
                    }
                }
                Ok(XmlEvent::Whitespace(text)) => {
                    if !self.ignore_whitespace {
                        if let Some(current) = stack.last_mut() {
                            current.children.push(XmlNodeChild::Text(text));
                        }
                    }
                }
                Err(e) => {
                    self.error = Some(format!("XML parsing error: {}", e));
                    self.done_parsing = true;
                    return -1;
                }
                _ => {}
            }
        }

        self.parsed_root = root;
        self.done_parsing = true;
        0 // Success
    }

    /// Convert the parsed XML tree to a Lingo property list structure
    fn node_to_prop_list(node: &XmlNode) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            // Create #name property
            let name_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Name)));
            let name_value = player.alloc_datum(Datum::String(node.name.clone()));

            // Create #attributes property list and #attributeName/#attributeValue lists
            let attributes_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Attributes)));
            let mut attr_pairs: VecDeque<(DatumRef, DatumRef)> = VecDeque::new();
            let mut attr_name_refs: VecDeque<DatumRef> = VecDeque::new();
            let mut attr_value_pairs: VecDeque<(DatumRef, DatumRef)> = VecDeque::new();
            for (attr_name, attr_value) in &node.attributes {
                let attr_key = player.alloc_datum(Datum::Symbol(Symbol::from_str(attr_name)));
                let attr_val = player.alloc_datum(Datum::String(attr_value.clone()));
                attr_pairs.push_back((attr_key, attr_val));
                attr_name_refs.push_back(player.alloc_datum(Datum::String(attr_name.clone())));
                let av_key = player.alloc_datum(Datum::String(attr_name.clone()));
                let av_val = player.alloc_datum(Datum::String(attr_value.clone()));
                attr_value_pairs.push_back((av_key, av_val));
            }
            let attributes_value = player.alloc_datum(Datum::PropList(attr_pairs, false));
            let attr_name_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::AttributeName)));
            let attr_name_value = player.alloc_datum(Datum::List(DatumType::List, attr_name_refs, false));
            let attr_value_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::AttributeValue)));
            // `XMLnode.attributeValue[ attributeNameOrNumber ]` (Director 11.5
            // Scripting Dictionary, `attributeValue`) — indexable by attribute
            // NAME as well as by position. A property list serves both through
            // the existing bracket rule, which tries a key lookup first and
            // falls back to 1-based positional access for an integer; a plain
            // linear list only ever answered the number. Argent Free Ride's
            // Track Loader uses each form in turn — `attributeValue[lAttrIdx]`
            // while collecting a node's attributes, then
            // `lChild.attributeValue["id"]` to pick the track out by name.
            let attr_value_value = player.alloc_datum(Datum::PropList(attr_value_pairs, false));

            // Create #child list and collect #charData
            let child_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Child)));
            let mut children_refs: VecDeque<DatumRef> = VecDeque::new();
            let mut char_data = String::new();

            for child in &node.children {
                match child {
                    XmlNodeChild::Element(child_node) => {
                        let child_ref = Self::node_to_prop_list_inner(player, child_node)?;
                        children_refs.push_back(child_ref);
                    }
                    XmlNodeChild::Text(text) => {
                        char_data.push_str(text);
                        if !text.trim().is_empty() {
                            let text_ref = Self::text_node_to_prop_list_inner(player, text);
                            children_refs.push_back(text_ref);
                        }
                    }
                }
            }

            let children_value =
                player.alloc_datum(Datum::List(DatumType::List, children_refs, false));

            let chardata_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::CharData)));
            let chardata_value = player.alloc_datum(Datum::String(char_data));

            let prop_list = Datum::PropList(
                VecDeque::from(vec![
                    (name_key, name_value),
                    (attributes_key, attributes_value),
                    (attr_name_key, attr_name_value),
                    (attr_value_key, attr_value_value),
                    (child_key, children_value),
                    (chardata_key, chardata_value),
                ]),
                false,
            );

            Ok(player.alloc_datum(prop_list))
        })
    }

    /// Inner helper to convert node to prop list when player is already borrowed
    fn node_to_prop_list_inner(
        player: &mut crate::player::DirPlayer,
        node: &XmlNode,
    ) -> Result<DatumRef, ScriptError> {
        // Create #name property
        let name_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Name)));
        let name_value = player.alloc_datum(Datum::String(node.name.clone()));

        // Create #attributes property list and #attributeName/#attributeValue lists
        let attributes_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Attributes)));
        let mut attr_pairs: VecDeque<(DatumRef, DatumRef)> = VecDeque::new();
        let mut attr_name_refs: VecDeque<DatumRef> = VecDeque::new();
        let mut attr_value_pairs: VecDeque<(DatumRef, DatumRef)> = VecDeque::new();
        for (attr_name, attr_value) in &node.attributes {
            let attr_key = player.alloc_datum(Datum::Symbol(Symbol::from_str(attr_name)));
            let attr_val = player.alloc_datum(Datum::String(attr_value.clone()));
            attr_pairs.push_back((attr_key, attr_val));
            attr_name_refs.push_back(player.alloc_datum(Datum::String(attr_name.clone())));
            let av_key = player.alloc_datum(Datum::String(attr_name.clone()));
            let av_val = player.alloc_datum(Datum::String(attr_value.clone()));
            attr_value_pairs.push_back((av_key, av_val));
        }
        let attributes_value = player.alloc_datum(Datum::PropList(attr_pairs, false));
        let attr_name_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::AttributeName)));
        let attr_name_value = player.alloc_datum(Datum::List(DatumType::List, attr_name_refs, false));
        let attr_value_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::AttributeValue)));
        let attr_value_value = player.alloc_datum(Datum::PropList(attr_value_pairs, false));

        // Create #child list and collect #charData
        let child_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Child)));
        let mut children_refs: VecDeque<DatumRef> = VecDeque::new();
        let mut char_data = String::new();

        for child in &node.children {
            match child {
                XmlNodeChild::Element(child_node) => {
                    let child_ref = Self::node_to_prop_list_inner(player, child_node)?;
                    children_refs.push_back(child_ref);
                }
                XmlNodeChild::Text(text) => {
                    char_data.push_str(text);
                    if !text.trim().is_empty() {
                        let text_ref = Self::text_node_to_prop_list_inner(player, text);
                        children_refs.push_back(text_ref);
                    }
                }
            }
        }

        let children_value =
            player.alloc_datum(Datum::List(DatumType::List, children_refs, false));

        let chardata_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::CharData)));
        let chardata_value = player.alloc_datum(Datum::String(char_data));

        let prop_list = Datum::PropList(
            VecDeque::from(vec![
                (name_key, name_value),
                (attributes_key, attributes_value),
                (attr_name_key, attr_name_value),
                (attr_value_key, attr_value_value),
                (child_key, children_value),
                (chardata_key, chardata_value),
            ]),
            false,
        );

        Ok(player.alloc_datum(prop_list))
    }

    /// makeList handler - converts parsed XML to Lingo property list
    pub fn make_list(&self) -> Result<DatumRef, ScriptError> {
        if let Some(ref root) = self.parsed_root {
            Self::node_to_prop_list(root)
        } else {
            Ok(DatumRef::Void)
        }
    }

    /// Convert a text node to a prop list with empty name
    fn text_node_to_prop_list_inner(
        player: &mut crate::player::DirPlayer,
        text: &str,
    ) -> DatumRef {
        let name_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Name)));
        let name_value = player.alloc_datum(Datum::String(String::new()));

        let attributes_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Attributes)));
        let attributes_value = player.alloc_datum(Datum::PropList(VecDeque::new(), false));

        let chardata_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::CharData)));
        let chardata_value = player.alloc_datum(Datum::String(text.to_string()));

        let text_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Text)));
        let text_value = player.alloc_datum(Datum::String(text.to_string()));

        let child_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Child)));
        let child_value =
            player.alloc_datum(Datum::List(DatumType::List, VecDeque::new(), false));

        let prop_list = Datum::PropList(
            VecDeque::from(vec![
                (name_key, name_value),
                (attributes_key, attributes_value),
                (chardata_key, chardata_value),
                (text_key, text_value),
                (child_key, child_value),
            ]),
            false,
        );

        player.alloc_datum(prop_list)
    }

    fn text_node_to_prop_list(text: &str) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            Ok(Self::text_node_to_prop_list_inner(player, text))
        })
    }
}

pub struct XmlParserXtraManager {
    pub instances: FxHashMap<u32, XmlParserXtraInstance>,
    pub instance_counter: u32,
}

impl XmlParserXtraManager {
    pub fn new() -> Self {
        XmlParserXtraManager {
            instances: FxHashMap::default(),
            instance_counter: 0,
        }
    }

    pub fn create_instance(&mut self, _args: &Vec<DatumRef>) -> u32 {
        self.instance_counter += 1;
        self.instances
            .insert(self.instance_counter, XmlParserXtraInstance::new());
        self.instance_counter
    }

    pub fn has_instance_async_handler(_name: &str) -> bool {
        // parseURL could be async, but we'll implement it synchronously for now
        false
    }

    pub async fn call_instance_async_handler(
        handler_name: &str,
        instance_id: u32,
        _args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        Err(ScriptError::new(format!(
            "No async handler {} found for XmlParser xtra instance #{}",
            handler_name, instance_id
        )))
    }

    pub fn call_instance_handler(
        handler_name: &str,
        instance_id: u32,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        let manager = unsafe { XMLPARSER_XTRA_MANAGER_OPT.as_mut().unwrap() };
        let instance = manager.instances.get_mut(&instance_id).ok_or_else(|| {
            ScriptError::new(format!("XmlParser instance #{} not found", instance_id))
        })?;

        match handler_name.to_lowercase().as_str() {
            "parsestring" => {
                let xml_string = crate::player::reserve_player_ref(|player| {
                    let arg = args.get(0).ok_or_else(|| {
                        ScriptError::new("parseString requires a string argument".to_string())
                    })?;
                    player.get_datum(arg).string_value()
                })?;

                let result = instance.parse_string(&xml_string);
                // VOID on success, the descriptive error string on failure.
                //
                // The Scripting Dictionary documents the pair together under
                // `getError() (XML)`: "When there is no error, this function
                // returns <VOID>", shown as
                //     errCode = parserObject.parseString(member("XMLtext").text)
                //     errorString = parserObject.getError()
                //     if voidP(errorString) then  -- use the XML
                // so a clean parse is signalled by VOID and a failure by the
                // string. Movies apply that same `voidp` test directly to
                // parseString's own return — Argent Free Ride's Xml Loader is
                // one:
                //     lError = lXmlXtra.parseString(pXmlCastMember.text)
                //     if not voidp(lError) then _Error(lError) else ParseXml(...)
                // Returning Int(0) for success made `voidp` false, so it took
                // the error branch on a perfectly good document and never
                // parsed its track XML at all — the level then built with no
                // attributes, no chunks and no tokens.
                if result == 0 && instance.error.is_none() {
                    return Ok(DatumRef::Void);
                }
                let message = instance
                    .error
                    .clone()
                    .unwrap_or_else(|| format!("XML parsing error: {}", result));
                reserve_player_mut(|player| Ok(player.alloc_datum(Datum::String(message))))
            }
            "makelist" => instance.make_list(),
            "makesublist" => {
                // makeSubList returns a property list for the root node (or could be called on child refs)
                instance.make_list()
            }
            "geterror" => {
                if let Some(ref error) = instance.error {
                    reserve_player_mut(|player| {
                        Ok(player.alloc_datum(Datum::String(error.clone())))
                    })
                } else {
                    Ok(DatumRef::Void)
                }
            }
            "ignorewhitespace" => {
                let ignore = crate::player::reserve_player_ref(|player| {
                    let arg = args.get(0).ok_or_else(|| {
                        ScriptError::new(
                            "ignoreWhiteSpace requires a boolean argument".to_string(),
                        )
                    })?;
                    player.get_datum(arg).bool_value()
                })?;

                instance.ignore_whitespace = ignore;
                Ok(DatumRef::Void)
            }
            "doneparsing" => reserve_player_mut(|player| {
                Ok(player.alloc_datum(Datum::Int(if instance.done_parsing { 1 } else { 0 })))
            }),
            "parseurl" => {
                // parseURL is not fully implemented - would require async HTTP fetch
                // For now, return an error suggesting to use getNetText + parseString
                Err(ScriptError::new(
                    "parseURL is not supported. Use getNetText to fetch XML, then parseString."
                        .to_string(),
                ))
            }
            // Manual node traversal methods
            "count" => {
                // count(#child) returns the number of children
                // count(#attribute) returns the number of attributes
                let prop_name = crate::player::reserve_player_ref(|player| {
                    if let Some(arg) = args.get(0) {
                        player.get_datum(arg).symbol_value()
                    } else {
                        Ok(Symbol::builtin(BuiltInSymbol::Child)) // Default to child count
                    }
                })?;

                if let Some(ref _root) = instance.parsed_root {
                    let count = match prop_name.into_builtin() {
                        Some(BuiltInSymbol::Child | BuiltInSymbol::Children) => 1, // The parser object has one child: the root element
                        Some(BuiltInSymbol::Attribute | BuiltInSymbol::Attributes) => 0, // Parser object has no attributes
                        _ => 0,
                    };
                    reserve_player_mut(|player| Ok(player.alloc_datum(Datum::Int(count))))
                } else {
                    reserve_player_mut(|player| Ok(player.alloc_datum(Datum::Int(0))))
                }
            }
            "child" => {
                // child[n] returns the nth child node
                let index = crate::player::reserve_player_ref(|player| {
                    let arg = args.get(0).ok_or_else(|| {
                        ScriptError::new("child requires an index argument".to_string())
                    })?;
                    player.get_datum(arg).int_value()
                })?;

                if let Some(ref root) = instance.parsed_root {
                    // The parser object has one child: the root element (index 1)
                    if index == 1 {
                        XmlParserXtraInstance::node_to_prop_list(root)
                    } else {
                        Ok(DatumRef::Void)
                    }
                } else {
                    Ok(DatumRef::Void)
                }
            }
            "name" => {
                // Returns the tag name of the root element
                if let Some(ref root) = instance.parsed_root {
                    reserve_player_mut(|player| {
                        Ok(player.alloc_datum(Datum::String(root.name.clone())))
                    })
                } else {
                    Ok(DatumRef::Void)
                }
            }
            "attributename" => {
                // attributeName[n] returns the name of the nth attribute
                let index = crate::player::reserve_player_ref(|player| {
                    let arg = args.get(0).ok_or_else(|| {
                        ScriptError::new("attributeName requires an index argument".to_string())
                    })?;
                    player.get_datum(arg).int_value()
                })?;

                if let Some(ref root) = instance.parsed_root {
                    let idx = (index - 1) as usize;
                    if idx < root.attributes.len() {
                        reserve_player_mut(|player| {
                            Ok(player
                                .alloc_datum(Datum::String(root.attributes[idx].0.clone())))
                        })
                    } else {
                        Ok(DatumRef::Void)
                    }
                } else {
                    Ok(DatumRef::Void)
                }
            }
            "attributevalue" => {
                // attributeValue[n] or attributeValue["name"] returns the attribute value
                let (by_index, index, attr_name) = crate::player::reserve_player_ref(|player| {
                    let arg = args.get(0).ok_or_else(|| {
                        ScriptError::new("attributeValue requires an argument".to_string())
                    })?;
                    let datum = player.get_datum(arg);
                    if datum.is_int() || datum.is_number() {
                        Ok((true, datum.int_value()?, String::new()))
                    } else {
                        Ok((false, 0, datum.string_value()?))
                    }
                })?;

                if let Some(ref root) = instance.parsed_root {
                    if by_index {
                        let idx = (index - 1) as usize;
                        if idx < root.attributes.len() {
                            reserve_player_mut(|player| {
                                Ok(player.alloc_datum(Datum::String(
                                    root.attributes[idx].1.clone(),
                                )))
                            })
                        } else {
                            Ok(DatumRef::Void)
                        }
                    } else {
                        // Find attribute by name
                        if let Some((_, value)) =
                            root.attributes.iter().find(|(name, _)| name == &attr_name)
                        {
                            reserve_player_mut(|player| {
                                Ok(player.alloc_datum(Datum::String(value.clone())))
                            })
                        } else {
                            Ok(DatumRef::Void)
                        }
                    }
                } else {
                    Ok(DatumRef::Void)
                }
            }
            "getprop" | "getpropref" => {
                // getPropRef(#child, n) returns a property list for the nth child
                // getPropRef(#attribute, n) returns the nth attribute as [name, value]
                let (prop_name, index) = crate::player::reserve_player_ref(|player| {
                    let prop_arg = args.get(0).ok_or_else(|| {
                        ScriptError::new("getPropRef requires a property name".to_string())
                    })?;
                    let index_arg = args.get(1).ok_or_else(|| {
                        ScriptError::new("getPropRef requires an index".to_string())
                    })?;
                    let prop_name = player.get_datum(prop_arg).symbol_value()?;
                    let index = player.get_datum(index_arg).int_value()?;
                    Ok((prop_name, index))
                })?;

                if let Some(ref root) = instance.parsed_root {
                    match prop_name.into_builtin() {
                        Some(BuiltInSymbol::Child | BuiltInSymbol::Children) => {
                            // The parser object has one child: the root element (index 1)
                            if index == 1 {
                                XmlParserXtraInstance::node_to_prop_list(root)
                            } else {
                                Ok(DatumRef::Void)
                            }
                        }
                        Some(BuiltInSymbol::Attribute | BuiltInSymbol::Attributes) => {
                            let idx = (index - 1) as usize;
                            if idx < root.attributes.len() {
                                reserve_player_mut(|player| {
                                    let (name, value) = &root.attributes[idx];
                                    let name_ref =
                                        player.alloc_datum(Datum::String(name.clone()));
                                    let value_ref =
                                        player.alloc_datum(Datum::String(value.clone()));
                                    Ok(player.alloc_datum(Datum::List(
                                        DatumType::List,
                                        VecDeque::from(vec![name_ref, value_ref]),
                                        false,
                                    )))
                                })
                            } else {
                                Ok(DatumRef::Void)
                            }
                        }
                        _ => Ok(DatumRef::Void),
                    }
                } else {
                    Ok(DatumRef::Void)
                }
            }
            _ => Err(ScriptError::new(format!(
                "No handler {} found for XmlParser xtra instance #{}",
                handler_name, instance_id
            ))),
        }
    }
}

pub fn borrow_xmlparser_manager_mut<T>(
    callback: impl FnOnce(&mut XmlParserXtraManager) -> T,
) -> T {
    let manager = unsafe { XMLPARSER_XTRA_MANAGER_OPT.as_mut().unwrap() };
    callback(manager)
}

pub static mut XMLPARSER_XTRA_MANAGER_OPT: Option<XmlParserXtraManager> = None;

/// Strip earlier occurrences of duplicate attributes within each element's
/// opening tag. Matches Director's XML Xtra behavior: last attribute wins.
/// Only touches text inside `<…>` tag delimiters; element text content is
/// left alone. Skips comments (`<!-- -->`), CDATA (`<![CDATA[…]]>`), and
/// processing instructions (`<?…?>`).
pub fn dedup_duplicate_attributes(xml: &str) -> String {
    let bytes = xml.as_bytes();
    let mut out = String::with_capacity(xml.len());
    let mut i = 0usize;
    while i < bytes.len() {
        let c = bytes[i];
        if c != b'<' {
            out.push(c as char);
            i += 1;
            continue;
        }
        // Possible specials: <!-- comment -->, <![CDATA[…]]>, <?…?>. Copy
        // through without parsing attributes.
        if xml[i..].starts_with("<!--") {
            if let Some(end) = xml[i + 4..].find("-->") {
                let end_idx = i + 4 + end + 3;
                out.push_str(&xml[i..end_idx]);
                i = end_idx;
                continue;
            } else {
                out.push_str(&xml[i..]);
                break;
            }
        }
        if xml[i..].starts_with("<![CDATA[") {
            if let Some(end) = xml[i + 9..].find("]]>") {
                let end_idx = i + 9 + end + 3;
                out.push_str(&xml[i..end_idx]);
                i = end_idx;
                continue;
            } else {
                out.push_str(&xml[i..]);
                break;
            }
        }
        if xml[i..].starts_with("<?") {
            if let Some(end) = xml[i + 2..].find("?>") {
                let end_idx = i + 2 + end + 2;
                out.push_str(&xml[i..end_idx]);
                i = end_idx;
                continue;
            } else {
                out.push_str(&xml[i..]);
                break;
            }
        }
        // Regular element tag: find matching `>` while respecting quotes.
        let mut j = i + 1;
        let mut in_quote: Option<u8> = None;
        while j < bytes.len() {
            let ch = bytes[j];
            if let Some(q) = in_quote {
                if ch == q { in_quote = None; }
            } else if ch == b'"' || ch == b'\'' {
                in_quote = Some(ch);
            } else if ch == b'>' {
                break;
            }
            j += 1;
        }
        if j >= bytes.len() {
            // Malformed — bail out copying the remainder verbatim.
            out.push_str(&xml[i..]);
            break;
        }
        // xml[i..=j] is the full tag including angle brackets.
        let tag = &xml[i..=j];
        out.push_str(&rewrite_tag_dedup(tag));
        i = j + 1;
    }
    out
}

/// Given a single opening tag like `<Foo a="1" b="2" a="3"/>`, rewrite it
/// keeping only the last occurrence of each attribute name.
fn rewrite_tag_dedup(tag: &str) -> String {
    // Fast path: tags without `=` have no attributes.
    if !tag.contains('=') { return tag.to_string(); }

    let bytes = tag.as_bytes();
    // Find end of element name: after `<` (or `</`), up to whitespace or `/`/`>`.
    let mut p = 1; // skip `<`
    if p < bytes.len() && bytes[p] == b'/' { p += 1; } // `</…>`
    let name_start = p;
    while p < bytes.len() {
        let ch = bytes[p];
        if ch.is_ascii_whitespace() || ch == b'/' || ch == b'>' { break; }
        p += 1;
    }
    let name_end = p;
    if name_start == name_end { return tag.to_string(); }

    // Parse attributes: (name, value, with_quotes_string) tuples, in order.
    #[derive(Default)]
    struct Attr { name: String, raw: String }
    let mut attrs: Vec<Attr> = Vec::new();

    let mut q = p;
    while q < bytes.len() {
        // Skip whitespace.
        while q < bytes.len() && bytes[q].is_ascii_whitespace() { q += 1; }
        // End of tag?
        if q >= bytes.len() || bytes[q] == b'/' || bytes[q] == b'>' { break; }
        // Read attribute name.
        let a_name_start = q;
        while q < bytes.len() {
            let ch = bytes[q];
            if ch.is_ascii_whitespace() || ch == b'=' || ch == b'/' || ch == b'>' { break; }
            q += 1;
        }
        let a_name_end = q;
        if a_name_start == a_name_end { break; }
        let a_name = &tag[a_name_start..a_name_end];
        // Skip whitespace + `=` + whitespace.
        while q < bytes.len() && bytes[q].is_ascii_whitespace() { q += 1; }
        if q >= bytes.len() || bytes[q] != b'=' {
            // Valueless attribute (rare in Director) — keep as-is.
            attrs.push(Attr { name: a_name.to_string(), raw: a_name.to_string() });
            continue;
        }
        q += 1;
        while q < bytes.len() && bytes[q].is_ascii_whitespace() { q += 1; }
        if q >= bytes.len() { break; }
        // Read quoted or unquoted value.
        let v_start = q;
        let quote = bytes[q];
        if quote == b'"' || quote == b'\'' {
            q += 1;
            while q < bytes.len() && bytes[q] != quote { q += 1; }
            if q < bytes.len() { q += 1; } // consume closing quote
        } else {
            while q < bytes.len() {
                let ch = bytes[q];
                if ch.is_ascii_whitespace() || ch == b'/' || ch == b'>' { break; }
                q += 1;
            }
        }
        let raw = format!("{}={}", a_name, &tag[v_start..q]);
        attrs.push(Attr { name: a_name.to_string(), raw });
    }

    // Deduplicate: keep only the LAST occurrence of each name.
    let mut seen_later: std::collections::HashSet<&str> = std::collections::HashSet::new();
    let mut keep = vec![true; attrs.len()];
    for idx in (0..attrs.len()).rev() {
        if !seen_later.insert(attrs[idx].name.as_str()) {
            keep[idx] = false;
        }
    }

    // Rebuild the tag.
    let suffix = {
        // Trailing `/` or just `>`.
        let end = bytes.len() - 1; // index of `>`
        if end > 0 && bytes[end - 1] == b'/' { "/>" } else { ">" }
    };
    let mut rebuilt = String::with_capacity(tag.len());
    rebuilt.push_str(&tag[0..name_end]);
    for (idx, attr) in attrs.iter().enumerate() {
        if !keep[idx] { continue; }
        rebuilt.push(' ');
        rebuilt.push_str(&attr.raw);
    }
    rebuilt.push_str(suffix);
    rebuilt
}
