use vm_rust::player::{testing::{TestPlayer,run_test},testing_shared::TestHarness,reserve_player_ref};
fn main(){let p=std::env::args().nth(1).unwrap();run_test(async{let mut player=TestPlayer::new();player.load_movie(&p).await;reserve_player_ref(|p|{for f in 1..=120 {if let Some(s)=p.movie.score.get_script_in_frame(f){println!("{f} {} {}",s.cast_lib,s.cast_member)}}});});}
