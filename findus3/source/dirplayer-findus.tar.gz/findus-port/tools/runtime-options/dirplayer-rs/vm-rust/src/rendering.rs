use std::{
    borrow::Borrow,
    cell::{Cell, RefCell},
    collections::HashMap,
    rc::Rc,
};

use async_std::task::spawn_local;
use chrono::Local;
use itertools::Itertools;
use log::{debug, warn};
use wasm_bindgen::{prelude::*, Clamped};

use crate::{js_api::safe_js_string, player::{reserve_player_mut, symbols::builtin::BuiltInSymbol}};
use crate::{
    console_warn,
    js_api::JsApi,
    player::{
        bitmap::{
            bitmap::{self, get_system_default_palette, resolve_color_ref, Bitmap, PaletteRef},
            drawing::{should_matte_sprite, CopyPixelsParams},
            mask::BitmapMask,
            palette_map::PaletteMap,
        },
        cast_lib::CastMemberRef,
        cast_member::CastMemberType,
        geometry::IntRect,
        reserve_player_ref,
        score::{
            get_concrete_sprite_rect, get_score, get_score_sprite, get_sprite_at, ScoreRef,
        },
        sprite::{ColorRef, CursorRef, Sprite},
        DirPlayer, PLAYER_OPT,
    },
};

use crate::player::cast_manager::CastManager;
use crate::player::font::BitmapFont;
use crate::player::font::FontManager;
use crate::player::font::bitmap_font_copy_char;
use crate::player::handlers::datum_handlers::cast_member::font::{FontMemberHandlers, TextAlignment, StyledSpan, HtmlStyle};
use crate::director::lingo::datum::Datum;
use crate::player::score_keyframes::SpritePathKeyframes;
use crate::rendering_gpu::{DynamicRenderer, Renderer};

/// 500ms-on, 500ms-off caret blink phase derived from wall time. The renderer
/// runs every frame so this query is cheap and needs no separate timer.
fn caret_blink_visible() -> bool {
    let t = crate::player::testing_shared::now_ms();
    (t.rem_euclid(1000.0)) < 500.0
}

/// Standard text-selection background color (matches macOS-ish blue). Drawn
/// before glyphs so the text reads on top.
const SELECTION_COLOR: (u8, u8, u8) = (164, 205, 255);

/// Fill selection-highlight rectangles for the byte range [sel_lo..sel_hi)
/// within a wrapped Field/Text. Math reuses `caret_index_to_xy` so the rects
/// agree with the rendered glyphs byte-for-byte. `line_h` is the per-line
/// stride the renderer used (so caret y matches glyph y).
fn draw_text_selection_rects(
    bitmap: &mut Bitmap,
    text: &str,
    font: &BitmapFont,
    loc_h: i32,
    loc_v: i32,
    max_width: i32,
    alignment: BuiltInSymbol,
    line_h: i32,
    top_spacing: i16,
    sel_lo: i32,
    sel_hi: i32,
    palettes: &PaletteMap,
) {
    if sel_lo >= sel_hi {
        return;
    }
    let lines = Bitmap::wrap_lines_with_spans(text, font, max_width);
    let lo = sel_lo as usize;
    let hi = sel_hi as usize;
    let base_y = loc_v + top_spacing as i32;
    for (i, line) in lines.iter().enumerate() {
        if hi <= line.start || lo >= line.end && line.start != line.end {
            continue;
        }
        let from = lo.max(line.start);
        let to = hi.min(line.end);
        if from > to {
            continue;
        }
        // Compute x positions inline for THIS line — caret_index_to_xy snaps
        // soft-wrap-boundary indices to the FOLLOWING visual line, which
        // would collapse a multi-line selection's right edge onto the wrong
        // row. Walking the line's own chars (not bytes!) keeps every rect
        // bound to its own visual line AND counts one glyph advance per
        // visible character — the byte-walk variant gave umlauts and other
        // multi-byte codepoints 2x width, stretching the highlight past
        // the actual text.
        let line_w: i32 = line.text.chars()
            .map(|c| font.get_char_advance_for(c) as i32)
            .sum();
        let x_offset: i32 = if max_width > 0 {
            match alignment {
                BuiltInSymbol::Center => ((max_width - line_w) / 2).max(0),
                BuiltInSymbol::Right => (max_width - line_w).max(0),
                _ => 0,
            }
        } else {
            0
        };
        // `start` and `end` are absolute byte indices into `text` (sel_lo /
        // sel_hi clamped to this line). Subtract `line.start` to get a
        // byte offset into `line.text`, snap any non-boundary positions
        // forward, then slice and walk chars.
        let advance_for = |start: usize, end: usize| -> i32 {
            let mut s = start.saturating_sub(line.start).min(line.text.len());
            let mut e = end.saturating_sub(line.start).min(line.text.len());
            while s < line.text.len() && !line.text.is_char_boundary(s) { s += 1; }
            while e < line.text.len() && !line.text.is_char_boundary(e) { e += 1; }
            if e < s { return 0; }
            line.text[s..e]
                .chars()
                .map(|c| font.get_char_advance_for(c) as i32)
                .sum()
        };
        let y = base_y + (i as i32) * line_h;
        let mut left = loc_h + x_offset + advance_for(line.start, from);
        let mut right = loc_h + x_offset + advance_for(line.start, to);
        if right == left && hi > line.end {
            // Selection continues to next line — show a trailing space's worth.
            right += font.get_char_advance(b' ') as i32;
        }
        if right < left {
            std::mem::swap(&mut left, &mut right);
        }
        bitmap.fill_rect(left, y, right, y + font.char_height as i32, SELECTION_COLOR, palettes, 1.0);
    }
}

/// Interpolate path position between keyframes for filmloop animation.
/// Returns interpolated (x, y) position for the given frame, or None if no interpolation is needed.
fn interpolate_path_position(path_keyframes: &SpritePathKeyframes, frame: u32) -> Option<(i32, i32)> {
    let keyframes = &path_keyframes.keyframes;
    if keyframes.is_empty() {
        return None;
    }

    // Find the keyframe pair surrounding the current frame
    let prev_kf = keyframes.iter().rev().find(|kf| kf.frame <= frame);
    let next_kf = keyframes.iter().find(|kf| kf.frame > frame);

    match (prev_kf, next_kf) {
        (Some(prev), Some(next)) => {
            // Interpolate between prev and next keyframes
            let frame_range = next.frame - prev.frame;
            if frame_range == 0 {
                return Some((prev.x as i32, prev.y as i32));
            }
            let t = (frame - prev.frame) as f32 / frame_range as f32;
            let x = prev.x as f32 + (next.x as f32 - prev.x as f32) * t;
            let y = prev.y as f32 + (next.y as f32 - prev.y as f32) * t;
            Some((x as i32, y as i32))
        }
        (Some(prev), None) => {
            // Past the last keyframe - use last keyframe position
            Some((prev.x as i32, prev.y as i32))
        }
        (None, Some(_next)) => {
            // Before the first keyframe - return None to use channel_initialization_data position
            None
        }
        (None, None) => None,
    }
}

/// An in-progress score/puppet transition: the captured pre-transition stage
/// (`old_bitmap`), the effect to run, and when it started. `draw_frame` blends
/// `old_bitmap` → the freshly-rendered new stage per elapsed progress until done.
pub struct TransitionPlayback {
    pub old_bitmap: Bitmap,
    pub info: crate::player::cast_member::TransitionInfo,
    pub start_ms: i64,
}

/// Composite a transition frame in place: `cur` holds the freshly-rendered NEW stage,
/// `old` the captured pre-transition stage. `progress` is 0..1. Reveal-style effects
/// copy `old` back over the not-yet-revealed pixels; dissolve/fallback crossfades.
/// Built-in codes per the Director 11.5 Scripting Dictionary `puppetTransition` table.
fn apply_transition_effect(cur: &mut Bitmap, old: &Bitmap, ty: u8, chunk: u8, progress: f32) {
    let w = cur.width as i64;
    let h = cur.height as i64;
    if old.width as i64 != w || old.height as i64 != h || old.data.len() != cur.data.len() {
        return;
    }
    composite_transition_pixels(cur.data.as_mut_slice(), old.data.as_slice(), w, h, ty, chunk, progress);
}

/// Stable per-cell pseudo-random value in 0..1 for dissolve/random effects.
fn transition_cell_hash(a: i64, b: i64) -> f32 {
    let h = (a.wrapping_mul(73856093) ^ b.wrapping_mul(19349663)) as u32;
    (h & 0xffff) as f32 / 65535.0
}

/// Slice-level transition compositing shared by both backends (Canvas2D's
/// `Bitmap` path above and the WebGL2 framebuffer path). `cur_d` holds the
/// freshly-rendered NEW stage RGBA (top-left origin), `old_d` the captured
/// pre-transition stage; both are `w*h*4` bytes. See `apply_transition_effect`.
///
/// Effect patterns (codes 1..52, Director 11.5 `puppetTransition` table) were
/// matched against a frame-by-frame capture of Director's own playback: center-
/// out effects grow a band/box from the centre, edges-in close from the borders,
/// covers slide the NEW frame on from a side/corner, reveals slide the OLD frame
/// off to expose the NEW underneath, strips sweep diagonally, and dissolves fill
/// pseudo-random cells whose size scales with the `chunk` (size) argument.
pub fn composite_transition_pixels(cur_d: &mut [u8], old_d: &[u8], w: i64, h: i64, ty: u8, chunk: u8, progress: f32) {
    if old_d.len() != cur_d.len() || cur_d.len() < (w * h * 4) as usize {
        return;
    }
    let p = progress.clamp(0.0, 1.0);
    let n = cur_d.len();
    let pw = (p as f64 * w as f64) as i64;
    let ph = (p as f64 * h as f64) as i64;
    let cs = (chunk.max(1) as i64).min(64);
    let pf = p as f64;
    // Blind/checkerboard cell geometry.
    let band_h = (h / 16).max(1);
    let band_w = (w / 16).max(1);
    let cell_w = (w / 12).max(1);
    let cell_h = (h / 9).max(1);
    // Strip width for the diagonal staircase effects (39-46): ~16 strips.
    let strip_w = (w / 16).max(1);
    let strip_h = (h / 16).max(1);

    // `keep_new(x,y)` true → keep the NEW pixel; false → restore the OLD pixel.
    let keep_new: Box<dyn Fn(i64, i64) -> bool> = match ty {
        // --- Wipes (1-4): a single hard edge sweeps across ---
        1 => Box::new(move |x, _| x < pw),           // wipe right (new grows L→R)
        2 => Box::new(move |x, _| x >= w - pw),      // wipe left
        3 => Box::new(move |_, y| y < ph),           // wipe down
        4 => Box::new(move |_, y| y >= h - ph),      // wipe up
        // --- Center-out (band/box grows from centre) & Edges-in (closes from borders) ---
        5 => Box::new(move |x, _| (x - w / 2).abs() < pw / 2),                 // center out horizontal (full-height band)
        6 => Box::new(move |x, _| (x - w / 2).abs() >= (w - pw) / 2),          // edges in horizontal
        7 => Box::new(move |_, y| (y - h / 2).abs() < ph / 2),                 // center out vertical (full-width band)
        8 => Box::new(move |_, y| (y - h / 2).abs() >= (h - ph) / 2),          // edges in vertical
        9 => Box::new(move |x, y| (x - w / 2).abs() < pw / 2 && (y - h / 2).abs() < ph / 2),          // center out square
        10 => Box::new(move |x, y| (x - w / 2).abs() >= (w - pw) / 2 || (y - h / 2).abs() >= (h - ph) / 2), // edges in square
        // --- Pushes (11-14): new slides in from a side (edge for solid fills) ---
        11 => Box::new(move |x, _| x >= w - pw),     // push left (new enters right)
        12 => Box::new(move |x, _| x < pw),          // push right
        13 => Box::new(move |_, y| y < ph),          // push down
        14 => Box::new(move |_, y| y >= h - ph),     // push up
        // --- Reveals (15-22): OLD slides off, exposing NEW; diagonals leave an L-shape ---
        15 => Box::new(move |_, y| y >= h - ph),                       // reveal up
        16 => Box::new(move |x, y| x < pw || y >= h - ph),             // reveal up-right
        17 => Box::new(move |x, _| x < pw),                            // reveal right
        18 => Box::new(move |x, y| x < pw || y < ph),                  // reveal down-right
        19 => Box::new(move |_, y| y < ph),                            // reveal down
        20 => Box::new(move |x, y| x >= w - pw || y < ph),             // reveal down-left
        21 => Box::new(move |x, _| x >= w - pw),                       // reveal left
        22 => Box::new(move |x, y| x >= w - pw || y >= h - ph),        // reveal up-left
        // --- Dissolves (23-26): pseudo-random cells; size scales with `chunk` ---
        23 => Box::new(move |x, y| transition_cell_hash(x / cs, y / cs) < p),          // pixels fast
        24 => { let cw = (cs * 4).max(1); let ch = (cs * 2).max(1); Box::new(move |x, y| transition_cell_hash(x / cw, y / ch) < p) }, // boxy rectangles
        25 => { let c = (cs * 3).max(1); Box::new(move |x, y| transition_cell_hash(x / c, y / c) < p) },  // boxy squares
        26 => Box::new(move |x, y| transition_cell_hash(x / cs.max(2), y / cs.max(2)) < p),               // patterns
        // --- Random rows / columns (27-28): whole lines appear in random order ---
        27 => Box::new(move |_, y| transition_cell_hash(y, 0) < p),
        28 => Box::new(move |x, _| transition_cell_hash(x, 0) < p),
        // --- Covers (29-36): NEW slides on top from a side/corner (corner = box grow) ---
        29 => Box::new(move |_, y| y < ph),                            // cover down
        30 => Box::new(move |x, y| x >= w - pw && y < ph),             // cover down-left (from top-right)
        31 => Box::new(move |x, y| x < pw && y < ph),                  // cover down-right (from top-left)
        32 => Box::new(move |x, _| x >= w - pw),                       // cover left
        33 => Box::new(move |x, _| x < pw),                            // cover right
        34 => Box::new(move |_, y| y >= h - ph),                       // cover up
        35 => Box::new(move |x, y| x >= w - pw && y >= h - ph),        // cover up-left (from bottom-right)
        36 => Box::new(move |x, y| x < pw && y >= h - ph),             // cover up-right (from bottom-left)
        // --- Venetian (horizontal) blinds (37): slats open together ---
        37 => { let open = (pf * band_h as f64) as i64; Box::new(move |_, y| (y % band_h) < open) },
        // --- Checkerboard (38): even cells fill first half, odd cells second half ---
        38 => Box::new(move |x, y| {
            let parity = (((x / cell_w) + (y / cell_h)) & 1) as f32;
            (p - parity * 0.5) * 2.0 > 0.0
        }),
        // --- Strips (39-46): diagonal staircase. "bottom"/"top" step in vertical
        //     strips (quantize X); "left"/"right" step in horizontal strips (Y). ---
        39 => Box::new(move |x, y| { let qx = (x / strip_w * strip_w) as f64 / w as f64; qx + (y as f64 / h as f64) < 2.0 * pf }),                       // bottom, build left  (TL, step X)
        40 => Box::new(move |x, y| { let qx = (x / strip_w * strip_w) as f64 / w as f64; (1.0 - qx) + (y as f64 / h as f64) < 2.0 * pf }),               // bottom, build right (TR, step X)
        41 => Box::new(move |x, y| { let qy = (y / strip_h * strip_h) as f64 / h as f64; (x as f64 / w as f64) + qy < 2.0 * pf }),                       // left, build down    (TL, step Y)
        42 => Box::new(move |x, y| { let qy = (y / strip_h * strip_h) as f64 / h as f64; (x as f64 / w as f64) + (1.0 - qy) < 2.0 * pf }),               // left, build up      (BL, step Y)
        43 => Box::new(move |x, y| { let qy = (y / strip_h * strip_h) as f64 / h as f64; (1.0 - (x as f64 / w as f64)) + qy < 2.0 * pf }),               // right, build down   (TR, step Y)
        44 => Box::new(move |x, y| { let qy = (y / strip_h * strip_h) as f64 / h as f64; (1.0 - (x as f64 / w as f64)) + (1.0 - qy) < 2.0 * pf }),       // right, build up     (BR, step Y)
        45 => Box::new(move |x, y| { let qx = (x / strip_w * strip_w) as f64 / w as f64; qx + (1.0 - (y as f64 / h as f64)) < 2.0 * pf }),               // top, build left     (BL, step X)
        46 => Box::new(move |x, y| { let qx = (x / strip_w * strip_w) as f64 / w as f64; (1.0 - qx) + (1.0 - (y as f64 / h as f64)) < 2.0 * pf }),       // top, build right    (BR, step X)
        // --- Zoom open (box grows from centre) / close (closes from edges) ---
        47 => Box::new(move |x, y| (x - w / 2).abs() < pw / 2 && (y - h / 2).abs() < ph / 2),
        48 => Box::new(move |x, y| (x - w / 2).abs() >= (w - pw) / 2 || (y - h / 2).abs() >= (h - ph) / 2),
        // --- Vertical blinds (49) ---
        49 => { let open = (pf * band_w as f64) as i64; Box::new(move |x, _| (x % band_w) < open) },
        // --- Dissolve bits/pixels (50-52): fine pseudo-random cells ---
        50 => Box::new(move |x, y| transition_cell_hash(x / cs, y / cs) < p),
        51 => Box::new(move |x, y| transition_cell_hash(x, y) < p),        // per-pixel
        52 => Box::new(move |x, y| transition_cell_hash(x / cs.max(2), y / cs.max(2)) < p),
        // Unknown code → smooth crossfade.
        _ => {
            let inv = 1.0 - p;
            for i in (0..n).step_by(4) {
                cur_d[i] = (old_d[i] as f32 * inv + cur_d[i] as f32 * p) as u8;
                cur_d[i + 1] = (old_d[i + 1] as f32 * inv + cur_d[i + 1] as f32 * p) as u8;
                cur_d[i + 2] = (old_d[i + 2] as f32 * inv + cur_d[i + 2] as f32 * p) as u8;
            }
            return;
        }
    };

    for y in 0..h {
        for x in 0..w {
            if !keep_new(x, y) {
                let i = ((y * w + x) * 4) as usize;
                cur_d[i..i + 4].copy_from_slice(&old_d[i..i + 4]);
            }
        }
    }
}

pub struct PlayerCanvasRenderer {
    pub active_transition: Option<TransitionPlayback>,
    pub container_element: Option<web_sys::HtmlElement>,
    pub preview_container_element: Option<web_sys::HtmlElement>,
    pub canvas: web_sys::HtmlCanvasElement,
    pub ctx2d: web_sys::CanvasRenderingContext2d,
    pub preview_canvas: web_sys::HtmlCanvasElement,
    pub preview_ctx2d: web_sys::CanvasRenderingContext2d,
    pub size: (u32, u32),
    pub preview_size: (u32, u32),
    pub preview_member_ref: Option<CastMemberRef>,
    pub preview_font_size: Option<u16>,
    pub debug_selected_channel_num: Option<i16>,
    pub bitmap: Bitmap,
    native_cursor_cache: crate::cursor::NativeCursorCache,
}

pub(crate) fn get_or_load_font(
    font_manager: &mut FontManager,
    cast_manager: &CastManager,
    font_name: &str,
    font_size: Option<u16>,
    font_style: Option<u8>,
) -> Option<Rc<BitmapFont>> {
    return get_or_load_font_with_id(font_manager, cast_manager, font_name, font_size, font_style, None);
}

pub(crate) fn get_or_load_font_with_id(
    font_manager: &mut FontManager,
    cast_manager: &CastManager,
    font_name: &str,
    font_size: Option<u16>,
    font_style: Option<u8>,
    font_id: Option<u16>,
) -> Option<Rc<BitmapFont>> {
    if font_name.is_empty() || font_name == "System" {
        return font_manager.get_system_font();
    }

    // When PFR is disabled, skip all font lookups and use system font
    if !font_manager.pfr_enabled {
        return font_manager.get_system_font();
    }

    let cache_key = format!(
        "{}_{}_{}",
        font_name,
        font_size.unwrap_or(0),
        font_style.unwrap_or(0)
    );

    if let Some(font) = font_manager.font_cache.get(&cache_key) {
        return Some(Rc::clone(font));
    }

    let name_key = FontManager::cache_key(font_name);
    if let Some(font) = font_manager.font_cache.get(&name_key) {
        return Some(Rc::clone(font));
    }

    // Try font_id-based lookup (for STXT formatting runs that reference fonts by ID)
    if let Some(id) = font_id {
        if let Some(font_ref) = font_manager.font_by_id.get(&id).copied() {
            if let Some(font) = font_manager.fonts.get(&font_ref) {
                debug!(
                    "Font '{}' not found by name, but found by font_id={}", font_name, id
                );
                return Some(Rc::clone(font));
            }
        }
    }

    if let Some(loaded_font) =
        font_manager.get_font_with_cast(font_name, Some(cast_manager), font_size, font_style)
    {
        return Some(loaded_font);
    }

    // Try case-insensitive match in font cache before falling back to system font
    let font_name_lower = font_name.to_lowercase();
    for (key, font) in font_manager.font_cache.iter() {
        if key.to_lowercase() == font_name_lower
            || key.to_lowercase().starts_with(&format!("{}_", font_name_lower))
        {
            debug!(
                "Font '{}' (id={:?}) not found by exact match, using cache entry '{}'",
                font_name, font_id, key
            );
            return Some(Rc::clone(font));
        }
    }

    // PFR canonical fallback: prefer an embedded PFR font over system font / Canvas2D native
    if !font_name.is_empty() {
        use crate::player::font::FontManager;
        let canon = FontManager::canonical_font_name(font_name);
        if !canon.is_empty() {
            for (_key, font) in font_manager.font_cache.iter() {
                if font.char_widths.is_some() && FontManager::canonical_font_name(&font.font_name) == canon {
                    return Some(Rc::clone(font));
                }
            }
        }
    }

    // Font not found by any method, attempt fallback to system font
    let system_font = font_manager.get_system_font();

    if system_font.is_some() {
        debug!(
            "Font '{}' (id={:?}) not found, using system font fallback. Available fonts: {:?}",
            font_name, font_id,
            font_manager.font_cache.keys().collect::<Vec<_>>()
        );
    } else {
        debug!(
            "Font '{}' (id={:?}) not found and system font unavailable. Available fonts: {:?}",
            font_name, font_id,
            font_manager.font_cache.keys().collect::<Vec<_>>()
        );
    }

    system_font
}

pub fn render_stage_to_bitmap(
    player: &mut DirPlayer,
    bitmap: &mut Bitmap,
    debug_sprite_num: Option<i16>,
) {
    render_score_to_bitmap(
        player,
        &ScoreRef::Stage,
        bitmap,
        debug_sprite_num,
        IntRect::from_size(0, 0, player.movie.rect.width(), player.movie.rect.height()),
    );
}

/// Render a preview bitmap for a cast member. Returns `None` if the member type
/// is not previewable or required data (fonts, bitmaps) is unavailable.
pub fn render_preview_bitmap(
    player: &mut DirPlayer,
    member_ref: &CastMemberRef,
    preview_font_size: Option<u16>,
) -> Option<Bitmap> {
    let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;
    match &member.member_type {
        CastMemberType::Bitmap(sprite_member) => {
            let image_ref = sprite_member.image_ref;
            let reg_point = sprite_member.reg_point;
            let sprite_bitmap = player.bitmap_manager.get_bitmap(image_ref)?;
            let width = sprite_bitmap.width;
            let height = sprite_bitmap.height;
            let original_bit_depth = sprite_bitmap.original_bit_depth;

            let mut bitmap = Bitmap::new(
                width,
                height,
                32,
                32,
                0,
                PaletteRef::BuiltIn(get_system_default_palette()),
            );
            let palettes = &player.movie.cast_manager.palettes();
            bitmap.fill_relative_rect(
                0, 0, 0, 0,
                resolve_color_ref(
                    &palettes,
                    &player.bg_color,
                    &PaletteRef::BuiltIn(get_system_default_palette()),
                    original_bit_depth,
                ),
                palettes,
                1.0,
            );
            let sprite_bitmap = player.bitmap_manager.get_bitmap(image_ref)?;
            bitmap.copy_pixels(
                &palettes,
                sprite_bitmap,
                IntRect::from(0, 0, width as i32, height as i32),
                IntRect::from(0, 0, width as i32, height as i32),
                &HashMap::new(),
                None,
            );
            bitmap.set_pixel(
                reg_point.0 as i32,
                reg_point.1 as i32,
                (255, 0, 255),
                palettes,
            );
            Some(bitmap)
        }
        CastMemberType::FilmLoop(loop_member) => {
            let width = loop_member.info.width as i32;
            let height = loop_member.info.height as i32;
            let member_ref = member_ref.clone();

            let mut bitmap = Bitmap::new(
                width as u16,
                height as u16,
                32,
                32,
                0,
                PaletteRef::BuiltIn(get_system_default_palette()),
            );
            render_score_to_bitmap(
                player,
                &ScoreRef::FilmLoop(member_ref),
                &mut bitmap,
                None,
                IntRect::from_size(0, 0, width, height),
            );
            Some(bitmap)
        }
        CastMemberType::Font(font_member) => {
            let font_name = font_member.font_info.name.clone();
            let font_style = font_member.font_info.style;
            let member_font_size = font_member.font_info.size;

            // Resolve the font through the same path the text member's `image`
            // getter uses (`get_font_with_cast_and_bitmap`). That function
            // takes care of: PFR rasterisation at the requested preview size,
            // cast-scoped lookup, and falling back to existing rasterised
            // entries — so the dev preview shows exactly the glyphs Director
            // would use when rendering text in this font at this size.
            let req_size = preview_font_size.or(if member_font_size > 0 { Some(member_font_size) } else { None });
            let font: Rc<BitmapFont> = player.font_manager
                .get_font_with_cast_and_bitmap(
                    &font_name,
                    &player.movie.cast_manager,
                    &mut player.bitmap_manager,
                    req_size,
                    None,
                )
                .or_else(|| {
                    let name_lower = font_name.to_lowercase();
                    for (key, font) in player.font_manager.font_cache.iter() {
                        if key.to_lowercase() == name_lower
                            || key.to_lowercase().starts_with(&format!("{}_", name_lower))
                        {
                            return Some(font.clone());
                        }
                    }
                    None
                })
                .or_else(|| player.font_manager.get_system_font())?;

            // Get system font for rendering character code labels
            let system_font = player.font_manager.get_system_font();

            let font_bitmap_opt = player.bitmap_manager.get_bitmap(font.bitmap_ref).cloned();

            let preview_size = preview_font_size.unwrap_or(font.font_size).max(8);

            // Cell size is driven by the PFR-rasterized glyph dimensions at
            // the requested preview size. If the rasteriser failed (no PFR
            // data, or rasterize_pfr_at_size returned None) we fall back to
            // the member's native cell size, with a floor based on
            // preview_size so cells aren't collapsed too small to be useful.
            let cols = 16u16;
            let rows = 16u16;
            let cell_w = (font.char_width as u16).max(preview_size + 4);
            let cell_h = (font.char_height as u16).max((preview_size as f32 * 1.4) as u16);

            // Layout: each cell = grid_line(1px) + label_height + glyph_height
            let label_h: u16 = if system_font.is_some() { 10 } else { 0 };
            let grid_w: u16 = 1;
            let total_cell_w = cell_w + grid_w;
            let total_cell_h = cell_h + label_h + grid_w;
            let width = cols * total_cell_w + grid_w;
            let height = rows * total_cell_h + grid_w;

            let palettes = &player.movie.cast_manager.palettes();
            let mut bitmap = Bitmap::new(
                width, height, 32, 32, 0,
                PaletteRef::BuiltIn(get_system_default_palette()),
            );
            bitmap.fill_relative_rect(0, 0, 0, 0, (255, 255, 255), palettes, 1.0);

            let grid_color = (200, 200, 200);

            // Draw horizontal grid lines
            for row in 0..=rows {
                let y = (row * total_cell_h) as i32;
                bitmap.fill_rect(0, y, width as i32, y + grid_w as i32, grid_color, palettes, 1.0);
            }
            // Draw vertical grid lines
            for col in 0..=cols {
                let x = (col * total_cell_w) as i32;
                bitmap.fill_rect(x, 0, x + grid_w as i32, height as i32, grid_color, palettes, 1.0);
            }

            // Glyph copy: in `is_text_rendering` mode, black source pixels
            // are remapped to `color` (foreground) and white source pixels
            // are dropped. The default Director bitmap atlas is black-on-white,
            // so we want foreground=BLACK on the white preview background —
            // *not* white-on-white which previously rendered invisible glyphs.
            let draw_params = CopyPixelsParams { mask_offset: (0, 0),
                blend: 100,
                ink: 0,
                color: ColorRef::Rgb(0, 0, 0),
                bg_color: ColorRef::Rgb(255, 255, 255),
                mask_image: None,
                is_text_rendering: true,
                rotation: 0.0,
                skew: 0.0,
                sprite: None,
                original_dst_rect: None,
                bg_color_explicit: false,
                fore_color_explicit: false,
                ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                floor_rule: false,
            };

            for char_code in 0u16..256 {
                let grid_col = char_code % cols;
                let grid_row = char_code / cols;
                let cell_x = (grid_col * total_cell_w + grid_w) as i32;
                let cell_y = (grid_row * total_cell_h + grid_w) as i32;

                // Draw character code label using system font
                if let Some(ref sys_font) = system_font {
                    if let Some(sys_bitmap) = player.bitmap_manager.get_bitmap(sys_font.bitmap_ref) {
                        let label = format!("{}", char_code);
                        let label_params = CopyPixelsParams {
                            blend: 100,
                            ink: 0,
                            color: ColorRef::PaletteIndex(255),
                            bg_color: ColorRef::PaletteIndex(0),
                            mask_image: None,
                            is_text_rendering: true,
                            rotation: 0.0,
                            skew: 0.0,
                            sprite: None,
                            mask_offset: (0, 0),
                            original_dst_rect: None,
                            bg_color_explicit: false,
                            fore_color_explicit: false,
                            ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                            floor_rule: false,
                        };
                        bitmap.draw_text(
                            &label,
                            sys_font,
                            sys_bitmap,
                            cell_x,
                            cell_y,
                            label_params,
                            palettes,
                            0,
                            0,
                        );
                    }
                }

                // Draw the character glyph below the label.
                // Prefer the PFR / bitmap-atlas path so we show the AUTHORED
                // glyphs (the cast's actual font, not the browser's installed
                // version of "Verdana"/"Arial"/etc.). If the font has no
                // bitmap atlas at all (outline-only system fonts) we fall back
                // to Canvas2D so something visible still renders.
                let glyph_y = cell_y + label_h as i32;
                let has_bitmap_atlas = font_bitmap_opt
                    .as_ref()
                    .map(|b| b.width > 0 && b.height > 0)
                    .unwrap_or(false)
                    && font.char_width > 0
                    && font.char_height > 0;

                let mut rendered = false;
                if has_bitmap_atlas {
                    if let Some(ref font_bitmap) = font_bitmap_opt {
                        if (char_code as u8) >= font.first_char_num {
                            bitmap_font_copy_char(
                                &font,
                                font_bitmap,
                                char_code as u8,
                                &mut bitmap,
                                cell_x,
                                glyph_y,
                                palettes,
                                &draw_params,
                            );
                            rendered = true;
                        }
                    }
                }

                if !rendered {
                    let printable = char_code >= 32 && char_code != 127;
                    if printable {
                        if let Some(ch) = char::from_u32(char_code as u32) {
                            let display_name = font_name.split('_').next().unwrap_or(&font_name);
                            let mut style = HtmlStyle::default();
                            style.font_face = Some(display_name.to_string());
                            style.font_size = Some(preview_size as i32);
                            style.color = Some(0); // black
                            style.bold = matches!(font_style, 1 | 3);
                            style.italic = matches!(font_style, 2 | 3);
                            let span = StyledSpan { text: ch.to_string(), style };
                            let _ = FontMemberHandlers::render_native_text_to_bitmap(
                                &mut bitmap,
                                &[span],
                                cell_x + 2,
                                glyph_y + 1,
                                cell_w as i32 - 4,
                                cell_h as i32 - 2,
                                TextAlignment::Center,
                                cell_w as i32 - 4,
                                false,
                                None,
                                cell_h,
                                0,
                                0,
                                &[],
                                &[],
                                &[],
                            );
                        }
                    }
                }
            }
            Some(bitmap)
        }
        _ => None,
    }
}

pub fn render_score_to_bitmap(
    player: &mut DirPlayer,
    score_source: &ScoreRef,
    bitmap: &mut Bitmap,
    debug_sprite_num: Option<i16>,
    dest_rect: IntRect,
) {
    render_score_to_bitmap_with_offset(player, score_source, bitmap, debug_sprite_num, dest_rect, (0, 0), None);
}

/// Get the filmloop's info rect (the authoritative viewport from the Director file).
/// The info rect is stored in the filmloop's member-specific data as:
///   reg_point = (left, top), width = right, height = bottom
/// Returns None if the member isn't a filmloop or the rect has zero dimensions.
pub fn get_filmloop_info_rect(player: &DirPlayer, member_ref: &CastMemberRef) -> Option<IntRect> {
    let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;
    let film_loop = match &member.member_type {
        CastMemberType::FilmLoop(fl) => fl,
        _ => return None,
    };
    let rect = IntRect::from(
        film_loop.info.reg_point.0 as i32,
        film_loop.info.reg_point.1 as i32,
        film_loop.info.width as i32,
        film_loop.info.height as i32,
    );
    if rect.width() > 0 && rect.height() > 0 {
        Some(rect)
    } else {
        None
    }
}

/// Recompute the initial_rect for a filmloop using actual bitmap dimensions.
/// This is more accurate than the precomputed initial_rect because it uses
/// the real cast member dimensions instead of the channel_data dimensions.
pub fn compute_filmloop_initial_rect_with_members(
    player: &DirPlayer,
    member_ref: &CastMemberRef,
) -> Option<IntRect> {
    let member = player.movie.cast_manager.find_member_by_ref(member_ref)?;
    let film_loop = match &member.member_type {
        CastMemberType::FilmLoop(fl) => fl,
        _ => return None,
    };

    let filmloop_cast_lib = member_ref.cast_lib;
    let mut min_x = i32::MAX;
    let mut min_y = i32::MAX;
    let mut max_x = i32::MIN;
    let mut max_y = i32::MIN;
    let mut found_any = false;

    for (_frame_idx, channel_idx, data) in film_loop.score.channel_initialization_data.iter() {
        // Skip effect channels (channels 0-5 in raw data)
        if *channel_idx < 6 {
            continue;
        }
        // Skip empty sprites
        if data.cast_member == 0 || data.cast_lib == 0 {
            continue;
        }

        // Resolve the cast member reference
        let sprite_cast_lib = if data.cast_lib == 65535 {
            filmloop_cast_lib as i32
        } else {
            data.cast_lib as i32
        };
        let sprite_member_ref = CastMemberRef {
            cast_lib: sprite_cast_lib,
            cast_member: data.cast_member as i32,
        };

        // Get actual bitmap dimensions and registration point from the cast member.
        // The registration point is the anchor used for positioning - sprite_left = pos_x - reg_x.
        let (actual_width, actual_height, reg_x, reg_y) = if let Some(sprite_member) =
            player.movie.cast_manager.find_filmloop_inner_member(&sprite_member_ref)
        {
            match &sprite_member.member_type {
                CastMemberType::Bitmap(bm) => {
                    // Try to get actual bitmap dimensions from BitmapManager
                    let (w, h) = if let Some(bitmap) = player.bitmap_manager.get_bitmap(bm.image_ref) {
                        (bitmap.width as i32, bitmap.height as i32)
                    } else {
                        // Fall back to BitmapInfo dimensions
                        (bm.info.width as i32, bm.info.height as i32)
                    };
                    // Use the actual registration point from the bitmap
                    (w, h, bm.reg_point.0 as i32, bm.reg_point.1 as i32)
                }
                _ => (data.width as i32, data.height as i32, data.width as i32 / 2, data.height as i32 / 2),
            }
        } else {
            (data.width as i32, data.height as i32, data.width as i32 / 2, data.height as i32 / 2)
        };

        if actual_width == 0 && actual_height == 0 {
            continue;
        }

        // pos_x/pos_y is the loc (registration point position).
        // The sprite's top-left corner is: pos - reg_point
        let sprite_left = data.pos_x as i32 - reg_x;
        let sprite_top = data.pos_y as i32 - reg_y;
        let sprite_right = sprite_left + actual_width;
        let sprite_bottom = sprite_top + actual_height;

        debug!(
            "  compute_initial_rect: ch {} m {}:{} pos ({}, {}) size {}x{} reg ({}, {}) -> bounds ({}, {}, {}, {})",
            channel_idx, sprite_member_ref.cast_lib, sprite_member_ref.cast_member,
            data.pos_x, data.pos_y, actual_width, actual_height, reg_x, reg_y,
            sprite_left, sprite_top, sprite_right, sprite_bottom
        );

        if sprite_left < min_x {
            min_x = sprite_left;
        }
        if sprite_top < min_y {
            min_y = sprite_top;
        }
        if sprite_right > max_x {
            max_x = sprite_right;
        }
        if sprite_bottom > max_y {
            max_y = sprite_bottom;
        }
        found_any = true;
    }

    if !found_any {
        return None;
    }

    let result = IntRect::from(min_x, min_y, max_x, max_y);
    debug!(
        "compute_filmloop_initial_rect_with_members: FINAL rect ({}, {}, {}, {}) size {}x{}",
        result.left, result.top, result.right, result.bottom,
        result.width(), result.height()
    );
    Some(result)
}

/// Resolve a filmloop child sprite's authored fore/bg colors from its
/// `ScoreFrameChannelData`. Mirrors `score.rs`'s `match data.color_flag`
/// table (0 = both palette, 1 = fg RGB, 2 = bg RGB, 3 = both RGB) so we
/// don't accidentally treat an authored palette index as RGB just because
/// the parser populated the unrelated `_g`/`_b` channel bytes.
fn resolve_filmloop_child_colors(
    data: &crate::director::chunks::score::ScoreFrameChannelData,
) -> (ColorRef, ColorRef) {
    let (fore_is_rgb, back_is_rgb) = match data.color_flag {
        1 => (true, false),
        2 => (false, true),
        3 => (true, true),
        _ => (false, false),
    };
    let fg = if fore_is_rgb {
        ColorRef::Rgb(data.fore_color, data.fore_color_g, data.fore_color_b)
    } else {
        ColorRef::PaletteIndex(data.fore_color)
    };
    let bg = if back_is_rgb {
        ColorRef::Rgb(data.back_color, data.back_color_g, data.back_color_b)
    } else {
        ColorRef::PaletteIndex(data.back_color)
    };
    (fg, bg)
}

/// Render a filmloop directly from its channel_initialization_data.
/// This is needed because filmloop Score.channels are not populated with sprite data
/// like the main stage score. Instead, we read sprite info directly from channel_initialization_data.
///
/// Director behavior: Film loop frames use the PARENT sprite's ink semantics,
/// not their own stored ink values. The parent_ink, parent_color, and parent_bg_color
/// are the properties of the sprite displaying the film loop on the stage.
fn render_filmloop_from_channel_data(
    player: &mut DirPlayer,
    member_ref: &CastMemberRef,
    bitmap: &mut Bitmap,
    dest_rect: IntRect,
    initial_rect: IntRect,
    parent_ink: u32,
    parent_color: ColorRef,
    parent_bg_color: ColorRef,
    prefer_bitmap_dims: bool,
) {
    use crate::player::bitmap::drawing::CopyPixelsParams;
    use crate::player::score::get_channel_number_from_index;

    let palettes = player.movie.cast_manager.palettes();

    // The filmloop's own cast_lib is used as the default when channel data has cast_lib=65535
    let filmloop_cast_lib = member_ref.cast_lib;

    // Get filmloop data
    // Filmloops use keyframe-based animation - not every frame has explicit data.
    // We need to find the most recent keyframe data for each channel that is <= current_frame.
    // Also extract keyframes_cache for path interpolation.
    let (current_frame, channel_data, total_frames, keyframes_cache) = {
        let member = player.movie.cast_manager.find_member_by_ref(member_ref);
        if member.is_none() {
            return;
        }
        let member = member.unwrap();
        match &member.member_type {
            CastMemberType::FilmLoop(film_loop_member) => {
                let frame = film_loop_member.current_frame;
                // Frame numbers are 1-based, channel_initialization_data frame indices are 0-based
                let frame_idx_target = frame.saturating_sub(1);

                // Group data by channel, keeping only valid sprite channels
                let mut channel_map: std::collections::HashMap<u16, (u32, crate::director::chunks::score::ScoreFrameChannelData)> =
                    std::collections::HashMap::new();

                // Sprite-span gating: the score writes explicit "clear" deltas
                // (all-zero bytes) at end_frame to deactivate channels, but the
                // score parser drops those entries (its has_sprite_data check
                // is all-or-nothing). Without checking spans, "most recent
                // active data" keeps every channel alive forever, so a
                // 6-channel radar-ping filmloop (nav_circleanim) accumulates
                // all six rings instead of cycling.
                //
                // Build a per-channel set of active spans up front. A channel
                // entry is only kept when current_frame falls inside one of
                // its spans (1-based, like the parsed FrameIntervalPrimary).
                let frame_intervals = &film_loop_member.score_chunk.frame_intervals;
                let has_spans = !frame_intervals.is_empty();

                for (frame_idx, channel_idx, data) in film_loop_member.score.channel_initialization_data.iter() {
                    // Skip effect channels (0-5)
                    if *channel_idx < 6 {
                        continue;
                    }
                    // Inline shape sprites use cast_lib=0xFFFE / cast_member=0 as a
                    // sentinel — they draw an oval/rect from the sprite-record
                    // geometry, no cast member required. Keep those entries.
                    let is_inline_shape = data.cast_lib == 0xFFFE && data.cast_member == 0
                        && (data.width > 0 || data.height > 0);
                    // Skip empty sprites (cast_member 0 with no inline-shape geometry).
                    if data.cast_member == 0 && !is_inline_shape {
                        continue;
                    }
                    // Only consider frames <= current frame (keyframe interpolation)
                    if *frame_idx > frame_idx_target {
                        continue;
                    }
                    // Span gating: skip channels whose span doesn't include the
                    // current frame. Only applies when the filmloop ships
                    // frame_intervals — older filmloops without them keep the
                    // legacy "most recent data wins" behaviour.
                    if has_spans {
                        let in_span = frame_intervals.iter().any(|(primary, _)| {
                            primary.channel_index == *channel_idx as u32
                                && primary.start_frame <= frame
                                && frame <= primary.end_frame
                        });
                        if !in_span {
                            continue;
                        }
                    }
                    // Keep the most recent (highest frame_idx) data for each channel
                    let entry = channel_map.entry(*channel_idx);
                    entry
                        .and_modify(|(existing_frame, existing_data)| {
                            if *frame_idx > *existing_frame {
                                *existing_frame = *frame_idx;
                                *existing_data = data.clone();
                            }
                        })
                        .or_insert((*frame_idx, data.clone()));
                }

                let data: Vec<_> = channel_map
                    .into_iter()
                    .map(|(channel_idx, (frame_idx, data))| (frame_idx, channel_idx, data))
                    .collect();

                // Use cached total_frames or compute and cache it
                let total_frames = film_loop_member.cached_total_frames.unwrap_or_else(|| {
                    let init_data_max = film_loop_member.score.channel_initialization_data
                        .iter()
                        .map(|(frame_idx, _, _)| *frame_idx + 1)
                        .max()
                        .unwrap_or(1);
                    let span_max = film_loop_member.score.sprite_spans
                        .iter()
                        .map(|span| span.end_frame)
                        .max()
                        .unwrap_or(1);
                    let keyframes_max = film_loop_member.score.keyframes_cache.values()
                        .filter_map(|channel_kf| channel_kf.path.as_ref())
                        .flat_map(|path_kf| path_kf.keyframes.iter())
                        .map(|kf| kf.frame)
                        .max()
                        .unwrap_or(1);
                    init_data_max.max(span_max).max(keyframes_max)
                });

                // Arc clone is O(1) - just a reference count bump
                let keyframes_cache = film_loop_member.score.keyframes_cache.clone();

                (frame, data, total_frames, keyframes_cache)
            }
            _ => return,
        }
    };

    // Since our bitmap is sized to match initial_rect dimensions (1:1 scaling),
    // we just need to translate by subtracting initial_rect origin.
    // If we later support non-1:1 scaling, we'd use:
    //   rel_x = (pos_x - initial_rect.left) * dest_width / initial_rect.width()
    let scale_x = dest_rect.width() as f32 / initial_rect.width().max(1) as f32;
    let scale_y = dest_rect.height() as f32 / initial_rect.height().max(1) as f32;

    debug!(
        "render_filmloop_from_channel_data: frame {}/{}, {} sprites, initial_rect ({}, {}, {}, {}), scale ({:.2}, {:.2})",
        current_frame, total_frames, channel_data.len(),
        initial_rect.left, initial_rect.top, initial_rect.right, initial_rect.bottom,
        scale_x, scale_y
    );

    // Sort by channel number for consistent z-ordering
    let mut sorted_data = channel_data;
    sorted_data.sort_by_key(|(_, channel_idx, _)| *channel_idx);

    for (_frame_idx, channel_idx, data) in sorted_data {
        let channel_num = get_channel_number_from_index(channel_idx as u32);

        // Inline shape sprite (no cast member): cast_lib=0xFFFE / cast_member=0.
        // The sprite-record geometry encodes an oval/rect drawn directly. CS uses
        // this in nav_circleanim to animate growing concentric ovals as a
        // radar-ping effect. Render it here and skip the cast-member path.
        let is_inline_shape = data.cast_lib == 0xFFFE && data.cast_member == 0
            && (data.width > 0 || data.height > 0);
        if is_inline_shape {
            // Director shape sprites centre on (pos_x, pos_y). For the radar-
            // ping nav_circleanim, every channel records the same pos and
            // grows width/height across frames, so all rings share a centre —
            // top-left positioning would scatter them by their increasing
            // half-widths and miss the city dot.
            let sprite_left = data.pos_x as i32 - (data.width as i32) / 2;
            let sprite_top = data.pos_y as i32 - (data.height as i32) / 2;
            let rel_x = sprite_left - initial_rect.left;
            let rel_y = sprite_top - initial_rect.top;
            let sprite_rect = IntRect::from(
                rel_x, rel_y,
                rel_x + data.width as i32,
                rel_y + data.height as i32,
            );

            // Inline shapes encode colour as RGB across the 6 D8+ extended
            // colour bytes: fore = (byte 2, byte 24, byte 26), back = (byte 3,
            // byte 25, byte 27). resolve_filmloop_child_colors only emits Rgb
            // when color_flag is set, but inline-shape records leave color_flag
            // at 0 and rely on the explicit RGB triplets directly — without
            // this, foreColor=0xFF resolves through SystemWin index 255 to
            // black, instead of nav_circleanim's authored red (255, 0, 0).
            let r = data.fore_color;
            let g = data.fore_color_g;
            let b = data.fore_color_b;
            let blend_pct = if data.blend == 255 || data.blend == 0 {
                100
            } else {
                ((255.0 - data.blend as f32) * 100.0 / 255.0) as i32
            };
            let alpha = (blend_pct as f32 / 100.0).clamp(0.0, 1.0);

            // Stroke directly with thickness=1 — bypasses
            // draw_shape_with_sprite's "subtract 1 for unfilled" convention so
            // the outline is exactly 1 pixel. Filling every channel produced
            // one solid blob because the largest concentric oval covered all
            // the smaller ones; real radar-ping is expanding rings.
            bitmap.stroke_ellipse(
                sprite_rect.left,
                sprite_rect.top,
                sprite_rect.right,
                sprite_rect.bottom,
                (r, g, b),
                &palettes,
                alpha,
                1,
            );
            continue;
        }

        // Build member ref from channel data
        // cast_lib 65535 means "use the filmloop's cast library"
        let sprite_member_ref = CastMemberRef {
            cast_lib: if data.cast_lib == 65535 { filmloop_cast_lib } else { data.cast_lib as i32 },
            cast_member: data.cast_member as i32,
        };

        let member = player.movie.cast_manager.find_filmloop_inner_member(&sprite_member_ref);
        if member.is_none() {
            warn!(
                "[FILMLOOP-LOOKUP-FAIL] filmloop=({},{}) chan={} asked_for=({},{}) raw_cast_lib={}",
                filmloop_cast_lib, member_ref.cast_member,
                channel_num,
                sprite_member_ref.cast_lib, sprite_member_ref.cast_member,
                data.cast_lib,
            );
            continue;
        }
        let member = member.unwrap();

        // Translate sprite position relative to initial_rect origin, then scale to dest_rect
        //
        // For channels with path keyframes, interpolate between keyframes
        // Director frame numbers are 1-based, keyframes use 1-based Director frame numbers
        let (pos_x, pos_y) = if let Some(channel_keyframes) = keyframes_cache.get(&(channel_num as u16)) {
            if let Some(path_keyframes) = &channel_keyframes.path {
                // Debug: log path keyframes for this channel
                if current_frame <= 5 || current_frame >= 95 {
                    let kf_summary: Vec<String> = path_keyframes.keyframes.iter()
                        .take(5)
                        .map(|kf| format!("f{}:({},{})", kf.frame, kf.x, kf.y))
                        .collect();
                    let last_kf = path_keyframes.keyframes.last();
                    debug!(
                        "    PATH keyframes for channel {}: {} keyframes, first 5: {:?}, last: {:?}",
                        channel_num, path_keyframes.keyframes.len(), kf_summary, last_kf
                    );
                }

                // Try to get interpolated position from path keyframes
                if let Some((interp_x, interp_y)) = interpolate_path_position(path_keyframes, current_frame) {
                    (interp_x as i16, interp_y as i16)
                } else {
                    // Fall back to static keyframe position
                    (data.pos_x, data.pos_y)
                }
            } else {
                (data.pos_x, data.pos_y)
            }
        } else {
            (data.pos_x, data.pos_y)
        };

        // Get actual member dimensions and registration point from the cast member.
        let (member_width, member_height, reg_x, reg_y) = match &member.member_type {
            CastMemberType::Bitmap(bm) => {
                let (w, h) = if let Some(bitmap) = player.bitmap_manager.get_bitmap(bm.image_ref) {
                    (bitmap.width as u16, bitmap.height as u16)
                } else {
                    (bm.info.width as u16, bm.info.height as u16)
                };
                (w, h, bm.reg_point.0 as i32, bm.reg_point.1 as i32)
            }
            // For shapes and other non-bitmap members, pos_x/pos_y is the top-left corner.
            // Use (0,0) registration — shapes don't have a registration point like bitmaps.
            _ => (data.width, data.height, 0, 0),
        };

        // Choose between channel data dims (sprite dims) and actual bitmap dims.
        // When the filmloop's info_rect matches the bitmap bounding box, the
        // filmloop shows full bitmap content and bitmap dims are more accurate.
        // Otherwise the filmloop is a viewport/crop and sprite dims represent
        // the intended display size within that viewport.
        let (use_width, use_height) = if prefer_bitmap_dims {
            if member_width > 0 && member_height > 0 {
                (member_width, member_height)
            } else if data.width > 0 && data.height > 0 {
                (data.width, data.height)
            } else {
                (member_width, member_height)
            }
        } else {
            if data.width > 0 && data.height > 0 {
                (data.width, data.height)
            } else {
                (member_width, member_height)
            }
        };

        // When bitmap dimensions differ from display dimensions (scale mode with channel data),
        // scale the registration point proportionally from bitmap space to display space.
        let (scaled_reg_x, scaled_reg_y) = if member_width > 0 && member_height > 0
            && (member_width != use_width || member_height != use_height)
        {
            (
                reg_x * use_width as i32 / member_width as i32,
                reg_y * use_height as i32 / member_height as i32,
            )
        } else {
            (reg_x, reg_y)
        };
        let sprite_left = pos_x as i32 - scaled_reg_x;
        let sprite_top = pos_y as i32 - scaled_reg_y;
        let rel_x = sprite_left - initial_rect.left;
        let rel_y = sprite_top - initial_rect.top;

        let rel_w = use_width as i32;
        let rel_h = use_height as i32;

        let sprite_rect = IntRect::from(
            rel_x,
            rel_y,
            rel_x + rel_w,
            rel_y + rel_h,
        );

        debug!(
            "  channel {}: member {}:{} type {:?} orig ({}, {}) interp ({}, {}) data_size {}x{} use_size {}x{} reg ({}, {}) sprite_left {} initial_left {} -> rect ({}, {}, {}, {})",
            channel_num, sprite_member_ref.cast_lib, sprite_member_ref.cast_member,
            member.member_type.member_type_id(),
            data.pos_x, data.pos_y,
            pos_x, pos_y,
            data.width, data.height,
            use_width, use_height,
            reg_x, reg_y,
            sprite_left, initial_rect.left,
            sprite_rect.left, sprite_rect.top, sprite_rect.right, sprite_rect.bottom
        );

        match &member.member_type {
            CastMemberType::Bitmap(bitmap_member) => {
                // Director rule: filmloop child sprites ALWAYS render with
                // their OWN authored ink/fore/bgColor. The outer sprite's ink
                // applies to the composited filmloop bitmap as a whole (at
                // the stage layer), it does NOT cascade down to override
                // individual child inks.
                let (mut ink, sprite_color, sprite_bg_color) = {
                    let (fg, bg) = resolve_filmloop_child_colors(&data);
                    // Mask off bit 7 (stretch flag) from the ink byte.
                    ((data.ink as u32) & 0x3F, fg, bg)
                };

                // For ink 9 (Mask), the mask bitmap is the next cast member
                // (cast_member + 1) in the same library. Resolve and clone it
                // before taking the mutable borrow on bitmap_manager below.
                // The mask is aligned to the source by their registration
                // points (Director allows mismatched dimensions: mask 55x63 vs
                // source 51x58 in CS rightwall torch).
                let src_reg = (bitmap_member.reg_point.0 as i32, bitmap_member.reg_point.1 as i32);
                let ink9_mask: Option<(Bitmap, (i32, i32))> = if ink == 9 {
                    let mask_ref = CastMemberRef {
                        cast_lib: if data.cast_lib == 65535 { filmloop_cast_lib } else { data.cast_lib as i32 },
                        cast_member: data.cast_member as i32 + 1,
                    };
                    let found_member = player.movie.cast_manager
                        .find_filmloop_inner_member(&mask_ref);
                    let mask_reg = match found_member.as_ref().map(|m| &m.member_type) {
                        Some(CastMemberType::Bitmap(bm)) => {
                            (bm.reg_point.0 as i32, bm.reg_point.1 as i32)
                        }
                        _ => src_reg,
                    };
                    found_member
                        .and_then(|m| {
                            if let CastMemberType::Bitmap(bm) = &m.member_type {
                                Some(bm.image_ref)
                            } else {
                                None
                            }
                        })
                        .and_then(|img_ref| player.bitmap_manager.get_bitmap(img_ref))
                        .cloned()
                        .map(|bmp| (bmp, (mask_reg.0 - src_reg.0, mask_reg.1 - src_reg.1)))
                } else {
                    None
                };

                let sprite_bitmap = player
                    .bitmap_manager
                    .get_bitmap_mut(bitmap_member.image_ref);
                if sprite_bitmap.is_none() {
                    debug!(
                        "    Bitmap image_ref {} not found in bitmap_manager",
                        bitmap_member.image_ref
                    );
                    continue;
                }
                let src_bitmap = sprite_bitmap.unwrap();

                let src_rect = IntRect::from(0, 0, src_bitmap.width as i32, src_bitmap.height as i32);
                // Use the display dimensions (from channel data) for dst_rect.
                // When bitmap dimensions differ from display dimensions (e.g. thin strips
                // that Director stretches to fill the display rect), copy_pixels will
                // handle the scaling automatically via its scale_x/scale_y computation.
                //
                // Filmloop inner sprites encode flipH/flipV as bit flags in the
                // `unk5` byte of the score record (bit 5 = flipH, bit 6 = flipV
                // — unused D7 editable/moveable byte repurposed in D8+). Wall
                // posters that ship a pre-flipped pair (`leftwall X` vs
                // `rightwall X`) rely on these bits. Invert the dst_rect
                // corners to trigger copy_pixels' existing mirror path.
                let flip_h = data.flip_h();
                let flip_v = data.flip_v();
                let dst_rect = {
                    let mut r = sprite_rect.clone();
                    if flip_h { std::mem::swap(&mut r.left, &mut r.right); }
                    if flip_v { std::mem::swap(&mut r.top, &mut r.bottom); }
                    r
                };

                // Check if bitmap has actual data
                let has_data = !src_bitmap.data.is_empty();
                let first_pixels: Vec<u8> = src_bitmap.data.iter().take(16).copied().collect();

                debug!(
                    "    Bitmap found: {}x{} bit_depth={} image_ref={} ink={} blend={} has_data={} first_bytes={:?} src_rect=({},{},{},{}) dst_rect=({},{},{},{})",
                    src_bitmap.width, src_bitmap.height, src_bitmap.bit_depth, bitmap_member.image_ref,
                    data.ink, data.blend, has_data, first_pixels,
                    src_rect.left, src_rect.top, src_rect.right, src_rect.bottom,
                    dst_rect.left, dst_rect.top, dst_rect.right, dst_rect.bottom
                );

                // Filmloop blend: inverted 0-255 scale (0 → 100%, 127 → ~50%)
                // 255 is treated as default/opaque (same as shape/vector paths)
                let blend = crate::player::score::convert_raw_blend(data.blend, data.sprite_flags, player.movie.dir_version);

                // blend 0 is fully transparent — Director draws nothing at all.
                // We must skip rather than draw-with-zero-alpha, because the
                // filmloop offscreen is 32-bit and `set_pixel_fast` hardcodes
                // alpha to 0xFF: a zero-alpha blend resolves to the destination
                // colour (the cleared RGBA(0,0,0,0) → black) and then stamps it
                // OPAQUE. mission_popup_anim_in has exactly this shape — a
                // full-size blend-0 layer on every frame — so the whole 519x290
                // offscreen turned into an opaque black rectangle that survived
                // the ink shader's `src.a < 0.01` discard and covered the popup.
                if blend <= 0 {
                    continue;
                }

                // Only use matte mask for inks that support it:
                // - Ink 0 (copy): for trimWhiteSpace edge transparency (indexed and 16-bit)
                // - Ink 8 (matte): always uses matte (indexed AND 16-bit; 32-bit
                //   without embedded alpha also needs it — drawing.rs has its
                //   own flood-fill path for that case).
                // - Ink 7, 36 (color-key): do NOT use matte - they have their own
                //   bgColor-based transparency that conflicts with matte logic
                let is_indexed = src_bitmap.original_bit_depth <= 8;
                let is_16bit = src_bitmap.original_bit_depth == 16;
                let is_32bit_no_alpha =
                    src_bitmap.original_bit_depth == 32 && !src_bitmap.use_alpha;
                let should_use_matte = (is_indexed && (ink == 0 || ink == 8))
                    || (is_16bit && (ink == 0 || ink == 8))
                    || (is_32bit_no_alpha && ink == 8);

                let mask = if should_use_matte {
                    if src_bitmap.matte.is_none() {
                        src_bitmap.create_matte(&palettes);
                    }
                    src_bitmap.matte.as_ref()
                } else {
                    None
                };

                // Debug: resolve some representative palette indices to see what colors they would be
                let test_idx_0 = crate::player::bitmap::bitmap::resolve_color_ref(
                    &palettes,
                    &ColorRef::PaletteIndex(0),
                    &src_bitmap.palette_ref,
                    src_bitmap.original_bit_depth,
                );
                let test_idx_255 = crate::player::bitmap::bitmap::resolve_color_ref(
                    &palettes,
                    &ColorRef::PaletteIndex(255),
                    &src_bitmap.palette_ref,
                    src_bitmap.original_bit_depth,
                );
                let test_idx_128 = crate::player::bitmap::bitmap::resolve_color_ref(
                    &palettes,
                    &ColorRef::PaletteIndex(128),
                    &src_bitmap.palette_ref,
                    src_bitmap.original_bit_depth,
                );

                debug!(
                    "    Calling copy_pixels: dest_bitmap {}x{} bit_depth={} src_palette={:?} orig_bit_depth={} sprite_color={:?} sprite_bg_color={:?}",
                    bitmap.width, bitmap.height, bitmap.bit_depth,
                    src_bitmap.palette_ref, src_bitmap.original_bit_depth, sprite_color, sprite_bg_color
                );
                debug!(
                    "    Palette test: idx_0={:?} idx_128={:?} idx_255={:?}",
                    test_idx_0, test_idx_128, test_idx_255
                );

                // Debug: check matte mask status
                if let Some(m) = &mask {
                    // Count true/false bits in matte
                    let total_pixels = m.width as usize * m.height as usize;
                    let true_count = m.data.count_ones();
                    let false_count = total_pixels - true_count;
                    debug!(
                        "    Matte mask: {}x{} total={} true(opaque)={} false(transparent)={}",
                        m.width, m.height, total_pixels, true_count, false_count
                    );
                } else {
                    debug!(
                        "    Matte mask: None"
                    );
                }

                let params = CopyPixelsParams {
                    blend,
                    ink,
                    color: sprite_color,
                    bg_color: sprite_bg_color,
                    mask_image: mask.map(|m| m as &BitmapMask),
                    is_text_rendering: false,
                    // Carry the inner sprite's stored rotation / skew so
                    // filmloops that mirror via Director's (rotation=180,
                    // skew=180) trick render correctly — without this, wall
                    // posters that ship both left/right filmloops with
                    // mirrored inner sprites render unflipped.
                    rotation: data.rotation,
                    skew: data.skew,
                    sprite: None,
                    mask_offset: (0, 0),
                    // Pass the non-inverted sprite_rect here — copy_pixels uses
                    // it for scale_w/scale_h, which must stay positive. The
                    // `dst_rect` argument carries the flip via swapped corners.
                    original_dst_rect: Some(sprite_rect.clone()),
                    bg_color_explicit: false,
                    fore_color_explicit: false,
                    ink9_mask_bitmap: ink9_mask.as_ref().map(|(bmp, _)| bmp),
                    ink9_mask_offset: ink9_mask.as_ref().map(|(_, off)| *off).unwrap_or((0, 0)),
                    floor_rule: true,
                };

                bitmap.copy_pixels_with_params(
                    &palettes,
                    &src_bitmap,
                    dst_rect,
                    src_rect,
                    &params,
                );
            }
            CastMemberType::Shape(shape_member) => {
                // Skip blank placeholders and zero-size shapes, but NOT a #line: a line
                // is 1 px in one dimension by nature, so "width <= 1 || height <= 1"
                // dropped every horizontal and vertical line before it reached the
                // draw code (which explicitly promises a line "never vanishes"). The
                // divider under the ruler on klods.dcr's working drawing went missing
                // this way; measured against the projector, S8. A line is skipped
                // only when BOTH dimensions collapse.
                let is_line = matches!(shape_member.shape_info.shape_type, crate::director::enums::ShapeType::Line);
                if (data.width <= 1 || data.height <= 1) && !(is_line && (data.width > 1 || data.height > 1)) {
                    continue;
                }

                // Get sprite foreground color from channel data
                let (sprite_color, _) = resolve_filmloop_child_colors(&data);

                // Build a temporary sprite for draw_shape_with_sprite
                let mut temp_sprite = Sprite::new(channel_num as usize);
                temp_sprite.color = sprite_color;
                temp_sprite.ink = ((data.ink & 0x7F) / 5) as i32;
                temp_sprite.blend = if data.blend == 255 { 100 } else {
                    ((255.0 - data.blend as f32) * 100.0 / 255.0) as i32
                };

                let frame_palette = player.movie.score.get_frame_palette(player.movie.current_frame);
                bitmap.draw_shape_with_sprite(&temp_sprite, &shape_member.shape_info, sprite_rect, &palettes, &frame_palette);
            }
            CastMemberType::VectorShape(vector_member) => {
                if data.width <= 1 || data.height <= 1 {
                    continue;
                }
                let mut temp_sprite = Sprite::new(channel_num as usize);
                temp_sprite.ink = ((data.ink & 0x7F) / 5) as i32;
                temp_sprite.blend = if data.blend == 255 { 100 } else {
                    ((255.0 - data.blend as f32) * 100.0 / 255.0) as i32
                };
                let alpha = (temp_sprite.blend as f32 / 100.0).clamp(0.0, 1.0);
                bitmap.draw_vector_shape(vector_member, sprite_rect, &palettes, alpha);
            }
            CastMemberType::Field(field_member) => {
                let font_opt = get_or_load_font_with_id(
                    &mut player.font_manager,
                    &player.movie.cast_manager,
                    &field_member.font,
                    Some(field_member.font_size),
                    None,
                    field_member.font_id,
                );

                if let Some(font) = font_opt {
                    let font_bitmap = player.bitmap_manager.get_bitmap(font.bitmap_ref).unwrap();
                    let ink = ((data.ink & 0x7F) / 5) as u32;
                    let blend = if data.blend == 255 { 100 } else {
                        ((255.0 - data.blend as f32) * 100.0 / 255.0) as i32
                    };

                    let (child_color, child_bg) = resolve_filmloop_child_colors(&data);

                    let params = CopyPixelsParams {
                        blend,
                        ink,
                        color: child_color,
                        bg_color: child_bg,
                        mask_image: None,
                        is_text_rendering: true,
                        rotation: 0.0,
                        skew: 0.0,
                        sprite: None,
                        mask_offset: (0, 0),
                        original_dst_rect: None,
                        bg_color_explicit: false,
                        fore_color_explicit: false,
                        ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                        floor_rule: false,
                    };

                    bitmap.draw_text(
                        &field_member.text,
                        &font,
                        font_bitmap,
                        sprite_rect.left,
                        sprite_rect.top,
                        params,
                        &palettes,
                        field_member.fixed_line_space,
                        field_member.top_spacing,
                    );
                }
            }
            CastMemberType::Text(text_member) => {
                let (font_name, font_size, font_style) = if !text_member.html_styled_spans.is_empty() {
                    let first_style = &text_member.html_styled_spans[0].style;
                    let name = first_style.font_face.clone().unwrap_or_else(|| text_member.font.clone());
                    let size = first_style.font_size.map(|s| s as u16).unwrap_or(text_member.font_size);
                    let style = (if first_style.bold { 1u8 } else { 0 })
                        | (if first_style.italic { 2u8 } else { 0 })
                        | (if first_style.underline { 4u8 } else { 0 });
                    (name, size, Some(style))
                } else {
                    (text_member.font.clone(), text_member.font_size, None)
                };

                let mut font_opt = get_or_load_font(
                    &mut player.font_manager,
                    &player.movie.cast_manager,
                    &font_name,
                    Some(font_size),
                    font_style,
                );
                if font_opt.is_none() && font_style.is_some() {
                    font_opt = get_or_load_font(
                        &mut player.font_manager,
                        &player.movie.cast_manager,
                        &font_name,
                        Some(font_size),
                        None,
                    );
                }
                if font_opt.is_none() {
                    font_opt = get_or_load_font(
                        &mut player.font_manager,
                        &player.movie.cast_manager,
                        &font_name,
                        None,
                        None,
                    );
                }

                if let Some(font) = font_opt {
                    let font_bitmap = player.bitmap_manager.get_bitmap(font.bitmap_ref).unwrap();
                    let ink = ((data.ink & 0x7F) / 5) as u32;
                    let blend = if data.blend == 255 { 100 } else {
                        ((255.0 - data.blend as f32) * 100.0 / 255.0) as i32
                    };

                    let (child_color, child_bg) = resolve_filmloop_child_colors(&data);

                    let params = CopyPixelsParams {
                        blend,
                        ink,
                        color: child_color,
                        bg_color: child_bg,
                        mask_image: None,
                        is_text_rendering: true,
                        rotation: 0.0,
                        skew: 0.0,
                        sprite: None,
                        mask_offset: (0, 0),
                        original_dst_rect: None,
                        bg_color_explicit: false,
                        fore_color_explicit: false,
                        ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                        floor_rule: false,
                    };

                    bitmap.draw_text(
                        &text_member.text,
                        &font,
                        font_bitmap,
                        sprite_rect.left,
                        sprite_rect.top,
                        params,
                        &palettes,
                        text_member.fixed_line_space,
                        text_member.top_spacing,
                    );
                }
            }
            CastMemberType::Flash(_) => {
                // Filmloop child Flash: per-sprite, same model as the
                // outer Flash branch.
                let flash_bitmap_ref = player
                    .flash_frame_buffers
                    .get(&(channel_num as i16))
                    .copied();

                if let Some(&bitmap_ref) = flash_bitmap_ref.as_ref().filter(|&&r| r != 0) {
                    let src_bitmap = player.bitmap_manager.get_bitmap(bitmap_ref);
                    if let Some(src_bitmap) = src_bitmap {
                        let src_rect = IntRect::from(0, 0, src_bitmap.width as i32, src_bitmap.height as i32);
                        let dst_rect = sprite_rect.clone();

                        let ink = parent_ink;
                        let blend = if data.blend == 255 { 100 } else {
                            ((255.0 - data.blend as f32) * 100.0 / 255.0) as i32
                        };

                        let params = CopyPixelsParams {
                            blend,
                            ink,
                            color: parent_color.clone(),
                            bg_color: parent_bg_color.clone(),
                            mask_image: None,
                            is_text_rendering: false,
                            rotation: 0.0,
                            skew: 0.0,
                            sprite: None,
                            mask_offset: (0, 0),
                            original_dst_rect: Some(dst_rect.clone()),
                            bg_color_explicit: false,
                            fore_color_explicit: false,
                            ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                            floor_rule: false,
                        };

                        bitmap.copy_pixels_with_params(
                            &palettes,
                            src_bitmap,
                            dst_rect,
                            src_rect,
                            &params,
                        );
                    }
                }
            }
            CastMemberType::FilmLoop(inner_film_loop) => {
                // Nested filmloop child: render the inner filmloop into its
                // own bitmap at its natural size, then composite onto the
                // parent filmloop's working bitmap using the resolved
                // ink/fore/bgColor (child's own when parent_ink==0, else
                // parent override).
                let inner_initial_rect = inner_film_loop.initial_rect.clone();

                let (child_ink, child_color, child_bg_color) = if parent_ink == 0 {
                    let (fg, bg) = resolve_filmloop_child_colors(&data);
                    ((data.ink as u32) & 0x3F, fg, bg)
                } else {
                    (parent_ink, parent_color.clone(), parent_bg_color.clone())
                };

                let inner_w = inner_initial_rect.width().max(1);
                let inner_h = inner_initial_rect.height().max(1);

                let mut inner_bitmap = Bitmap::new(
                    inner_w as u16,
                    inner_h as u16,
                    32,
                    32,
                    8,
                    PaletteRef::BuiltIn(get_system_default_palette()),
                );
                inner_bitmap.use_alpha = true;
                inner_bitmap.data.fill(0);

                // Pass ink=0 down recursively so every grandchild renders with
                // its OWN authored ink (matte/bgTrans/mask/add‑pin). The
                // child_ink applies only at the composite step below, on the
                // already-rendered inner bitmap.
                render_score_to_bitmap_with_offset(
                    player,
                    &ScoreRef::FilmLoop(sprite_member_ref.clone()),
                    &mut inner_bitmap,
                    None,
                    IntRect::from_size(0, 0, inner_w, inner_h),
                    (inner_initial_rect.left, inner_initial_rect.top),
                    Some(FilmLoopParentProps {
                        ink: 0,
                        color: child_color.clone(),
                        bg_color: child_bg_color.clone(),
                    }),
                );

                let blend = crate::player::score::convert_raw_blend(data.blend, data.sprite_flags, player.movie.dir_version);

                // Mirror the Bitmap arm's flip handling so nested filmloops
                // honor the child sprite's flipH/flipV bits.
                let flip_h = data.flip_h();
                let flip_v = data.flip_v();
                let dst_rect = {
                    let mut r = sprite_rect.clone();
                    if flip_h { std::mem::swap(&mut r.left, &mut r.right); }
                    if flip_v { std::mem::swap(&mut r.top, &mut r.bottom); }
                    r
                };

                let params = CopyPixelsParams {
                    blend,
                    ink: child_ink,
                    color: child_color,
                    bg_color: child_bg_color,
                    mask_image: None,
                    is_text_rendering: false,
                    rotation: data.rotation,
                    skew: data.skew,
                    sprite: None,
                    mask_offset: (0, 0),
                    original_dst_rect: Some(sprite_rect.clone()),
                    bg_color_explicit: false,
                    fore_color_explicit: false,
                    ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                    floor_rule: false,
                };

                bitmap.copy_pixels_with_params(
                    &palettes,
                    &inner_bitmap,
                    dst_rect,
                    IntRect::from_size(0, 0, inner_w, inner_h),
                    &params,
                );
            }
            _ => {
                // Other member types not yet supported in filmloop rendering
                debug!(
                    "  channel {}: unsupported member type {:?}",
                    channel_num, member.member_type.member_type_id()
                );
            }
        }
    }
}

/// Parent sprite properties for film loop rendering.
/// In Director, film loop internal sprites use the parent sprite's ink semantics.
pub struct FilmLoopParentProps {
    pub ink: u32,
    pub color: ColorRef,
    pub bg_color: ColorRef,
}

/// Render a score to a bitmap with an optional coordinate offset.
/// The offset is used for filmloop rendering where sprite coordinates need to be
/// translated relative to the filmloop's initial_rect.
///
/// For film loop rendering, pass `parent_props` with the parent sprite's ink, color,
/// and bgColor. These will be applied to all internal sprites in the film loop.
pub fn render_score_to_bitmap_with_offset(
    player: &mut DirPlayer,
    score_source: &ScoreRef,
    bitmap: &mut Bitmap,
    debug_sprite_num: Option<i16>,
    dest_rect: IntRect,
    offset: (i32, i32),
    parent_props: Option<FilmLoopParentProps>,
) {
    let palettes = player.movie.cast_manager.palettes();

    // For filmloops, use transparent background so sprites composite correctly
    // onto the stage without a solid background color showing through.
    if let ScoreRef::FilmLoop(member_ref) = score_source {
        // Clear with transparent pixels for filmloop
        bitmap.clear_rect_transparent(
            dest_rect.left,
            dest_rect.top,
            dest_rect.right,
            dest_rect.bottom,
        );

        // Prefer info_rect (authoritative viewport from Director file).
        // Fall back to computed rect.
        let info_rect = get_filmloop_info_rect(player, member_ref);
        let bitmap_dim_rect = compute_filmloop_initial_rect_with_members(player, member_ref);

        let initial_rect = info_rect.clone()
            .or_else(|| bitmap_dim_rect.clone())
            .unwrap_or_else(|| {
                // Fall back to load-time computed initial_rect
                let member = player.movie.cast_manager.find_member_by_ref(member_ref);
                if let Some(member) = member {
                    if let CastMemberType::FilmLoop(film_loop) = &member.member_type {
                        film_loop.initial_rect.clone()
                    } else {
                        IntRect::from(0, 0, 1, 1)
                    }
                } else {
                    IntRect::from(0, 0, 1, 1)
                }
            });

        // When the info_rect matches the bitmap bounding box, the filmloop
        // shows full bitmap content — use bitmap dims for internal sprites.
        // When they differ, the filmloop is a viewport/crop — use sprite dims
        // (channel data) which represent the intended display sizes.
        let prefer_bitmap_dims = match (&info_rect, &bitmap_dim_rect) {
            (Some(info), Some(bm)) => {
                (info.width() - bm.width()).abs() <= 10
                    && (info.height() - bm.height()).abs() <= 10
            }
            _ => false,
        };

        // Get parent sprite properties - use defaults if not provided
        let props = parent_props.unwrap_or(FilmLoopParentProps {
            ink: 0, // Default to copy ink
            color: ColorRef::PaletteIndex(255), // Default foreground (black in most palettes)
            bg_color: ColorRef::PaletteIndex(0), // Default background (white in most palettes)
        });

        render_filmloop_from_channel_data(
            player,
            member_ref,
            bitmap,
            dest_rect,
            initial_rect,
            props.ink,
            props.color,
            props.bg_color,
            prefer_bitmap_dims,
        );
        return;
    }

    // For stage rendering, use the player's background color
    bitmap.clear_rect(
        dest_rect.left,
        dest_rect.top,
        dest_rect.right,
        dest_rect.bottom,
        resolve_color_ref(
            &palettes,
            &player.bg_color,
            &PaletteRef::BuiltIn(get_system_default_palette()),
            bitmap.original_bit_depth,
        ),
        &palettes,
    );

    // Composite accumulated trails bitmap onto the cleared stage
    if let Some(trails_bmp) = &player.trails_bitmap {
        if trails_bmp.width == bitmap.width && trails_bmp.height == bitmap.height {
            // Copy non-transparent pixels from trails bitmap onto stage
            let w = bitmap.width as usize;
            let h = bitmap.height as usize;
            for y in 0..h {
                for x in 0..w {
                    let idx = (y * w + x) * 4;
                    if idx + 3 < trails_bmp.data.len() {
                        let alpha = trails_bmp.data[idx + 3];
                        if alpha > 0 {
                            bitmap.data[idx] = trails_bmp.data[idx];
                            bitmap.data[idx + 1] = trails_bmp.data[idx + 1];
                            bitmap.data[idx + 2] = trails_bmp.data[idx + 2];
                            bitmap.data[idx + 3] = trails_bmp.data[idx + 3];
                        }
                    }
                }
            }
        }
    }

    let sorted_channel_numbers = {
        // Get the correct frame number for this score
        let frame_num = match score_source {
            ScoreRef::Stage => player.movie.current_frame,
            ScoreRef::FilmLoop(_) => unreachable!(), // Handled above
        };

        let score = match score_source {
            ScoreRef::Stage => &player.movie.score,
            ScoreRef::FilmLoop(_) => unreachable!(), // Handled above
        };
        score
            .get_sorted_channels(frame_num)
            .iter()
            .map(|x| x.number as i16)
            .collect_vec()
    };

    // Debug: log which channels are being rendered
    if matches!(score_source, ScoreRef::Stage) {
        debug!(
            "STAGE RENDER: frame {} channels {:?}",
            player.movie.current_frame, sorted_channel_numbers
        );
    }

    for channel_num in sorted_channel_numbers {
        let member_ref = {
            let score = get_score(&player.movie, score_source).unwrap();
            let sprite = score.get_sprite(channel_num);
            if sprite.is_none() {
                if matches!(score_source, ScoreRef::Stage) {
                    debug!(
                        "  STAGE channel {} SKIPPED: sprite is None",
                        channel_num
                    );
                }
                continue;
            }
            let sprite = sprite.unwrap();
            let member = sprite.member.as_ref();
            if member.is_none() {
                if matches!(score_source, ScoreRef::Stage) {
                    debug!(
                        "  STAGE channel {} SKIPPED: sprite.member is None",
                        channel_num
                    );
                }
                continue;
            }
            member.unwrap().clone()
        };
        let member = player.movie.cast_manager.find_member_by_ref(&member_ref);
        if member.is_none() {
            if matches!(score_source, ScoreRef::Stage) {
                debug!(
                    "  STAGE channel {} SKIPPED: member {}:{} not found in cast_manager",
                    channel_num, member_ref.cast_lib, member_ref.cast_member
                );
            }
            continue;
        }
        let member = member.unwrap();

        // Debug: log each channel being rendered on stage
        if matches!(score_source, ScoreRef::Stage) {
            debug!(
                "  STAGE channel {}: member {}:{} type {:?}",
                channel_num, member_ref.cast_lib, member_ref.cast_member,
                member.member_type.member_type_id()
            );
        }

        match &member.member_type {
            CastMemberType::Bitmap(bitmap_member) => {
                let sprite =
                    get_score_sprite(&player.movie, score_source, channel_num).unwrap();
                let sprite_rect = get_concrete_sprite_rect(player, sprite);
                let logical_rect = sprite_rect.clone();

                // For ink 9 (Mask), find the mask bitmap BEFORE mutable borrow
                // of bitmap_manager. Director aligns the mask to the source by
                // their registration points; mask dimensions need not match
                // the source.
                let stage_src_reg = (
                    bitmap_member.reg_point.0 as i32,
                    bitmap_member.reg_point.1 as i32,
                );
                let ink9_mask: Option<(Bitmap, (i32, i32))> = if sprite.ink == 9 {
                    sprite.member.as_ref().and_then(|mref| {
                        let mask_ref = CastMemberRef {
                            cast_lib: mref.cast_lib,
                            cast_member: mref.cast_member + 1,
                        };
                        let found = player.movie.cast_manager.find_member_by_ref(&mask_ref);
                        let mask_reg = match found.as_ref().map(|m| &m.member_type) {
                            Some(CastMemberType::Bitmap(bm)) => {
                                (bm.reg_point.0 as i32, bm.reg_point.1 as i32)
                            }
                            _ => stage_src_reg,
                        };
                        found
                            .and_then(|m| {
                                if let CastMemberType::Bitmap(bm) = &m.member_type {
                                    Some(bm.image_ref)
                                } else {
                                    None
                                }
                            })
                            .and_then(|img_ref| player.bitmap_manager.get_bitmap(img_ref))
                            .cloned()
                            .map(|bmp| (bmp, (mask_reg.0 - stage_src_reg.0, mask_reg.1 - stage_src_reg.1)))
                    })
                } else {
                    None
                };

                // A GIF carries the background colour the file declares, and
                // a movie hides it with ink 36, which keys out the background
                // colour. The score's bgColor for such a sprite is whatever
                // the author left there, usually white, so a GIF with any
                // other background drew as a solid box. Prefer the member's.
                let bg_color = match sprite.member.as_ref() {
                    Some(m) if crate::player::gif::is_gif_member(player, m.cast_lib, m.cast_member) => {
                        player.movie.cast_manager.find_member_by_ref(m)
                            .map(|mem| mem.bg_color.clone())
                            .unwrap_or_else(|| sprite.bg_color.clone())
                    }
                    _ => sprite.bg_color.clone(),
                };
                let sprite_bitmap = player
                    .bitmap_manager
                    .get_bitmap_mut(bitmap_member.image_ref);
                if sprite_bitmap.is_none() {
                    continue;
                }
                let src_bitmap = sprite_bitmap.unwrap();
                let mask = if should_matte_sprite(sprite.ink as u32) {
                    if src_bitmap.matte.is_none() {
                        src_bitmap.create_matte(&palettes);
                    }
                    Some(src_bitmap.matte.as_ref().unwrap())
                } else {
                    None
                };

                let mut src_rect = IntRect::from(0, 0, 0, 0);

                let mut option = 0;

                if sprite.has_size_tweened || sprite.has_size_changed {
                    src_rect = IntRect::from(0, 0, src_bitmap.width as i32, src_bitmap.height as i32);
                } else if sprite.width > player.movie.rect.width() && sprite.height >  player.movie.rect.height() {
                    // sprite dimensions > movie dimensions
                    src_rect = IntRect::from(0, 0, bitmap_member.info.width as i32, bitmap_member.info.height as i32);
                    option = 1;
                } else if bitmap_member.info.width == 0 && bitmap_member.info.height == 0 {
                    // bitmap dimensions are 0
                    src_rect = IntRect::from(0, 0, sprite.width as i32, sprite.height as i32);
                    option = 2;
                } else if i32::from(bitmap_member.info.width) < sprite.width && i32::from(bitmap_member.info.height) < sprite.height || 
                    i32::from(bitmap_member.info.width) > sprite.width && i32::from(bitmap_member.info.height) > sprite.height {
                    // bitmap dimensions are < than sprite dimensions OR bitmap dimensions are > than sprite dimensions
                    src_rect = IntRect::from(0, 0, bitmap_member.info.width as i32, bitmap_member.info.height as i32);
                    option = 3;
                } else if sprite.width > i32::from(bitmap_member.info.width) || sprite.height > i32::from(bitmap_member.info.height) {
                    // sprite dimensions > bitmap dimensions
                    src_rect = IntRect::from(0, 0, bitmap_member.info.width as i32, bitmap_member.info.height as i32);
                    option = 4;
                } else {
                    src_rect = IntRect::from(0, 0, sprite.width as i32, sprite.height as i32);
                    option = 5;
                }

                let dst_rect = sprite_rect;
                let dst_rect = IntRect::from(
                    if sprite.flip_h {
                        dst_rect.right
                    } else {
                        dst_rect.left
                    },
                    if sprite.flip_v {
                        dst_rect.bottom
                    } else {
                        dst_rect.top
                    },
                    if sprite.flip_h {
                        dst_rect.left
                    } else {
                        dst_rect.right
                    },
                    if sprite.flip_v {
                        dst_rect.top
                    } else {
                        dst_rect.bottom
                    },
                );

                // 6) Params
                let mut params = CopyPixelsParams {
                    blend: sprite.effective_blend(),
                    ink: sprite.ink as u32,
                    color: sprite.color.clone(),
                    bg_color: sprite.bg_color.clone(),
                    bg_color_explicit: false,
                    fore_color_explicit: false,
                    mask_image: None,
                    is_text_rendering: false,
                    rotation: sprite.rotation,
                    skew: sprite.skew,
                    sprite: Some(sprite),
                    mask_offset: (0, 0),
                    original_dst_rect: Some(logical_rect),
                    ink9_mask_bitmap: ink9_mask.as_ref().map(|(bmp, _)| bmp),
                    ink9_mask_offset: ink9_mask.as_ref().map(|(_, off)| *off).unwrap_or((0, 0)),
                    floor_rule: true,
                };

                if let Some(mask) = mask {
                    let mask_bitmap: &BitmapMask = mask.borrow();
                    params.mask_image = Some(mask_bitmap);
                }

                debug!(
                    "DRAW Sprite {} dimensions {}x{} bitmap dimensions {}x{} bitmap_member.info dimensions {}x{} Option {} src_rect: {:?}",
                    sprite.number,
                    sprite.width,
                    sprite.height,
                    bitmap.width,
                    bitmap.height,
                    bitmap_member.info.width,
                    bitmap_member.info.height,
                    option,
                    src_rect
                );

                bitmap.copy_pixels_with_params(
                    &palettes,
                    &src_bitmap,
                    dst_rect,
                    src_rect,
                    &params,
                );
            }
            CastMemberType::Shape(shape_member) => {
                let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();

                // Skip blank placeholders and zero-size shapes, but NOT a #line: a line
                // is 1 px in one dimension by nature, so "width <= 1 || height <= 1"
                // dropped every horizontal and vertical line before it reached the
                // draw code (which explicitly promises a line "never vanishes"). The
                // divider under the ruler on klods.dcr's working drawing went missing
                // this way; measured against the projector, S8. A line is skipped
                // only when BOTH dimensions collapse.
                let is_line = matches!(shape_member.shape_info.shape_type, crate::director::enums::ShapeType::Line);
                if (sprite.width <= 1 || sprite.height <= 1) && !(is_line && (sprite.width > 1 || sprite.height > 1)) {
                    continue;
                }

                // Skip rendering shapes that use member 1:1 (placeholder) — but
                // ONLY for D5+. Director 4 movies legitimately use cast member 1
                // as a real authored shape (e.g. thead's full-stage pattern
                // background), and there's no separate placeholder convention in
                // D4, so this skip would wrongly drop it.
                if player.movie.dir_version >= 500 {
                    if let Some(member_ref) = &sprite.member {
                        if member_ref.cast_lib == 1 && member_ref.cast_member == 1 {
                            continue;
                        }
                    }
                }

                let frame_palette = player.movie.score.get_frame_palette(player.movie.current_frame);
                debug!(
                    "  SHAPE RENDER: channel {} member {:?} type {:?} size {}x{} color {:?} bg {:?} ink {} blend {} filled={} lineThick={}",
                    channel_num, sprite.member, shape_member.shape_info.shape_type,
                    sprite.width, sprite.height,
                    sprite.color, sprite.bg_color, sprite.ink, sprite.blend,
                    shape_member.shape_info.fill_type, shape_member.shape_info.line_thickness
                );

                let shape_info = &shape_member.shape_info;
                let rect = get_concrete_sprite_rect(player, sprite);
                let sprite_rect = IntRect::from(
                    rect.left - offset.0,
                    rect.top - offset.1,
                    rect.right - offset.0,
                    rect.bottom - offset.1,
                );

                // VWTL user-defined tile (pattern 57-64 with a custom bitmap
                // member, e.g. employee's blue/white checker). Tile the member's
                // region across the shape instead of using the built-in tile.
                let custom_tile = if shape_info.pattern >= 57 && shape_info.pattern <= 64 {
                    player.movie.score.custom_tiles
                        .get((shape_info.pattern - 57) as usize)
                        .filter(|t| t.is_custom())
                        .copied()
                } else { None };
                let mut drew_custom = false;
                if let Some(tile) = custom_tile {
                    let tile_ref = CastMemberRef { cast_lib: tile.cast_lib, cast_member: tile.member };
                    let src = player.movie.cast_manager.find_member_by_ref(&tile_ref)
                        .and_then(|m| match &m.member_type {
                            CastMemberType::Bitmap(b) => Some(b.image_ref),
                            _ => None,
                        })
                        .and_then(|ir| player.bitmap_manager.get_bitmap(ir).cloned());
                    if let Some(src) = src {
                        let tile_rect = IntRect::from(
                            tile.left as i32, tile.top as i32, tile.right as i32, tile.bottom as i32,
                        );
                        // Phase the tile to the shape's absolute stage position
                        // (dst_rect is already in stage coords here).
                        let abs_origin = (sprite_rect.left, sprite_rect.top);
                        bitmap.fill_rect_custom_tile(&palettes, &src, tile_rect, sprite_rect.clone(), abs_origin);
                        drew_custom = true;
                    }
                }

                if !drew_custom {
                    if offset.0 != 0 || offset.1 != 0 {
                        let mut translated_sprite = sprite.clone();
                        translated_sprite.loc_h -= offset.0;
                        translated_sprite.loc_v -= offset.1;
                        bitmap.draw_shape_with_sprite(&translated_sprite, shape_info, sprite_rect, &palettes, &frame_palette);
                    } else {
                        bitmap.draw_shape_with_sprite(sprite, shape_info, sprite_rect, &palettes, &frame_palette);
                    }
                }
            }
            CastMemberType::VectorShape(vector_member) => {
                let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();

                if sprite.width <= 1 || sprite.height <= 1 {
                    continue;
                }

                // D5+ only — see the Shape branch above.
                if player.movie.dir_version >= 500 {
                    if let Some(member_ref) = &sprite.member {
                        if member_ref.cast_lib == 1 && member_ref.cast_member == 1 {
                            continue;
                        }
                    }
                }

                let rect = get_concrete_sprite_rect(player, sprite);
                let sprite_rect = IntRect::from(
                    rect.left - offset.0,
                    rect.top - offset.1,
                    rect.right - offset.0,
                    rect.bottom - offset.1,
                );
                if offset.0 != 0 || offset.1 != 0 {
                    let mut translated_sprite = sprite.clone();
                    translated_sprite.loc_h -= offset.0;
                    translated_sprite.loc_v -= offset.1;
                    bitmap.draw_vector_shape_with_sprite(&translated_sprite, vector_member, sprite_rect, &palettes);
                } else {
                    bitmap.draw_vector_shape_with_sprite(sprite, vector_member, sprite_rect, &palettes);
                }
            }
            CastMemberType::Field(field_member) => {
                let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();

                let font_opt = get_or_load_font_with_id(
                    &mut player.font_manager,
                    &player.movie.cast_manager,
                    &field_member.font,
                    Some(field_member.font_size),
                    None,
                    field_member.font_id,
                );

                if let Some(font) = font_opt {
                    let font_bitmap = player.bitmap_manager.get_bitmap(font.bitmap_ref).unwrap();

                    // A cast member `.color` set to an RGB value wins over the sprite's
                    // palette-index color — matches Director semantics and Coke Studios'
                    // `sprite.color = paletteIndex(255)` + `member.color = rgb(...)` pattern
                    // where the authored RGB must render.
                    let text_color = if matches!(member.color, ColorRef::Rgb(..)) {
                        member.color.clone()
                    } else if let Some(fc) = field_member.fore_color.clone() {
                        fc
                    } else {
                        sprite.color.clone()
                    };

                    let params = CopyPixelsParams {
                        blend: sprite.effective_blend() as i32,
                        ink: sprite.ink as u32,
                        color: text_color,
                        bg_color: sprite.bg_color.clone(),
                        mask_image: None,
                        is_text_rendering: true,
                        rotation: 0.0,
                        skew: 0.0,
                        sprite: None,
                        mask_offset: (0, 0),
                        original_dst_rect: None,
                        bg_color_explicit: false,
                        fore_color_explicit: false,
                        ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                        floor_rule: false,
                    };

                    let is_focused = player.keyboard_focus_sprite == sprite.number as i16;
                    let sel_lo = field_member.sel_start.min(field_member.sel_end).max(0);
                    let sel_hi = field_member.sel_start.max(field_member.sel_end).max(0);
                    let has_selection = is_focused && sel_lo != sel_hi;
                    // Same line stride bitmap.draw_text_wrapped uses internally.
                    let line_h = font.char_height as i32 + field_member.fixed_line_space as i32;
                    let wrap_w = if field_member.word_wrap { sprite.width } else { 0 };

                    if has_selection {
                        draw_text_selection_rects(
                            bitmap,
                            &field_member.text,
                            &font,
                            sprite.loc_h,
                            sprite.loc_v,
                            wrap_w,
                            field_member.alignment,
                            line_h,
                            field_member.top_spacing,
                            sel_lo,
                            sel_hi,
                            &palettes,
                        );
                    }

                    bitmap.draw_text_wrapped(
                        &field_member.text,
                        &font,
                        font_bitmap,
                        sprite.loc_h,
                        sprite.loc_v,
                        wrap_w,
                        field_member.alignment,
                        params,
                        &palettes,
                        field_member.fixed_line_space,
                        field_member.top_spacing,
                    );

                    if is_focused && !has_selection && caret_blink_visible() {
                        let (dx, dy) = Bitmap::caret_index_to_xy(
                            &field_member.text,
                            &font,
                            wrap_w,
                            field_member.alignment,
                            line_h,
                            field_member.sel_end,
                        );
                        let caret_x = sprite.loc_h + dx;
                        let caret_y = sprite.loc_v + field_member.top_spacing as i32 + dy;
                        bitmap.fill_rect(
                            caret_x,
                            caret_y,
                            caret_x + 1,
                            caret_y + font.char_height as i32,
                            (0, 0, 0),
                            &palettes,
                            1.0,
                        );
                    }
                }
            }
            CastMemberType::Button(button_member) => {
                let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();
                let sprite_rect = get_concrete_sprite_rect(player, sprite);
                let draw_x = sprite_rect.left;
                let draw_y = sprite_rect.top;
                let draw_w = sprite_rect.width();
                let draw_h = sprite_rect.height();

                if draw_w <= 0 || draw_h <= 0 {
                    continue;
                }

                let button_type = &button_member.button_type;
                let hilite = button_member.hilite;
                let field = &button_member.field;

                // Determine colors based on hilite state
                // Only push buttons invert everything; radio/checkbox keep black text
                let is_push = matches!(button_type, crate::player::cast_member::ButtonType::PushButton);
                let (frame_color, fill_color, text_color_rgb): ((u8,u8,u8),(u8,u8,u8),(u8,u8,u8)) = if hilite && is_push {
                    ((255,255,255), (0,0,0), (255,255,255))
                } else {
                    ((0,0,0), (255,255,255), (0,0,0))
                };

                // Render button to intermediate bitmap, then composite with ink.
                // This handles all ink modes (bgTransparent, addPin, etc.) uniformly.
                let mut temp = Bitmap::new(
                    draw_w as u16, draw_h as u16,
                    32, 32, 0,
                    PaletteRef::BuiltIn(get_system_default_palette()),
                );
                temp.data.fill(0); // Start fully transparent
                temp.use_alpha = true;

                // For push buttons: draw text FIRST onto transparent bitmap to preserve
                // AA alpha, then fill remaining transparent pixels with the fill color,
                // then draw the border on top. This prevents native text AA from blending
                // with the white fill (which would create near-white pixels that survive
                // ink 36 color-keying).
                // For checkbox/radio: draw chrome first (no fill behind text area).

                // Draw non-pushbutton chrome first (checkbox/radio don't have fill behind text)
                // Chrome is positioned at the top-left, aligned with the first line of text
                if !is_push {
                    match button_type {
                        crate::player::cast_member::ButtonType::CheckBox => {
                            let box_y = 0;
                            temp.fill_rect(0, box_y, 10, box_y + 1, (0, 0, 0), &palettes, 1.0);
                            temp.fill_rect(0, box_y + 9, 10, box_y + 10, (0, 0, 0), &palettes, 1.0);
                            temp.fill_rect(0, box_y, 1, box_y + 10, (0, 0, 0), &palettes, 1.0);
                            temp.fill_rect(9, box_y, 10, box_y + 10, (0, 0, 0), &palettes, 1.0);
                            temp.fill_rect(1, box_y + 1, 9, box_y + 9, (255, 255, 255), &palettes, 1.0);
                            if hilite {
                                for i in 1..9 {
                                    temp.fill_rect(i, box_y + i, i + 1, box_y + i + 1, (0, 0, 0), &palettes, 1.0);
                                    temp.fill_rect(9 - i, box_y + i, 10 - i, box_y + i + 1, (0, 0, 0), &palettes, 1.0);
                                }
                            }
                        }
                        crate::player::cast_member::ButtonType::RadioButton => {
                            let base_y = 0;
                            let circle_points: &[(i32, i32)] = &[
                                (4, 0), (5, 0), (6, 0),
                                (3, 1), (7, 1),
                                (2, 2), (8, 2),
                                (1, 3), (9, 3),
                                (0, 4), (10, 4),
                                (0, 5), (10, 5),
                                (0, 6), (10, 6),
                                (1, 7), (9, 7),
                                (2, 8), (8, 8),
                                (3, 9), (7, 9),
                                (4, 10), (5, 10), (6, 10),
                            ];
                            for &(px, py) in circle_points {
                                temp.fill_rect(px, base_y + py, px + 1, base_y + py + 1, (0, 0, 0), &palettes, 1.0);
                            }
                            if hilite {
                                temp.fill_rect(4, base_y + 3, 7, base_y + 4, (0, 0, 0), &palettes, 1.0);
                                temp.fill_rect(3, base_y + 4, 8, base_y + 5, (0, 0, 0), &palettes, 1.0);
                                temp.fill_rect(3, base_y + 5, 8, base_y + 6, (0, 0, 0), &palettes, 1.0);
                                temp.fill_rect(3, base_y + 6, 8, base_y + 7, (0, 0, 0), &palettes, 1.0);
                                temp.fill_rect(4, base_y + 7, 7, base_y + 8, (0, 0, 0), &palettes, 1.0);
                            }
                        }
                        _ => {}
                    }
                }

                // Draw text label into temp bitmap
                let chrome_offset_x = match button_type {
                    crate::player::cast_member::ButtonType::CheckBox => 13, // 10px box + 3px gap
                    crate::player::cast_member::ButtonType::RadioButton => 14, // 11px circle + 3px gap
                    _ => 0,
                };

                let font_opt = get_or_load_font_with_id(
                    &mut player.font_manager,
                    &player.movie.cast_manager,
                    &field.font,
                    Some(field.font_size),
                    None,
                    field.font_id,
                );

                let text_area_x = chrome_offset_x;
                let text_area_w = draw_w - chrome_offset_x;

                let is_pfr_font = font_opt.as_ref().map_or(false, |f| f.char_widths.is_some());

                if let (true, Some(font)) = (is_pfr_font, &font_opt) {
                    let font_bitmap = player.bitmap_manager.get_bitmap(font.bitmap_ref).unwrap();

                    let wrapped_lines = Bitmap::wrap_text_lines(&field.text, font, text_area_w);
                    let line_h = font.char_height as i32 + field.fixed_line_space as i32;
                    let total_text_h = (wrapped_lines.len() as i32) * line_h;
                    // Push buttons center text vertically; radio/checkbox start at top
                    let text_y = if is_push {
                        ((draw_h - total_text_h) / 2).max(0)
                    } else {
                        0
                    };

                    let text_params = CopyPixelsParams {
                        blend: 100,
                        ink: 36, // bg transparent for text onto temp
                        color: ColorRef::Rgb(text_color_rgb.0, text_color_rgb.1, text_color_rgb.2),
                        bg_color: ColorRef::Rgb(255, 255, 255),
                        mask_image: None,
                        is_text_rendering: true,
                        rotation: 0.0,
                        skew: 0.0,
                        sprite: None,
                        mask_offset: (0, 0),
                        original_dst_rect: None,
                        bg_color_explicit: false,
                        fore_color_explicit: false,
                        ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                        floor_rule: false,
                    };

                    let wrap_w = if field.word_wrap { text_area_w } else { 0 };
                    temp.draw_text_wrapped(
                        &field.text,
                        font,
                        font_bitmap,
                        text_area_x,
                        text_y,
                        wrap_w,
                        field.alignment,
                        text_params,
                        &palettes,
                        field.fixed_line_space,
                        field.top_spacing,
                    );
                } else {
                    // Native Canvas2D rendering for system fonts (Arial etc.)
                    let font_name = if field.font.is_empty() { "Arial".to_string() } else { field.font.clone() };
                    let font_size = if field.font_size > 0 { field.font_size as i32 } else { 12 };
                    let text_color = ((text_color_rgb.0 as u32) << 16)
                        | ((text_color_rgb.1 as u32) << 8)
                        | (text_color_rgb.2 as u32);

                    let span = StyledSpan {
                        text: field.text.clone(),
                        style: HtmlStyle {
                            font_face: Some(font_name),
                            font_size: Some(font_size),
                            color: Some(text_color),
                            ..HtmlStyle::default()
                        },
                    };

                    let alignment = match field.alignment {
                        BuiltInSymbol::Center => TextAlignment::Center,
                        BuiltInSymbol::Right => TextAlignment::Right,
                        _ => TextAlignment::Left,
                    };

                    // Push buttons center text vertically; radio/checkbox start at top
                    let text_y = if is_push {
                        ((draw_h - font_size) / 2).max(0)
                    } else {
                        0
                    };

                    if let Err(e) = FontMemberHandlers::render_native_text_to_bitmap(
                        &mut temp,
                        &[span],
                        text_area_x,
                        text_y,
                        text_area_w,
                        draw_h,
                        alignment,
                        text_area_w,
                        true,
                        None,
                        field.fixed_line_space,
                        field.top_spacing,
                        0,
                        &[],
                        &[],
                        &[],
                    ) {
                        console_warn!("Native text render error for Button: {:?}", e);
                    }
                }

                // For push buttons: fill background and draw border.
                // For matte-like inks (bgTransparent 36, Matte 8, Not Ghost 7),
                // skip the fill and rely on the alpha channel instead of color-keying.
                // This avoids white fringe from AA text pixels that don't exactly match bgColor.
                let use_alpha_matte = sprite.ink == 2 || sprite.ink == 36 || sprite.ink == 8 || sprite.ink == 7;

                if is_push {
                    if !use_alpha_matte {
                        // Fill transparent interior pixels with fill color (inset 1px for border)
                        for y in 1..(draw_h - 1) {
                            for x in 1..(draw_w - 1) {
                                let idx = ((y * draw_w + x) * 4) as usize;
                                if idx + 3 < temp.data.len() && temp.data[idx + 3] == 0 {
                                    temp.data[idx] = fill_color.0;
                                    temp.data[idx + 1] = fill_color.1;
                                    temp.data[idx + 2] = fill_color.2;
                                    temp.data[idx + 3] = 255;
                                }
                            }
                        }
                    }
                    // Border on top
                    temp.fill_rect(2, 0, draw_w - 2, 1, frame_color, &palettes, 1.0);
                    temp.fill_rect(2, draw_h - 1, draw_w - 2, draw_h, frame_color, &palettes, 1.0);
                    temp.fill_rect(0, 2, 1, draw_h - 2, frame_color, &palettes, 1.0);
                    temp.fill_rect(draw_w - 1, 2, draw_w, draw_h - 2, frame_color, &palettes, 1.0);
                    // Corner pixels
                    temp.fill_rect(1, 0, 2, 1, frame_color, &palettes, 1.0);
                    temp.fill_rect(draw_w - 2, 0, draw_w - 1, 1, frame_color, &palettes, 1.0);
                    temp.fill_rect(0, 1, 1, 2, frame_color, &palettes, 1.0);
                    temp.fill_rect(draw_w - 1, 1, draw_w, 2, frame_color, &palettes, 1.0);
                    temp.fill_rect(1, draw_h - 1, 2, draw_h, frame_color, &palettes, 1.0);
                    temp.fill_rect(draw_w - 2, draw_h - 1, draw_w - 1, draw_h, frame_color, &palettes, 1.0);
                    temp.fill_rect(0, draw_h - 2, 1, draw_h - 1, frame_color, &palettes, 1.0);
                    temp.fill_rect(draw_w - 1, draw_h - 2, draw_w, draw_h - 1, frame_color, &palettes, 1.0);
                }

                // Composite temp bitmap onto stage with sprite's ink.
                // For matte-like inks, use Matte (ink 8) to composite via alpha channel
                // instead of color-keying, which avoids AA fringe artifacts.
                let compositing_ink = if use_alpha_matte { 8 } else { sprite.ink as i32 };

                let mut ink_params = HashMap::new();
                ink_params.insert("blend".into(), Datum::Int(sprite.blend as i32));
                ink_params.insert("ink".into(), Datum::Int(compositing_ink));
                ink_params.insert("color".into(), Datum::ColorRef(sprite.color.clone()));
                ink_params.insert("bgColor".into(), Datum::ColorRef(sprite.bg_color.clone()));

                bitmap.copy_pixels(
                    &palettes,
                    &temp,
                    IntRect::from(draw_x, draw_y, draw_x + draw_w, draw_y + draw_h),
                    IntRect::from_tuple((0, 0, draw_w, draw_h)),
                    &ink_params,
                    None,
                );
            }
            CastMemberType::Font(font_member) => {
                let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();

                // Get font by info with fallback
                let font: Rc<BitmapFont> =
                    if let Some(f) = player.font_manager.get_font_by_info(&font_member.font_info) {
                        Rc::new(f.clone()) // wrap &BitmapFont in Rc
                    } else if let Some(f) = player.font_manager.get_system_font() {
                        f // already Rc<BitmapFont>
                    } else {
                        continue;
                    };

                let font_bitmap: &mut bitmap::Bitmap = player
                    .bitmap_manager
                    .get_bitmap_mut(font.bitmap_ref)
                    .unwrap();

                let mask = if should_matte_sprite(sprite.ink as u32) {
                    if font_bitmap.matte.is_none() {
                        font_bitmap.create_matte_text(&palettes);
                    }
                    Some(font_bitmap.matte.as_ref().unwrap())
                } else {
                    None
                };

                let mut params = CopyPixelsParams {
                    blend: sprite.blend as i32,
                    ink: sprite.ink as u32,
                    color: sprite.color.clone(),
                    bg_color: sprite.bg_color.clone(),
                    mask_image: None,
                    is_text_rendering: true,
                    rotation: 0.0,
                    skew: 0.0,
                    sprite: None,
                    mask_offset: (0, 0),
                    original_dst_rect: None,
                    bg_color_explicit: false,
                    fore_color_explicit: false,
                    ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                    floor_rule: false,
                };

                if let Some(mask) = mask {
                    let mask_bitmap: &BitmapMask = mask.borrow();
                    params.mask_image = Some(mask_bitmap);
                }

                if !font_member.preview_html_spans.is_empty() {
                    if let Err(e) = FontMemberHandlers::render_html_text_to_bitmap(
                        bitmap,
                        &font_member.preview_html_spans,
                        &font,
                        font_bitmap,
                        &palettes,
                        font_member.fixed_line_space,
                        sprite.loc_h as i32,
                        sprite.loc_v as i32 + font_member.top_spacing as i32,
                        params,
                    ) {
                        console_warn!("HTML render error: {:?}", e);
                    }
                } else if !font_member.preview_text.is_empty() {
                    bitmap.draw_text(
                        &font_member.preview_text,
                        &font,
                        font_bitmap,
                        sprite.loc_h,
                        sprite.loc_v,
                        params,
                        &palettes,
                        font.char_height,
                        font_member.top_spacing,
                    );
                }
            }
            CastMemberType::Text(text_member) => {
                let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();
                let sprite_rect = get_concrete_sprite_rect(player, sprite);
                let draw_x = sprite_rect.left;
                let draw_y = sprite_rect.top;
                let draw_w = sprite_rect.width();
                let draw_h = sprite_rect.height();

                // Extract font properties from first styled span if available
                let (font_name, font_size, font_style) = if !text_member.html_styled_spans.is_empty() {
                    let first_style = &text_member.html_styled_spans[0].style;
                    let name = first_style.font_face.clone().unwrap_or_else(|| text_member.font.clone());
                    let size = first_style.font_size.map(|s| s as u16).unwrap_or(text_member.font_size);
                    // Convert bold/italic/underline to font_style: bit 0 = bold, bit 1 = italic, bit 2 = underline
                    let style = (if first_style.bold { 1u8 } else { 0 })
                        | (if first_style.italic { 2u8 } else { 0 })
                        | (if first_style.underline { 4u8 } else { 0 });
                    (name, size, Some(style))
                } else {
                    (text_member.font.clone(), text_member.font_size, None)
                };

                debug!(
                    "🔤 Text member font request: name='{}', size={}, style={:?}",
                    font_name, font_size, font_style
                );

                // Try to load font with specified style first
                let mut font_opt = get_or_load_font(
                    &mut player.font_manager,
                    &player.movie.cast_manager,
                    &font_name,
                    Some(font_size),
                    font_style,
                );

                // If not found with style, try without style
                if font_opt.is_none() && font_style.is_some() {
                    debug!(
                        "⚠️ Font not found with style, trying without style..."
                    );
                    font_opt = get_or_load_font(
                        &mut player.font_manager,
                        &player.movie.cast_manager,
                        &font_name,
                        Some(font_size),
                        None,
                    );
                }

                // If still not found with size, try without size
                if font_opt.is_none() {
                    debug!(
                        "⚠️ Font not found with size, trying without size..."
                    );
                    font_opt = get_or_load_font(
                        &mut player.font_manager,
                        &player.movie.cast_manager,
                        &font_name,
                        None,
                        None,
                    );
                }

                if let Some(ref font) = font_opt {
                    debug!(
                        "Using font: name='{}', size={}, style={}",
                        font.font_name, font.font_size, font.font_style
                    );
                } else {
                    debug!(
                        "Skipping text rendering: no font available for '{}' (size={}, style={:?}) and system font unavailable",
                        font_name, font_size, font_style
                    );
                }

                if let Some(font) = font_opt {
                    let font_bitmap = player.bitmap_manager.get_bitmap(font.bitmap_ref).unwrap();

                    // A cast member `.color` set to an RGB value wins over the sprite's
                    // palette-index color — matches Director semantics and Coke Studios'
                    // `new(#text)` + `myMember.color = rgb(...)` pattern where the authored
                    // RGB must render even when Lingo also sets `sprite.color = paletteIndex(255)`.
                    let text_color = if matches!(member.color, ColorRef::Rgb(..)) {
                        member.color.clone()
                    } else {
                        sprite.color.clone()
                    };

                    let params = CopyPixelsParams {
                        blend: sprite.effective_blend() as i32,
                        ink: sprite.ink as u32,
                        color: text_color,
                        bg_color: sprite.bg_color.clone(),
                        mask_image: None,
                        is_text_rendering: true,
                        rotation: 0.0,
                        skew: 0.0,
                        sprite: None,
                        mask_offset: (0, 0),
                        original_dst_rect: None,
                        bg_color_explicit: false,
                        fore_color_explicit: false,
                        ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                        floor_rule: false,
                    };

                    // Use styled text rendering if html_styled_spans is populated
                    // BUT only use native rendering if the font is NOT a PFR bitmap font
                    // PFR fonts can't be used by Canvas2D, so we must use bitmap rendering
                    let is_pfr_font = font.char_widths.is_some();
                    if !text_member.html_styled_spans.is_empty() && !is_pfr_font && player.font_manager.pfr_enabled {
                        // Parse alignment from text_member
                        let alignment = match text_member.alignment {
                            BuiltInSymbol::Center => TextAlignment::Center,
                            BuiltInSymbol::Right => TextAlignment::Right,
                            BuiltInSymbol::Justify => TextAlignment::Justify,
                            _ => TextAlignment::Left,
                        };

                        let initial_span_size = text_member
                            .html_styled_spans
                            .first()
                            .and_then(|s| s.style.font_size)
                            .unwrap_or(0);
                        let should_override_span_sizes = text_member.font_size > 0
                            && (text_member.font_size as i32) != initial_span_size;

                        // Clone spans and apply text member runtime overrides when needed.
                        // The movie can set font, fontSize, fontStyle at runtime, so these
                        // should override whatever was in the original styled spans
                        let spans_with_defaults: Vec<StyledSpan> = text_member.html_styled_spans.iter().map(|span| {
                            let mut style = span.style.clone();

                            // ALWAYS use text_member's font if set (movie may have changed it)
                            if !text_member.font.is_empty() {
                                style.font_face = Some(text_member.font.clone());
                            } else if style.font_face.as_ref().map_or(true, |f| f.is_empty()) {
                                style.font_face = Some("Arial".to_string());
                            }

                            // Preserve per-span sizes unless the movie changed fontSize at runtime.
                            if should_override_span_sizes {
                                style.font_size = Some(text_member.font_size as i32);
                            } else if style.font_size.map_or(true, |s| s <= 0) {
                                style.font_size = Some(12);
                            }

                            // Use sprite color if span doesn't have color
                            if style.color.is_none() {
                                style.color = match &sprite.color {
                                    ColorRef::Rgb(r, g, b) => {
                                        Some(((*r as u32) << 16) | ((*g as u32) << 8) | (*b as u32))
                                    }
                                    ColorRef::PaletteIndex(idx) => {
                                        match *idx {
                                            0 => Some(0xFFFFFF),
                                            255 => Some(0x000000),
                                            _ => Some(0x000000),
                                        }
                                    }
                                };
                            }

                            // ALWAYS apply text_member's fontStyle (movie may have changed it)
                            if !text_member.font_style.is_empty() {
                                style.bold = text_member.font_style.iter().any(|s| *s == BuiltInSymbol::Bold);
                                style.italic = text_member.font_style.iter().any(|s| *s == BuiltInSymbol::Italic);
                                style.underline = text_member.font_style.iter().any(|s| *s == BuiltInSymbol::Underline);
                            }

                            StyledSpan {
                                text: span.text.clone(),
                                style,
                            }
                        }).collect();

                        // Use native browser text rendering for smooth, anti-aliased text
                        if let Err(e) = FontMemberHandlers::render_native_text_to_bitmap(
                            bitmap,
                            &spans_with_defaults,
                            draw_x,
                            draw_y,
                            draw_w,
                            draw_h,
                            alignment,
                            draw_w,
                            text_member.word_wrap,
                            None, // Color is now in the spans
                            text_member.fixed_line_space,
                            text_member.top_spacing,
                            text_member.bottom_spacing,
                            &text_member.tab_stops,
                            &text_member.par_infos,
                            &text_member.par_runs,
                        ) {
                            console_warn!("Native text render error for Text member: {:?}", e);
                        }
                    } else {
                        let is_focused = player.keyboard_focus_sprite == sprite.number as i16;
                        let sel_lo = text_member.sel_start.min(text_member.sel_end).max(0);
                        let sel_hi = text_member.sel_start.max(text_member.sel_end).max(0);
                        let has_selection = is_focused && sel_lo != sel_hi;
                        // bitmap.draw_text uses font.char_height + line_spacing as the per-line stride.
                        let line_h = font.char_height as i32 + text_member.fixed_line_space as i32;

                        if has_selection {
                            draw_text_selection_rects(
                                bitmap,
                                &text_member.text,
                                &font,
                                draw_x,
                                draw_y,
                                0, // draw_text doesn't wrap; treat as unbounded
                                BuiltInSymbol::Left,
                                line_h,
                                text_member.top_spacing,
                                sel_lo,
                                sel_hi,
                                &palettes,
                            );
                        }

                        bitmap.draw_text(
                            &text_member.text,
                            &font,
                            font_bitmap,
                            draw_x,
                            draw_y,
                            params,
                            &palettes,
                            text_member.fixed_line_space,
                            text_member.top_spacing,
                        );

                        if is_focused && !has_selection && caret_blink_visible() {
                            let (dx, dy) = Bitmap::caret_index_to_xy(
                                &text_member.text,
                                &font,
                                0,
                                BuiltInSymbol::Left,
                                line_h,
                                text_member.sel_end,
                            );
                            let caret_x = draw_x + dx;
                            let caret_y = draw_y + text_member.top_spacing as i32 + dy;
                            bitmap.fill_rect(
                                caret_x,
                                caret_y,
                                caret_x + 1,
                                caret_y + font.char_height as i32,
                                (0, 0, 0),
                                &palettes,
                                1.0,
                            );
                        }
                    }
                }
            }
            CastMemberType::FilmLoop(film_loop) => {
                // ---- 1. Snapshot sprite data ----
                let computed_initial_rect = film_loop.initial_rect.clone();

                let (
                    sprite_rect,
                    blend,
                    ink,
                    color,
                    bg_color,
                    rotation,
                    skew,
                    logical_rect,
                    initial_rect,
                    current_frame,
                ) = {
                    let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();

                    let rect = get_concrete_sprite_rect(player, sprite);

                    (
                        rect.clone(),
                        sprite.blend,
                        sprite.ink as u32,
                        sprite.color.clone(),
                        sprite.bg_color.clone(),
                        sprite.rotation,
                        sprite.skew,
                        rect, // logical rect
                        computed_initial_rect,
                        film_loop.current_frame,
                    )
                };

                // ---- 2. Create filmloop bitmap using INITIAL_RECT dimensions ----
                // The filmloop is rendered at its natural size (initial_rect coordinate space).
                // This bitmap is then composited at sprite_rect, with copy_pixels
                // handling scaling if sprite_rect differs from initial_rect.
                let width = initial_rect.width().max(1);
                let height = initial_rect.height().max(1);

                debug!(
                    "Rendering FilmLoop: channel {} frame {} ink={} blend={} initial_rect ({}, {}, {}, {}) bitmap size {}x{} sprite_rect ({}, {}, {}, {}) offset ({}, {})",
                    channel_num,
                    current_frame,
                    ink, blend,
                    initial_rect.left, initial_rect.top, initial_rect.right, initial_rect.bottom,
                    width, height,
                    sprite_rect.left, sprite_rect.top, sprite_rect.right, sprite_rect.bottom,
                    initial_rect.left, initial_rect.top
                );

                let mut filmloop_bitmap = Bitmap::new(
                    width as u16,
                    height as u16,
                    32,
                    32,
                    8, // alpha_depth = 8 for transparency support
                    PaletteRef::BuiltIn(get_system_default_palette()),
                );
                // Enable alpha channel for filmloop transparency
                filmloop_bitmap.use_alpha = true;
                // Clear to fully transparent (RGBA 0,0,0,0) so only rendered sprites are visible
                filmloop_bitmap.data.fill(0);

                // ---- 3. Recursive render with coordinate offset ----
                // Render at natural size (initial_rect dimensions)
                // Pass parent sprite's ink, color, and bgColor - Director behavior is that
                // film loop internal sprites use the parent sprite's ink semantics.
                render_score_to_bitmap_with_offset(
                    player,
                    &ScoreRef::FilmLoop(member_ref.clone()),
                    &mut filmloop_bitmap,
                    debug_sprite_num,
                    IntRect::from_size(0, 0, width, height),
                    (initial_rect.left, initial_rect.top),
                    Some(FilmLoopParentProps {
                        ink,
                        color: color.clone(),
                        bg_color: bg_color.clone(),
                    }),
                );

                // ---- 4. Composite filmloop onto stage ----
                // Count total opaque pixels in filmloop bitmap to verify rendering worked
                let opaque_count = (0..filmloop_bitmap.data.len()).step_by(4)
                    .filter(|&i| i + 3 < filmloop_bitmap.data.len() && filmloop_bitmap.data[i + 3] > 0)
                    .count();
                let transparent_count = (0..filmloop_bitmap.data.len()).step_by(4)
                    .filter(|&i| i + 3 < filmloop_bitmap.data.len() && filmloop_bitmap.data[i + 3] == 0)
                    .count();
                let total_pixels = filmloop_bitmap.width as usize * filmloop_bitmap.height as usize;
                debug!(
                    "    FILMLOOP BITMAP STATS: {}x{} total={} opaque={} ({}%) transparent={} ({}%)",
                    filmloop_bitmap.width, filmloop_bitmap.height, total_pixels,
                    opaque_count, if total_pixels > 0 { opaque_count * 100 / total_pixels } else { 0 },
                    transparent_count, if total_pixels > 0 { transparent_count * 100 / total_pixels } else { 0 }
                );

                let params = CopyPixelsParams {
                    blend,
                    ink,
                    color,
                    bg_color,
                    mask_image: None,
                    is_text_rendering: false,
                    rotation,
                    skew,
                    sprite: None,
                    mask_offset: (0, 0),
                    original_dst_rect: Some(logical_rect),
                    bg_color_explicit: false,
                    fore_color_explicit: false,
                    ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                    floor_rule: false,
                };

                // Debug: log filmloop bitmap properties before compositing
                debug!(
                    "    FILMLOOP COMPOSITE: use_alpha={} bit_depth={} orig_bit_depth={} ink={}",
                    filmloop_bitmap.use_alpha, filmloop_bitmap.bit_depth,
                    filmloop_bitmap.original_bit_depth, ink
                );

                // Position the filmloop bitmap at sprite_rect location, but keep natural size.
                let dst_rect = IntRect::from_size(sprite_rect.left, sprite_rect.top, width, height);
                debug!(
                    "    FILMLOOP DST_RECT: ({}, {}, {}, {}) <- sprite_rect.left={} sprite_rect.top={}",
                    dst_rect.left, dst_rect.top, dst_rect.right, dst_rect.bottom,
                    sprite_rect.left, sprite_rect.top
                );
                bitmap.copy_pixels_with_params(
                    &palettes,
                    &filmloop_bitmap,
                    dst_rect,
                    IntRect::from_size(0, 0, width, height),
                    &params,
                );
            }
            CastMemberType::Flash(flash_member) => {
                // Render Flash content from the per-sprite frame buffer.
                // Each Flash sprite has its own Ruffle player so multiple
                // sprites sharing one cast member can show different frames.
                let flash_bitmap_ref = player
                    .flash_frame_buffers
                    .get(&(channel_num as i16))
                    .copied();

                if let Some(&bitmap_ref) = flash_bitmap_ref.as_ref().filter(|&&r| r != 0) {
                    let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();
                    let rect = get_concrete_sprite_rect(player, sprite);
                    let sprite_rect = IntRect::from(
                        rect.left - offset.0,
                        rect.top - offset.1,
                        rect.right - offset.0,
                        rect.bottom - offset.1,
                    );

                    let src_bitmap = player.bitmap_manager.get_bitmap(bitmap_ref);
                    if let Some(src_bitmap) = src_bitmap {
                        let src_rect = IntRect::from(0, 0, src_bitmap.width as i32, src_bitmap.height as i32);
                        // Apply flipH/flipV by inverting the dst_rect (left↔right,
                        // top↔bottom) so copy_pixels mirrors the content — the same
                        // way the bitmap path does it. get_concrete_sprite_rect
                        // already mirrored the reg point to place the box on the
                        // correct side; without this inversion the Flash content
                        // filled the box un-mirrored (bogey_nights' end-game grab
                        // hands are flipV — they grabbed downward instead of up).
                        let dst_rect = IntRect::from(
                            if sprite.flip_h { sprite_rect.right } else { sprite_rect.left },
                            if sprite.flip_v { sprite_rect.bottom } else { sprite_rect.top },
                            if sprite.flip_h { sprite_rect.left } else { sprite_rect.right },
                            if sprite.flip_v { sprite_rect.top } else { sprite_rect.bottom },
                        );

                        let params = CopyPixelsParams {
                            blend: sprite.effective_blend(),
                            ink: sprite.ink as u32,
                            color: sprite.color.clone(),
                            bg_color: sprite.bg_color.clone(),
                            mask_image: None,
                            is_text_rendering: false,
                            rotation: sprite.rotation,
                            skew: sprite.skew,
                            sprite: Some(sprite),
                            mask_offset: (0, 0),
                            original_dst_rect: Some(sprite_rect.clone()),
                            bg_color_explicit: false,
                            fore_color_explicit: false,
                            ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                            floor_rule: false,
                        };

                        bitmap.copy_pixels_with_params(
                            &palettes,
                            src_bitmap,
                            dst_rect,
                            src_rect,
                            &params,
                        );
                    }
                } else if flash_bitmap_ref.is_none() && has_swf_signature(&flash_member.data) {
                    // First time this sprite renders a Flash member — ask
                    // JS to spin up a dedicated Ruffle instance for it.
                    let dispatch_key = (channel_num as i16, member_ref.cast_lib, member_ref.cast_member);
                    // Host-only: a nested sub-player's Flash lifecycle is owned by
                    // its own pre_dispatch_flash_members (see webgl2 render_sprite).
                    let is_host = unsafe { crate::player::ACTIVE_PLAYER_ID } == 0;
                    if is_host && !player.flash_sprite_loaded.contains(&dispatch_key) {
                        let sprite = get_score_sprite(&player.movie, score_source, channel_num).unwrap();
                        let w = sprite.width.max(1) as u32;
                        let h = sprite.height.max(1) as u32;
                        debug!(
                            "  Flash sprite#{}: requesting Ruffle instance for member {}:{} ({}x{}, {} bytes SWF)",
                            channel_num, member_ref.cast_lib, member_ref.cast_member, w, h, flash_member.data.len()
                        );
                        let paused_at_start = flash_member
                            .flash_info
                            .as_ref()
                            .map(|fi| fi.paused_at_start)
                            .unwrap_or(false);
                        let asserted_frame = sprite.flash_asserted_frame.unwrap_or(-1);
                        JsApi::dispatch_flash_member_loaded(
                            channel_num as i32,
                            member_ref.cast_lib,
                            member_ref.cast_member,
                            &flash_member.data,
                            w,
                            h,
                            paused_at_start,
                            asserted_frame,
                        );
                        player.flash_sprite_loaded.insert(dispatch_key);
                    }
                }
            }
            _ => {}
        }
    }

    // Accumulate trails sprites into the persistent trails bitmap
    if matches!(score_source, ScoreRef::Stage) {
        // Check if any sprite in the current frame has trails
        let mut has_trails = false;
        let frame_num = player.movie.current_frame;
        let channels: Vec<i16> = player.movie.score
            .get_sorted_channels(frame_num)
            .iter()
            .map(|x| x.number as i16)
            .collect();
        for &ch in &channels {
            if let Some(sprite) = player.movie.score.get_sprite(ch) {
                if sprite.trails {
                    has_trails = true;
                    break;
                }
            }
        }

        if has_trails {
            // Ensure trails bitmap exists and is the right size
            let bw = bitmap.width;
            let bh = bitmap.height;
            if player.trails_bitmap.is_none()
                || player.trails_bitmap.as_ref().unwrap().width != bw
                || player.trails_bitmap.as_ref().unwrap().height != bh
            {
                let mut trails_bmp = Bitmap::new(
                    bw,
                    bh,
                    32,
                    32,
                    0,
                    PaletteRef::BuiltIn(get_system_default_palette()),
                );
                // Start fully transparent
                for pixel in trails_bmp.data.chunks_exact_mut(4) {
                    pixel[0] = 0;
                    pixel[1] = 0;
                    pixel[2] = 0;
                    pixel[3] = 0;
                }
                player.trails_bitmap = Some(trails_bmp);
            }

            // For each trails sprite, copy its bounding rect from the rendered bitmap to trails_bitmap
            for &ch in &channels {
                if let Some(sprite) = player.movie.score.get_sprite(ch) {
                    if sprite.trails && sprite.member.is_some() {
                        let sprite_rect = get_concrete_sprite_rect(player, sprite);
                        let x1 = sprite_rect.left.max(0) as usize;
                        let y1 = sprite_rect.top.max(0) as usize;
                        let x2 = (sprite_rect.right as usize).min(bw as usize);
                        let y2 = (sprite_rect.bottom as usize).min(bh as usize);
                        let w = bw as usize;

                        if let Some(trails_bmp) = &mut player.trails_bitmap {
                            for y in y1..y2 {
                                for x in x1..x2 {
                                    let idx = (y * w + x) * 4;
                                    if idx + 3 < bitmap.data.len() {
                                        trails_bmp.data[idx] = bitmap.data[idx];
                                        trails_bmp.data[idx + 1] = bitmap.data[idx + 1];
                                        trails_bmp.data[idx + 2] = bitmap.data[idx + 2];
                                        trails_bmp.data[idx + 3] = 255; // Mark as opaque
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // No trails sprites in this frame - clear the trails bitmap
            player.trails_bitmap = None;
        }
    }

    // Draw debug rect
    if let Some(sprite) = debug_sprite_num.and_then(|x| player.movie.score.get_sprite(x)) {
        let sprite_rect = get_concrete_sprite_rect(player, sprite);
        bitmap.stroke_rect(
            sprite_rect.left,
            sprite_rect.top,
            sprite_rect.right,
            sprite_rect.bottom,
            (255, 0, 0),
            &palettes,
            1.0,
        );
        bitmap.set_pixel(sprite.loc_h, sprite.loc_v, (0, 255, 0), &palettes);
    }

    // Draw pick rect
    let is_picking_sprite = player.picking_mode
        || (player.keyboard_manager.is_alt_down()
            && (player.keyboard_manager.is_control_down() || player.keyboard_manager.is_command_down()));
    if is_picking_sprite {
        let hovered_sprite = get_sprite_at(player, player.mouse_loc.0, player.mouse_loc.1, false);
        if let Some(hovered_sprite) = hovered_sprite {
            let sprite = player
                .movie
                .score
                .get_sprite(hovered_sprite as i16)
                .unwrap();
            let sprite_rect = get_concrete_sprite_rect(player, sprite);
            bitmap.stroke_rect(
                sprite_rect.left,
                sprite_rect.top,
                sprite_rect.right,
                sprite_rect.bottom,
                (0, 255, 0),
                &palettes,
                1.0,
            );
        }
    }
}


impl PlayerCanvasRenderer {
    #[allow(dead_code)]
    pub fn set_size(&mut self, width: u32, height: u32) {
        self.size = (width, height);
        self.canvas.set_width(width);
        self.canvas.set_height(height);
    }

    pub fn set_preview_size(&mut self, width: u32, height: u32) {
        self.preview_size = (width, height);
        self.preview_canvas.set_width(width);
        self.preview_canvas.set_height(height);

        // console_warn!("Set preview size: {}x{}", width, height);
    }

    pub fn set_container_element(&mut self, container_element: web_sys::HtmlElement) {
        if self.canvas.parent_node().is_some() {
            self.canvas.remove();
        }
        container_element.append_child(&self.canvas).unwrap();
        self.container_element = Some(container_element);
    }

    pub fn set_preview_container_element(
        &mut self,
        container_element: Option<web_sys::HtmlElement>,
    ) {
        if self.preview_canvas.parent_node().is_some() {
            self.preview_canvas.remove();
        }
        if let Some(container_element) = container_element {
            container_element
                .append_child(&self.preview_canvas)
                .unwrap();
            self.preview_container_element = Some(container_element);
        }
    }

    pub fn draw_preview_frame(&mut self, player: &mut DirPlayer) {
        if self.preview_member_ref.is_none()
            || self.preview_container_element.is_none()
            || self.preview_ctx2d.is_null()
            || self.preview_ctx2d.is_undefined()
        {
            return;
        }

        let member_ref = self.preview_member_ref.as_ref().unwrap().clone();
        let bitmap = render_preview_bitmap(player, &member_ref, self.preview_font_size);
        if let Some(bitmap) = bitmap {
            if self.preview_size.0 != bitmap.width as u32
                || self.preview_size.1 != bitmap.height as u32
            {
                self.set_preview_size(bitmap.width as u32, bitmap.height as u32);
            }
            let slice_data = Clamped(bitmap.data.as_slice());
            let image_data = web_sys::ImageData::new_with_u8_clamped_array_and_sh(
                slice_data,
                bitmap.width.into(),
                bitmap.height.into(),
            );
            if let Ok(image_data) = image_data {
                let _ = self.preview_ctx2d.put_image_data(&image_data, 0.0, 0.0);
            }
        }
    }

    pub fn draw_frame(&mut self, player: &mut DirPlayer) {
        // Sync persistent Transform3d datums → node_transforms for in-place mutations
        // (e.g. model.transform.position = vector(...) used by overlay/HUD scripts)
        crate::player::handlers::datum_handlers::shockwave3d_object::sync_persistent_transforms(player);
        crate::player::handlers::datum_handlers::shockwave3d_object::sync_shader_texture_lists(player);

        // let time = chrono::Utc::now().timestamp_millis() as i64;
        // let time_seconds = time as f64 / 1000.0;
        // let oscillated_r = 127.0 + 255.0 * (time_seconds * 2.0 * std::f32::consts::PI as f64).sin();
        // let oscillated_g = 127.0 + 255.0 * (time_seconds * 2.0 * std::f32::consts::PI as f64 + (std::f32::consts::PI / 2.0) as f64).sin();
        // let oscillated_b = 127.0 + 255.0 * (time_seconds * 2.0 * std::f32::consts::PI as f64 + (std::f32::consts::PI) as f64).sin();

        // let color = format!("rgba({}, {}, {}, {})", oscillated_r, oscillated_g, oscillated_b, 1);
        // let bg_color = "black";

        // let (width, height) = self.size;
        // self.ctx2d.clear_rect(0.0, 0.0, width as f64, height as f64);
        // self.ctx2d.set_fill_style(&JsValue::from_str(&bg_color));
        // self.ctx2d.fill_rect(0.0, 0.0, width as f64, height as f64);

        // self.ctx2d.set_fill_style(&JsValue::from_str("black"));
        // self.ctx2d
        //     .fill_text(
        //         &format!("dir_version: {}", player.movie.dir_version),
        //         0.0,
        //         10.0,
        //     )
        //     .unwrap();

        let movie_width = player.movie.rect.width();
        let movie_height = player.movie.rect.height();

        if self.bitmap.width != movie_width as u16 || self.bitmap.height != movie_height as u16 {
            self.bitmap = Bitmap::new(
                movie_width as u16,
                movie_height as u16,
                32,
                32,
                0,
                PaletteRef::BuiltIn(get_system_default_palette()),
            );
        }
        // A score/puppet transition just started: snapshot the CURRENT stage (the
        // pre-transition image) before render_stage_to_bitmap overwrites it with the
        // new frame. Play it out below over the transition's duration.
        if let Some(info) = player.pending_transition.take() {
            self.active_transition = Some(TransitionPlayback {
                old_bitmap: self.bitmap.clone(),
                info,
                start_ms: chrono::Utc::now().timestamp_millis(),
            });
        }

        let bitmap = &mut self.bitmap;
        render_stage_to_bitmap(player, bitmap, self.debug_selected_channel_num);

        // Composite the script-owned stage framebuffer over the sprite render
        // for "imaging Lingo" movies that draw straight into `(the stage).image`
        // (see stage.rs `image` getter). Only once a script has actually drawn
        // into it (`stage_image_dirty`).
        if player.stage_image_dirty {
            if let Some(stage_ref) = player.stage_image {
                if let Some(src) = player.bitmap_manager.get_bitmap(stage_ref) {
                    let palettes = player.movie.cast_manager.palettes();
                    let w = bitmap.width as i32;
                    let h = bitmap.height as i32;
                    bitmap.copy_pixels(
                        &palettes,
                        src,
                        IntRect::from(0, 0, w, h),
                        IntRect::from(0, 0, src.width as i32, src.height as i32),
                        &HashMap::new(),
                        None,
                    );
                }
            }
        }

        #[cfg(feature = "alloc-debug-overlay")]
        if let Some(font) = player.font_manager.get_system_font() {
            let font_bitmap = player.bitmap_manager.get_bitmap(font.bitmap_ref).unwrap();
            let txt = format!(
                "Datum count: {}\nScript count: {}",
                player.allocator.datum_count(),
                player.allocator.script_instance_count()
            );

            let params = CopyPixelsParams { mask_offset: (0, 0),
                blend: 100,
                ink: 36,
                color: bitmap.get_fg_color_ref(),
                bg_color: bitmap.get_bg_color_ref(),
                mask_image: None,
                is_text_rendering: false,
                rotation: 0.0,
                skew: 0.0,
                sprite: None,
                original_dst_rect: None,
                bg_color_explicit: false,
                fore_color_explicit: false,
                ink9_mask_bitmap: None, ink9_mask_offset: (0, 0),
                floor_rule: false,
            };

            bitmap.draw_text(
                txt.as_str(),
                &font,
                font_bitmap,
                0,
                0,
                params,
                &player.movie.cast_manager.palettes(),
                0,
                0,
            );
        }

        // Play out an active transition: blend the captured OLD stage into the freshly
        // rendered NEW one per elapsed progress. Releases the player's playhead hold
        // on completion (precise sync); a time failsafe in the player backs it up.
        if let Some(trans) = self.active_transition.take() {
            let elapsed = chrono::Utc::now().timestamp_millis() - trans.start_ms;
            let progress = (elapsed as f32 / trans.info.duration_ms.max(1) as f32).min(1.0);
            apply_transition_effect(bitmap, &trans.old_bitmap, trans.info.transition_type, trans.info.chunk_size, progress);
            if progress < 1.0 {
                self.active_transition = Some(trans);
            } else {
                player.score_transition_active = false;
            }
        }

        let slice_data = Clamped(bitmap.data.as_slice());
        let image_data = web_sys::ImageData::new_with_u8_clamped_array_and_sh(
            slice_data,
            bitmap.width.into(),
            bitmap.height.into(),
        );
        self.ctx2d.set_fill_style(&safe_js_string("white"));
        match image_data {
            Ok(image_data) => {
                self.ctx2d.put_image_data(&image_data, 0.0, 0.0).unwrap();
            }
            _ => {}
        }

        crate::cursor::update_native_cursor(player, &self.canvas, &mut self.native_cursor_cache);
    }

    pub fn capture_stage_bitmap(&mut self, player: &mut DirPlayer) -> Bitmap {
        self.draw_frame(player);

        let (width, height) = self.size;
        let image_data = self
            .ctx2d
            .get_image_data(0.0, 0.0, width as f64, height as f64)
            .expect("Canvas2D stage capture failed");
        let mut bitmap = Bitmap::new(
            width as u16,
            height as u16,
            32,
            32,
            8,
            PaletteRef::BuiltIn(get_system_default_palette()),
        );
        bitmap.data = image_data.data().0;
        bitmap.use_alpha = true;
        bitmap
    }

    /// Get the backend name
    pub fn backend_name(&self) -> &'static str {
        "Canvas2D"
    }
}

impl Renderer for PlayerCanvasRenderer {
    fn draw_frame(&mut self, player: &mut DirPlayer) {
        PlayerCanvasRenderer::draw_frame(self, player)
    }

    fn capture_stage_bitmap(&mut self, player: &mut DirPlayer) -> Bitmap {
        PlayerCanvasRenderer::capture_stage_bitmap(self, player)
    }

    fn draw_preview_frame(&mut self, player: &mut DirPlayer) {
        PlayerCanvasRenderer::draw_preview_frame(self, player)
    }

    fn set_size(&mut self, width: u32, height: u32) {
        PlayerCanvasRenderer::set_size(self, width, height)
    }

    fn size(&self) -> (u32, u32) {
        self.size
    }

    fn backend_name(&self) -> &'static str {
        PlayerCanvasRenderer::backend_name(self)
    }

    fn canvas(&self) -> &web_sys::HtmlCanvasElement {
        &self.canvas
    }

    fn set_preview_member_ref(&mut self, member_ref: Option<CastMemberRef>) {
        self.preview_member_ref = member_ref;
    }

    fn set_preview_container_element(&mut self, container_element: Option<web_sys::HtmlElement>) {
        PlayerCanvasRenderer::set_preview_container_element(self, container_element)
    }

    fn set_preview_font_size(&mut self, size: Option<u16>) {
        self.preview_font_size = size;
    }

    fn preview_font_size(&self) -> Option<u16> {
        self.preview_font_size
    }
}

thread_local! {
    pub static RENDERER_LOCK: RefCell<Option<DynamicRenderer>> = RefCell::new(None);
    pub static LAST_DRAW_MS: Cell<i64> = Cell::new(0);
    /// Whether the persistent draw loop has already been spawned. The loop
    /// itself picks up whatever renderer is currently in RENDERER_LOCK on
    /// each rAF, so we only need one loop across the whole WASM lifetime —
    /// dropping and recreating the renderer between tests must not respawn it.
    pub static DRAW_LOOP_SPAWNED: Cell<bool> = Cell::new(false);
    /// True while the stage WebGL2 context is lost (browser reclaimed it, e.g.
    /// the tab was backgrounded). Drawing is skipped until `webglcontextrestored`
    /// re-initializes the renderer. See `register_webgl_context_handlers`.
    pub static WEBGL_CONTEXT_LOST: Cell<bool> = Cell::new(false);
}

/// True when the document/tab is hidden (backgrounded). Rendering to a hidden
/// tab's GL context is wasted work and provokes context-loss; skip it.
fn document_is_hidden() -> bool {
    #[cfg(target_arch = "wasm32")]
    {
        web_sys::window()
            .and_then(|w| w.document())
            .map(|d| d.hidden())
            .unwrap_or(false)
    }
    #[cfg(not(target_arch = "wasm32"))]
    { false }
}

/// Skip the stage draw when the context is lost or the tab is hidden.
fn should_skip_stage_draw() -> bool {
    WEBGL_CONTEXT_LOST.with(|c| c.get()) || document_is_hidden()
}

pub fn mark_frame_drawn() {
    LAST_DRAW_MS.with(|ts| ts.set(chrono::Utc::now().timestamp_millis()));
}

fn was_frame_drawn_recently(interval_ms: i64) -> bool {
    LAST_DRAW_MS.with(|ts| chrono::Utc::now().timestamp_millis() - ts.get() < interval_ms)
}

#[allow(dead_code)]
pub fn with_renderer_ref<F, R>(f: F) -> R
where
    F: FnOnce(&DynamicRenderer) -> R,
{
    RENDERER_LOCK.with(|renderer_lock| {
        let renderer = renderer_lock.borrow();
        f(renderer.as_ref().unwrap())
    })
}

pub fn with_renderer_mut<F, R>(f: F) -> R
where
    F: FnOnce(&mut Option<DynamicRenderer>) -> R,
{
    RENDERER_LOCK.with_borrow_mut(|renderer_lock| f(renderer_lock))
}

pub fn draw_frame_immediate() {
    use crate::rendering_gpu::Renderer;
    // A nested `#movie` sub-player is headless: its stage is composited by the
    // HOST once per host frame via render_nested_player_stages into an
    // off-screen FBO. If the sub calls updateStage()/nothing() (very common
    // during keyboard movement and busy-wait loops), draw_frame here would run
    // against the HOST's framebuffer + size, smearing the sub's sprites (wide
    // scrolling background, off-screen tiles) across the whole host stage
    // unclipped — flickering on every such call. Never let a sub draw directly
    // to the host stage; leave stage_dirty so the host recomposites its FBO.
    if unsafe { crate::player::ACTIVE_PLAYER_ID } != 0 {
        return;
    }
    let (tempo, dirty) = reserve_player_ref(|player| {
        (player.current_frame_tempo as f64, player.stage_dirty)
    });
    if !dirty {
        return;
    }
    if should_skip_stage_draw() {
        return;
    }
    let interval = if tempo > 0.0 {
        (60000.0 / tempo) as i64
    } else {
        1000 // Default to 1 second interval if tempo is invalid
    };
    if !was_frame_drawn_recently(interval) {
        with_renderer_mut(|renderer_lock| {
            if let Some(renderer) = renderer_lock {
                reserve_player_mut(|player| {
                    renderer.draw_frame(player);
                    player.stage_dirty = false;
                });
            }
            mark_frame_drawn();
        });
    }
}

/// Draw the stage at the end of a frame cycle whose input handlers held the
/// redraw (see `DirPlayer::draw_hold_since_ms`). Unpaced: this is the one
/// draw Director makes for that frame.
pub fn draw_frame_at_frame_end() {
    if unsafe { crate::player::ACTIVE_PLAYER_ID } != 0 {
        return;
    }
    if should_skip_stage_draw() {
        return;
    }
    with_renderer_mut(|renderer_lock| {
        if let Some(renderer) = renderer_lock {
            reserve_player_mut(|player| {
                renderer.draw_frame(player);
                player.stage_dirty = false;
            });
        }
        mark_frame_drawn();
    });
}

/// Helper to access Canvas2D renderer for Canvas2D-specific operations
#[allow(dead_code)]
pub fn with_canvas2d_renderer<F, R>(f: F) -> Option<R>
where
    F: FnOnce(&PlayerCanvasRenderer) -> R,
{
    RENDERER_LOCK.with(|renderer_lock| {
        let renderer = renderer_lock.borrow();
        if let Some(dynamic) = renderer.as_ref() {
            if let Some(canvas2d) = dynamic.as_canvas2d() {
                return Some(f(canvas2d));
            }
        }
        None
    })
}

/// Helper to access Canvas2D renderer mutably for Canvas2D-specific operations
pub fn with_canvas2d_renderer_mut<F, R>(f: F) -> Option<R>
where
    F: FnOnce(&mut PlayerCanvasRenderer) -> R,
{
    RENDERER_LOCK.with_borrow_mut(|renderer_lock| {
        if let Some(dynamic) = renderer_lock {
            if let Some(canvas2d) = dynamic.as_canvas2d_mut() {
                return Some(f(canvas2d));
            }
        }
        None
    })
}

/// Legacy helper - kept for backward compatibility with existing code
/// Prefer using with_renderer_mut or with_canvas2d_renderer_mut
#[allow(dead_code)]
pub fn with_canvas_renderer_mut<F, R>(f: F) -> R
where
    F: FnOnce(&mut PlayerCanvasRenderer) -> R,
    R: Default,
{
    with_canvas2d_renderer_mut(f).unwrap_or_default()
}

#[wasm_bindgen]
pub fn player_set_preview_member_ref(cast_lib: i32, cast_num: i32) -> Result<(), JsValue> {
    use crate::rendering_gpu::Renderer;
    with_renderer_mut(|renderer_lock| {
        if let Some(dynamic) = renderer_lock {
            dynamic.set_preview_member_ref(Some(CastMemberRef {
                cast_lib,
                cast_member: cast_num,
            }));
        }
    });
    reserve_player_mut(|player| {
        player.preview_dirty = true;
    });
    Ok(())
}

#[wasm_bindgen]
pub fn player_set_preview_font_size(size: u16) -> Result<(), JsValue> {
    use crate::rendering_gpu::Renderer;
    with_renderer_mut(|renderer_lock| {
        if let Some(dynamic) = renderer_lock {
            dynamic.set_preview_font_size(if size > 0 { Some(size) } else { None });
        }
    });
    reserve_player_mut(|player| {
        player.preview_dirty = true;
    });
    Ok(())
}

#[wasm_bindgen]
pub fn player_set_debug_selected_channel(channel_num: i16) -> Result<(), JsValue> {
    // Set on whichever renderer is active (Canvas2D or WebGL2)
    with_renderer_mut(|renderer_lock| {
        if let Some(dynamic) = renderer_lock {
            if let Some(canvas2d) = dynamic.as_canvas2d_mut() {
                canvas2d.debug_selected_channel_num = Some(channel_num);
            } else if let Some(webgl2) = dynamic.as_webgl2_mut() {
                webgl2.debug_selected_channel_num = Some(channel_num);
            }
        }
    });
    JsApi::dispatch_channel_changed(channel_num);
    Ok(())
}

#[wasm_bindgen]
pub fn player_set_preview_parent(parent_selector: &str) -> Result<(), JsValue> {
    use crate::rendering_gpu::Renderer;
    if parent_selector.is_empty() {
        with_renderer_mut(|renderer_lock| {
            if let Some(dynamic) = renderer_lock {
                dynamic.set_preview_container_element(None);
            }
        });
        return Ok(());
    }
    let parent_element = web_sys::window()
        .unwrap()
        .document()
        .unwrap()
        .query_selector(parent_selector)
        .unwrap()
        .unwrap()
        .dyn_into::<web_sys::HtmlElement>()?;

    with_renderer_mut(|renderer_lock| {
        if let Some(dynamic) = renderer_lock {
            dynamic.set_preview_container_element(Some(parent_element));
        }
    });

    Ok(())
}

/// Helper to set pixel-perfect rendering styles on a canvas
fn set_pixelated_canvas_style(canvas: &web_sys::HtmlCanvasElement) {
    let style = canvas.style();
    // Nearest-neighbor scaling when CSS size differs from canvas resolution
    style.set_property("image-rendering", "pixelated").unwrap_or(());
    style.set_property("image-rendering", "-moz-crisp-edges").unwrap_or(());
    style.set_property("image-rendering", "crisp-edges").unwrap_or(());
    // Disable ClearType / subpixel font smoothing - force grayscale AA
    style.set_property("-webkit-font-smoothing", "none").unwrap_or(());
    style.set_property("-moz-osx-font-smoothing", "grayscale").unwrap_or(());
    style.set_property("font-smooth", "never").unwrap_or(());
    // Disable text anti-aliasing optimizations
    style.set_property("text-rendering", "optimizeSpeed").unwrap_or(());
    // Force no backface-visibility optimization (can cause blurring on some GPUs)
    style.set_property("backface-visibility", "hidden").unwrap_or(());
}

/// Create a Canvas2D renderer (fallback)
pub(crate) fn create_canvas2d_renderer(
    canvas_size: (u32, u32),
) -> PlayerCanvasRenderer {
    let canvas = web_sys::window()
        .unwrap()
        .document()
        .unwrap()
        .create_element("canvas")
        .unwrap()
        .dyn_into::<web_sys::HtmlCanvasElement>()
        .unwrap();

    let preview_canvas = web_sys::window()
        .unwrap()
        .document()
        .unwrap()
        .create_element("canvas")
        .unwrap()
        .dyn_into::<web_sys::HtmlCanvasElement>()
        .unwrap();

    canvas.set_width(canvas_size.0);
    canvas.set_height(canvas_size.1);

    preview_canvas.set_width(1);
    preview_canvas.set_height(1);

    set_pixelated_canvas_style(&canvas);
    set_pixelated_canvas_style(&preview_canvas);

    let ctx = canvas
        .get_context("2d")
        .unwrap()
        .unwrap()
        .dyn_into::<web_sys::CanvasRenderingContext2d>()
        .unwrap();

    let preview_ctx = preview_canvas
        .get_context("2d")
        .unwrap()
        .unwrap()
        .dyn_into::<web_sys::CanvasRenderingContext2d>()
        .unwrap();

    ctx.set_image_smoothing_enabled(false);
    preview_ctx.set_image_smoothing_enabled(false);

    PlayerCanvasRenderer {
        active_transition: None,
        container_element: None,
        preview_container_element: None,
        canvas,
        preview_canvas,
        ctx2d: ctx,
        preview_ctx2d: preview_ctx,
        size: canvas_size,
        preview_size: (1, 1),
        preview_member_ref: None,
        preview_font_size: None,
        debug_selected_channel_num: None,
        bitmap: Bitmap::new(
            1,
            1,
            32,
            32,
            0,
            PaletteRef::BuiltIn(get_system_default_palette()),
        ),
        native_cursor_cache: None,
    }
}

/// Try to create a WebGL2 renderer, returns None if not supported or fails
pub(crate) fn try_create_webgl2_renderer(
    canvas_size: (u32, u32),
) -> Option<crate::rendering_gpu::webgl2::WebGL2Renderer> {
    use crate::rendering_gpu::webgl2::WebGL2Renderer;

    // Check if WebGL2 is supported
    if !crate::rendering_gpu::is_webgl2_supported() {
        debug!("WebGL2 not supported, falling back to Canvas2D");
        return None;
    }

    // Create canvases for WebGL2
    let canvas = web_sys::window()
        .unwrap()
        .document()
        .unwrap()
        .create_element("canvas")
        .ok()?
        .dyn_into::<web_sys::HtmlCanvasElement>()
        .ok()?;

    let preview_canvas = web_sys::window()
        .unwrap()
        .document()
        .unwrap()
        .create_element("canvas")
        .ok()?
        .dyn_into::<web_sys::HtmlCanvasElement>()
        .ok()?;

    canvas.set_width(canvas_size.0);
    canvas.set_height(canvas_size.1);
    preview_canvas.set_width(1);
    preview_canvas.set_height(1);

    // Mark the stage canvas so the Flash manager's global `getContext`
    // monkey-patch does NOT force `preserveDrawingBuffer: true` on it (that
    // patch is only needed for Ruffle's frame-capture readback; on the stage
    // it just wastes GPU memory and makes background context-loss more likely).
    let _ = canvas.set_attribute("data-dp-stage", "1");

    set_pixelated_canvas_style(&canvas);
    set_pixelated_canvas_style(&preview_canvas);

    // Try to create the WebGL2 renderer
    match WebGL2Renderer::new(canvas, preview_canvas) {
        Ok(renderer) => {
            debug!("WebGL2 renderer created successfully");
            register_webgl_context_handlers(renderer.canvas());
            Some(renderer)
        }
        Err(e) => {
            warn!("Failed to create WebGL2 renderer: {:?}, falling back to Canvas2D", e);
            None
        }
    }
}

/// Register `webglcontextlost` / `webglcontextrestored` listeners on the stage
/// canvas. Browsers reclaim a tab's WebGL context when it is backgrounded; the
/// default is to NOT restore it, so without `preventDefault()` the stage would
/// stay dead after the tab regains focus. On loss we pause drawing; on restore
/// we rebuild the renderer on the same canvas (fresh programs/buffers/textures).
/// The closures are leaked (`forget`) so they live for the canvas's lifetime.
fn register_webgl_context_handlers(canvas: &web_sys::HtmlCanvasElement) {
    let lost_cb = Closure::<dyn FnMut(web_sys::Event)>::new(move |e: web_sys::Event| {
        // preventDefault tells the browser we will restore -> it will fire
        // webglcontextrestored once the tab is visible again.
        e.prevent_default();
        WEBGL_CONTEXT_LOST.with(|c| c.set(true));
        warn!("[webgl] stage context lost — pausing draw until restored");
    });
    let _ = canvas.add_event_listener_with_callback(
        "webglcontextlost",
        lost_cb.as_ref().unchecked_ref(),
    );
    lost_cb.forget();

    let restored_cb = Closure::<dyn FnMut(web_sys::Event)>::new(move |_e: web_sys::Event| {
        on_webgl_context_restored();
    });
    let _ = canvas.add_event_listener_with_callback(
        "webglcontextrestored",
        restored_cb.as_ref().unchecked_ref(),
    );
    restored_cb.forget();
}

/// Rebuild the WebGL2 renderer on the existing (now-restored) canvas so its GL
/// objects are recreated, then resume drawing. Caches (textures/text) start
/// empty and re-populate on the next frame.
fn on_webgl_context_restored() {
    use crate::rendering_gpu::webgl2::WebGL2Renderer;
    with_renderer_mut(|renderer_lock| {
        if let Some(DynamicRenderer::WebGL2(old)) = renderer_lock.as_ref() {
            let canvas = old.canvas().clone();
            let preview = old.preview_canvas().clone();
            match WebGL2Renderer::new(canvas, preview) {
                Ok(new_renderer) => {
                    *renderer_lock = Some(DynamicRenderer::WebGL2(new_renderer));
                    warn!("[webgl] stage context restored — renderer rebuilt");
                }
                Err(e) => {
                    warn!("[webgl] failed to rebuild renderer after context restore: {:?}", e);
                }
            }
        }
    });
    WEBGL_CONTEXT_LOST.with(|c| c.set(false));
    // Force a full redraw on the next frame.
    reserve_player_mut(|player| {
        player.stage_dirty = true;
    });
}

fn get_stage_container() -> Result<web_sys::HtmlElement, JsValue> {
    web_sys::window()
        .unwrap()
        .document()
        .unwrap()
        .query_selector("#stage_canvas_container")
        .unwrap()
        .unwrap()
        .dyn_into::<web_sys::HtmlElement>()
        .map_err(|e| JsValue::from(e))
}

fn get_canvas_size() -> (u32, u32) {
    with_renderer_mut(|renderer_lock| {
        if let Some(renderer) = renderer_lock {
            renderer.size()
        } else {
            reserve_player_ref(crate::player::stage::stage_canvas_dims)
        }
    })
}

fn create_renderer(backend: &str, canvas_size: (u32, u32)) -> Option<DynamicRenderer> {
    match backend {
        "WebGL2" => {
            try_create_webgl2_renderer(canvas_size)
                .map(DynamicRenderer::WebGL2)
        }
        _ => Some(DynamicRenderer::Canvas2D(create_canvas2d_renderer(canvas_size))),
    }
}

fn attach_renderer_to_container(container: &web_sys::HtmlElement) {
    with_renderer_mut(|renderer_lock| {
        if let Some(renderer) = renderer_lock {
            match renderer {
                DynamicRenderer::Canvas2D(canvas_renderer) => {
                    canvas_renderer.set_container_element(container.clone());
                }
                DynamicRenderer::WebGL2(webgl_renderer) => {
                    if webgl_renderer.canvas().parent_node().is_some() {
                        webgl_renderer.canvas().remove();
                    }
                    container.append_child(webgl_renderer.canvas()).unwrap();
                }
            }
        }
    });
}

#[wasm_bindgen]
pub fn player_create_canvas() -> Result<(), JsValue> {
    let container = get_stage_container()?;

    with_renderer_mut(|renderer_lock| {
        if renderer_lock.is_none() {
            let canvas_size = reserve_player_ref(crate::player::stage::stage_canvas_dims);

            // Try WebGL2 first, fall back to Canvas2D
            let dynamic_renderer = if let Some(webgl2_renderer) = try_create_webgl2_renderer(canvas_size) {
                DynamicRenderer::WebGL2(webgl2_renderer)
            } else {
                DynamicRenderer::Canvas2D(create_canvas2d_renderer(canvas_size))
            };

            *renderer_lock = Some(dynamic_renderer);
            // Only spawn the draw loop the first time. Later calls (after the
            // renderer was dropped between movies) reuse the existing loop.
            if !DRAW_LOOP_SPAWNED.with(|f| f.get()) {
                DRAW_LOOP_SPAWNED.with(|f| f.set(true));
                crate::player::spawn_player_local(async {
                    run_draw_loop().await;
                });
            }
        }
    });

    attach_renderer_to_container(&container);
    Ok(())
}

#[wasm_bindgen]
pub fn player_set_renderer_backend(backend: &str) -> Result<(), JsValue> {
    let container = get_stage_container()?;

    // Remove old canvas from container
    while let Some(child) = container.first_child() {
        container.remove_child(&child).unwrap();
    }

    let canvas_size = get_canvas_size();
    if let Some(new_renderer) = create_renderer(backend, canvas_size) {
        with_renderer_mut(|renderer_lock| {
            *renderer_lock = Some(new_renderer);
        });
    }

    attach_renderer_to_container(&container);
    Ok(())
}

fn request_animation_frame(f: &Closure<dyn FnMut()>) {
    web_sys::window()
        .unwrap()
        .request_animation_frame(f.as_ref().unchecked_ref())
        .unwrap();
}

async fn run_draw_loop() {
    let rc = Rc::new(RefCell::new(None));
    let rc_clone = rc.clone();

    let mut last_frame_ms = 0;
    let cb = Closure::<dyn FnMut()>::new(move || {
        // Player may be momentarily None while a test harness tears down the
        // old player before allocating the new one. Skip drawing instead of
        // panicking — the next rAF will pick it back up.
        let player = match unsafe { PLAYER_OPT.as_mut() } {
            Some(p) => p,
            None => {
                if let Ok(cb) = rc.try_borrow() {
                    if let Some(cb) = cb.as_ref() {
                        request_animation_frame(cb);
                    }
                }
                return;
            }
        };
        let mut player = player;
        // Pace the stage redraw to the MOVIE'S OWN TEMPO rather than a fixed
        // rate. This used to be a hardcoded 24, so a movie authored above that
        // — HavocCarDemo runs at 60 — advanced its playhead at full speed while
        // the canvas only ever showed 24 of those frames per second. The
        // simulation was right and the picture was stale.
        //
        // `current_frame_tempo` is the cached effective tempo (authored
        // frame_rate, or `puppetTempo` when set), refreshed every frame by
        // `refresh_frame_tempo` — the same value the frame loop paces from, so
        // drawing and advancing stay in step, including when a script changes
        // the tempo mid-movie.
        //
        // requestAnimationFrame is the real ceiling: the browser will not call
        // us faster than the display refresh, so a movie asking for 100fps
        // simply draws on every rAF (~60 on a 60Hz panel) rather than 100. The
        // clamp only guards against a nonsense tempo; `MIN` keeps the previous
        // 24fps as a FLOOR so nothing redraws slower than it did before, which
        // matters for movies that change the stage without advancing a frame.
        const MIN_DRAW_FPS: u32 = 24;
        const MAX_DRAW_FPS: u32 = 240;
        let draw_fps = player.current_frame_tempo.clamp(MIN_DRAW_FPS, MAX_DRAW_FPS);

        let frame_interval = 1000 / draw_fps as i64;
        if chrono::Utc::now().timestamp_millis() - last_frame_ms >= frame_interval {
            last_frame_ms = chrono::Utc::now().timestamp_millis();
            let skip_stage = should_skip_stage_draw();
            with_renderer_mut(|renderer_lock| {
                if let Some(renderer) = renderer_lock {
                    // Between an input handler and the exitFrame that follows it the
                    // stage is not redrawn (see `draw_hold_since_ms`). Bounded by
                    // time so a paused or stalled frame loop cannot hold it forever.
                    let held = player.draw_hold_since_ms.map_or(false, |since| {
                        player.is_playing && chrono::Utc::now().timestamp_millis() - since < 250
                    });
                    if !skip_stage && !held && (player.is_playing || player.stage_dirty) && !was_frame_drawn_recently(frame_interval) {
                        renderer.draw_frame(&mut player);
                        player.stage_dirty = false;
                    }
                    if !skip_stage && player.preview_dirty {
                        renderer.draw_preview_frame(&mut player);
                        player.preview_dirty = false;
                    }
                }
            });
        }

        let cb = rc.as_ref().borrow();
        let cb = cb.as_ref().unwrap();
        request_animation_frame(&cb);
    });
    rc_clone.replace(Some(cb));

    let cb = rc_clone.as_ref().borrow();
    let cb = cb.as_ref().unwrap();
    request_animation_frame(&cb);
}

/// Check if data starts with a valid SWF signature (FWS, CWS, or ZWS)
pub fn has_swf_signature(data: &[u8]) -> bool {
    if data.len() < 3 {
        return false;
    }
    let sig = &data[0..3];
    sig == b"FWS" || sig == b"CWS" || sig == b"ZWS"
}
