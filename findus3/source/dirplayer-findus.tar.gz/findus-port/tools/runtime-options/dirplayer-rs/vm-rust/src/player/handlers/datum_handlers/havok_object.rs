use std::collections::VecDeque;

use crate::{
    director::lingo::datum::{Datum, DatumType, HavokObjectRef},
    player::{
        DatumRef, ScriptError, cast_lib::CastMemberRef, cast_member::CastMemberType, reserve_player_mut, symbols::builtin::BuiltInSymbol, symbols::symbol::Symbol
    },
};

pub struct HavokObjectDatumHandlers {}

impl HavokObjectDatumHandlers {
    pub fn get_prop(obj_ref: &DatumRef, prop_name: &str) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let hk_ref = match player.get_datum(obj_ref) {
                Datum::HavokObjectRef(r) => r.clone(),
                _ => return Err(ScriptError::new("Expected HavokObjectRef".to_string())),
            };
            let member_ref = CastMemberRef {
                cast_lib: hk_ref.cast_lib,
                cast_member: hk_ref.cast_member,
            };
            match hk_ref.object_type {
                BuiltInSymbol::RigidBody => Self::get_rigid_body_prop(player, &member_ref, hk_ref.name, prop_name),
                BuiltInSymbol::Spring => Self::get_spring_prop(player, &member_ref, hk_ref.name, prop_name),
                BuiltInSymbol::LinearDashpot => Self::get_linear_dashpot_prop(player, &member_ref, hk_ref.name, prop_name),
                BuiltInSymbol::AngularDashpot => Self::get_angular_dashpot_prop(player, &member_ref, hk_ref.name, prop_name),
                BuiltInSymbol::Corrector => Self::get_corrector_prop(player, &member_ref, hk_ref.name, prop_name),
                _ => Err(ScriptError::new(format!("Unknown Havok object type: {}", hk_ref.object_type))),
            }
        })
    }

    pub fn set_prop(obj_ref: &DatumRef, prop_name: &str, value: DatumRef) -> Result<(), ScriptError> {
        reserve_player_mut(|player| {
            let hk_ref = match player.get_datum(obj_ref) {
                Datum::HavokObjectRef(r) => r.clone(),
                _ => return Err(ScriptError::new("Expected HavokObjectRef".to_string())),
            };
            let val = player.get_datum(&value).clone();
            let member_ref = CastMemberRef {
                cast_lib: hk_ref.cast_lib,
                cast_member: hk_ref.cast_member,
            };
            match hk_ref.object_type {
                BuiltInSymbol::RigidBody => Self::set_rigid_body_prop(player, &member_ref, hk_ref.name, prop_name, val),
                BuiltInSymbol::Spring => Self::set_spring_prop(player, &member_ref, hk_ref.name, prop_name, val),
                BuiltInSymbol::LinearDashpot => Self::set_linear_dashpot_prop(player, &member_ref, hk_ref.name, prop_name, val),
                BuiltInSymbol::AngularDashpot => Self::set_angular_dashpot_prop(player, &member_ref, hk_ref.name, prop_name, val),
                BuiltInSymbol::Corrector => Self::set_corrector_prop(player, &member_ref, hk_ref.name, prop_name, val),
                _ => Err(ScriptError::new(format!("Unknown Havok object type: {}", hk_ref.object_type))),
            }
        })
    }

    pub fn call(obj_ref: &DatumRef, handler_name: &str, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let hk_ref = match player.get_datum(obj_ref) {
                Datum::HavokObjectRef(r) => r.clone(),
                _ => return Err(ScriptError::new("Expected HavokObjectRef".to_string())),
            };
            let member_ref = CastMemberRef {
                cast_lib: hk_ref.cast_lib,
                cast_member: hk_ref.cast_member,
            };
            match hk_ref.object_type {
                BuiltInSymbol::RigidBody => Self::call_rigid_body(player, &member_ref, hk_ref.name, handler_name, args),
                BuiltInSymbol::Spring | BuiltInSymbol::LinearDashpot | BuiltInSymbol::AngularDashpot => {
                    Self::call_constraint(player, &member_ref, hk_ref.object_type, hk_ref.name, handler_name, args)
                }
                _ => Err(ScriptError::new(format!(
                    "No handler {} for Havok {} object", handler_name, hk_ref.object_type
                ))),
            }
        })
    }

    // --- Rigid Body ---

    fn get_rigid_body_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        rb_name: Symbol,
        prop: &str,
    ) -> Result<DatumRef, ScriptError> {
        // "rotation" returns a list — needs alloc_datum for each element which
        // requires &mut player. Handle in its own scope so the immutable borrow
        // chain ends before allocating the list.
        if prop == "rotation" {
            let (axis, angle) = {
                let member = player.movie.cast_manager.find_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                let rb = havok.state.rigid_bodies.iter()
                    .find(|r| r.name == rb_name)
                    .ok_or_else(|| ScriptError::new(format!("Rigid body '{}' not found", rb_name)))?;
                (rb.rotation_axis, rb.rotation_angle)
            };
            let axis_ref = player.alloc_datum(Datum::Vector(axis));
            let angle_ref = player.alloc_datum(Datum::Float(angle));
            return Ok(player.alloc_datum(Datum::List(DatumType::List, VecDeque::from([axis_ref, angle_ref]), false)));
        }

        // Read all needed values with an immutable borrow first
        let member = player.movie.cast_manager.find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let rb = havok.state.rigid_bodies.iter()
            .find(|r| r.name == rb_name)
            .ok_or_else(|| ScriptError::new(format!("Rigid body '{}' not found", rb_name)))?;

        let result = match prop {
            "name" => Datum::String(rb.name.to_string()),
            "position" => Datum::Vector(rb.position),
            "centerOfMass" | "centerofmass" => {
                // Havok Lingo docs: "offset from the models origin to the rigid
                // body's center of mass." Returns the unrotated local offset.
                // Under our convention where rb.position is the reference position
                // (visual origin that tracks COM velocity), the world COM equals
                // rb.position + com_local, so the getter returns com_local as-is.
                Datum::Vector(rb.center_of_mass)
            }
            // "rotation" handled separately at top of function (returns a list)
            "mass" => Datum::Float(rb.mass),
            "restitution" => Datum::Float(rb.restitution),
            "friction" => Datum::Float(rb.friction),
            "active" => Datum::Int(if rb.active { 1 } else { 0 }),
            "pinned" => Datum::Int(if rb.pinned { 1 } else { 0 }),
            "linearVelocity" | "linearvelocity" => Datum::Vector(rb.linear_velocity),
            "angularVelocity" | "angularvelocity" => Datum::Vector(rb.angular_velocity),
            "linearMomentum" | "linearmomentum" => Datum::Vector(rb.linear_momentum),
            "angularMomentum" | "angularmomentum" => {
                use crate::player::handlers::datum_handlers::cast_member::havok_physics::{quat_to_mat3, mat3_mul, mat3_transpose, mat3_transform, v3_scale};
                // L = I_world * omega (the engine derives angular momentum from the body's
                // angular velocity, not a stored field). I_world = R * I_body * R^T.
                // Expressed in Havok METER-scale units (× worldScale²): Lingo reads and
                // CLAMPS angular momentum in meter-scale, so a bare I·ω in display units is
                // ~1/worldScale² too large — that inflated value trips the car's spin clamp
                // (angularMomentum.length > 4) at a near-zero yaw, killing the steering.
                let rmat = quat_to_mat3(rb.orientation);
                let i_world = mat3_mul(mat3_mul(rmat, rb.inertia_tensor), mat3_transpose(rmat));
                let ws = havok.state.scale;
                Datum::Vector(v3_scale(mat3_transform(i_world, rb.angular_velocity), ws * ws))
            }
            "force" => Datum::Vector(rb.force),
            "torque" => Datum::Vector(rb.torque),
            "corrector" => {
                // Drop borrow via return
                return Ok(player.alloc_datum(Datum::HavokObjectRef(HavokObjectRef {
                    cast_lib: member_ref.cast_lib,
                    cast_member: member_ref.cast_member,
                    object_type: BuiltInSymbol::Corrector,
                    name: rb_name,
                })));
            }
            _ => return Err(ScriptError::new(format!("Unknown rigidBody property: {}", prop))),
        };
        // Borrow on member/havok/rb is dropped here since result is an owned Datum
        Ok(player.alloc_datum(result))
    }

    fn set_rigid_body_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        rb_name: Symbol,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        // For rotation, we need to extract list item values via player.get_datum
        // before borrowing the member mutably.
        if prop == "rotation" {
            let (axis, angle) = if let Datum::List(_, items, _) = &value {
                if items.len() >= 2 {
                    let axis = match player.get_datum(&items[0]) {
                        Datum::Vector(v) => *v,
                        _ => return Err(ScriptError::new("Expected vector for rotation axis".to_string())),
                    };
                    let angle = player.get_datum(&items[1]).to_float()?;
                    (Some(axis), Some(angle))
                } else {
                    (None, None)
                }
            } else {
                (None, None)
            };
            if let (Some(axis), Some(angle)) = (axis, angle) {
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                {
                    let rb = havok.state.rigid_bodies.iter_mut()
                        .find(|r| r.name == rb_name)
                        .ok_or_else(|| ScriptError::new(format!("Rigid body '{}' not found", rb_name)))?;
                    rb.rotation_axis = axis;
                    rb.rotation_angle = angle;
                    // Update internal quaternion from axis-angle degrees
                    rb.orientation = crate::player::handlers::datum_handlers::cast_member::havok_physics::quat_from_axis_angle_degrees(axis, angle);
                }
            }
            return Ok(());
        }

        // Extract rotation data from list BEFORE mutable borrow (to satisfy borrow checker)
        let rotation_data: Option<([f64; 3], f64)> = if prop == "rotation" {
            if let Datum::List(_, items, _) = &value {
                if items.len() >= 2 {
                    let axis = if let Datum::Vector(v) = player.get_datum(&items[0]) { Some(*v) } else { None };
                    let angle = player.get_datum(&items[1]).to_float().unwrap_or(0.0);
                    axis.map(|a| (a, angle))
                } else { None }
            } else { None }
        } else { None };

        // Read W3D refs BEFORE mutably borrowing havok (for position sync)
        let (w3d_cast_lib, w3d_cast_member) = {
            let member = player.movie.cast_manager.find_member_by_ref(member_ref)
                .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
            match &member.member_type {
                CastMemberType::HavokPhysics(h) => (h.state.w3d_cast_lib, h.state.w3d_cast_member),
                _ => return Err(ScriptError::new("Not a Havok member".to_string())),
            }
        };

        let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };

        // Track whether W3D sync is needed
        let mut needs_w3d_sync = false;

        // Update the HavokRigidBody fields
        {
            // Captured before the &mut borrow below so the angularMomentum setter can convert
            // the meter-scale L back to display-unit angular velocity (÷ worldScale²).
            let world_scale = havok.state.scale;
            let rb = havok.state.rigid_bodies.iter_mut()
                .find(|r| r.name == rb_name)
                .ok_or_else(|| ScriptError::new(format!("Rigid body '{}' not found", rb_name)))?;

            match prop {
                "position" => { if let Datum::Vector(v) = &value { rb.position = *v; needs_w3d_sync = true; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
                "rotation" => {
                    if let Some((axis, angle)) = rotation_data {
                        rb.rotation_axis = axis;
                        rb.rotation_angle = angle;
                        rb.orientation = crate::player::handlers::datum_handlers::cast_member::havok_physics::quat_from_axis_angle_degrees(axis, angle);
                        needs_w3d_sync = true;
                    }
                }
                "mass" => {
                    let new_mass = value.to_float()?;
                    rb.mass = new_mass;
                    // On a mass change, rescale inertia: I = unit_inertia * mass; then invert.
                    // unit_inertia_tensor was populated from the mesh at body creation time.
                    crate::player::handlers::datum_handlers::cast_member::havok_physics::recompute_body_inertia(
                        new_mass,
                        rb.unit_inertia_tensor,
                        &mut rb.inertia_tensor,
                        &mut rb.inverse_inertia_tensor,
                        &mut rb.inverse_mass,
                    );
                }
                "restitution" => { rb.restitution = value.to_float()?; }
                "friction" => { rb.friction = value.to_float()?; }
                "active" => { rb.active = value.int_value()? != 0; }
                "pinned" => {
                    let pinned = value.int_value()? != 0;
                    rb.pinned = pinned;
                    if pinned {
                        rb.linear_velocity = [0.0; 3];
                        rb.angular_velocity = [0.0; 3];
                        rb.inverse_mass = 0.0;
                        rb.inverse_inertia_tensor = [0.0; 9];
                    } else if rb.mass > 0.0 {
                        rb.inverse_mass = 1.0 / rb.mass;
                        rb.inverse_inertia_tensor = crate::player::handlers::datum_handlers::cast_member::havok_physics::mat3_inverse(rb.inertia_tensor);
                    }
                }
                // Setting a velocity/momentum is a disturbance: wake the body so it
                // isn't skipped in step (otherwise the new velocity is ignored).
                "linearVelocity" | "linearvelocity" => { if let Datum::Vector(v) = &value { rb.linear_velocity = *v; rb.active = true; rb.lingo_disturbed = true; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
                "angularVelocity" | "angularvelocity" => { if let Datum::Vector(v) = &value { rb.angular_velocity = *v; rb.active = true; rb.lingo_disturbed = true; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
                "linearMomentum" | "linearmomentum" => { if let Datum::Vector(v) = &value { rb.linear_momentum = *v; rb.active = true; rb.lingo_disturbed = true; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
                "angularMomentum" | "angularmomentum" => { if let Datum::Vector(v) = &value {
                    use crate::player::handlers::datum_handlers::cast_member::havok_physics::{quat_to_mat3, mat3_mul, mat3_transpose, mat3_transform, v3_scale};
                    // omega = I_world^-1 * L (the engine's setAngularMomentum drives the body's
                    // angular velocity from the given momentum). L arrives in meter-scale units,
                    // so divide by worldScale² (the inverse of the getter's × worldScale²) to get
                    // display-unit angular velocity. Without this, the car's spin clamp
                    // (angularMomentum = normalized*4) set a near-zero yaw and killed the steering.
                    let rmat = quat_to_mat3(rb.orientation);
                    let i_world_inv = mat3_mul(mat3_mul(rmat, rb.inverse_inertia_tensor), mat3_transpose(rmat));
                    let inv_scale_sq = if world_scale.abs() > 1e-10 { (1.0 / world_scale) * (1.0 / world_scale) } else { 1.0 };
                    rb.angular_velocity = v3_scale(mat3_transform(i_world_inv, *v), inv_scale_sq);
                    rb.angular_momentum = *v; rb.active = true; rb.lingo_disturbed = true;
                } else { return Err(ScriptError::new("Expected vector".to_string())); } }
                _ => return Err(ScriptError::new(format!("Cannot set rigidBody property: {}", prop))),
            }
        }

        // Collect sync data after property update
        let sync_data = if needs_w3d_sync {
            havok.state.rigid_bodies.iter()
                .find(|r| r.name.as_str().eq_ignore_ascii_case(rb_name.as_str()))
                .map(|rb| (rb.position, rb.orientation, rb.center_of_mass, rb.sync_scale))
        } else { None };

        // Sync rigid body position+rotation to W3D model transform (quaternion-based).
        // Goes through set_node_transform so the Lingo-visible persistent datum
        // is also updated, not just node_transforms.
        if let Some((pos, orientation, com, sscale)) = sync_data {
            let t = crate::player::handlers::datum_handlers::cast_member::havok_physics::build_sync_transform(
                pos, orientation, com, sscale,
            );
            let w3d_ref = CastMemberRef { cast_lib: w3d_cast_lib, cast_member: w3d_cast_member };
            crate::player::handlers::datum_handlers::shockwave3d_object::set_node_transform(
                player, &w3d_ref, rb_name, t,
            );
        }

        Ok(())
    }

    /// Read a vector argument for the applyForce/applyImpulse/applyTorque
    /// family, returning None when it isn't one.
    ///
    /// INFERRED from shipping movies, not from the Havok Xtra docs: the Xtra
    /// ignores such a call rather than raising, because a Lingo error would
    /// abort the handler and the movies plainly kept running. Age of Speed 2's
    /// `Game.UpdateGravity` applies `lVehicle.getGravity()` to every player's
    /// chassis each frame, but `pGravity` is only assigned inside the VEHICLE's
    /// own `Update` — so on the frames before a vehicle has updated once it is
    /// VOID, and erroring there killed the frame that would have set it.
    fn vector_arg(player: &crate::player::DirPlayer, arg: Option<&DatumRef>) -> Option<[f64; 3]> {
        match arg.map(|a| player.get_datum(a)) {
            Some(Datum::Vector(v)) => Some(*v),
            _ => None,
        }
    }

    fn call_rigid_body(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        rb_name: Symbol,
        handler_name: &str,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        match handler_name {
            "applyForce" | "applyforce" => {
                let Some(force) = Self::vector_arg(player, args.get(0)) else { return Ok(DatumRef::Void) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    rb.active = true; rb.lingo_disturbed = true;
                    // Record that this body is force-driven so a later kinematic
                    // interpolatingMoveTo won't reclassify a hover vehicle as a
                    // passive stacking block. See HavokRigidBody::received_force.
                    rb.received_force = true;
                    // A force applied from a step callback (age-of-speed gravity) is
                    // per-sub-step and must not be force_scale-attenuated — route it
                    // to the full-strength accumulator. See IN_STEP_CALLBACK.
                    let acc = if super::cast_member::havok_physics::in_step_callback() {
                        &mut rb.step_force
                    } else {
                        &mut rb.force
                    };
                    acc[0] += force[0];
                    acc[1] += force[1];
                    acc[2] += force[2];
                }
                Ok(DatumRef::Void)
            }
            "applyForceAtPoint" | "applyforceatpoint" => {
                let Some(force) = Self::vector_arg(player, args.get(0)) else { return Ok(DatumRef::Void) };
                let Some(point) = Self::vector_arg(player, args.get(1)) else { return Ok(DatumRef::Void) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };

                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    use super::cast_member::havok_physics::{v3_sub, quat_rotate_v, v3_cross};
                    rb.active = true; rb.lingo_disturbed = true;
                    // Hover force — record force-driven so a later kinematic
                    // interpolatingMoveTo can't reclassify this vehicle as a
                    // passive stacking block. See HavokRigidBody::received_force.
                    rb.received_force = true;

                    // Compute world-space lever arm from the model-local point, so
                    // torque = lever × force.
                    let rel = v3_sub(point, rb.center_of_mass);
                    let r = quat_rotate_v(rb.orientation, rel);
                    let t = v3_cross(r, force);

                    // A force applied from a step callback is per-sub-step (full
                    // strength); a force from the frame update is once-per-frame and
                    // gets force_scale attenuation. Route to the matching accumulator.
                    if super::cast_member::havok_physics::in_step_callback() {
                        for i in 0..3 { rb.step_force[i] += force[i]; rb.step_torque[i] += t[i]; }
                    } else {
                        for i in 0..3 { rb.force[i] += force[i]; rb.torque[i] += t[i]; }
                    }
                }
                Ok(DatumRef::Void)
            }
            "applyImpulse" | "applyimpulse" => {
                let Some(impulse) = Self::vector_arg(player, args.get(0)) else { return Ok(DatumRef::Void) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    use super::cast_member::havok_physics::{v3_add, v3_scale};
                    rb.active = true; rb.lingo_disturbed = true;
                    if rb.inverse_mass > 0.0 {
                        rb.linear_velocity = v3_add(rb.linear_velocity, v3_scale(impulse, rb.inverse_mass));
                    }
                    // Clear resting contact so the ball can be dragged off surfaces
                    rb.resting_normal = None;
                }
                Ok(DatumRef::Void)
            }
            "applyImpulseAtPoint" | "applyimpulseatpoint" => {
                let Some(impulse) = Self::vector_arg(player, args.get(0)) else { return Ok(DatumRef::Void) };
                let Some(point) = Self::vector_arg(player, args.get(1)) else { return Ok(DatumRef::Void) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };

                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    use super::cast_member::havok_physics::{v3_sub, v3_add, v3_scale, v3_cross, quat_rotate_v, mat3_transform, mat3_mul, mat3_transpose, quat_to_mat3};
                    rb.active = true; rb.lingo_disturbed = true;
                    if rb.inverse_mass > 0.0 {
                        // Linear: v += impulse * inverseMass
                        rb.linear_velocity = v3_add(rb.linear_velocity, v3_scale(impulse, rb.inverse_mass));

                        // Rotate model-local point by body orientation.
                        //
                        // NB the Xtra's `applyImpulseSingle` uses `r = point -
                        // position` rather than subtracting
                        // the centre of mass. Tried matching that: it made Age of
                        // Speed's loop WORSE (speed decayed to 188-197 km/h where
                        // the COM-relative lever holds 226-241), so it is not simply
                        // a lever-origin mismatch. Don't repeat without also
                        // reworking how `center_of_mass` feeds the integrator.
                        let rel = v3_sub(point, rb.center_of_mass);
                        let r = quat_rotate_v(rb.orientation, rel);

                        // Angular: omega += I_world^-1 * cross(lever, impulse). The lever and
                        // impulse are world-frame, so the body-frame inverse inertia must be
                        // rotated into the current orientation (R·Iinv·R^T) — matching
                        // integrate_body / applyAngularImpulse / the engine's impulse resolver.
                        let torque_impulse = v3_cross(r, impulse);
                        let rmat = quat_to_mat3(rb.orientation);
                        let i_world_inv = mat3_mul(mat3_mul(rmat, rb.inverse_inertia_tensor), mat3_transpose(rmat));
                        let ang = mat3_transform(i_world_inv, torque_impulse);
                        rb.angular_velocity = v3_add(rb.angular_velocity, ang);
                    }
                }
                Ok(DatumRef::Void)
            }
            "applyTorque" | "applytorque" => {
                let Some(torque) = Self::vector_arg(player, args.get(0)) else { return Ok(DatumRef::Void) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                // A bare Lingo torque needs the (1/worldScale)² factor, exactly like
                // applyAngularImpulse below: the chassis inertia is in DISPLAY units, and a
                // force-based torque (applyForceAtPoint) carries the r×F that already supplies
                // the worldScale² which cancels — a bare torque does not, so it must be scaled
                // here to match real Havok (measured: Director's applyTorque response is
                // ~1/worldScale² stronger than the unscaled value).
                let world_scale = havok.state.scale;
                let inv_scale_sq = if world_scale.abs() > 1e-10 { (1.0 / world_scale) * (1.0 / world_scale) } else { 1.0 };
                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    // Wake a sleeping body — a Lingo torque is a disturbance, and
                    // an inactive body is skipped in step (the torque would be
                    // silently ignored). Matches applyForce/applyImpulse above.
                    rb.active = true; rb.lingo_disturbed = true;
                    // Record force-driven (see applyForce) so a later kinematic
                    // interpolatingMoveTo can't reclassify this body as passive.
                    rb.received_force = true;
                    rb.torque[0] += torque[0] * inv_scale_sq;
                    rb.torque[1] += torque[1] * inv_scale_sq;
                    rb.torque[2] += torque[2] * inv_scale_sq;
                }
                Ok(DatumRef::Void)
            }
            "applyAngularImpulse" | "applyangularimpulse" => {
                let Some(impulse) = Self::vector_arg(player, args.get(0)) else { return Ok(DatumRef::Void) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                // The chassis inertia is stored in DISPLAY (scene) units, but Havok
                // applies a Lingo angular impulse to the METER-scale inertia. A force-
                // based torque (applyForceAtPoint) carries r×F which already supplies
                // the worldScale² that cancels — a bare angular impulse does not, so it
                // must be scaled by (1/worldScale)² here to match real Havok's response.
                let world_scale = havok.state.scale;
                let inv_scale_sq = if world_scale.abs() > 1e-10 { (1.0 / world_scale) * (1.0 / world_scale) } else { 1.0 };
                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    use super::cast_member::havok_physics::{v3_add, v3_scale, mat3_transform, mat3_mul, mat3_transpose, quat_to_mat3};
                    // Wake a sleeping body (consistent with applyImpulse).
                    rb.active = true; rb.lingo_disturbed = true;
                    // angVel += I_world^-1 * angularImpulse. The impulse is world-frame
                    // (e.g. the raycast car steers about world-up), so the body-frame
                    // inverse inertia must be rotated into the current orientation,
                    // matching integrate_body's angular update.
                    let r = quat_to_mat3(rb.orientation);
                    let i_world_inv = mat3_mul(mat3_mul(r, rb.inverse_inertia_tensor), mat3_transpose(r));
                    let dw = v3_scale(mat3_transform(i_world_inv, impulse), inv_scale_sq);
                    rb.angular_velocity = v3_add(rb.angular_velocity, dw);
                }
                Ok(DatumRef::Void)
            }
            "attemptMoveTo" | "attemptmoveto" => {
                let pos = match player.get_datum(&args[0]) { Datum::Vector(v) => *v, _ => return Err(ScriptError::new("Expected vector".to_string())) };
                // rotation is a list [axis_vector, angle_float] - extract before mut borrow
                let rotation = if args.len() > 1 {
                    let rot = player.get_datum(&args[1]).clone();
                    if let Datum::List(_, items, _) = &rot {
                        if items.len() >= 2 {
                            let axis = match player.get_datum(&items[0]) { Datum::Vector(v) => *v, _ => return Err(ScriptError::new("Expected vector for rotation axis".to_string())) };
                            let angle = player.get_datum(&items[1]).to_float()?;
                            Some((axis, angle))
                        } else { None }
                    } else { None }
                } else { None };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                use crate::player::handlers::datum_handlers::cast_member::havok_physics as hv;
                let idx = havok.state.rigid_bodies.iter()
                    .position(|r| r.name.as_str().eq_ignore_ascii_case(rb_name.as_str()));
                if let Some(idx) = idx {
                    let new_orient = match rotation {
                        Some((axis, angle)) => hv::quat_from_axis_angle_degrees(axis, angle),
                        None => havok.state.rigid_bodies[idx].orientation,
                    };
                    // Engine attemptMoveTo: only commit when the target is clear;
                    // otherwise leave the body in place and report failure.
                    if hv::body_blocked_at(&mut havok.state, idx, pos, new_orient) {
                        return Ok(player.alloc_datum(Datum::Int(0)));
                    }
                    let rb = &mut havok.state.rigid_bodies[idx];
                    rb.position = pos;
                    if let Some((axis, angle)) = rotation {
                        rb.rotation_axis = axis;
                        rb.rotation_angle = angle;
                        rb.orientation = new_orient;
                    }
                    return Ok(player.alloc_datum(Datum::Int(1)));
                }
                // No such body — move did not happen.
                Ok(player.alloc_datum(Datum::Int(0)))
            }
            "interpolatingMoveTo" | "interpolatingmoveto" => {
                let pos = match player.get_datum(&args[0]) { Datum::Vector(v) => *v, _ => return Err(ScriptError::new("Expected vector".to_string())) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                // A body positioned purely kinematically and never force-driven is a
                // passive stacking object (the add-cubes demo), not a hover vehicle.
                // A raycast car has already hovered (received_force) before its
                // recovery interpolatingMoveTo, so it stays a vehicle and just moves
                // to the exact target.
                let idx = havok.state.rigid_bodies.iter()
                    .position(|r| r.name.as_str().eq_ignore_ascii_case(rb_name.as_str()));
                if let Some(idx) = idx {
                    let (received_force, half) = {
                        let rb = &havok.state.rigid_bodies[idx];
                        (rb.received_force, rb.inertia_half_extents)
                    };
                    if received_force {
                        havok.state.rigid_bodies[idx].position = pos;
                    } else {
                        // Stacking spawn: real Havok interpolatingMoveTo moves the body
                        // toward the target but collisions STOP it, so a new cube lands
                        // ON TOP of the pile. Teleporting straight to the target z would
                        // bury it under the stack (it would be "added from the bottom").
                        // So drop it just above whatever already occupies the target
                        // column — the existing cubes AND the static floor — and land
                        // it over the TOP cube's x,y, not the target x,y. Re-centring
                        // every cube over the target fights the lean and makes the
                        // tower far too stable; landing on the leaning top (where the
                        // pile actually blocks it) lets the lean carry up so it topples
                        // like Director's does.
                        let mut baseline = pos[2];
                        let mut top_xy = [pos[0], pos[1]];
                        for (j, other) in havok.state.rigid_bodies.iter().enumerate() {
                            if j == idx || other.collisions_disabled || other.pinned { continue; }
                            let dx = (other.position[0] - pos[0]).abs();
                            let dy = (other.position[1] - pos[1]).abs();
                            if dx < half[0] + other.inertia_half_extents[0]
                                && dy < half[1] + other.inertia_half_extents[1] {
                                let top = other.position[2] + other.inertia_half_extents[2];
                                if top > baseline {
                                    baseline = top;
                                    top_xy = [other.position[0], other.position[1]];
                                }
                            }
                        }
                        for mesh in &havok.state.collision_meshes {
                            // Only FIXED-owned / static meshes form the floor.
                            if let Some(owner) = mesh.body_index {
                                if !havok.state.rigid_bodies[owner].pinned { continue; }
                            }
                            if pos[0] >= mesh.aabb_min[0] - half[0] && pos[0] <= mesh.aabb_max[0] + half[0]
                                && pos[1] >= mesh.aabb_min[1] - half[1] && pos[1] <= mesh.aabb_max[1] + half[1] {
                                baseline = baseline.max(mesh.aabb_max[2]);
                            }
                        }
                        // Nudge the landing a touch further out along the existing
                        // lean so the tower leans a bit faster and topples around the
                        // same height Director's does (~11) instead of standing far
                        // too long. Pure follow-the-top only grows the lean from
                        // drift, which holds ~16. Tune LEAN_NUDGE to move the topple
                        // height (bigger = topples sooner).
                        const LEAN_NUDGE: f64 = 0.05;
                        let lean = [top_xy[0] - pos[0], top_xy[1] - pos[1]];
                        let lean_len = (lean[0]*lean[0] + lean[1]*lean[1]).sqrt();
                        let place_xy = if lean_len > 1e-3 {
                            let k = LEAN_NUDGE / lean_len;
                            [top_xy[0] + lean[0]*k, top_xy[1] + lean[1]*k]
                        } else {
                            top_xy
                        };
                        let rb = &mut havok.state.rigid_bodies[idx];
                        rb.position = [place_xy[0], place_xy[1], baseline + half[2] + 1.0];
                        rb.driven = false;
                        rb.active = true;
                    }
                }
                // Return 1.0 (fully moved)
                Ok(player.alloc_datum(Datum::Float(1.0)))
            }
            "correctorMoveTo" | "correctormoveto" => {
                let pos = match player.get_datum(&args[0]) { Datum::Vector(v) => *v, _ => return Err(ScriptError::new("Expected vector".to_string())) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    rb.position = pos;
                }
                Ok(DatumRef::Void)
            }
            "shiftCenterOfMass" | "shiftcenterofmass" => {
                let offset = match player.get_datum(&args[0]) { Datum::Vector(v) => *v, _ => return Err(ScriptError::new("Expected vector".to_string())) };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                if let Some(rb) = havok.state.rigid_bodies.iter_mut()
                    .find(|r| r.name == rb_name)
                {
                    rb.center_of_mass[0] += offset[0];
                    rb.center_of_mass[1] += offset[1];
                    rb.center_of_mass[2] += offset[2];
                }
                // Native Havok: rb.position stays at VISUAL origin.
                // COM offset is stored in rb.center_of_mass and used by
                // build_sync_transform and applyForceAtPoint.
                // Do NOT shift rb.position — that would break Lingo readback.
                Ok(DatumRef::Void)
            }
            "getProp" => {
                let prop = player.get_datum(&args[0]).string_value()?;
                let result = Self::get_rigid_body_prop(player, member_ref, rb_name, &prop)?;
                // Bytecode form `obj.prop[N]` compiles to obj.getProp(#prop, N).
                // If a numeric index follows the prop name, return the Nth
                // component of the prop's value (vector or list).
                if args.len() >= 2 {
                    let index = player.get_datum(&args[1]).int_value()?;
                    let value = player.get_datum(&result).clone();
                    return match value {
                        Datum::Vector(arr) => {
                            let i = (index - 1) as usize;
                            if i < 3 {
                                Ok(player.alloc_datum(Datum::Float(arr[i])))
                            } else {
                                Err(ScriptError::new(format!(
                                    "Vector index {} out of range (1..3) for rigidBody.{}", index, prop
                                )))
                            }
                        }
                        Datum::List(_, items, _) => {
                            let i = (index - 1) as usize;
                            items.get(i).cloned().ok_or_else(|| ScriptError::new(format!(
                                "List index {} out of range for rigidBody.{}", index, prop
                            )))
                        }
                        _ => Ok(result),
                    };
                }
                Ok(result)
            }
            _ => Err(ScriptError::new(format!("No handler {} for rigidBody", handler_name))),
        }
    }

    // --- Spring ---

    fn get_spring_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        spring_name: Symbol,
        prop: &str,
    ) -> Result<DatumRef, ScriptError> {
        let member = player.movie.cast_manager.find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let spring = havok.state.springs.iter()
            .find(|s| s.name == spring_name)
            .ok_or_else(|| ScriptError::new(format!("Spring '{}' not found", spring_name)))?;

        let result = match prop {
            "name" => Datum::String(spring.name.to_string()),
            "pointA" | "pointa" => Datum::Vector(spring.point_a),
            "pointB" | "pointb" => Datum::Vector(spring.point_b),
            "restLength" | "restlength" => Datum::Float(spring.rest_length),
            "elasticity" => Datum::Float(spring.elasticity),
            "damping" => Datum::Float(spring.damping),
            "onCompression" | "oncompression" => Datum::Int(if spring.on_compression { 1 } else { 0 }),
            "onExtension" | "onextension" => Datum::Int(if spring.on_extension { 1 } else { 0 }),
            _ => return Err(ScriptError::new(format!("Unknown spring property: {}", prop))),
        };
        Ok(player.alloc_datum(result))
    }

    fn set_spring_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        spring_name: Symbol,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let spring = havok.state.springs.iter_mut()
            .find(|s| s.name == spring_name)
            .ok_or_else(|| ScriptError::new(format!("Spring '{}' not found", spring_name)))?;

        match prop {
            "pointA" | "pointa" => { if let Datum::Vector(v) = &value { spring.point_a = *v; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
            "pointB" | "pointb" => { if let Datum::Vector(v) = &value { spring.point_b = *v; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
            "restLength" | "restlength" => { spring.rest_length = value.to_float()?; }
            "elasticity" => { spring.elasticity = value.to_float()?; }
            "damping" => { spring.damping = value.to_float()?; }
            "onCompression" | "oncompression" => { spring.on_compression = value.int_value()? != 0; }
            "onExtension" | "onextension" => { spring.on_extension = value.int_value()? != 0; }
            _ => return Err(ScriptError::new(format!("Cannot set spring property: {}", prop))),
        }
        Ok(())
    }

    // --- LinearDashpot ---

    fn get_linear_dashpot_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        name: Symbol,
        prop: &str,
    ) -> Result<DatumRef, ScriptError> {
        let member = player.movie.cast_manager.find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let dp = havok.state.linear_dashpots.iter()
            .find(|d| d.name == name)
            .ok_or_else(|| ScriptError::new(format!("LinearDashpot '{}' not found", name)))?;

        let result = match prop {
            "name" => Datum::String(dp.name.to_string()),
            "pointA" | "pointa" => Datum::Vector(dp.point_a),
            "pointB" | "pointb" => Datum::Vector(dp.point_b),
            "strength" => Datum::Float(dp.strength),
            "damping" => Datum::Float(dp.damping),
            _ => return Err(ScriptError::new(format!("Unknown linearDashpot property: {}", prop))),
        };
        Ok(player.alloc_datum(result))
    }

    fn set_linear_dashpot_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        name: Symbol,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let dp = havok.state.linear_dashpots.iter_mut()
            .find(|d| d.name == name)
            .ok_or_else(|| ScriptError::new(format!("LinearDashpot '{}' not found", name)))?;

        match prop {
            "pointA" | "pointa" => { if let Datum::Vector(v) = &value { dp.point_a = *v; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
            "pointB" | "pointb" => { if let Datum::Vector(v) = &value { dp.point_b = *v; } else { return Err(ScriptError::new("Expected vector".to_string())); } }
            "strength" => { dp.strength = value.to_float()?; }
            "damping" => { dp.damping = value.to_float()?; }
            _ => return Err(ScriptError::new(format!("Cannot set linearDashpot property: {}", prop))),
        }
        Ok(())
    }

    // --- AngularDashpot ---

    fn get_angular_dashpot_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        name: Symbol,
        prop: &str,
    ) -> Result<DatumRef, ScriptError> {
        let member = player.movie.cast_manager.find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let dp = havok.state.angular_dashpots.iter()
            .find(|d| d.name == name)
            .ok_or_else(|| ScriptError::new(format!("AngularDashpot '{}' not found", name)))?;

        let result = match prop {
            "name" => Datum::String(dp.name.to_string()),
            "damping" => Datum::Float(dp.damping),
            "strength" => Datum::Float(dp.strength),
            "rotation" => {
                let axis = dp.rotation_axis;
                let angle = dp.rotation_angle;
                // Drop borrow before alloc
                let axis_ref = player.alloc_datum(Datum::Vector(axis));
                let angle_ref = player.alloc_datum(Datum::Float(angle));
                return Ok(player.alloc_datum(Datum::List(DatumType::List, VecDeque::from([axis_ref, angle_ref]), false)));
            }
            _ => return Err(ScriptError::new(format!("Unknown angularDashpot property: {}", prop))),
        };
        Ok(player.alloc_datum(result))
    }

    fn set_angular_dashpot_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        name: Symbol,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        // For rotation, extract list item values before borrowing member mutably
        if prop == "rotation" {
            let (axis, angle) = if let Datum::List(_, items, _) = &value {
                if items.len() >= 2 {
                    let axis = match player.get_datum(&items[0]) {
                        Datum::Vector(v) => *v,
                        _ => return Err(ScriptError::new("Expected vector for rotation axis".to_string())),
                    };
                    let angle = player.get_datum(&items[1]).to_float()?;
                    (Some(axis), Some(angle))
                } else {
                    (None, None)
                }
            } else {
                (None, None)
            };
            if let (Some(axis), Some(angle)) = (axis, angle) {
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                let dp = havok.state.angular_dashpots.iter_mut()
                    .find(|d| d.name == name)
                    .ok_or_else(|| ScriptError::new(format!("AngularDashpot '{}' not found", name)))?;
                dp.rotation_axis = axis;
                dp.rotation_angle = angle;
            }
            return Ok(());
        }

        let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let dp = havok.state.angular_dashpots.iter_mut()
            .find(|d| d.name == name)
            .ok_or_else(|| ScriptError::new(format!("AngularDashpot '{}' not found", name)))?;

        match prop {
            "damping" => { dp.damping = value.to_float()?; }
            "strength" => { dp.strength = value.to_float()?; }
            _ => return Err(ScriptError::new(format!("Cannot set angularDashpot property: {}", prop))),
        }
        Ok(())
    }

    // --- Corrector ---

    fn get_corrector_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        rb_name: Symbol,
        prop: &str,
    ) -> Result<DatumRef, ScriptError> {
        let member = player.movie.cast_manager.find_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let rb = havok.state.rigid_bodies.iter()
            .find(|r| r.name == rb_name)
            .ok_or_else(|| ScriptError::new(format!("Rigid body '{}' not found", rb_name)))?;
        let c = &rb.corrector;

        let result = match prop {
            "enabled" => Datum::Int(if c.enabled { 1 } else { 0 }),
            "threshold" => Datum::Float(c.threshold),
            "multiplier" => Datum::Float(c.multiplier),
            "level" => Datum::Int(c.level),
            "maxTries" | "maxtries" => Datum::Int(c.max_tries),
            "maxDistance" | "maxdistance" => Datum::Float(c.max_distance),
            _ => return Err(ScriptError::new(format!("Unknown corrector property: {}", prop))),
        };
        Ok(player.alloc_datum(result))
    }

    fn set_corrector_prop(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        rb_name: Symbol,
        prop: &str,
        value: Datum,
    ) -> Result<(), ScriptError> {
        let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
            .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
        let havok = match &mut member.member_type {
            CastMemberType::HavokPhysics(h) => h,
            _ => return Err(ScriptError::new("Not a Havok member".to_string())),
        };
        let rb = havok.state.rigid_bodies.iter_mut()
            .find(|r| r.name == rb_name)
            .ok_or_else(|| ScriptError::new(format!("Rigid body '{}' not found", rb_name)))?;
        let c = &mut rb.corrector;

        match prop {
            "enabled" => { c.enabled = value.int_value()? != 0; }
            "threshold" => { c.threshold = value.to_float()?; }
            "multiplier" => { c.multiplier = value.to_float()?; }
            "level" => { c.level = value.int_value()?; }
            "maxTries" | "maxtries" => { c.max_tries = value.int_value()?; }
            "maxDistance" | "maxdistance" => { c.max_distance = value.to_float()?; }
            _ => return Err(ScriptError::new(format!("Cannot set corrector property: {}", prop))),
        }
        Ok(())
    }

    // --- Shared constraint methods (spring, linearDashpot, angularDashpot) ---

    fn call_constraint(
        player: &mut crate::player::DirPlayer,
        member_ref: &CastMemberRef,
        object_type: BuiltInSymbol,
        name: Symbol,
        handler_name: &str,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        match handler_name {
            "setRigidBodyA" | "setrigidbodya" => {
                let rb_name = player.get_datum(&args[0]).string_value()?;
                let rb_sym = Symbol::from_str(&rb_name);
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                match object_type {
                    BuiltInSymbol::Spring => {
                        if let Some(s) = havok.state.springs.iter_mut().find(|s| s.name == name) {
                            s.rigid_body_a = Some(rb_sym);
                        }
                    }
                    BuiltInSymbol::LinearDashpot => {
                        if let Some(d) = havok.state.linear_dashpots.iter_mut().find(|d| d.name == name) {
                            d.rigid_body_a = Some(rb_sym);
                        }
                    }
                    BuiltInSymbol::AngularDashpot => {
                        if let Some(d) = havok.state.angular_dashpots.iter_mut().find(|d| d.name == name) {
                            d.rigid_body_a = Some(rb_sym);
                        }
                    }
                    _ => {}
                }
                Ok(DatumRef::Void)
            }
            "setRigidBodyB" | "setrigidbodyb" => {
                let rb_name_str = player.get_datum(&args[0]).string_value()?;
                let rb_val: Option<Symbol> = if Symbol::from_str(&rb_name_str) == BuiltInSymbol::None {
                    None
                } else {
                    Some(Symbol::from_str(&rb_name_str))
                };
                let member = player.movie.cast_manager.find_mut_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &mut member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                match object_type {
                    BuiltInSymbol::Spring => {
                        if let Some(s) = havok.state.springs.iter_mut().find(|s| s.name == name) {
                            s.rigid_body_b = rb_val;
                        }
                    }
                    BuiltInSymbol::LinearDashpot => {
                        if let Some(d) = havok.state.linear_dashpots.iter_mut().find(|d| d.name == name) {
                            d.rigid_body_b = rb_val;
                        }
                    }
                    BuiltInSymbol::AngularDashpot => {
                        if let Some(d) = havok.state.angular_dashpots.iter_mut().find(|d| d.name == name) {
                            d.rigid_body_b = rb_val;
                        }
                    }
                    _ => {}
                }
                Ok(DatumRef::Void)
            }
            "getRigidBodyA" | "getrigidbodya" => {
                let member = player.movie.cast_manager.find_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                let rb_name: Option<Symbol> = match object_type {
                    BuiltInSymbol::Spring => havok.state.springs.iter().find(|s| s.name == name).and_then(|s| s.rigid_body_a),
                    BuiltInSymbol::LinearDashpot => havok.state.linear_dashpots.iter().find(|d| d.name == name).and_then(|d| d.rigid_body_a),
                    BuiltInSymbol::AngularDashpot => havok.state.angular_dashpots.iter().find(|d| d.name == name).and_then(|d| d.rigid_body_a),
                    _ => None,
                };
                match rb_name {
                    Some(n) => Ok(player.alloc_datum(Datum::String(n.to_string()))),
                    None => Ok(player.alloc_datum(Datum::Symbol(BuiltInSymbol::None.into()))),
                }
            }
            "getRigidBodyB" | "getrigidbodyb" => {
                let member = player.movie.cast_manager.find_member_by_ref(member_ref)
                    .ok_or_else(|| ScriptError::new("Havok member not found".to_string()))?;
                let havok = match &member.member_type {
                    CastMemberType::HavokPhysics(h) => h,
                    _ => return Err(ScriptError::new("Not a Havok member".to_string())),
                };
                let rb_name: Option<Symbol> = match object_type {
                    BuiltInSymbol::Spring => havok.state.springs.iter().find(|s| s.name == name).and_then(|s| s.rigid_body_b),
                    BuiltInSymbol::LinearDashpot => havok.state.linear_dashpots.iter().find(|d| d.name == name).and_then(|d| d.rigid_body_b),
                    BuiltInSymbol::AngularDashpot => havok.state.angular_dashpots.iter().find(|d| d.name == name).and_then(|d| d.rigid_body_b),
                    _ => None,
                };
                match rb_name {
                    Some(n) => Ok(player.alloc_datum(Datum::String(n.to_string()))),
                    None => Ok(player.alloc_datum(Datum::Symbol(BuiltInSymbol::None.into()))),
                }
            }
            "getProp" => {
                let prop = player.get_datum(&args[0]).string_value()?;
                let result = match object_type {
                    BuiltInSymbol::Spring => Self::get_spring_prop(player, member_ref, name, &prop)?,
                    BuiltInSymbol::LinearDashpot => Self::get_linear_dashpot_prop(player, member_ref, name, &prop)?,
                    BuiltInSymbol::AngularDashpot => Self::get_angular_dashpot_prop(player, member_ref, name, &prop)?,
                    _ => return Err(ScriptError::new(format!("Unknown constraint type: {}", object_type))),
                };
                // Optional indexed-access form: obj.getProp(#prop, N) → Nth element.
                if args.len() >= 2 {
                    let index = player.get_datum(&args[1]).int_value()?;
                    let value = player.get_datum(&result).clone();
                    return match value {
                        Datum::Vector(arr) => {
                            let i = (index - 1) as usize;
                            if i < 3 {
                                Ok(player.alloc_datum(Datum::Float(arr[i])))
                            } else {
                                Err(ScriptError::new(format!(
                                    "Vector index {} out of range (1..3) for {}.{}", index, object_type, prop
                                )))
                            }
                        }
                        Datum::List(_, items, _) => {
                            let i = (index - 1) as usize;
                            items.get(i).cloned().ok_or_else(|| ScriptError::new(format!(
                                "List index {} out of range for {}.{}", index, object_type, prop
                            )))
                        }
                        _ => Ok(result),
                    };
                }
                Ok(result)
            }
            _ => Err(ScriptError::new(format!(
                "No handler {} for {} '{}'", handler_name, object_type, name
            ))),
        }
    }
}
