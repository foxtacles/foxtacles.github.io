use std::collections::VecDeque;

use log::warn;

use crate::{
    director::lingo::datum::{
        Datum, DatumType, StringChunkExpr, StringChunkSource, StringChunkType,
    },
    player::{DatumRef, DirPlayer, ScriptError, eval::try_eval_lingo_expr_static, reserve_player_mut, reserve_player_ref, symbols::{builtin::BuiltInSymbol, symbol::Symbol}},
};

use super::string_chunk::StringChunkUtils;

pub struct StringDatumHandlers {}
pub struct StringDatumUtils {}

impl StringDatumUtils {
    pub fn get_prop_ref(
        player: &DirPlayer,
        datum_ref: &DatumRef,
        prop_name: Symbol,
        start: i32,
        end: i32,
    ) -> Result<Datum, ScriptError> {
        let datum = player.get_datum(datum_ref);
        if let Datum::String(str_val) = datum {
            match prop_name.into_builtin() {
                Some(BuiltInSymbol::Item | BuiltInSymbol::Word | BuiltInSymbol::Char | BuiltInSymbol::Line) => {
                    let chunk_expr = StringChunkExpr {
                        chunk_type: StringChunkType::from(prop_name),
                        start,
                        end,
                        item_delimiter: player.movie.item_delimiter.to_owned(),
                    };
                    let resolved_str =
                        StringChunkUtils::resolve_chunk_expr_string(str_val, &chunk_expr)?;
                    Ok(Datum::StringChunk(
                        StringChunkSource::Datum(datum_ref.clone()),
                        chunk_expr,
                        resolved_str,
                    ))
                }
                _ => Err(ScriptError::new(format!(
                    "getPropRef: invalid prop_name {prop_name} for string"
                ))),
            }
        } else {
            return Err(ScriptError::new(format!(
                "getPropRef: datum is not a string"
            )));
        }
    }

    pub fn get_built_in_prop(value: &str, prop_name: Symbol) -> Result<Datum, ScriptError> {
        match prop_name.into_builtin() {
            Some(BuiltInSymbol::Length) => Ok(Datum::Int(value.chars().count() as i32)),
            Some(BuiltInSymbol::Ilk) => Ok(Datum::Symbol(Symbol::builtin(BuiltInSymbol::String))),
            // `.text` yields the textual content. For a plain string (and for
            // a resolved string chunk falling through here) it's the string
            // itself — same as `.string`. spectral-wizard's
            // getDefaultFixedLineSpace reads `member(..).char[1..1].ref.text`
            // to copy a character into a probe field.
            Some(BuiltInSymbol::String | BuiltInSymbol::Text) => Ok(Datum::String(value.to_owned())),
            Some(BuiltInSymbol::Value) => {
                // Normalise (strip comments + trim unbalanced brackets) before
                // parsing, then evaluate as a Lingo expression.
                let cleaned = normalise_lingo_expr_for_value(value);
                // Per the Director 11.5 Scripting Dictionary entry for
                // `value()`: "The result is the value of the initial portion of
                // the expression up to the first syntax error found in the
                // string." So a leading list literal wins even when the member
                // holds trailing prose. NabiscoWorld Mini Mini-Golf's Hole6Data
                // is a Scanframes-generated list followed by authoring notes
                // ("had to add, ... to remove startup glitch", "TEst case", and
                // a second sample list); parsing the whole thing failed, `.value`
                // fell back to the raw string, and `count(movie)` then raised
                // "Cannot get count of non-list (type: string)". The `value()`
                // FUNCTION path already did this — the property path did not.
                let cleaned = crate::player::handlers::types::truncate_to_first_balanced_list(&cleaned);
                match try_eval_lingo_expr_static(cleaned.clone()) {
                    Ok(datum_ref) => {
                        reserve_player_ref(|player| Ok(player.get_datum(&datum_ref).clone()))
                    }
                    Err(err) => {
                        if !crate::player::handlers::types::is_expected_value_retry_fragment(
                            value, &cleaned,
                        ) {
                            // `warn!` never reaches the browser console, so every
                            // `.value` parse failure was silent — the movie just gets
                            // its raw string back with no explanation.
                            crate::console_warn!(
                                "[VALPROBE] .value FAILED err={} cleaned={:?}",
                                err.message,
                                cleaned.chars().take(300).collect::<String>()
                            );
                        }
                        Ok(Datum::String(value.to_owned()))
                    }
                }
            }
            Some(BuiltInSymbol::CharToNum) => {
                let code = value.chars().next().map_or(0, |c| c as i32);
                Ok(Datum::Int(code))
            }
            Some(BuiltInSymbol::CharSpacing) => Ok(Datum::Int(0)),
            Some(BuiltInSymbol::Char) => {
                // String chunk type accessed as property — return the string itself
                // so subsequent indexing (e.g., .char[1]) can work via character indexing
                Ok(Datum::String(value.to_owned()))
            }
            Some(BuiltInSymbol::Marker) => {
                // Quirky director behavior:
                // Any string can run .marker on it to get the frame number of the marker, if it does not match a marker name, it returns 0
                reserve_player_ref(|player| {
                    let marker_name_lower = value.to_lowercase();
                    let frame_num = player
                        .movie
                        .score
                        .frame_labels
                        .iter()
                        .find(|label| label.label.to_lowercase() == marker_name_lower)
                        .map_or(0, |label| label.frame_num as i32);
                    Ok(Datum::Int(frame_num))
                })
            }
            // Director's `the number of <chunk> in <str>` form lands here as
            // a compound property name "number of lines/words/items/chars".
            // Returns the chunk count.
            Some(BuiltInSymbol::NumberOfChars | BuiltInSymbol::NumberOfCharacters) => {
                Ok(Datum::Int(value.chars().count() as i32))
            }
            Some(BuiltInSymbol::NumberOfLines) => {
                Ok(Datum::Int(string_get_lines(value).len() as i32))
            }
            Some(BuiltInSymbol::NumberOfWords) => {
                Ok(Datum::Int(string_get_words(value).len() as i32))
            }
            Some(BuiltInSymbol::NumberOfItems) => {
                let delim = reserve_player_ref(|player| Ok(player.movie.item_delimiter))?;
                Ok(Datum::Int(string_get_items(value, delim).len() as i32))
            }
            _ => Err(ScriptError::new(format!(
                "Invalid string built-in property {prop_name}"
            ))),
        }
    }
}

impl StringDatumHandlers {
    pub fn count(datum: &DatumRef, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let value = player.get_datum(datum).string_value()?;
            let operand = player.get_datum(&args[0]).string_value()?;
            let delimiter = player.movie.item_delimiter;
            let count = string_get_count(&value, &operand, delimiter)?;
            Ok(player.alloc_datum(Datum::Int(count as i32)))
        })
    }

    pub fn get_at(datum: &DatumRef, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let value = player.get_datum(datum).string_value()?;
            let index = player.get_datum(&args[0]).int_value()? as usize;
            // 1-based index
            let ch = value.chars().nth(index.wrapping_sub(1)).unwrap_or(' ');
            Ok(player.alloc_datum(Datum::String(ch.to_string())))
        })
    }

    pub fn duplicate(datum: &DatumRef, _args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let value = player.get_datum(datum).string_value()?;
            Ok(player.alloc_datum(Datum::String(value)))
        })
    }

    pub fn get_chunk_prop_ref(
        datum: &DatumRef,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let prop_name = player.get_datum(&args[0]).symbol_value()?;
            let start = player.get_datum(&args[1]).int_value()?;
            let end = if args.len() > 2 {
                player.get_datum(&args[2]).int_value()?
            } else {
                start
            };

            let prop_ref = StringDatumUtils::get_prop_ref(player, datum, prop_name, start, end)?;
            Ok(player.alloc_datum(prop_ref))
        })
    }

    pub fn get_chunk_prop(datum: &DatumRef, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let prop_name = player.get_datum(&args[0]).symbol_value()?;
            let start = player.get_datum(&args[1]).int_value()?;
            let end = if args.len() > 2 {
                player.get_datum(&args[2]).int_value()?
            } else {
                start
            };

            let str_value = StringDatumUtils::get_prop_ref(player, datum, prop_name, start, end)?
                .string_value()?;
            Ok(player.alloc_datum(Datum::String(str_value)))
        })
    }

    pub fn split(datum: &DatumRef, args: &Vec<DatumRef>) -> Result<DatumRef, ScriptError> {
        reserve_player_mut(|player| {
            let value = player.get_datum(datum).string_value()?;
            let delimiter = if args.is_empty() {
                "&".to_string() // TODO: verify the correct default delimiter
            } else {
                player.get_datum(&args[0]).string_value()?
            };

            let parts: VecDeque<DatumRef> = value
                .split(&delimiter)
                .map(|s| player.alloc_datum(Datum::String(s.to_string())))
                .collect();

            // Create the list datum properly
            Ok(player.alloc_datum(Datum::List(
                DatumType::String, // type of elements
                parts,
                false, // not sorted
            )))
        })
    }

    pub fn call(
        datum: &DatumRef,
        handler_name: Symbol,
        args: &Vec<DatumRef>,
    ) -> Result<DatumRef, ScriptError> {
        match handler_name.into_builtin() {
            Some(BuiltInSymbol::Count) => Self::count(datum, args),
            Some(BuiltInSymbol::GetAt) => Self::get_at(datum, args),
            Some(BuiltInSymbol::Duplicate) => Self::duplicate(datum, args),
            Some(BuiltInSymbol::GetPropRef) => Self::get_chunk_prop_ref(datum, args),
            Some(BuiltInSymbol::GetProp) => Self::get_chunk_prop(datum, args),
            Some(BuiltInSymbol::Split) => Self::split(datum, args),
            _ => Err(ScriptError::new(format!(
                "No handler {handler_name} for string datum"
            ))),
        }
    }
}

pub fn string_get_count(
    value: &str,
    operand: &str,
    delimiter: char,
) -> Result<u32, ScriptError> {
    match operand {
        "char" | "chars" => Ok(value.chars().count() as u32),
        "item" | "items" => Ok(string_get_items(value, delimiter).len() as u32),
        "word" | "words" => Ok(if value.len() > 0 {
            string_get_words(value).len() as u32
        } else {
            0
        }),
        "line" | "lines" => Ok(string_get_lines(value).len() as u32),
        _ => Err(ScriptError::new(format!(
            "Invalid operand {operand} for string_get_count"
        ))),
    }
}

pub fn string_get_items(value: &str, delimiter: char) -> Vec<String> {
    if delimiter == '\r' || delimiter == '\n' {
        string_get_lines(value)
    } else {
        value.split(delimiter).map(|s| s.to_string()).collect()
    }
}

pub fn is_director_whitespace(byte: char) -> bool {
    if byte.is_ascii_control() || byte.is_ascii_whitespace() || byte == 2 as char {
        return true;
    } else {
        return false;
    }
}

#[allow(dead_code)]
pub fn string_get_words(value: &str) -> Vec<String> {
    value
        .split(is_director_whitespace)
        .filter(|s| !s.is_empty())
        .map(|s| s.to_string())
        .collect()
}

/// Character-offset ranges `(start, end_exclusive)` of each word in `value`,
/// consistent with `string_get_words` (a word is a maximal run of
/// non-`is_director_whitespace` chars). Indices are CHAR indices. Used by
/// in-place word deletion, which must preserve the surrounding whitespace
/// Director leaves untouched (rejoining tokens with a single space loses it).
pub fn word_char_ranges(value: &str) -> Vec<(usize, usize)> {
    let mut ranges = Vec::new();
    let mut start: Option<usize> = None;
    let mut count = 0usize;
    for (i, c) in value.chars().enumerate() {
        if is_director_whitespace(c) {
            if let Some(st) = start.take() {
                ranges.push((st, i));
            }
        } else if start.is_none() {
            start = Some(i);
        }
        count = i + 1;
    }
    if let Some(st) = start {
        ranges.push((st, count));
    }
    ranges
}

pub fn string_get_lines(value: &str) -> Vec<String> {
    // In Director, the number of lines in "" returns 0
    if value.is_empty() {
        return Vec::new();
    }
    let line_break = if value.contains("\r\n") {
        "\r\n"
    } else if value.contains("\n") {
        "\n"
    } else {
        "\r"
    };
    value.split(line_break).map(|s| s.to_string()).collect()
}

/// Trim an expression string so all brackets/parens are matched.
/// Handles both trailing unbalanced closers (stale `]`/`)`) AND trailing
/// unclosed openers — the latter happens when Coke Studios' ElementManager
/// splits elements XML at every `]` and feeds partial prop-list fragments
/// like `[#member: "x", #fontStyle: [#bold]` to value(); the Lingo relies
/// on a Void-on-failure retry, but we want the fragment to be normalised
/// so pest doesn't shout on every attempt.
fn trim_unbalanced_brackets(input: &str) -> String {
    let mut depth_square: i32 = 0;
    let mut depth_paren: i32 = 0;
    let mut in_string = false;
    // Track the last index where both depths were zero — i.e. a fully
    // balanced prefix. We'll truncate to that point if the input never
    // returns to balance by the end.
    let mut last_fully_balanced_end = 0;

    for (i, ch) in input.char_indices() {
        if in_string {
            if ch == '"' { in_string = false; }
        } else {
            match ch {
                '"' => in_string = true,
                '[' => depth_square += 1,
                ']' => depth_square -= 1,
                '(' => depth_paren += 1,
                ')' => depth_paren -= 1,
                _ => {}
            }
        }
        let end = i + ch.len_utf8();
        if depth_square == 0 && depth_paren == 0 && !in_string {
            last_fully_balanced_end = end;
        }
    }

    // If the whole string is balanced, keep it. Otherwise truncate back
    // to the last known balanced point (may be empty if input never
    // balanced, in which case pest will error and the caller returns Void).
    let end = if depth_square == 0 && depth_paren == 0 && !in_string {
        input.len()
    } else {
        last_fully_balanced_end
    };
    input[..end].trim().to_string()
}

/// Public wrapper for the `.value` / `value()` input normalisation — runs
/// `strip_lingo_comments` then `trim_unbalanced_brackets`. Both the
/// property-form and function-form `value` should use this so partial /
/// unbalanced inputs (from Lingo code that intentionally feeds fragments
/// until one parses) don't dump a pest parse error to the console.
pub fn normalise_lingo_expr_for_value(input: &str) -> String {
    let cleaned = strip_lingo_comments(input);
    let cleaned = strip_line_continuations(&cleaned);
    trim_unbalanced_brackets(cleaned.trim())
}

/// Drop Lingo's `\` line-continuation markers (outside quoted strings) before
/// the expression reaches the grammar.
///
/// A literal stored in a text member is normally authored across several lines
/// with `\` continuations. Scripts that parse such a member usually strip the
/// RETURNs first, which welds each `\` onto its neighbours — NabiscoWorld Mini
/// Mini-Golf's `castlist` member is
///
///   [\<CR>#script,#script,...,#bitmap\<CR>]
///
/// and `objTextData.init` does `StringEliminateChars(text, RETURN)` then
/// `.value`, so the grammar was handed `[\#script,...,#bitmap\]` and failed at
/// column 2. `.value` reports a parse failure by returning the raw string, so
/// the movie silently got a string where it expected a 1018-element list.
///
/// Backslashes inside quoted strings are preserved — Director strings hold
/// Windows paths like "C:\dir\file".
fn strip_line_continuations(input: &str) -> String {
    let mut result = String::with_capacity(input.len());
    let mut in_string = false;
    let mut chars = input.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '"' {
            in_string = !in_string;
            result.push(ch);
        } else if ch == '\\' && !in_string {
            // The continuation eats an immediately following newline too, so a
            // not-yet-stripped `\<CR>` doesn't leave a stray line break behind.
            if matches!(chars.peek(), Some('\r') | Some('\n')) {
                chars.next();
            }
        } else {
            result.push(ch);
        }
    }
    result
}

/// Strip Lingo `--` comments from a string, respecting quoted strings.
fn strip_lingo_comments(input: &str) -> String {
    let mut result = String::with_capacity(input.len());
    let mut in_string = false;
    let mut chars = input.chars().peekable();
    while let Some(ch) = chars.next() {
        if in_string {
            result.push(ch);
            if ch == '"' {
                in_string = false;
            }
        } else if ch == '"' {
            result.push(ch);
            in_string = true;
        } else if ch == '-' {
            if chars.peek() == Some(&'-') {
                // Comment: skip rest of line
                for c in chars.by_ref() {
                    if c == '\n' || c == '\r' {
                        result.push(c);
                        break;
                    }
                }
            } else {
                result.push(ch);
            }
        } else {
            result.push(ch);
        }
    }
    result
}
