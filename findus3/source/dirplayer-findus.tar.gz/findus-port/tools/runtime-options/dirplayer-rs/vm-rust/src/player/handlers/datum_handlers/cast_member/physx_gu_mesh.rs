//! Triangle-mesh container + midphase + per-tri narrowphase.
//!
//! Sources cited in the C# files (PhysX 3.4):
//!   GeomUtils\src\mesh\GuMeshData.h, GuMidphaseInterface.h, GuMidphaseRTree.cpp
//!   GeomUtils\src\distance\GuDistancePointTriangle.cpp:37-111
//!   GeomUtils\src\contact\GuContactSphereMesh.cpp:288-355
//!   GeomUtils\src\distance\GuDistanceSegmentTriangle.cpp
//!
//! All inputs/outputs are in mesh-LOCAL space. The Lingo dispatch in
//! `physx_native.rs` transforms shape positions into mesh-local before invoking
//! the contact driver here.

use super::physx_gu_rtree::{LeafTriangles, RTree, RTreeAabbCallback, RTreeBuilder, RTreeRaycastCallback};

/// Source: GuTriangleMesh.h:42-110 (subset). Wraps vertex+index+RTree.
#[derive(Debug, Clone, Default)]
pub struct GuTriangleMesh {
    pub vertices: Vec<[f32; 3]>,
    /// 3 indices per triangle.
    pub triangles: Vec<u32>,
    pub tree: RTree,
    /// Local-space AABB.
    pub aabb_min: [f32; 3],
    pub aabb_max: [f32; 3],
    /// Per-triangle internal-edge mask, bit k set when edge k (vertex k → k+1)
    /// is shared with a COPLANAR neighbour. PhysX cooks the same adjacency
    /// (`PxTriangleMeshFlag`/edge flags) and uses it to suppress edge contacts:
    /// a shared coplanar edge is not a real crease, so it must never supply a
    /// contact normal. See `box_vs_triangle`.
    pub internal_edges: Vec<u8>,
}

impl GuTriangleMesh {
    pub fn nb_triangles(&self) -> usize { self.triangles.len() / 3 }

    pub fn get_triangle(&self, tri_index: u32) -> ([f32; 3], [f32; 3], [f32; 3]) {
        let i = tri_index as usize * 3;
        (
            self.vertices[self.triangles[i    ] as usize],
            self.vertices[self.triangles[i + 1] as usize],
            self.vertices[self.triangles[i + 2] as usize],
        )
    }

    pub fn build(vertices: Vec<[f32; 3]>, triangles: Vec<u32>) -> Self {
        let tree = RTreeBuilder::build(&triangles, &vertices);
        let internal_edges = Self::cook_internal_edges(&vertices, &triangles);
        let mut mesh = Self {
            vertices, triangles, tree,
            aabb_min: [0.0; 3], aabb_max: [0.0; 3],
            internal_edges,
        };
        if mesh.vertices.is_empty() {
            return mesh;
        }
        let mut mn = mesh.vertices[0];
        let mut mx = mesh.vertices[0];
        for v in mesh.vertices.iter().skip(1) {
            if v[0] < mn[0] { mn[0] = v[0]; } if v[0] > mx[0] { mx[0] = v[0]; }
            if v[1] < mn[1] { mn[1] = v[1]; } if v[1] > mx[1] { mx[1] = v[1]; }
            if v[2] < mn[2] { mn[2] = v[2]; } if v[2] > mx[2] { mx[2] = v[2]; }
        }
        mesh.aabb_min = mn; mesh.aabb_max = mx;
        mesh
    }

    /// Find, per triangle, which of its three edges are shared with a coplanar
    /// neighbour. Vertices are welded by quantised POSITION rather than index:
    /// the cooked mesh concatenates submeshes with rebased indices, so the two
    /// halves of one authored quad can reference different vertex records for
    /// the same corner.
    fn cook_internal_edges(vertices: &[[f32; 3]], triangles: &[u32]) -> Vec<u8> {
        use std::collections::HashMap;
        let tri_count = triangles.len() / 3;
        let mut flags = vec![0u8; tri_count];
        if tri_count < 2 {
            return flags;
        }
        // 0.01 world units. Authored features are orders of magnitude coarser
        // than this, and f32 at track scale (~1e4) still resolves ~5e-4.
        const WELD: f32 = 0.01;
        let mut weld: HashMap<(i64, i64, i64), u32> = HashMap::new();
        let mut welded: Vec<u32> = Vec::with_capacity(vertices.len());
        for v in vertices {
            let key = (
                (v[0] / WELD).round() as i64,
                (v[1] / WELD).round() as i64,
                (v[2] / WELD).round() as i64,
            );
            let next = weld.len() as u32;
            welded.push(*weld.entry(key).or_insert(next));
        }

        // Triangle normals (unnormalised length carries the degeneracy test).
        let mut normals: Vec<Option<[f32; 3]>> = Vec::with_capacity(tri_count);
        for t in 0..tri_count {
            let (a, b, c) = (
                vertices[triangles[t * 3] as usize],
                vertices[triangles[t * 3 + 1] as usize],
                vertices[triangles[t * 3 + 2] as usize],
            );
            let n = cross(sub(b, a), sub(c, a));
            normals.push(if dot(n, n) > 1e-12 { Some(normalize(n)) } else { None });
        }

        // Edge → the (triangle, edge index) pairs that use it.
        let mut edges: HashMap<(u32, u32), Vec<(usize, usize)>> = HashMap::new();
        for t in 0..tri_count {
            for e in 0..3 {
                let i0 = welded[triangles[t * 3 + e] as usize];
                let i1 = welded[triangles[t * 3 + (e + 1) % 3] as usize];
                if i0 == i1 { continue; }
                let key = if i0 < i1 { (i0, i1) } else { (i1, i0) };
                edges.entry(key).or_default().push((t, e));
            }
        }

        // cos(2.5°) — two triangles this close to parallel share a flat surface,
        // not a crease. |dot| so a coplanar pair with opposite winding (a
        // zero-thickness double-sided wall) counts too.
        const COPLANAR: f32 = 0.999;
        for users in edges.values() {
            if users.len() < 2 { continue; }
            for i in 0..users.len() {
                for j in (i + 1)..users.len() {
                    let (ti, ei) = users[i];
                    let (tj, ej) = users[j];
                    let (Some(ni), Some(nj)) = (normals[ti], normals[tj]) else { continue };
                    if dot(ni, nj).abs() >= COPLANAR {
                        flags[ti] |= 1 << ei;
                        flags[tj] |= 1 << ej;
                    }
                }
            }
        }
        flags
    }
}

/// Source: GuMidphaseInterface.h:58-73 — `MeshHitCallback`.
pub trait MeshHitCallback {
    /// Returns true to continue traversal, false to abort.
    fn process(&mut self, tri_index: u32, v0: [f32; 3], v1: [f32; 3], v2: [f32; 3]) -> bool;
}

/// Source: GuMidphaseRTree.cpp pattern. AABB-overlap query.
pub fn midphase_intersect_aabb<C: MeshHitCallback + ?Sized>(
    mesh: &GuTriangleMesh,
    box_min: [f32; 3],
    box_max: [f32; 3],
    cb: &mut C,
) {
    if mesh.nb_triangles() == 0 { return; }
    let mut adapter = MidphaseAabbAdapter { mesh, cb, aborted: false };
    mesh.tree.traverse_aabb(box_min, box_max, &mut adapter);
}

struct MidphaseAabbAdapter<'a, C: MeshHitCallback + ?Sized> {
    mesh: &'a GuTriangleMesh,
    cb: &'a mut C,
    aborted: bool,
}

impl<'a, C: MeshHitCallback + ?Sized> RTreeAabbCallback for MidphaseAabbAdapter<'a, C> {
    fn process(&mut self, leaf_encoded: u32) -> bool {
        let lf = LeafTriangles { data: leaf_encoded | 1 };
        let first = lf.triangle_index();
        for k in 0..lf.nb_triangles() {
            let orig_tri = self.mesh.tree.tri_indices[(first + k) as usize];
            let (v0, v1, v2) = self.mesh.get_triangle(orig_tri);
            if !self.cb.process(orig_tri, v0, v1, v2) {
                self.aborted = true;
                return false;
            }
        }
        true
    }
}

// =============================================================================
//  Per-triangle contact gen
// =============================================================================

/// One contact between a query shape and a triangle. All in mesh-local space.
#[derive(Debug, Clone, Copy, Default)]
pub struct GuTriContact {
    pub point: [f32; 3],
    /// triangle → query shape (unit length).
    pub normal: [f32; 3],
    /// PhysX convention: < 0 ⇒ penetrating.
    pub separation: f32,
    pub triangle_index: u32,
}

#[inline] fn dot(a: [f32; 3], b: [f32; 3]) -> f32 { a[0]*b[0] + a[1]*b[1] + a[2]*b[2] }
#[inline] fn cross(a: [f32; 3], b: [f32; 3]) -> [f32; 3] {
    [a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0]]
}
#[inline] fn sub(a: [f32; 3], b: [f32; 3]) -> [f32; 3] { [a[0]-b[0], a[1]-b[1], a[2]-b[2]] }
#[inline] fn add(a: [f32; 3], b: [f32; 3]) -> [f32; 3] { [a[0]+b[0], a[1]+b[1], a[2]+b[2]] }
#[inline] fn scale(v: [f32; 3], s: f32) -> [f32; 3] { [v[0]*s, v[1]*s, v[2]*s] }
#[inline] fn neg(v: [f32; 3]) -> [f32; 3] { [-v[0], -v[1], -v[2]] }
#[inline] fn normalize(v: [f32; 3]) -> [f32; 3] {
    let l = dot(v, v).sqrt();
    if l < 1e-12 { [0.0; 3] } else { [v[0]/l, v[1]/l, v[2]/l] }
}

/// Source: GuDistancePointTriangle.cpp:37-111 — Ericson's closest-pt-on-tri.
pub fn closest_pt_point_triangle(
    p: [f32; 3], a: [f32; 3], b: [f32; 3], c: [f32; 3],
) -> [f32; 3] {
    let ab = sub(b, a);
    let ac = sub(c, a);
    let ap = sub(p, a);
    let d1 = dot(ab, ap);
    let d2 = dot(ac, ap);
    if d1 <= 0.0 && d2 <= 0.0 { return a; }

    let bp = sub(p, b);
    let d3 = dot(ab, bp);
    let d4 = dot(ac, bp);
    if d3 >= 0.0 && d4 <= d3 { return b; }

    let vc = d1 * d4 - d3 * d2;
    if vc <= 0.0 && d1 >= 0.0 && d3 <= 0.0 {
        let v = d1 / (d1 - d3);
        return add(a, scale(ab, v));
    }

    let cp = sub(p, c);
    let d5 = dot(ab, cp);
    let d6 = dot(ac, cp);
    if d6 >= 0.0 && d5 <= d6 { return c; }

    let vb = d5 * d2 - d1 * d6;
    if vb <= 0.0 && d2 >= 0.0 && d6 <= 0.0 {
        let w = d2 / (d2 - d6);
        return add(a, scale(ac, w));
    }

    let va = d3 * d6 - d5 * d4;
    if va <= 0.0 && (d4 - d3) >= 0.0 && (d5 - d6) >= 0.0 {
        let w = (d4 - d3) / ((d4 - d3) + (d5 - d6));
        return add(b, scale(sub(c, b), w));
    }

    let denom = 1.0 / (va + vb + vc);
    let vv = vb * denom;
    let ww = vc * denom;
    add(add(a, scale(ab, vv)), scale(ac, ww))
}

/// Source: GuContactSphereMesh.cpp:288-355 — sphere-vs-triangle.
pub fn sphere_vs_triangle(
    sphere_center: [f32; 3], sphere_radius: f32, contact_dist: f32,
    v0: [f32; 3], v1: [f32; 3], v2: [f32; 3], tri_index: u32,
) -> Option<GuTriContact> {
    let inflated = sphere_radius + contact_dist;
    let inflated2 = inflated * inflated;
    let cp = closest_pt_point_triangle(sphere_center, v0, v1, v2);
    let d = sub(cp, sphere_center);
    let sq_dist = dot(d, d);
    if sq_dist >= inflated2 { return None; }

    let e0 = sub(v1, v0);
    let e1 = sub(v2, v0);
    let plane_normal = cross(e0, e1);
    let plane_d = dot(plane_normal, v0);
    if dot(plane_normal, sphere_center) < plane_d { return None; }

    const K_EPS: f32 = 1e-12;
    let (dir, dist) = if sq_dist > K_EPS {
        let dist = sq_dist.sqrt();
        ([d[0]/dist, d[1]/dist, d[2]/dist], dist)
    } else {
        (neg(normalize(plane_normal)), 0.0)
    };
    Some(GuTriContact {
        normal: neg(dir),
        point: [
            sphere_center[0] + sphere_radius * dir[0],
            sphere_center[1] + sphere_radius * dir[1],
            sphere_center[2] + sphere_radius * dir[2],
        ],
        separation: dist - sphere_radius,
        triangle_index: tri_index,
    })
}

/// Source: Ericson §5.1.9 — segment-vs-segment closest pair.
fn closest_pt_segment_segment(
    p1: [f32; 3], q1: [f32; 3], p2: [f32; 3], q2: [f32; 3],
) -> ([f32; 3], [f32; 3], f32) {
    const K_EPS: f32 = 1e-10;
    let d1 = sub(q1, p1);
    let d2 = sub(q2, p2);
    let r  = sub(p1, p2);
    let a = dot(d1, d1);
    let e = dot(d2, d2);
    let f = dot(d2, r);

    if a <= K_EPS && e <= K_EPS {
        let dd = sub(p1, p2);
        return (p1, p2, dot(dd, dd));
    }

    let (s, t);
    if a <= K_EPS {
        s = 0.0;
        t = (f / e).clamp(0.0, 1.0);
    } else {
        let cdot = dot(d1, r);
        if e <= K_EPS {
            t = 0.0;
            s = (-cdot / a).clamp(0.0, 1.0);
        } else {
            let bdot = dot(d1, d2);
            let denom = a * e - bdot * bdot;
            let mut s_calc = if denom != 0.0 { ((bdot * f - cdot * e) / denom).clamp(0.0, 1.0) } else { 0.0 };
            let mut t_calc = (bdot * s_calc + f) / e;
            if t_calc < 0.0 {
                t_calc = 0.0;
                s_calc = (-cdot / a).clamp(0.0, 1.0);
            } else if t_calc > 1.0 {
                t_calc = 1.0;
                s_calc = ((bdot - cdot) / a).clamp(0.0, 1.0);
            }
            s = s_calc; t = t_calc;
        }
    }
    let c1 = add(p1, scale(d1, s));
    let c2 = add(p2, scale(d2, t));
    let dd = sub(c1, c2);
    (c1, c2, dot(dd, dd))
}

/// Source: GuDistanceSegmentTriangle.cpp pattern. Closest pair between a
/// segment and a triangle. Returns (segPt, triPt, sqDist).
pub fn closest_pt_segment_triangle(
    p: [f32; 3], q: [f32; 3],
    a: [f32; 3], b: [f32; 3], c: [f32; 3],
) -> ([f32; 3], [f32; 3], f32) {
    let mut best_sq = f32::MAX;
    let mut seg_pt = p;
    let mut tri_pt = a;

    let trial = closest_pt_point_triangle(p, a, b, c);
    let dd = sub(p, trial); let sq = dot(dd, dd);
    if sq < best_sq { best_sq = sq; seg_pt = p; tri_pt = trial; }

    let trial = closest_pt_point_triangle(q, a, b, c);
    let dd = sub(q, trial); let sq = dot(dd, dd);
    if sq < best_sq { best_sq = sq; seg_pt = q; tri_pt = trial; }

    for &(ea, eb) in &[(a, b), (b, c), (c, a)] {
        let (sp, tp, sq3) = closest_pt_segment_segment(p, q, ea, eb);
        if sq3 < best_sq { best_sq = sq3; seg_pt = sp; tri_pt = tp; }
    }

    // Segment-vs-face: penetrating intersection ⇒ sqDist = 0.
    let pq = sub(q, p);
    let ab = sub(b, a);
    let ac = sub(c, a);
    let n = cross(ab, ac);
    let denom = dot(n, pq);
    if denom.abs() > 1e-12 {
        let u = dot(n, sub(a, p)) / denom;
        if (0.0..=1.0).contains(&u) {
            let hit = add(p, scale(pq, u));
            // Inside-tri barycentric test.
            let pmv0 = sub(hit, a);
            let dot00 = dot(ac, ac);
            let dot01 = dot(ac, ab);
            let dot02 = dot(ac, pmv0);
            let dot11 = dot(ab, ab);
            let dot12 = dot(ab, pmv0);
            let inv_denom = 1.0 / (dot00 * dot11 - dot01 * dot01);
            let uu = (dot11 * dot02 - dot01 * dot12) * inv_denom;
            let vv = (dot00 * dot12 - dot01 * dot02) * inv_denom;
            if uu >= 0.0 && vv >= 0.0 && uu + vv <= 1.0 {
                best_sq = 0.0;
                seg_pt = hit;
                tri_pt = hit;
            }
        }
    }
    (seg_pt, tri_pt, best_sq)
}

pub fn capsule_vs_triangle(
    p0: [f32; 3], p1: [f32; 3], radius: f32, contact_dist: f32,
    v0: [f32; 3], v1: [f32; 3], v2: [f32; 3], tri_index: u32,
) -> Option<GuTriContact> {
    let (seg_pt, tri_pt, sq_dist) = closest_pt_segment_triangle(p0, p1, v0, v1, v2);
    let inflated = radius + contact_dist;
    if sq_dist >= inflated * inflated { return None; }

    let e0 = sub(v1, v0);
    let e1 = sub(v2, v0);
    let plane_normal = cross(e0, e1);
    let plane_d = dot(plane_normal, v0);
    if dot(plane_normal, seg_pt) < plane_d { return None; }

    const K_EPS: f32 = 1e-12;
    let d = sub(tri_pt, seg_pt);
    let (dir, dist) = if sq_dist > K_EPS {
        let dist = sq_dist.sqrt();
        ([d[0]/dist, d[1]/dist, d[2]/dist], dist)
    } else {
        (neg(normalize(plane_normal)), 0.0)
    };
    Some(GuTriContact {
        normal: neg(dir),
        point: [
            seg_pt[0] + radius * dir[0],
            seg_pt[1] + radius * dir[1],
            seg_pt[2] + radius * dir[2],
        ],
        separation: dist - radius,
        triangle_index: tri_index,
    })
}

/// Source: GuPCMTriangleContactGen.cpp::SATSweep pattern (reduced — single
/// contact per (axis, triangle)). The dispatcher accumulates contacts across
/// all triangles for a multi-point manifold per body pair.
/// `internal_edges` is the cooked mask from `GuTriangleMesh::internal_edges`
/// (bit k = edge k is shared with a coplanar neighbour). Edge-cross axes for
/// those edges are NOT candidates: the edge is interior to a flat surface, so
/// the minimising axis it produces is a lateral direction that does not exist
/// on the real surface. Pass 0 for geometry with no adjacency information.
pub fn box_vs_triangle(
    box_center: [f32; 3], box_half_extents: [f32; 3],
    box_axis_x: [f32; 3], box_axis_y: [f32; 3], box_axis_z: [f32; 3],
    contact_dist: f32,
    v0: [f32; 3], v1: [f32; 3], v2: [f32; 3], tri_index: u32,
    internal_edges: u8,
) -> Option<GuTriContact> {
    let mut best_overlap = f32::MAX;
    let mut best_axis = [0.0f32; 3];
    let mut best_sign = 1.0f32;

    if !test_axis(box_axis_x, box_center, box_half_extents,
                  box_axis_x, box_axis_y, box_axis_z, v0, v1, v2,
                  &mut best_overlap, &mut best_axis, &mut best_sign, contact_dist) {
        return None;
    }
    if !test_axis(box_axis_y, box_center, box_half_extents,
                  box_axis_x, box_axis_y, box_axis_z, v0, v1, v2,
                  &mut best_overlap, &mut best_axis, &mut best_sign, contact_dist) {
        return None;
    }
    if !test_axis(box_axis_z, box_center, box_half_extents,
                  box_axis_x, box_axis_y, box_axis_z, v0, v1, v2,
                  &mut best_overlap, &mut best_axis, &mut best_sign, contact_dist) {
        return None;
    }

    let tri_e0 = sub(v1, v0);
    let tri_e1 = sub(v2, v0);
    let tri_normal_raw = cross(tri_e0, tri_e1);
    let tri_normal = if dot(tri_normal_raw, tri_normal_raw) > 1e-12 {
        let n = normalize(tri_normal_raw);
        if !test_axis(n, box_center, box_half_extents,
                      box_axis_x, box_axis_y, box_axis_z, v0, v1, v2,
                      &mut best_overlap, &mut best_axis, &mut best_sign, contact_dist) {
            return None;
        }
        n
    } else {
        [0.0; 3]
    };

    let tri_edges = [sub(v1, v0), sub(v2, v1), sub(v0, v2)];
    let box_edges = [box_axis_x, box_axis_y, box_axis_z];
    for be in box_edges.iter() {
        for (ei, te) in tri_edges.iter().enumerate() {
            // Interior edge of a flat surface: no crease here, so it must not
            // win the minimum-overlap axis. A box resting on a large tile has a
            // tiny face-normal overlap, so without this ANY edge axis from the
            // tile's internal split undercuts it and the contact normal comes
            // out horizontal — Agent Free Ride 2 spawns its jet ski at x ≈ 0,
            // exactly on `l_t_d3_4`'s split, and the spurious sideways impulse
            // launched it off the start line.
            if internal_edges & (1 << ei) != 0 { continue; }
            let axis = cross(*be, *te);
            let ax2 = dot(axis, axis);
            if ax2 < 1e-8 { continue; }
            let axis = normalize(axis);
            if !test_axis(axis, box_center, box_half_extents,
                          box_axis_x, box_axis_y, box_axis_z, v0, v1, v2,
                          &mut best_overlap, &mut best_axis, &mut best_sign, contact_dist) {
                return None;
            }
        }
    }

    let n = scale(best_axis, best_sign);
    // Back-face rejection, measured against the BOX rather than its centre.
    //
    // This exists so a body genuinely underneath one-sided terrain isn't
    // yanked up through it. Testing the centre alone made it fire as soon as
    // the centre dipped a hair below the triangle plane, even though the box
    // still straddled the surface — so a resting body lost every contact the
    // moment it settled and then free-fell with the mesh right there.
    //
    // Measured on Agent Free Ride: a chassis 61 units deep sliding down
    // `l_t_d1_1` had contacts at centre +1.6 above the plane and NONE at -1.6
    // below, after which its downward velocity ran away (-563 → -1036 → …).
    // The allowance is the box's extent along the triangle normal, so the
    // contact survives while any part of the box is still in front of the
    // plane, and rejection only kicks in once the whole box is behind it.
    let box_reach_along_n = box_half_extents[0] * dot(box_axis_x, tri_normal).abs()
        + box_half_extents[1] * dot(box_axis_y, tri_normal).abs()
        + box_half_extents[2] * dot(box_axis_z, tri_normal).abs();
    if dot(tri_normal, box_center)
        < dot(tri_normal, v0) - box_reach_along_n - contact_dist
    {
        return None;
    }
    // Single-sidedness, decided on the CONTACT NORMAL rather than the box's
    // extent. A mesh triangle only pushes along its own front face, so a normal
    // opposing it means the box is behind the surface and there is nothing to
    // push against. The extent allowance above keeps a RESTING body's contacts
    // alive (its normal still points out of the face, so it passes here), but on
    // its own it also made every one-sided wall solid from behind: as soon as any
    // part of the box crossed the plane it got a contact pointing back the way it
    // came, so it could never pass through.
    //
    // Agent Free Ride 2's canal has `x_collision_101`, a 2-triangle plane whose
    // faces both point +y, sealing the dead-end behind the start line. The racing
    // line (token t4) runs +y straight through where it sits, and the jet ski
    // wedged 0.4 units short of it — an invisible wall across the track.
    // Only a normal that CLEARLY opposes the face is rejected (more than 120°
    // away from it). Perpendicular normals must be kept: when a box sinks deep
    // into a floor the face-normal overlap grows with the penetration, so the
    // minimum-overlap axis flips to a lateral one — rejecting those took away a
    // sunk body's last support and it kept creeping down (AreaZero sank slowly
    // through the floor). Opposing is unambiguous: the wall case above is -1.
    if dot(tri_normal, tri_normal) > 0.0 && dot(n, tri_normal) < -0.5 {
        return None;
    }
    let sx = if dot(box_axis_x, n) >= 0.0 { -box_half_extents[0] } else { box_half_extents[0] };
    let sy = if dot(box_axis_y, n) >= 0.0 { -box_half_extents[1] } else { box_half_extents[1] };
    let sz = if dot(box_axis_z, n) >= 0.0 { -box_half_extents[2] } else { box_half_extents[2] };
    let deepest = [
        box_center[0] + box_axis_x[0] * sx + box_axis_y[0] * sy + box_axis_z[0] * sz,
        box_center[1] + box_axis_x[1] * sx + box_axis_y[1] * sy + box_axis_z[1] * sz,
        box_center[2] + box_axis_x[2] * sx + box_axis_y[2] * sy + box_axis_z[2] * sz,
    ];
    Some(GuTriContact {
        normal: n,
        point: deepest,
        separation: -best_overlap,
        triangle_index: tri_index,
    })
}

/// Box-vs-triangle producing a MANIFOLD rather than a single point.
///
/// `box_vs_triangle` returns only the deepest vertex. One point at a long lever
/// arm from the centre of mass is not enough to hold a box up: the effective
/// mass along the normal is `1 / (invM + (ra×n)·I⁻¹·(ra×n))`, and for Agent
/// Free Ride's chassis (half extents 138×181×61, invMass 0.01) the angular term
/// is ~0.043 against invMass 0.01 — so `eff_mass` collapses from ≈100 to ≈19 and
/// the contact returns about a fifth of the impulse needed to cancel gravity.
/// Measured: gravity added −28.5/step while the solver gave back only +6.7, so
/// the vehicle sank a little every step until it fell through entirely.
///
/// PhysX generates a patch (`PxcGenerateContacts` / GuContactBoxMesh) for this
/// case. When the contact normal IS the triangle normal — the resting case —
/// clip the box's incident face against the triangle and emit one contact per
/// corner that lies over it. The corners straddle the centre of mass, so their
/// rotational contributions cancel and the normal impulse recovers.
///
/// Falls back to the single deepest point for edge/corner contacts, where a
/// face patch is not meaningful.
pub fn box_vs_triangle_manifold(
    box_center: [f32; 3], box_half_extents: [f32; 3],
    box_axis_x: [f32; 3], box_axis_y: [f32; 3], box_axis_z: [f32; 3],
    contact_dist: f32,
    v0: [f32; 3], v1: [f32; 3], v2: [f32; 3], tri_index: u32,
    internal_edges: u8,
    out: &mut Vec<GuTriContact>,
) {
    let Some(single) = box_vs_triangle(
        box_center, box_half_extents, box_axis_x, box_axis_y, box_axis_z,
        contact_dist, v0, v1, v2, tri_index, internal_edges,
    ) else { return; };

    let raw_n = cross(sub(v1, v0), sub(v2, v0));
    if dot(raw_n, raw_n) <= 1e-12 {
        out.push(single);
        return;
    }
    // Triangle normal oriented the same way as the contact normal (mesh → box).
    let tri_n = normalize(raw_n);
    let tri_n = if dot(tri_n, single.normal) < 0.0 { scale(tri_n, -1.0) } else { tri_n };

    // Only build a patch for a face-on contact; otherwise the deepest point is
    // the right answer (cos 20° ≈ 0.94).
    if dot(tri_n, single.normal) < 0.94 {
        out.push(single);
        return;
    }

    // The box face pressing into the triangle: the axis most aligned with the
    // normal, stepped to the side facing the triangle.
    let axes = [box_axis_x, box_axis_y, box_axis_z];
    let mut fi = 0usize;
    let mut best = -1.0f32;
    for i in 0..3 {
        let d = dot(axes[i], tri_n).abs();
        if d > best { best = d; fi = i; }
    }
    let step = if dot(axes[fi], tri_n) > 0.0 { -box_half_extents[fi] } else { box_half_extents[fi] };
    let face_c = add(box_center, scale(axes[fi], step));
    let (i1, i2) = ((fi + 1) % 3, (fi + 2) % 3);
    let e1 = scale(axes[i1], box_half_extents[i1]);
    let e2 = scale(axes[i2], box_half_extents[i2]);
    let corners = [
        add(add(face_c, e1), e2),
        add(sub(face_c, e1), e2),
        sub(sub(face_c, e1), e2),
        sub(add(face_c, e1), e2),
    ];

    let mut emitted = 0usize;
    for c in corners.iter() {
        // Signed height above the triangle plane along the contact normal;
        // negative means penetrating, which is what the solver consumes.
        let sep = dot(tri_n, sub(*c, v0));
        if sep > contact_dist { continue; }
        if !point_over_triangle(*c, v0, v1, v2, tri_n) { continue; }
        out.push(GuTriContact {
            normal: single.normal,
            point: *c,
            separation: sep,
            triangle_index: tri_index,
        });
        emitted += 1;
    }

    // Box face wider than the triangle (or hanging off its edge): no corner sits
    // over it, so keep the deepest-point contact rather than dropping the pair.
    if emitted == 0 {
        out.push(single);
    }
}

/// Does `p`, projected along `n` onto the triangle's plane, lie inside it?
fn point_over_triangle(p: [f32; 3], v0: [f32; 3], v1: [f32; 3], v2: [f32; 3], n: [f32; 3]) -> bool {
    let proj = sub(p, scale(n, dot(n, sub(p, v0))));
    // Same-side test against each edge.
    let e0 = sub(v1, v0);
    let e1 = sub(v2, v1);
    let e2 = sub(v0, v2);
    let c0 = dot(cross(e0, sub(proj, v0)), n);
    let c1 = dot(cross(e1, sub(proj, v1)), n);
    let c2 = dot(cross(e2, sub(proj, v2)), n);
    (c0 >= 0.0 && c1 >= 0.0 && c2 >= 0.0) || (c0 <= 0.0 && c1 <= 0.0 && c2 <= 0.0)
}

fn test_axis(
    axis: [f32; 3],
    box_center: [f32; 3], box_half_extents: [f32; 3],
    box_axis_x: [f32; 3], box_axis_y: [f32; 3], box_axis_z: [f32; 3],
    v0: [f32; 3], v1: [f32; 3], v2: [f32; 3],
    best_overlap: &mut f32, best_axis: &mut [f32; 3], best_sign: &mut f32,
    contact_dist: f32,
) -> bool {
    let r = box_half_extents[0] * dot(box_axis_x, axis).abs()
          + box_half_extents[1] * dot(box_axis_y, axis).abs()
          + box_half_extents[2] * dot(box_axis_z, axis).abs();
    let box_c = dot(box_center, axis);
    let box_min = box_c - r;
    let box_max = box_c + r;

    let p0 = dot(v0, axis); let p1 = dot(v1, axis); let p2 = dot(v2, axis);
    let tri_min = p0.min(p1).min(p2);
    let tri_max = p0.max(p1).max(p2);

    if box_max + contact_dist < tri_min { return false; }
    if tri_max + contact_dist < box_min { return false; }

    let depth_a = box_max - tri_min;
    let depth_b = tri_max - box_min;
    let (depth, sign) = if depth_a < depth_b { (depth_a, -1.0f32) } else { (depth_b, 1.0f32) };
    if depth < *best_overlap {
        *best_overlap = depth;
        *best_axis = axis;
        *best_sign = sign;
    }
    true
}

// =============================================================================
//  High-level shape-vs-mesh contact driver
// =============================================================================

pub fn sphere_vs_mesh(
    mesh: &GuTriangleMesh,
    sphere_center: [f32; 3], sphere_radius: f32, contact_dist: f32,
) -> Vec<GuTriContact> {
    let mut out = Vec::new();
    let r = sphere_radius + contact_dist;
    let mn = [sphere_center[0] - r, sphere_center[1] - r, sphere_center[2] - r];
    let mx = [sphere_center[0] + r, sphere_center[1] + r, sphere_center[2] + r];
    struct Cb<'a> { center: [f32; 3], radius: f32, contact_dist: f32, out: &'a mut Vec<GuTriContact> }
    impl<'a> MeshHitCallback for Cb<'a> {
        fn process(&mut self, ti: u32, v0: [f32; 3], v1: [f32; 3], v2: [f32; 3]) -> bool {
            if let Some(c) = sphere_vs_triangle(self.center, self.radius, self.contact_dist, v0, v1, v2, ti) {
                self.out.push(c);
            }
            true
        }
    }
    midphase_intersect_aabb(mesh, mn, mx, &mut Cb { center: sphere_center, radius: sphere_radius, contact_dist, out: &mut out });
    out
}

pub fn capsule_vs_mesh(
    mesh: &GuTriangleMesh,
    p0: [f32; 3], p1: [f32; 3], radius: f32, contact_dist: f32,
) -> Vec<GuTriContact> {
    let mut out = Vec::new();
    let r = radius + contact_dist;
    let mn = [p0[0].min(p1[0]) - r, p0[1].min(p1[1]) - r, p0[2].min(p1[2]) - r];
    let mx = [p0[0].max(p1[0]) + r, p0[1].max(p1[1]) + r, p0[2].max(p1[2]) + r];
    struct Cb<'a> { p0: [f32; 3], p1: [f32; 3], radius: f32, contact_dist: f32, out: &'a mut Vec<GuTriContact> }
    impl<'a> MeshHitCallback for Cb<'a> {
        fn process(&mut self, ti: u32, v0: [f32; 3], v1: [f32; 3], v2: [f32; 3]) -> bool {
            if let Some(c) = capsule_vs_triangle(self.p0, self.p1, self.radius, self.contact_dist, v0, v1, v2, ti) {
                self.out.push(c);
            }
            true
        }
    }
    midphase_intersect_aabb(mesh, mn, mx, &mut Cb { p0, p1, radius, contact_dist, out: &mut out });
    out
}

pub fn box_vs_mesh(
    mesh: &GuTriangleMesh,
    box_center: [f32; 3], box_half_extents: [f32; 3],
    box_axis_x: [f32; 3], box_axis_y: [f32; 3], box_axis_z: [f32; 3],
    contact_dist: f32,
) -> Vec<GuTriContact> {
    let mut out = Vec::new();
    let ex = box_half_extents[0] * box_axis_x[0].abs() + box_half_extents[1] * box_axis_y[0].abs() + box_half_extents[2] * box_axis_z[0].abs();
    let ey = box_half_extents[0] * box_axis_x[1].abs() + box_half_extents[1] * box_axis_y[1].abs() + box_half_extents[2] * box_axis_z[1].abs();
    let ez = box_half_extents[0] * box_axis_x[2].abs() + box_half_extents[1] * box_axis_y[2].abs() + box_half_extents[2] * box_axis_z[2].abs();
    let pad = contact_dist;
    let mn = [box_center[0] - ex - pad, box_center[1] - ey - pad, box_center[2] - ez - pad];
    let mx = [box_center[0] + ex + pad, box_center[1] + ey + pad, box_center[2] + ez + pad];
    struct Cb<'a> { c: [f32;3], he: [f32;3], ax: [f32;3], ay: [f32;3], az: [f32;3], cd: f32, edges: &'a [u8], out: &'a mut Vec<GuTriContact> }
    impl<'a> MeshHitCallback for Cb<'a> {
        fn process(&mut self, ti: u32, v0: [f32; 3], v1: [f32; 3], v2: [f32; 3]) -> bool {
            // Manifold, not a single point — see box_vs_triangle_manifold.
            let mask = self.edges.get(ti as usize).copied().unwrap_or(0);
            box_vs_triangle_manifold(
                self.c, self.he, self.ax, self.ay, self.az, self.cd,
                v0, v1, v2, ti, mask, self.out,
            );
            true
        }
    }
    midphase_intersect_aabb(mesh, mn, mx, &mut Cb { c: box_center, he: box_half_extents, ax: box_axis_x, ay: box_axis_y, az: box_axis_z, cd: contact_dist, edges: &mesh.internal_edges, out: &mut out });
    out
}

/// Raycast against a triangle mesh — used by Lingo `getRayCastClosestShape`
/// when a #concaveShape body is in the scene. Returns (tri_index, t, point,
/// normal) for the closest hit, or None if no hit.
pub fn raycast_mesh(
    mesh: &GuTriangleMesh,
    ray_origin: [f32; 3], ray_dir: [f32; 3], max_t: f32,
) -> Option<(u32, f32, [f32; 3], [f32; 3])> {
    if mesh.nb_triangles() == 0 { return None; }
    struct Cb<'a> {
        mesh: &'a GuTriangleMesh,
        ray_origin: [f32; 3],
        ray_dir: [f32; 3],
        best_t: f32,
        best: Option<(u32, [f32; 3], [f32; 3])>,
    }
    impl<'a> RTreeRaycastCallback for Cb<'a> {
        fn process(&mut self, leaf_encoded: u32, max_t: &mut f32) -> bool {
            let lf = LeafTriangles { data: leaf_encoded | 1 };
            let first = lf.triangle_index();
            for k in 0..lf.nb_triangles() {
                let orig_tri = self.mesh.tree.tri_indices[(first + k) as usize];
                let (v0, v1, v2) = self.mesh.get_triangle(orig_tri);
                if let Some((t, n)) = ray_vs_triangle(self.ray_origin, self.ray_dir, v0, v1, v2, *max_t) {
                    if t < self.best_t {
                        self.best_t = t;
                        let p = [
                            self.ray_origin[0] + self.ray_dir[0] * t,
                            self.ray_origin[1] + self.ray_dir[1] * t,
                            self.ray_origin[2] + self.ray_dir[2] * t,
                        ];
                        self.best = Some((orig_tri, p, n));
                        *max_t = t;
                    }
                }
            }
            true
        }
    }
    let mut cb = Cb { mesh, ray_origin, ray_dir, best_t: max_t, best: None };
    mesh.tree.traverse_ray(ray_origin, ray_dir, max_t, &mut cb, [0.0; 3]);
    cb.best.map(|(t, p, n)| (t, cb.best_t, p, n))
}

/// Möller–Trumbore ray-vs-triangle intersection. Returns (t, normal) if
/// the ray hits the triangle within [0, max_t] from the front side.
fn ray_vs_triangle(
    origin: [f32; 3], dir: [f32; 3],
    v0: [f32; 3], v1: [f32; 3], v2: [f32; 3], max_t: f32,
) -> Option<(f32, [f32; 3])> {
    let e1 = sub(v1, v0);
    let e2 = sub(v2, v0);
    let p = cross(dir, e2);
    let det = dot(e1, p);
    if det.abs() < 1e-12 { return None; }
    let inv_det = 1.0 / det;
    let s = sub(origin, v0);
    let u = dot(s, p) * inv_det;
    if !(0.0..=1.0).contains(&u) { return None; }
    let q = cross(s, e1);
    let v = dot(dir, q) * inv_det;
    if v < 0.0 || u + v > 1.0 { return None; }
    let t = dot(e2, q) * inv_det;
    if t <= 0.0 || t > max_t { return None; }
    let n = normalize(cross(e1, e2));
    Some((t, n))
}
