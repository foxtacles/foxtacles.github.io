use std::collections::{HashMap, VecDeque};

use chrono::Local;

use crate::{
    CastMemberRef, director::{
        file::DirectorFile,
        lingo::datum::{Datum, datum_bool},
    }, player::{ColorRef, ScriptInstanceRef, symbols::{builtin::{self, BuiltInSymbol}, symbol::Symbol}}, reserve_player_mut, reserve_player_ref, utils::PATH_SEPARATOR
};

use super::{
    allocator::DatumAllocator, bitmap::manager::BitmapManager, cast_manager::CastManager,
    geometry::IntRect, net_manager::NetManager, score::Score, ScriptError, ScriptReceiver,
};

pub struct Movie {
    pub rect: IntRect,
    pub cast_manager: CastManager,
    pub score: Score,
    pub current_frame: u32,
    pub puppet_tempo: u32,
    pub random_seed: Option<i32>,
    pub exit_lock: bool,
    pub dir_version: u16,
    pub item_delimiter: char,
    pub alert_hook: Option<ScriptReceiver>,
    pub base_path: String,
    pub file_name: String,
    pub stage_color: (u8, u8, u8),
    pub stage_color_ref: ColorRef,
    pub frame_rate: u16,
    pub file: Option<DirectorFile>,
    pub update_lock: bool,
    pub mouse_down_script: Option<ScriptReceiver>,
    pub mouse_up_script: Option<ScriptReceiver>,
    pub key_down_script: Option<ScriptReceiver>,
    pub key_up_script: Option<ScriptReceiver>,
    pub timeout_script: Option<ScriptReceiver>,
    /// `the timeoutLength` — idle ticks (1/60 s) before a `timeOut` event fires.
    /// Director default is 10800 (3 min). See `check_global_timeout`.
    pub timeout_length: i32,
    /// `the timeoutMouse` / `timeoutKeyDown` — when TRUE (default), mouse / key
    /// activity resets the idle counter.
    pub timeout_mouse: bool,
    pub timeout_keydown: bool,
    /// Wall-clock ms of the last idle-counter reset (input activity or a fire).
    /// `the timeoutLapsed` is derived from this.
    pub timeout_last_reset_ms: f64,
    pub allow_custom_caching: bool,
    pub trace_script: bool,
    pub trace_log_file: String,
    pub debug_playback_enabled: bool,
    /// `_player.emulateMultibuttonMouse` — "determines whether a movie
    /// interprets a mouse click with the Control key pressed on the Mac the
    /// same as a right mouse click in Windows (TRUE) or not (FALSE, default).
    /// Read/write." (Director 11.5 Scripting Dictionary.) It gates nothing
    /// off the Mac: `rightMouseDown` / `rightMouseUp` already fire from a real
    /// right button everywhere else, and the docs are explicit that the flag
    /// only decides whether Ctrl+click ALSO raises them on the Mac. Stored for
    /// round-trip read/write, like `edit_shortcuts_enabled`.
    pub emulate_multibutton_mouse: bool,
    /// `the editShortCutsEnabled` — when FALSE, the player disables built-in
    /// cut/copy/paste keyboard shortcuts. Web player has no native edit menu,
    /// so this is stored for round-trip read/write but has no side effect.
    /// Default TRUE for movies authored in Director 8+ (Scripting Dict p.890).
    pub edit_shortcuts_enabled: bool,
    /// `the enableFlashLingo` — Director movie property (Scripting Dict p.897).
    /// Gates whether a Flash sprite may run Lingo via Flash's `getURL()` (the
    /// `lingo:` / `event:` schemes); default FALSE for movies of unknown origin.
    /// We store it for round-trip read/write ONLY and DO NOT gate the actual
    /// callback dispatch on it: real movies fire `event:`/`lingo:` without ever
    /// setting this property, so honoring it as a hard gate would break them
    /// (see [[flash-lingo-geturl-scheme]]). dirplayer always allows the callback.
    pub enable_flash_lingo: bool,
    pub mouse_down: bool,
    /// Tracks the right mouse button independently of `mouse_down` — set by
    /// `right_mouse_down(x, y)` / `right_mouse_up(x, y)` from the JS host.
    /// Read by `the rightMouseDown` / `the rightMouseUp`.
    pub right_mouse_down: bool,
    pub click_loc: (i32, i32),
    pub frame_script_instance: Option<ScriptInstanceRef>,
    pub frame_script_member: Option<CastMemberRef>,
    /// Start frame of the channel-0 (frame-script) SPAN the cached instance was
    /// created for. The same behavior member can appear in several consecutive
    /// spans with DIFFERENT parameters (e.g. the Game Loop dropped on the intro
    /// frames as `#Nonlooping` and on the gameplay frames as `#CostumeChange`);
    /// the instance must be recreated (and its params re-applied) when the span
    /// changes, not only when the member changes — otherwise the gameplay span
    /// inherits the intro span's stale `pType`.
    pub frame_script_span_start: Option<u32>,
    pub sound_device: String,
}

impl Movie {
    /// Construct an empty movie with default state (no cast/score loaded).
    /// Used for the player's primary movie and for nested linked-movie
    /// (`#movie`) playback, which builds a second Movie from the linked .dcr
    /// and drives it through the same engine.
    pub fn empty() -> Self {
        Movie {
            rect: IntRect::from(0, 0, 0, 0),
            cast_manager: CastManager::empty(),
            score: Score::empty(),
            current_frame: 1,
            puppet_tempo: 0,
            random_seed: None,
            exit_lock: false,
            dir_version: 0,
            item_delimiter: ',',
            alert_hook: None,
            base_path: "".to_string(),
            file_name: "".to_string(),
            stage_color: (255, 255, 255),
            stage_color_ref: ColorRef::PaletteIndex(255),
            frame_rate: 30,
            file: None,
            update_lock: false,
            mouse_down_script: None,
            mouse_up_script: None,
            key_down_script: None,
            key_up_script: None,
            timeout_script: None,
            timeout_length: 10800,
            timeout_mouse: true,
            timeout_keydown: true,
            timeout_last_reset_ms: 0.0,
            allow_custom_caching: false,
            trace_script: false,
            trace_log_file: String::new(),
            debug_playback_enabled: false,
            emulate_multibutton_mouse: false,
            edit_shortcuts_enabled: true,
            enable_flash_lingo: false,
            mouse_down: false,
            right_mouse_down: false,
            click_loc: (0, 0),
            frame_script_instance: None,
            frame_script_member: None,
            frame_script_span_start: None,
            sound_device: String::new(),
        }
    }

    pub async fn load_from_file(
        &mut self,
        file: DirectorFile,
        net_manager: &mut NetManager,
        bitmap_manager: &mut BitmapManager,
        dir_cache: &mut HashMap<Box<str>, DirectorFile>,
    ) {
        self.dir_version = file.version;
        // Determine stage color based on Director version and color mode
        let stage_color_ref = if self.dir_version < 700 {
            // Director 6 and below: always palette index
            ColorRef::PaletteIndex(file.config.pre_d7_stage_color as u8)
        } else {
            // Director 7+: check is_rgb flag
            if file.config.d7_stage_color_is_rgb != 0 {
                // RGB mode
                ColorRef::Rgb(
                    file.config.d7_stage_color_r,
                    file.config.d7_stage_color_g,
                    file.config.d7_stage_color_b,
                )
            } else {
                // Palette index mode (index stored in d7_stage_color_r)
                ColorRef::PaletteIndex(file.config.d7_stage_color_r)
            }
        };
        
        // Store as RGB tuple for backward compatibility (if needed elsewhere)
        self.stage_color = (
            file.config.d7_stage_color_r,
            file.config.d7_stage_color_g,
            file.config.d7_stage_color_b,
        );

        self.base_path = file.base_path.to_string();
        self.rect = IntRect {
            left: file.config.movie_left as i32,
            top: file.config.movie_top as i32,
            right: file.config.movie_right as i32,
            bottom: file.config.movie_bottom as i32,
        };
        self.cast_manager
            .load_from_dir(&file, net_manager, bitmap_manager, dir_cache)
            .await;
        self.score.load_from_dir(&file);
        self.file_name = file.file_name.to_string();
        self.frame_rate = file.config.frame_rate;
        self.file = Some(file);

        // Store the resolved color reference
        self.stage_color_ref = stage_color_ref;
    }

    pub fn get_prop(&self, prop: Symbol) -> Result<Datum, ScriptError> {
        let builtin_prop = prop.into_builtin_or_error()?;
        match builtin_prop {
            BuiltInSymbol::AlertHook => match self.alert_hook.to_owned() {
                Some(ScriptReceiver::Script(script_ref)) => Ok(Datum::ScriptRef(script_ref)),
                Some(ScriptReceiver::ScriptInstance(script_instance_id)) => {
                    Ok(Datum::ScriptInstanceRef(script_instance_id))
                }
                Some(ScriptReceiver::ScriptText(text)) => Ok(Datum::String(text)),
                None => Ok(Datum::Int(0)),
            },
            BuiltInSymbol::ExitLock => Ok(datum_bool(self.exit_lock)),
            BuiltInSymbol::ItemDelimiter => Ok(Datum::String(self.item_delimiter.into())),
            BuiltInSymbol::RunMode => Ok(Datum::String("Plugin".to_string())), // Plugin / Author
            BuiltInSymbol::Date | BuiltInSymbol::ShortDate | BuiltInSymbol::AbbrDate | BuiltInSymbol::LongDate => {
                // TODO localize formatting
                let time = Local::now();
                let format = match builtin_prop {
                    BuiltInSymbol::AbbrDate => "%a, %b %-d, %Y",
                    BuiltInSymbol::LongDate => "%A, %B %-d, %Y",
                    _ => "%-m/%-d/%Y",
                };
                let formatted = time.format(format).to_string();
                Ok(Datum::String(formatted))
            },
            BuiltInSymbol::ShortTime | BuiltInSymbol::AbbrTime | BuiltInSymbol::LongTime => {
                let time = Local::now();
                let format = if builtin_prop == BuiltInSymbol::LongTime { "%I:%M:%S %p" } else { "%I:%M %p" };
                let formatted = time.format(format).to_string();
                Ok(Datum::String(formatted))
            },
            BuiltInSymbol::LastChannel => Ok(Datum::Int(self.score.get_channel_count() as i32)),
            // Movie property, read-only: the number of the last frame in the movie.
            // A score always has at least frame 1, so fall back to 1 rather than 0
            // when the frame count couldn't be determined.
            BuiltInSymbol::LastFrame => Ok(Datum::Int(self.score.frame_count.unwrap_or(1).max(1) as i32)),
            BuiltInSymbol::MoviePath => {
                let mut result = self.base_path.clone();
                if !result.is_empty() && !result.ends_with(PATH_SEPARATOR) {
                    result.push_str(PATH_SEPARATOR);
                }
                Ok(Datum::String(result))
            },
            BuiltInSymbol::Platform => Ok(Datum::String("Windows,32".to_string())),
            BuiltInSymbol::Frame => Ok(Datum::Int(self.current_frame as i32)),
            BuiltInSymbol::ProductVersion => Ok(Datum::String("11.0".to_string())),
            // `_movie.name` is the Movie object's form of `the movieName` — the
            // Director 11.5 Scripting Dictionary uses it directly in its Window
            // examples (`put("Just moved window containing" && _movie.name)`).
            // AreaZero's `[M] Main.InitGlobals` builds its asset base with
            // `gSystem.path & _movie.name`, and without the alias that raised
            // "Cannot get movie prop name".
            BuiltInSymbol::MovieName | BuiltInSymbol::Movie | BuiltInSymbol::Name => Ok(Datum::String(self.file_name.to_owned())),
            BuiltInSymbol::UpdateLock => Ok(Datum::Int(if self.update_lock { 1 } else { 0 })),
            BuiltInSymbol::Path => Ok(Datum::String(self.base_path.to_owned())),
            BuiltInSymbol::MouseDownScript | BuiltInSymbol::MouseUpScript | BuiltInSymbol::KeyDownScript | BuiltInSymbol::KeyUpScript | BuiltInSymbol::TimeoutScript => {
                let script = if prop.eq_ignore_ascii_case("mouseDownScript") {
                    &self.mouse_down_script
                } else if builtin_prop == BuiltInSymbol::MouseUpScript {
                    &self.mouse_up_script
                } else if builtin_prop == BuiltInSymbol::KeyDownScript {
                    &self.key_down_script
                } else if builtin_prop == BuiltInSymbol::KeyUpScript {
                    &self.key_up_script
                } else {
                    &self.timeout_script
                };
                match script.to_owned() {
                    Some(ScriptReceiver::Script(script_ref)) => Ok(Datum::ScriptRef(script_ref)),
                    Some(ScriptReceiver::ScriptInstance(id)) => Ok(Datum::ScriptInstanceRef(id)),
                    Some(ScriptReceiver::ScriptText(text)) => Ok(Datum::String(text)),
                    None => Ok(Datum::Int(0)),
                }
            },
            BuiltInSymbol::AllowCustomCaching => Ok(datum_bool(self.allow_custom_caching)),
            BuiltInSymbol::Timer => {
                reserve_player_ref(|player| {
                    // Utc: identical difference, without re-resolving the local
                    // timezone offset on every call (see `the milliSeconds`).
                    let elapsed = chrono::Utc::now().timestamp_millis()
                        - player.start_time.timestamp_millis();
                    // Convert to ticks (60ths of a second)
                    let ticks = (elapsed * 60) / 1000;
                    Ok(Datum::Int(ticks as i32))
                })
            },
            BuiltInSymbol::LastKey => {
                // `the lastKey` returns ticks (1/60 s) since the last key event.
                // Before any key is pressed, fall back to ticks since movie start
                // (matches Director's monotonic behaviour for these accessors).
                reserve_player_ref(|player| {
                    let reference = player
                        .keyboard_manager
                        .last_key_time
                        .unwrap_or(player.start_time);
                    let elapsed = chrono::Utc::now().timestamp_millis()
                        - reference.timestamp_millis();
                    let ticks = (elapsed * 60) / 1000;
                    Ok(Datum::Int(ticks as i32))
                })
            },
            BuiltInSymbol::MouseDown => {
                Ok(datum_bool(self.mouse_down))
            },
            // `the mouseUp` is the inverse of `the mouseDown` — true while
            // the mouse button is in the up (released) state. Director uses
            // this in per-frame polling like storyscramble's Draggable
            // behavior (`if the mouseUp then …`) to detect button release.
            BuiltInSymbol::MouseUp => {
                Ok(datum_bool(!self.mouse_down))
            },
            BuiltInSymbol::RightMouseDown => Ok(datum_bool(self.right_mouse_down)),
            BuiltInSymbol::RightMouseUp => Ok(datum_bool(!self.right_mouse_down)),
            // `the trace` toggles the same Lingo-tracing facility as the Trace
            // button / `the traceScript` (Director 11.5 Scripting Dictionary).
            BuiltInSymbol::Trace | BuiltInSymbol::TraceScript => Ok(datum_bool(self.trace_script)),
            BuiltInSymbol::ActiveWindow => Ok(Datum::Stage),
            // `the frontWindow` — "indicates which movie in a window (MIAW) is
            // currently frontmost on the screen… When the Stage is frontmost,
            // frontWindow is the Stage" (Director 11.5 Scripting Dictionary,
            // Player property, read-only). It returns VOID only when a media
            // editor or floating palette is frontmost, neither of which exists
            // outside the authoring environment. dirplayer has no MIAW support,
            // so the Stage is always frontmost — same reasoning as
            // `the activeWindow` above.
            //
            // Merlin's Revenge gates all mouse input on it: its `on int`
            // handler does
            //   clickedWindow = (the windowList).getPos(the frontWindow)
            //   if clickedWindow = winnum then Active = 1
            // and with an empty windowList both sides are 0, so the click is
            // accepted. Erroring here aborted the handler and the game took no
            // input at all.
            BuiltInSymbol::FrontWindow => Ok(Datum::Stage),
            // `the windowList` is the Player property listing all open
            // movie-in-a-window (MIAW) windows (Director 11.5 Scripting
            // Dictionary). dirplayer has no MIAW support, so it's always empty —
            // `count(the windowList)` is then 0, matching a player with only the
            // Stage open.
            BuiltInSymbol::WindowList => Ok(Datum::List(
                crate::director::lingo::datum::DatumType::List,
                VecDeque::new(),
                false,
            )),
            BuiltInSymbol::Rollover => {
                reserve_player_ref(|player| {
                    let sprite = super::score::get_sprite_at(player, player.mouse_loc.0, player.mouse_loc.1, false);
                    Ok(Datum::Int(sprite.unwrap_or(0) as i32))
                })
            },
            BuiltInSymbol::RandomSeed => Ok(Datum::Int(self.random_seed.unwrap_or(0))),
            BuiltInSymbol::MaxInteger => Ok(Datum::Int(i32::MAX)),
            BuiltInSymbol::MemorySize => Ok(Datum::Int(256 * 1024 * 1024)), // 256 MB
            // Memory-reporting companions to `the memorySize`, in bytes.
            //   freeBytes  — total free memory, not necessarily contiguous
            //   freeBlock  — the largest free CONTIGUOUS block
            // (Director 11.5 Scripting Dictionary, pp. 364-365.) Movies use
            // these to gate on minimum requirements — Heatwave Racing's
            // `getspec` frame script does
            //   tmemfree = the freeBytes / 1024 / 1024
            // — so returning nothing aborts the handler. There is no such
            // budget in a browser: the WASM heap grows on demand and no API
            // exposes a figure comparable to a Director partition. Report a
            // plausible amount of the 256 MB we claim for memorySize, with
            // freeBlock <= freeBytes as the spec requires ("differs from
            // freeBlock in that it reports ALL free memory"), so requirement
            // checks pass instead of failing on a fabricated shortage.
            BuiltInSymbol::FreeBytes => Ok(Datum::Int(192 * 1024 * 1024)),
            BuiltInSymbol::FreeBlock => Ok(Datum::Int(128 * 1024 * 1024)),
            // `_system.colorDepth` — monitor color depth (Director 11.5
            // Scripting Dictionary, valid values 1/2/4/8/16/32). The web
            // canvas is true-color, so report 32. Setting it is a no-op
            // (see set_prop), matching a monitor that can't change depth.
            BuiltInSymbol::ColorDepth => Ok(Datum::Int(32)),
            // A SYMBOL, per the Scripting Dictionary: "The possible values of the
            // active3dRenderer property are #openGL, #directX7_0, #directx9,
            // #directX5_2, and #software". Returning the string "#openGL" made
            // `_movie.active3dRenderer = #openGL` compare false, so AreaZero's
            // `[M] 3D Shaders` BlendShader took its DirectX branch and built the
            // additive material with THREE stacked copies of the same texture
            // instead of the two-layer OpenGL form.
            BuiltInSymbol::Active3dRenderer => Ok(Datum::Symbol(Symbol::from_str("openGL"))),
            BuiltInSymbol::ScriptExecutionStyle => Ok(Datum::Int(9)),
            BuiltInSymbol::XtraList => {
                // Return a list of prop lists, each with #name and #fileName
                use crate::player::xtra::manager::get_registered_xtra_names;
                reserve_player_mut(|player| {
                    let names = get_registered_xtra_names();
                    let mut items = VecDeque::new();
                    for name in names {
                        let name_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::Name)));
                        let name_val = player.alloc_datum(Datum::String(name.to_string()));
                        let file_key = player.alloc_datum(Datum::Symbol(Symbol::builtin(BuiltInSymbol::FileName)));
                        let file_val = player.alloc_datum(Datum::String(format!("{}.x32", name)));
                        let entry = player.alloc_datum(Datum::PropList(VecDeque::from(vec![
                            (name_key, name_val), (file_key, file_val),
                        ]), false));
                        items.push_back(entry);
                    }
                    Ok(Datum::List(
                        crate::director::lingo::datum::DatumType::List,
                        items,
                        false,
                    ))
                })
            },
            BuiltInSymbol::SoundDevice => Ok(Datum::String(if self.sound_device.is_empty() { "DirectSound".to_string() } else { self.sound_device.clone() })),
            BuiltInSymbol::SoundDeviceList => {
                reserve_player_mut(|player| {
                    let device = player.alloc_datum(Datum::String("WebAudio".to_string()));
                    Ok(Datum::List(
                        crate::director::lingo::datum::DatumType::List,
                        VecDeque::from(vec![device]),
                        false,
                    ))
                })
            },
            BuiltInSymbol::DesktopRectList => {
                reserve_player_mut(|player| {
                    let w = player.movie.rect.right as i32;
                    let h = player.movie.rect.bottom as i32;
                    let rect = player.alloc_datum(Datum::Rect([0.0, 0.0, w as f64, h as f64], 0));
                    Ok(Datum::List(
                        crate::director::lingo::datum::DatumType::List,
                        VecDeque::from(vec![rect]),
                        false,
                    ))
                })
            },
            BuiltInSymbol::LabelList => {
                // Director's `the labelList` ends each label (including the
                // last) with a `\r`, so `the number of lines in the labelList`
                // returns label_count + 1 — script idioms like
                //   numMarkers = the number of lines in the labelList
                //   repeat with i = 1 to numMarkers
                //     L = (the labelList).line[i]
                //     ...
                // expect the trailing empty line to be present (the last
                // iteration sees L = "") so downstream lists end with the
                // same shape they would in Director.
                let mut s = String::new();
                for fl in &self.score.frame_labels {
                    s.push_str(&fl.label);
                    s.push('\r');
                }
                Ok(Datum::String(s))
            },
            BuiltInSymbol::DebugPlaybackEnabled => Ok(datum_bool(self.debug_playback_enabled)),
            BuiltInSymbol::EmulateMultibuttonMouse => Ok(datum_bool(self.emulate_multibutton_mouse)),
            BuiltInSymbol::EditShortcutsEnabled => Ok(datum_bool(self.edit_shortcuts_enabled)),
            BuiltInSymbol::EnableFlashLingo => Ok(datum_bool(self.enable_flash_lingo)),
            // No-op system prop: nothing to preload-abort in dirplayer.
            // Return the Director default (FALSE) so read-backs don't error.
            BuiltInSymbol::PreLoadEventAbort => Ok(datum_bool(false)),
            // soundMixMedia (Sound property, read/write) — Flash sound mixing is a
            // Windows-only nuance we don't model. Return the Director 7+ default (TRUE).
            BuiltInSymbol::SoundMixMedia => Ok(datum_bool(true)),
            // machineType (classic Director system property, absent from the 11.5
            // dictionary): a Macintosh model code, or 256 on Windows/Intel. dirplayer
            // emulates Windows Shockwave playback, so report 256 — movies branch their
            // path separators and platform paths on this.
            BuiltInSymbol::MachineType => Ok(Datum::Int(256)),
            _ => Err(ScriptError::new(format!("Cannot get movie prop {prop}")))
        }
    }

    pub fn set_prop(
        &mut self,
        prop: Symbol,
        value: Datum,
        datums: &DatumAllocator,
    ) -> Result<(), ScriptError> {
        let builtin_prop = prop.into_builtin_or_error()?;
        match builtin_prop {
            BuiltInSymbol::ExitLock => {
                self.exit_lock = value.int_value()? == 1;
                Ok(())
            },
            BuiltInSymbol::ItemDelimiter => {
                self.item_delimiter = (value.string_value()?).chars().next().unwrap();
                Ok(())
            },
            BuiltInSymbol::DebugPlaybackEnabled => {
                self.debug_playback_enabled = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::EmulateMultibuttonMouse => {
                self.emulate_multibutton_mouse = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::EditShortcutsEnabled => {
                self.edit_shortcuts_enabled = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::EnableFlashLingo => {
                // Store the flag for read-back; does NOT restrict Flash->Lingo
                // callbacks (see field comment). Round-trip only.
                self.enable_flash_lingo = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::AlertHook => {
                match value {
                    Datum::Int(0) => {
                        self.alert_hook = None;
                        Ok(())
                    }
                    Datum::ScriptRef(script_ref) => {
                        self.alert_hook = Some(ScriptReceiver::Script(script_ref));
                        Ok(())
                    }
                    Datum::ScriptInstanceRef(script_instance_id) => {
                        self.alert_hook = Some(ScriptReceiver::ScriptInstance(script_instance_id));
                        Ok(())
                    }
                    _ => Err(ScriptError::new(
                        "Object or 0 expected for alertHook value".to_string(),
                    )),
                }
            },
            // `the trace` is an alias for the Trace-button / `the traceScript`
            // tracing toggle (Director 11.5 Scripting Dictionary).
            BuiltInSymbol::Trace | BuiltInSymbol::TraceScript => {
                self.trace_script = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::TraceLogFile => {
                self.trace_log_file = value.string_value()?;
                Ok(())
            },
            BuiltInSymbol::UpdateLock => {
                self.update_lock = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::MouseDownScript | BuiltInSymbol::MouseUpScript | BuiltInSymbol::KeyDownScript | BuiltInSymbol::KeyUpScript | BuiltInSymbol::TimeoutScript => {
                let target = if builtin_prop == BuiltInSymbol::MouseDownScript {
                    &mut self.mouse_down_script
                } else if builtin_prop == BuiltInSymbol::MouseUpScript {
                    &mut self.mouse_up_script
                } else if builtin_prop == BuiltInSymbol::KeyDownScript {
                    &mut self.key_down_script
                } else if builtin_prop == BuiltInSymbol::KeyUpScript {
                    &mut self.key_up_script
                } else {
                    &mut self.timeout_script
                };
                match value {
                    Datum::Int(0) | Datum::Void => {
                        *target = None;
                        Ok(())
                    }
                    Datum::String(script_text) => {
                        if script_text.is_empty() {
                            *target = None;
                        } else {
                            *target = Some(ScriptReceiver::ScriptText(script_text));
                        }
                        Ok(())
                    }
                    Datum::ScriptRef(script_ref) => {
                        *target = Some(ScriptReceiver::Script(script_ref));
                        Ok(())
                    }
                    Datum::ScriptInstanceRef(script_instance_id) => {
                        *target = Some(ScriptReceiver::ScriptInstance(script_instance_id));
                        Ok(())
                    }
                    _ => Err(ScriptError::new(
                        format!("String, object or 0 expected for {} value", prop),
                    )),
                }
            },
            BuiltInSymbol::AllowCustomCaching => {
                self.allow_custom_caching = value.int_value()? != 0;
                Ok(())
            },
            BuiltInSymbol::PuppetTempo => {
                self.puppet_tempo = value.int_value()? as u32;
                Ok(())
            },
            BuiltInSymbol::ColorDepth | BuiltInSymbol::UseFastQuads | BuiltInSymbol::RomanLingo | BuiltInSymbol::AllowSaveLocal | BuiltInSymbol::CpuHogTicks
            | BuiltInSymbol::PreLoadEventAbort => {
                // Read-only / no-op in practice; ignore sets like Director does.
                // preLoadEventAbort gates whether a preload event handler may
                // abort preloading — dirplayer loads synchronously, so there
                // is nothing to abort (netjack's startMovie sets it).
                Ok(())
            },
            BuiltInSymbol::StageColor => {
                match value {
                    Datum::Int(color_index) => {
                        self.stage_color_ref = ColorRef::PaletteIndex(color_index as u8);
                        Ok(())
                    }
                    Datum::ColorRef(color_ref) => {
                        self.stage_color_ref = color_ref;
                        Ok(())
                    }
                    _ => {
                        Err(ScriptError::new("Integer color index expected for stageColor".to_string()))
                    }
                }
            },
            BuiltInSymbol::TimeoutLength => {
                // Idle ticks before `timeOut`. Restart the idle counter so the
                // countdown runs from now (the movie usually sets this right after
                // the activity that should trigger the eventual timeout).
                self.timeout_length = value.int_value()?;
                self.timeout_last_reset_ms = crate::player::testing_shared::now_ms();
                Ok(())
            },
            BuiltInSymbol::TimeoutMouse => { self.timeout_mouse = value.int_value()? != 0; Ok(()) },
            BuiltInSymbol::TimeoutKeyDown => { self.timeout_keydown = value.int_value()? != 0; Ok(()) },
            BuiltInSymbol::TimeoutLapsed => {
                // Writable: `set the timeoutLapsed` re-bases the idle counter.
                let ticks = value.int_value()? as f64;
                self.timeout_last_reset_ms =
                    crate::player::testing_shared::now_ms() - ticks * (1000.0 / 60.0);
                Ok(())
            },
            BuiltInSymbol::TimeoutPlay
            | BuiltInSymbol::SoundEnabled | BuiltInSymbol::SoundLevel
            | BuiltInSymbol::BeepOn | BuiltInSymbol::CenterStage | BuiltInSymbol::ExitLock | BuiltInSymbol::FixStageSize
            // soundMixMedia (Director 11.5 Scripting Dictionary: Sound property,
            // read/write) toggles whether Flash cast members mix their audio into the
            // Score sound channels — a Windows-only playback nuance. dirplayer uses
            // WebAudio, so we accept the set without acting on it.
            | BuiltInSymbol::SoundMixMedia => {
                // Anim props that are set via property_type 0x07 - accept silently
                Ok(())
            },
            BuiltInSymbol::RandomSeed => {
                self.random_seed = Some(value.int_value()?);
                Ok(())
            },
            BuiltInSymbol::SoundDevice => {
                // Accept the sound device setting (DirectSound, MacroMix, QT3Mix, etc.)
                // In WASM we use WebAudio, so this is stored but not acted upon
                self.sound_device = value.string_value().unwrap_or_default();
                Ok(())
            },
            BuiltInSymbol::Preferred3dRenderer | BuiltInSymbol::MilesFast => {
                // 3D renderer preference / sound settings — accept silently in WASM
                Ok(())
            },
            _ => Err(ScriptError::new(format!("Cannot set movie prop {prop}")))
        }
    }

    /// Get the current effective tempo (puppetTempo overrides frameTempo)
    pub fn get_effective_tempo(&self) -> u32 {
        if self.puppet_tempo > 0 {
            self.puppet_tempo
        } else {
            // Get tempo from current frame, or fall back to movie frame_rate
            self.score.get_frame_tempo(self.current_frame)
                .unwrap_or(self.frame_rate as u32)
        }
    }
    
    /// Calculate frame delay in milliseconds based on tempo
    pub fn get_frame_delay_ms(&self) -> f64 {
        let tempo = self.get_effective_tempo();
        if tempo == 0 {
            return 1000.0 / 30.0; // Default to 30fps if tempo is 0
        }
        
        // Director tempo: frames per second
        // So delay = 1000ms / tempo
        1000.0 / tempo as f64
    }

    pub fn next_random_int(&mut self, max: i32) -> Option<i32> {
        let seed = self.random_seed?;
        let seed_u32 = seed as u32;

        // Note: This does not match the Director implementation exactly - there is no public knowledge of the seed algorithm.
        let next_seed = seed_u32.wrapping_mul(214013).wrapping_add(2531011);
        self.random_seed = Some(next_seed as i32);
        let value = (next_seed % (max as u32)) as i32 + 1;
        Some(value)
    }
}
