import { initPolyfill } from './core';
import { getEmbeddedWasmUrl, getEmbeddedFontUrl } from './embedded-loader';
import { loadDefaultXtraRegistry, setXtraHostBase } from 'dirplayer-js-api';

declare const DIRPLAYER_VERSION: string;

// Lightweight config interface — must NOT import from flashPlayerManager.ts
// to avoid pulling in its side effects (fetch intercept, WebGL patch)
// which would collide with the main app's copy.
interface FlashConfig {
  socketProxy?: Array<{host: string, port: number, proxyUrl: string}>;
  fetchRewriteRules?: Array<{pathPrefix: string, targetHost: string, targetPort: string, targetProtocol: string}>;
  renderer?: string;
  logLevel?: string;
  /** When true, skip Ruffle entirely. Lingo Flash calls become no-ops. */
  disableFlash?: boolean;
}

function configureFlash(partial: FlashConfig): void {
  const win = window as any;
  const existing = win.__dirplayerFlashConfig || {};
  win.__dirplayerFlashConfig = { ...existing, ...partial };

  // Set up the global socket URL resolver for the Multiuser Xtra (WASM side)
  if (partial.socketProxy && partial.socketProxy.length > 0) {
    win.dirplayerResolveSocketUrl = (host: string, port: number): string => {
      for (const entry of partial.socketProxy!) {
        if (entry.host === host && entry.port === port) {
          return entry.proxyUrl;
        }
      }
      return '';
    };
  }
}

declare global {
  interface Window {
    DirPlayer: {
      init: () => void;
      configureFlash: (config: FlashConfig) => void;
    };
    RufflePlayer: any;
  }
}

/**
 * Resolve the base URL of the polyfill script itself,
 * so we can load sibling assets (like ruffle/) relative to it.
 */
const polyfillScript = document.currentScript as HTMLScriptElement | null;
function getPolyfillBaseUrl(): string {
  if (polyfillScript?.src) {
    return polyfillScript.src.substring(0, polyfillScript.src.lastIndexOf('/') + 1);
  }
  return '';
}

/**
 * Load Ruffle by injecting a <script> tag for ruffle/dirplayer_ruffle.js
 * relative to the polyfill script's location. The loader file is renamed
 * (from upstream's `ruffle.js`) so the fork doesn't collide with stock
 * Ruffle if both bundles are on the same page (e.g. via a browser
 * extension that ships its own ruffle.js).
 *
 * Skips if dirplayer's Ruffle fork is already on window. The fork
 * namespaces its global as `dirplayer_RufflePlayer` so it doesn't collide
 * with stock Ruffle.
 */
function loadRuffle(): Promise<void> {
  const win = window as any;
  if (win.dirplayer_RufflePlayer?.newest) {
    return Promise.resolve();
  }

  // Check for a custom ruffle URL on the script tag: data-ruffle-url="..."
  const customUrl = polyfillScript?.getAttribute('data-ruffle-url');
  const ruffleUrl = customUrl || (getPolyfillBaseUrl() + 'ruffle/dirplayer_ruffle.js');

  // Set up dirplayer_RufflePlayer config before the script loads
  win.dirplayer_RufflePlayer = win.dirplayer_RufflePlayer || {};
  win.dirplayer_RufflePlayer.config = {
    ...(win.dirplayer_RufflePlayer.config || {}),
    allowNetworking: 'all',
  };

  return new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = ruffleUrl;
    script.onload = () => resolve();
    script.onerror = () => {
      console.warn(`[DirPlayer] Failed to load Ruffle from ${ruffleUrl} — Flash content will not work`);
      resolve(); // Don't block dirplayer init if Ruffle fails
    };
    document.head.appendChild(script);
  });
}

function init() {
  // Tell the xtra plugin loader where xtras live for THIS deployment.
  //
  // Resolution order:
  //   1. `data-xtra-host-base="..."` attribute on the polyfill <script>
  //      tag. Lets embedders point at a CDN / sibling path / different
  //      origin without touching JS. Both absolute URLs and paths
  //      resolved against the embedding page work. Trailing slash is
  //      not required — the resolver absolutifies via `new URL()`.
  //   2. The polyfill script's own base URL (where dirplayer-polyfill.js
  //      was loaded from). The common case: ship xtras + registry next
  //      to the bundle.
  //
  // Registry / loadExternalXtra URLs prefixed with "~/" then resolve to
  // <host-base>/... — `~/foo.wasm` and the default `~/xtra-registry.json`
  // both route through this same base.
  const customHostBase = polyfillScript?.getAttribute('data-xtra-host-base');
  const polyfillBase = getPolyfillBaseUrl();
  const xtraHostBase = customHostBase || polyfillBase;
  if (xtraHostBase) {
    setXtraHostBase(xtraHostBase);
    // Optional override for the registry JSON path. Defaults to
    // ~/xtra-registry.json (i.e. <host-base>/xtra-registry.json) when
    // the attribute is absent. The override accepts any form
    // _resolveXtraUrl understands — `~/foo.json`, `/foo.json`, or a
    // full absolute URL — so a deployment can pin the registry at a
    // different path / CDN than the wasms themselves.
    const customRegistryUrl = polyfillScript?.getAttribute('data-xtra-registry-url');
    // Fire-and-forget: the registry merges in as soon as the JSON
    // arrives; movies started after that pick up the entries. The
    // alternative (awaiting here) would delay polyfill init for one
    // round-trip on every page load, even when there are no xtras.
    loadDefaultXtraRegistry(customRegistryUrl || undefined);
  }

  const disableFlash = polyfillScript?.hasAttribute('data-disable-flash') ?? false;
  if (disableFlash) {
    const win = window as any;
    win.__dirplayerFlashConfig = {
      ...(win.__dirplayerFlashConfig || {}),
      disableFlash: true,
    };
    console.log('[DirPlayer] data-disable-flash set — skipping Ruffle. Lingo Flash calls will no-op.');
  }

  const requireClick = polyfillScript?.hasAttribute('data-require-click') ?? false;
  const config = {
    wasmUrl: getEmbeddedWasmUrl(),
    systemFontUrl: getEmbeddedFontUrl(),
    requireClickToPlay: requireClick,
  };

  // Register ownership SYNCHRONOUSLY, before any async work (like loadRuffle).
  // This ensures the extension's MutationObserver sees ATTR_SOURCE='polyfill'
  // before the page appends embed/object elements, so it yields immediately.
  initPolyfill(config, DIRPLAYER_VERSION, 'polyfill');

  // Load Ruffle in the background — it will be ready by the time any Flash
  // content inside a Director movie actually needs to play.
  if (!disableFlash) {
    loadRuffle();
  }
}

// Expose the API globally
window.DirPlayer = {
  init,
  configureFlash,
};

// Auto-initialize unless data-manual-init is present on the script tag
if (!polyfillScript?.hasAttribute('data-manual-init')) {
  init();
}
